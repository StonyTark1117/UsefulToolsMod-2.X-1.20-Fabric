package com.stonytark.usefultoolsmod.util;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModTags {
    public static class Blocks {
        public static class_6862<class_2248> NEEDS_RGOLD_TOOL = createTag("needs_rgold_tool");
        public static class_6862<class_2248> INCORRECT_RGOLD_TOOL = createTag("incorrect_rgold_tool");
        public static class_6862<class_2248> NEEDS_RLAPIS_TOOL = createTag("needs_rlapis_tool");
        public static class_6862<class_2248> INCORRECT_RLAPIS_TOOL = createTag("incorrect_rlapis_tool");
        public static class_6862<class_2248> NEEDS_HRED_TOOL = createTag("needs_hred_tool");
        public static class_6862<class_2248> INCORRECT_HRED_TOOL = createTag("incorrect_hred_tool");
        public static class_6862<class_2248> NEEDS_JEM_TOOL = createTag("needs_jem_tool");
        public static class_6862<class_2248> INCORRECT_JEM_TOOL = createTag("incorrect_jem_tool");
        public static class_6862<class_2248> NEEDS_SEM_TOOL = createTag("needs_sem_tool");
        public static class_6862<class_2248> INCORRECT_SEM_TOOL = createTag("incorrect_sem_tool");
        public static class_6862<class_2248> NEEDS_SOB_TOOL = createTag("needs_sob_tool");
        public static class_6862<class_2248> INCORRECT_SOB_TOOL = createTag("incorrect_sob_tool");
        public static class_6862<class_2248> NEEDS_JOB_TOOL = createTag("needs_job_tool");
        public static class_6862<class_2248> INCORRECT_JOB_TOOL = createTag("incorrect_job_tool");
        public static class_6862<class_2248> NEEDS_OP_TOOL = createTag("needs_op_tool");
        public static class_6862<class_2248> INCORRECT_OP_TOOL = createTag("incorrect_op_tool");

        private static class_6862<class_2248> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41254, new class_2960(UsefultoolsMod.MOD_ID, name));
        }
    }

    public static class Items {
        private static class_6862<class_1792> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41197, new class_2960(UsefultoolsMod.MOD_ID, name));
        }
    }
}
