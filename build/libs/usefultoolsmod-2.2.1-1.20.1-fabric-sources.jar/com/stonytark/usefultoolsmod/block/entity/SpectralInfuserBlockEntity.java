package com.stonytark.usefultoolsmod.block.entity;

import com.stonytark.usefultoolsmod.block.custom.SpectralInfuserBlock;
import com.stonytark.usefultoolsmod.item.ModItems;
import com.stonytark.usefultoolsmod.item.custom.EctoplasmInfusionHelper;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1262;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1831;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import org.jetbrains.annotations.Nullable;

public class SpectralInfuserBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory {
    private final class_2371<class_1799> inventory = class_2371.method_10213(3, class_1799.field_8037);
    private int progress = 0;
    private int maxProgress = 200;

    private final class_3913 propertyDelegate = new class_3913() {
        @Override
        public int method_17390(int index) {
            return switch (index) {
                case 0 -> progress;
                case 1 -> maxProgress;
                default -> 0;
            };
        }

        @Override
        public void method_17391(int index, int value) {
            switch (index) {
                case 0 -> progress = value;
                case 1 -> maxProgress = value;
            }
        }

        @Override
        public int method_17389() {
            return 2;
        }
    };

    public SpectralInfuserBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntityTypes.SPECTRAL_INFUSER, pos, state);
    }

    public class_2371<class_1799> getInventory() {
        return inventory;
    }

    public class_3913 getPropertyDelegate() {
        return propertyDelegate;
    }

    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new SpectralInfuserMenu(syncId, playerInventory, this, propertyDelegate);
    }

    public class_2561 method_5476() {
        return class_2561.method_43471("block.usefultoolsmod.spectral_infuser");
    }

    public boolean canPlayerUseInverted(class_1657 player) {
        return this.canPlayerUse(player);
    }

    private boolean canPlayerUse(class_1657 player) {
        if (this.field_11863.method_8321(this.method_11016()) != this) {
            return false;
        }
        return player.method_5649((double)this.method_11016().method_10263() + 0.5, (double)this.method_11016().method_10264() + 0.5, (double)this.method_11016().method_10260() + 0.5) <= 64.0;
    }

    @Override
    public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
        buf.method_10807(this.method_11016());
    }

    @Override
    public void method_11014(class_2487 tag) {
        super.method_11014(tag);
        class_1262.method_5429(tag, inventory);
        progress = tag.method_10550("progress");
    }

    @Override
    protected void method_11007(class_2487 tag) {
        super.method_11007(tag);
        class_1262.method_5426(tag, inventory);
        tag.method_10569("progress", progress);
    }

    @Override
    public class_2622 method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887() {
        class_2487 tag = new class_2487();
        method_11007(tag);
        return tag;
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state,
                            SpectralInfuserBlockEntity be) {
        boolean powered = world.method_49803(pos);

        if (!powered && be.hasRecipe()) {
            be.progress++;
            if (!state.method_11654(SpectralInfuserBlock.LIT)) {
                world.method_8652(pos, state.method_11657(SpectralInfuserBlock.LIT, true), 3);
            }
            be.method_5431();
            if (be.progress >= be.maxProgress) {
                be.craftItem();
                be.resetProgress();
            }
        } else {
            if (be.progress > 0) {
                be.resetProgress();
            }
            if (state.method_11654(SpectralInfuserBlock.LIT)) {
                world.method_8652(pos, state.method_11657(SpectralInfuserBlock.LIT, false), 3);
            }
        }
    }

    private boolean hasRecipe() {
        class_1799 input = inventory.get(0);
        class_1799 fuel = inventory.get(1);
        class_1799 output = inventory.get(2);
        return isInfusable(input) && fuel.method_31574(ModItems.ECTOPLASM)
                && !fuel.method_7960() && output.method_7960();
    }

    private void craftItem() {
        class_1799 input = inventory.get(0);
        class_1799 result;

        if (input.method_31574(class_1802.field_8803)) {
            result = new class_1799(ModItems.GHOST_SPAWN_EGG);
        } else {
            result = input.method_7972();
            result.method_7939(1);
            result.method_7974(0);
            EctoplasmInfusionHelper.setInfused(result, true);
        }

        inventory.set(2, result);
        inventory.set(0, class_1799.field_8037);
        inventory.get(1).method_7934(1);
    }

    private void resetProgress() {
        progress = 0;
    }

    public static boolean isInfusable(class_1799 stack) {
        if (stack.method_7960()) return false;
        return stack.method_7909() instanceof class_1831
                || stack.method_7909() instanceof class_1738
                || stack.method_31574(class_1802.field_8803);
    }
}
