package com.stonytark.usefultoolsmod.block.entity;

import com.stonytark.usefultoolsmod.block.ModBlocks;
import com.stonytark.usefultoolsmod.item.ModItems;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_3913;

public class SpectralInfuserMenu extends class_1703 {
    private final SpectralInfuserBlockEntity blockEntity;
    private final class_3913 propertyDelegate;

    // Slot indices
    private static final int PLAYER_INV_START = 0;
    private static final int PLAYER_INV_END = 27;
    private static final int PLAYER_HOTBAR_END = 36;
    private static final int INPUT_SLOT = 36;
    private static final int FUEL_SLOT = 37;
    private static final int OUTPUT_SLOT = 38;

    public SpectralInfuserMenu(int syncId, class_1661 playerInventory,
                               SpectralInfuserBlockEntity blockEntity, class_3913 propertyDelegate) {
        super(ModMenuTypes.SPECTRAL_INFUSER, syncId);
        this.blockEntity = blockEntity;
        this.propertyDelegate = propertyDelegate;

        addPlayerInventory(playerInventory);
        addPlayerHotbar(playerInventory);

        // Block entity slots
        class_2371<class_1799> inv = blockEntity.getInventory();
        this.method_7621(new class_1735(new SimpleInventory(inv), 0, 56, 17));   // input (top)
        this.method_7621(new class_1735(new SimpleInventory(inv), 1, 56, 53));   // ectoplasm (bottom)
        this.method_7621(new class_1735(new SimpleInventory(inv), 2, 116, 35) {   // output (right)
            @Override
            public boolean method_7680(class_1799 stack) {
                return false; // output-only
            }
        });

        this.method_17360(propertyDelegate);
    }

    public boolean isCrafting() {
        return propertyDelegate.method_17390(0) > 0;
    }

    public int getScaledProgress() {
        int progress = propertyDelegate.method_17390(0);
        int maxProgress = propertyDelegate.method_17390(1);
        int arrowPixelWidth = 24;
        return maxProgress != 0 ? progress * arrowPixelWidth / maxProgress : 0;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(index);
        if (slot.method_7681()) {
            class_1799 original = slot.method_7677().method_7972();
            newStack = original;

            if (index == OUTPUT_SLOT) {
                // Output → player inventory
                if (!this.method_7616(original, PLAYER_INV_START, PLAYER_HOTBAR_END, true)) {
                    return class_1799.field_8037;
                }
                slot.method_7670(original, newStack);
            } else if (index >= INPUT_SLOT) {
                // Input/fuel → player inventory
                if (!this.method_7616(original, PLAYER_INV_START, PLAYER_HOTBAR_END, false)) {
                    return class_1799.field_8037;
                }
            } else {
                // Player inventory → block entity slots
                if (SpectralInfuserBlockEntity.isInfusable(original)) {
                    if (!this.method_7616(original, INPUT_SLOT, INPUT_SLOT + 1, false)) {
                        return class_1799.field_8037;
                    }
                } else if (original.method_31574(ModItems.ECTOPLASM)) {
                    if (!this.method_7616(original, FUEL_SLOT, FUEL_SLOT + 1, false)) {
                        return class_1799.field_8037;
                    }
                } else if (index < PLAYER_INV_END) {
                    // Main inventory → hotbar
                    if (!this.method_7616(original, PLAYER_INV_END, PLAYER_HOTBAR_END, false)) {
                        return class_1799.field_8037;
                    }
                } else {
                    // Hotbar → main inventory
                    if (!this.method_7616(original, PLAYER_INV_START, PLAYER_INV_END, false)) {
                        return class_1799.field_8037;
                    }
                }
            }

            if (original.method_7960()) {
                slot.method_48931(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }
        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return blockEntity.canPlayerUseInverted(player);
    }

    private void addPlayerInventory(class_1661 inv) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new class_1735(inv, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
    }

    private void addPlayerHotbar(class_1661 inv) {
        for (int col = 0; col < 9; col++) {
            this.method_7621(new class_1735(inv, col, 8 + col * 18, 142));
        }
    }

    // Simple wrapper to expose inventory
    private static class SimpleInventory implements class_1263 {
        private final class_2371<class_1799> stacks;

        public SimpleInventory(class_2371<class_1799> stacks) {
            this.stacks = stacks;
        }

        @Override
        public int method_5439() {
            return stacks.size();
        }

        @Override
        public boolean method_5442() {
            for (class_1799 stack : stacks) {
                if (!stack.method_7960()) return false;
            }
            return true;
        }

        @Override
        public class_1799 method_5438(int slot) {
            return stacks.get(slot);
        }

        @Override
        public class_1799 method_5434(int slot, int amount) {
            return stacks.get(slot).method_7971(amount);
        }

        @Override
        public class_1799 method_5441(int slot) {
            class_1799 stack = stacks.get(slot);
            stacks.set(slot, class_1799.field_8037);
            return stack;
        }

        @Override
        public void method_5447(int slot, class_1799 stack) {
            stacks.set(slot, stack);
        }

        @Override
        public void method_5431() {
        }

        @Override
        public boolean method_5443(class_1657 player) {
            return true;
        }

        @Override
        public void method_5448() {
            stacks.clear();
        }
    }
}
