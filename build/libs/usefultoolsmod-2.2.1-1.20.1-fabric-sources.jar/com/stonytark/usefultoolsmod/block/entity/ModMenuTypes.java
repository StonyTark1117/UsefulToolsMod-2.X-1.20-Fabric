package com.stonytark.usefultoolsmod.block.entity;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class ModMenuTypes {

    public static final class_3917<SpectralInfuserMenu> SPECTRAL_INFUSER =
            class_2378.method_10230(class_7923.field_41187,
                    new class_2960(UsefultoolsMod.MOD_ID, "spectral_infuser_menu"),
                    new ExtendedScreenHandlerType<>((syncId, playerInventory, buf) -> {
                        var pos = buf.method_10811();
                        var world = playerInventory.field_7546.method_37908();
                        var blockEntity = (SpectralInfuserBlockEntity) world.method_8321(pos);
                        return new SpectralInfuserMenu(syncId, playerInventory, blockEntity, blockEntity.getPropertyDelegate());
                    }));

    public static void register() {
        // Registration happens via the static initializer
    }
}
