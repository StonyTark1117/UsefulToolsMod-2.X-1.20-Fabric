package com.stonytark.usefultoolsmod.block.entity;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.block.ModBlocks;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlockEntityTypes {

    public static final class_2591<SpectralInfuserBlockEntity> SPECTRAL_INFUSER =
            class_2378.method_10230(class_7923.field_41181,
                    new class_2960(UsefultoolsMod.MOD_ID, "spectral_infuser"),
                    class_2591.class_2592.method_20528(SpectralInfuserBlockEntity::new,
                            ModBlocks.SPECTRAL_INFUSER).method_11034(null));

    public static void register() {
        // Registration happens via the static initializer
    }
}
