package com.stonytark.usefultoolsmod.block.custom;

import com.stonytark.usefultoolsmod.block.entity.ModBlockEntityTypes;
import com.stonytark.usefultoolsmod.block.entity.SpectralInfuserBlockEntity;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public class SpectralInfuserBlock extends class_2237 {
    public static final class_2753 FACING = class_2741.field_12481;
    public static final class_2746 LIT = class_2741.field_12548;

    public SpectralInfuserBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.method_9595().method_11664()
                .method_11657(FACING, class_2350.field_11043)
                .method_11657(LIT, false));
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, LIT);
    }

    @Override
    public class_2680 method_9605(net.minecraft.class_1750 ctx) {
        return this.method_9564()
                .method_11657(FACING, ctx.method_7715().method_10153());
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new SpectralInfuserBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        if (world.field_9236) return null;
        return method_31618(type, ModBlockEntityTypes.SPECTRAL_INFUSER,
                SpectralInfuserBlockEntity::tick);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos,
                              class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236 && player instanceof net.minecraft.class_3222 serverPlayer) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof SpectralInfuserBlockEntity sibe) {
                serverPlayer.method_17355((ExtendedScreenHandlerFactory) sibe);
            }
        }
        return class_1269.method_29236(world.field_9236);
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos,
                                class_2680 newState, boolean isMoving) {
        if (!state.method_27852(newState.method_26204())) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof SpectralInfuserBlockEntity sibe) {
                class_1264.method_17349(world, pos, sibe.getInventory());
            }
        }
        super.method_9536(state, world, pos, newState, isMoving);
    }
}
