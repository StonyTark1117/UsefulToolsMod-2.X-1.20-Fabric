package com.stonytark.usefultoolsmod.block;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.block.custom.SpectralInfuserBlock;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2431;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_6019;
import net.minecraft.class_7923;

public class ModBlocks {
    public static class_2248 RGOLDBLOCK;
    public static class_2248 HRBLOCK;
    public static class_2248 RGOLDORE;
    public static class_2248 RGOLD_NETHER_ORE;
    public static class_2248 RGOLD_END_ORE;
    public static class_2248 RGOLD_DEEPSLATE_ORE;
    public static class_2248 SEMBLOCK;
    public static class_2248 SOBLOCK;
    public static class_2248 LBLOCK;

    // Storage blocks
    public static class_2248 HGLOW_BLOCK;
    public static class_2248 RAW_RGOLD_BLOCK;
    public static class_2248 ECTOPLASM_BLOCK;
    public static class_2248 REFINED_ECTOPLASM_BLOCK;
    public static class_2248 HARDENED_COAL_BLOCK;
    public static class_2248 COAL_DUST_BLOCK;
    public static class_2248 OBSHARD_BLOCK;
    public static class_2248 CALCIFIED_AMETHYST_BLOCK;
    public static class_2248 GLACIAL_SHARD_BLOCK;
    public static class_2248 POLISHED_QUARTZ_BLOCK;
    public static class_2248 POLISHED_PRISMARINE_BLOCK;

    // Spectral Infuser
    public static class_2248 SPECTRAL_INFUSER;

    public static void register() {
        RGOLDBLOCK = registerBlock("rgoldblock",
                new class_2248(class_4970.class_2251.method_9637().method_9632(4f).method_29292().method_9626(class_2498.field_11533)));
        HRBLOCK = registerBlock("hrblock",
                new class_2248(class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_22146)));
        RGOLDORE = registerBlock("rgoldore",
                new class_2431(class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_11544),
                        class_6019.method_35017(2, 4)));
        RGOLD_NETHER_ORE = registerBlock("rgold_nether_ore",
                new class_2431(class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_22148),
                        class_6019.method_35017(2, 4)));
        RGOLD_END_ORE = registerBlock("rgold_end_ore",
                new class_2431(class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_28700),
                        class_6019.method_35017(2, 4)));
        RGOLD_DEEPSLATE_ORE = registerBlock("rgold_deepslate_ore",
                new class_2431(class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_29033),
                        class_6019.method_35017(2, 4)));
        SEMBLOCK = registerBlock("semblock",
                new class_2248(class_4970.class_2251.method_9637().method_9632(4f).method_29292().method_9626(class_2498.field_27197)));
        SOBLOCK = registerBlock("soblock",
                new class_2248(class_4970.class_2251.method_9637().method_9632(5f).method_29292().method_9626(class_2498.field_27197)));
        LBLOCK = registerBlock("lblock",
                new class_2248(class_4970.class_2251.method_9637().method_9632(4f).method_29292().method_9626(class_2498.field_11533)));

        // Storage blocks
        HGLOW_BLOCK = registerBlock("hglow_block",
                new class_2248(class_4970.class_2251.method_9637().method_9632(4f).method_29292().method_9626(class_2498.field_11533)));
        RAW_RGOLD_BLOCK = registerBlock("raw_rgold_block",
                new class_2248(class_4970.class_2251.method_9637().method_9632(4f).method_29292().method_9626(class_2498.field_11544)));
        ECTOPLASM_BLOCK = registerBlock("ectoplasm_block",
                new class_2248(class_4970.class_2251.method_9637().method_9632(2.5f).method_29292().method_9626(class_2498.field_11545)));
        REFINED_ECTOPLASM_BLOCK = registerBlock("refined_ectoplasm_block",
                new class_2248(class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_11545)));
        HARDENED_COAL_BLOCK = registerBlock("hardened_coal_block",
                new class_2248(class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_11544)));
        COAL_DUST_BLOCK = registerBlock("coal_dust_block",
                new class_2248(class_4970.class_2251.method_9637().method_9632(2f).method_29292().method_9626(class_2498.field_11526)));
        OBSHARD_BLOCK = registerBlock("obshard_block",
                new class_2248(class_4970.class_2251.method_9637().method_9632(4f).method_29292().method_9626(class_2498.field_27197)));
        CALCIFIED_AMETHYST_BLOCK = registerBlock("calcified_amethyst_block",
                new class_2248(class_4970.class_2251.method_9637().method_9632(3.5f).method_29292().method_9626(class_2498.field_27197)));
        GLACIAL_SHARD_BLOCK = registerBlock("glacial_shard_block",
                new class_2248(class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_11537)));
        POLISHED_QUARTZ_BLOCK = registerBlock("polished_quartz_block",
                new class_2248(class_4970.class_2251.method_9637().method_9632(3f).method_29292().method_9626(class_2498.field_11544)));
        POLISHED_PRISMARINE_BLOCK = registerBlock("polished_prismarine_block",
                new class_2248(class_4970.class_2251.method_9637().method_9632(3.5f).method_29292().method_9626(class_2498.field_11544)));

        // Spectral Infuser
        SPECTRAL_INFUSER = registerBlock("spectral_infuser",
                new SpectralInfuserBlock(class_4970.class_2251.method_9637()
                        .method_9632(3.5f)
                        .method_29292()
                        .method_9626(class_2498.field_11544)
                        .method_9631(state -> state.method_11654(SpectralInfuserBlock.LIT) ? 13 : 0)));
    }

    private static <T extends class_2248> T registerBlock(String name, T block) {
        class_2378.method_10230(class_7923.field_41175, new class_2960(UsefultoolsMod.MOD_ID, name), block);
        class_2378.method_10230(class_7923.field_41178, new class_2960(UsefultoolsMod.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
        return block;
    }
}
