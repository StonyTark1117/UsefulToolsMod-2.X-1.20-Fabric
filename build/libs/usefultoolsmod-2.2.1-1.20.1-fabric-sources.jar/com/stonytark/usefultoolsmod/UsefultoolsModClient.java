package com.stonytark.usefultoolsmod;

import com.stonytark.usefultoolsmod.Config;
import com.stonytark.usefultoolsmod.block.entity.ModMenuTypes;
import com.stonytark.usefultoolsmod.client.SpectralInfuserScreen;
import com.stonytark.usefultoolsmod.entity.ModEntities;
import com.stonytark.usefultoolsmod.entity.client.GhostModel;
import com.stonytark.usefultoolsmod.entity.client.GhostRenderer;
import com.stonytark.usefultoolsmod.item.ModArmorMaterials;
import com.stonytark.usefultoolsmod.item.ModItems;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_310;
import net.minecraft.class_3929;
import net.minecraft.class_953;

public class UsefultoolsModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Register entity model layers (defines geometry for baking)
        EntityModelLayerRegistry.registerModelLayer(GhostModel.LAYER_LOCATION, GhostModel::createBodyLayer);

        // Register entity renderers
        EntityRendererRegistry.register(ModEntities.GHOST, GhostRenderer::new);
        EntityRendererRegistry.register(ModEntities.GRENADE, class_953::new);

        // Register screen handler screens
        class_3929.method_17542(ModMenuTypes.SPECTRAL_INFUSER, SpectralInfuserScreen::new);

        // Register client-side tick for particle aura effects
        ClientTickEvents.END_CLIENT_TICK.register(UsefultoolsModClient::onClientTick);
    }

    private static void onClientTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        class_1657 player = client.field_1724;

        class_1799 mainHand = player.method_6047();
        class_1799 offHand = player.method_6079();

        // Spawn enchant glint particles for OVERPOWER tools
        if (isOverpowerTool(mainHand) || isOverpowerTool(offHand)) {
            spawnAuraParticles(player);
        }

        // Spawn aura particles for each OVERPOWER armor piece worn
        if (Config.overpowerEnabled && Config.opArmorEffectsEnabled) {
            spawnArmorAuraIfOp(player);
        }
    }

    private static boolean isOverpowerTool(class_1799 stack) {
        return stack.method_31574(ModItems.OVERPOWER_SWORD)
                || stack.method_31574(ModItems.OVERPOWER_PICKAXE)
                || stack.method_31574(ModItems.OVERPOWER_SHOVEL)
                || stack.method_31574(ModItems.OVERPOWER_AXE);
    }

    private static void spawnArmorAuraIfOp(class_1657 player) {
        for (class_1799 armorStack : player.method_5661()) {
            if (armorStack.method_7909() instanceof class_1738 armor) {
                if (ModArmorMaterials.OVERPOWER == armor.method_7686()) {
                    spawnOpAuraParticles(player);
                }
            }
        }
    }

    private static void spawnAuraParticles(class_1657 player) {
        double x = player.method_23317() + (player.method_6051().method_43058() - 0.5) * 1.2;
        double y = player.method_23318() + player.method_6051().method_43058() * player.method_17682();
        double z = player.method_23321() + (player.method_6051().method_43058() - 0.5) * 1.2;
        player.method_37908().method_8406(class_2398.field_11215, x, y, z, 0.0, 0.1, 0.0);
    }

    private static void spawnOpAuraParticles(class_1657 player) {
        double radius = 0.5 + player.method_6051().method_43058() * 0.5;
        double angle  = player.method_6051().method_43058() * Math.PI * 2;
        double x = player.method_23317() + Math.cos(angle) * radius;
        double y = player.method_23318() + 1.0 + (player.method_6051().method_43058() - 0.5) * 0.3;
        double z = player.method_23321() + Math.sin(angle) * radius;

        if (player.method_6051().method_43056()) {
            player.method_37908().method_8406(class_2398.field_22246, x, y, z, 0, 0.02, 0);
        } else {
            player.method_37908().method_8406(class_2398.field_11215, x, y, z, 0, 0.01, 0);
        }
    }
}
