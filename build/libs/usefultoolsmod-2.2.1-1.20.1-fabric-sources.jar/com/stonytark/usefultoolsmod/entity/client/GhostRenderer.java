package com.stonytark.usefultoolsmod.entity.client;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.entity.custom.GhostEntity;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class GhostRenderer extends class_927<GhostEntity, GhostModel<GhostEntity>> {

    public GhostRenderer(class_5617.class_5618 context) {
        super(context, new GhostModel<>(context.method_32167(GhostModel.LAYER_LOCATION)), 0.85f);
    }

    @Override
    public class_2960 getTexture(GhostEntity entity) {
        return new class_2960(UsefultoolsMod.MOD_ID, "textures/entity/ghost/ghost_white.png");
    }

    @Override
    public void render(GhostEntity entity, float yaw, float tickDelta, class_4587 matrices,
                       class_4597 vertexConsumers, int light) {
        if (entity.method_6109()) {
            matrices.method_22905(0.5f, 0.5f, 0.5f);
        }
        super.method_4072(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }
}
