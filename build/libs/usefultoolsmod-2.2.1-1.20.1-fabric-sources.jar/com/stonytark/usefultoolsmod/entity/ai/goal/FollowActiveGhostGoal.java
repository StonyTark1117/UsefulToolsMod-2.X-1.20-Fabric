package com.stonytark.usefultoolsmod.entity.ai.goal;

import com.stonytark.usefultoolsmod.entity.custom.GhostEntity;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_1308;
import net.minecraft.class_1352;
import net.minecraft.class_1657;

/**
 * Ghost AI goal: trail behind another ghost that is itself actively navigating
 * toward a real target (player or animal).
 *
 * <p>This produces emergent group movement — ghosts drift together toward the
 * same subject of interest — while breaking the deadlock loop where two idle
 * ghosts would otherwise target each other in {@link ObserveFriendlyMobGoal}.
 * An idle/wandering ghost has no active navigation path and therefore cannot
 * be selected as a lead, so circular chasing is impossible.
 *
 * <p>When trailing ghosts arrive close enough to the lead ghost's destination,
 * their own higher-priority goals ({@link FollowPlayerGoal} or
 * {@link ObserveFriendlyMobGoal}) will fire and they independently observe
 * the same target — producing the natural small-group behaviour.
 */
public class FollowActiveGhostGoal extends class_1352 {

    private final class_1308 mob;
    private GhostEntity leadGhost;
    private final double speedModifier;
    private final double followRange;
    private double stopDistance;

    public FollowActiveGhostGoal(class_1308 mob, double speedModifier, double followRange) {
        this.mob = mob;
        this.speedModifier = speedModifier;
        this.followRange = followRange;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        if (mob.method_6109()) return false;
        if (hasVisiblePlayer()) return false;

        List<GhostEntity> activeGhosts = mob.method_37908().method_8390(
                GhostEntity.class,
                mob.method_5829().method_1014(followRange),
                g -> g != mob
                        && g.method_5805()
                        && g.method_5942().method_23966()
        );

        if (activeGhosts.isEmpty()) return false;

        GhostEntity closest = null;
        double closestDist = Double.MAX_VALUE;
        for (GhostEntity g : activeGhosts) {
            double d = mob.method_5858(g);
            if (d < closestDist) {
                closestDist = d;
                closest = g;
            }
        }

        if (closest != null) {
            this.leadGhost = closest;
            this.stopDistance = 2.0 + mob.method_6051().method_43058() * 3.0;
            return true;
        }
        return false;
    }

    @Override
    public boolean method_6266() {
        return leadGhost != null
                && leadGhost.method_5805()
                && leadGhost.method_5942().method_23966()
                && mob.method_5858(leadGhost) < followRange * followRange;
    }

    @Override
    public void method_6270() {
        leadGhost = null;
        mob.method_5942().method_6340();
    }

    @Override
    public void method_6268() {
        if (leadGhost == null) return;
        mob.method_5988().method_6226(leadGhost, 30.0F, 30.0F);
        if (mob.method_5858(leadGhost) > stopDistance * stopDistance) {
            mob.method_5942().method_6335(leadGhost, speedModifier);
        }
    }

    private boolean hasVisiblePlayer() {
        return !mob.method_37908().method_8390(
                class_1657.class,
                mob.method_5829().method_1014(followRange),
                p -> p.method_5805() && !p.method_7325() && mob.method_6057(p)
        ).isEmpty();
    }
}
