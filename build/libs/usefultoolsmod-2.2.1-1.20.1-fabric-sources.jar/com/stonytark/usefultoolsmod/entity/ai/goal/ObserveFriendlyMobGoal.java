package com.stonytark.usefultoolsmod.entity.ai.goal;

import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_1308;
import net.minecraft.class_1352;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_3988;

/**
 * Ghost AI goal: passively observe nearby friendly mobs (animals/villagers) when
 * no player is in direct line of sight. Lower priority than FollowPlayerGoal.
 *
 * <p>An optional {@code excluded} class prevents ghosts from targeting each other,
 * breaking the mutual-follow deadlock where two idle ghosts orbit one another.
 */
public class ObserveFriendlyMobGoal extends class_1352 {

    private final class_1308 mob;
    private class_1308 targetMob;
    private final double speedModifier;
    private final double followRange;
    private float variableStopDist;
    private final Class<? extends class_1308> excluded;

    public ObserveFriendlyMobGoal(class_1308 mob, double speedModifier, double followRange, Class<? extends class_1308> excluded) {
        this.mob = mob;
        this.speedModifier = speedModifier;
        this.followRange = followRange;
        this.excluded = excluded;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        if (mob.method_6109()) return false;
        if (hasVisiblePlayer()) return false;

        List<class_1308> friendlyMobs = mob.method_37908().method_8390(
                class_1308.class,
                mob.method_5829().method_1014(followRange),
                m -> (m instanceof class_1429 || m instanceof class_3988)
                        && m.method_5805()
                        && m != mob
                        && !excluded.isInstance(m)
        );

        if (friendlyMobs.isEmpty()) return false;

        class_1308 closest = null;
        double closestDist = Double.MAX_VALUE;
        for (class_1308 m : friendlyMobs) {
            double d = mob.method_5858(m);
            if (d < closestDist) {
                closestDist = d;
                closest = m;
            }
        }

        if (closest != null) {
            this.targetMob = closest;
            this.variableStopDist = 1.0f + mob.method_6051().method_43057() * 4.0f;
            return true;
        }
        return false;
    }

    @Override
    public boolean method_6266() {
        if (hasVisiblePlayer()) return false;
        return targetMob != null
                && targetMob.method_5805()
                && mob.method_5858(targetMob) > variableStopDist * variableStopDist;
    }

    @Override
    public void method_6270() {
        targetMob = null;
        mob.method_5942().method_6340();
    }

    @Override
    public void method_6268() {
        if (targetMob == null) return;
        mob.method_5988().method_6226(targetMob, 30.0F, 30.0F);
        mob.method_5942().method_6335(targetMob, speedModifier);
    }

    private boolean hasVisiblePlayer() {
        List<class_1657> players = mob.method_37908().method_8390(
                class_1657.class,
                mob.method_5829().method_1014(followRange),
                p -> p.method_5805() && !p.method_7325() && mob.method_6057(p)
        );
        return !players.isEmpty();
    }
}
