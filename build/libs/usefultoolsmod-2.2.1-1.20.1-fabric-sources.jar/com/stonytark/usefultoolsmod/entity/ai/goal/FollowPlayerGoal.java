package com.stonytark.usefultoolsmod.entity.ai.goal;

import com.stonytark.usefultoolsmod.Config;
import com.stonytark.usefultoolsmod.item.custom.EctoplasmArmorHelper;
import com.stonytark.usefultoolsmod.trigger.ModTriggers;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_1308;
import net.minecraft.class_1352;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3222;

/**
 * Ghost AI goal: follow the nearest visible player while maintaining a
 * randomised stop-distance of 1-5 blocks so the ghost acts as a passive
 * observer rather than crowding the player.
 */
public class FollowPlayerGoal extends class_1352 {

    private final class_1308 mob;
    private class_1657 targetPlayer;
    private final double speedModifier;
    private final double followRange;
    private final double minStopDistance;
    private final double maxStopDistance;
    /** Randomised each time the goal activates (1-5 blocks). */
    private double variableStopDist;

    public FollowPlayerGoal(class_1308 mob, double speedModifier, double followRange, double minStopDistance) {
        this.mob = mob;
        this.speedModifier = speedModifier;
        this.followRange = followRange;
        this.minStopDistance = minStopDistance;
        this.maxStopDistance = 5.0;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        if (mob.method_6109()) return false;
        if (mob instanceof class_1429 a && a.method_6479()) return false;
        List<class_1657> players = mob.method_37908().method_8390(
                class_1657.class,
                mob.method_5829().method_1014(followRange),
                player -> player.method_5805() && !player.method_7325()
        );

        double closestDist = Double.MAX_VALUE;
        class_1657 closestPlayer = null;

        for (class_1657 player : players) {
            if (Config.ectoplasmGhostAvoidance && EctoplasmArmorHelper.isGhostInvisible(player)) {
                continue;
            }
            double dist = mob.method_5858(player);
            if (dist < closestDist && mob.method_6057(player)) {
                closestDist = dist;
                closestPlayer = player;
            }
        }

        if (closestPlayer != null) {
            this.targetPlayer = closestPlayer;
            this.variableStopDist = minStopDistance
                    + mob.method_6051().method_43058() * (maxStopDistance - minStopDistance);
            // Fire the ghost_nearby advancement trigger on first targeting
            if (closestPlayer instanceof class_3222 serverPlayer) {
                ModTriggers.GHOST_NEARBY.trigger(serverPlayer);
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean method_6266() {
        if (targetPlayer != null && Config.ectoplasmGhostAvoidance
                && EctoplasmArmorHelper.isGhostInvisible(targetPlayer)) {
            return false;
        }
        return targetPlayer != null
                && targetPlayer.method_5805()
                && mob.method_5858(targetPlayer) > variableStopDist * variableStopDist
                && mob.method_6057(targetPlayer);
    }

    @Override
    public void method_6270() {
        targetPlayer = null;
        mob.method_5942().method_6340();
    }

    @Override
    public void method_6268() {
        if (targetPlayer == null) return;
        mob.method_5988().method_6226(targetPlayer, 30.0F, 30.0F);
        class_243 targetPos = targetPlayer.method_19538();
        mob.method_5942().method_6337(targetPos.field_1352, targetPos.field_1351 + 1.0D, targetPos.field_1350, speedModifier);
    }
}
