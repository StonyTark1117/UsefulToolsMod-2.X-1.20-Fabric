package com.stonytark.usefultoolsmod.entity.ai.goal;

import com.stonytark.usefultoolsmod.entity.custom.GhostEntity;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_2338;
import net.minecraft.class_243;

/**
 * Baby ghost AI goal: when any non-ghost entity is nearby, flee to safety.
 *
 * <p>Three-tier fallback in priority order:
 * <ol>
 *   <li><b>Adult ghost cover</b> — navigate to the far side of the nearest adult ghost
 *       relative to the threat, tucking the baby behind it.</li>
 *   <li><b>Block cover</b> — search outward in the flee direction for a solid block and
 *       navigate just past it so the block breaks line of sight.</li>
 *   <li><b>Pure flee</b> — if neither option is available, simply move 8 blocks away from
 *       the threat.</li>
 * </ol>
 *
 * <p>The hiding destination is cached for 20 ticks to avoid expensive recalculations
 * every tick.
 */
public class HideBehindAdultGoal extends class_1352 {

    private static final double THREAT_RANGE   = 10.0;
    private static final double ADULT_RANGE    = 16.0;
    private static final double HIDE_OFFSET    = 2.5;
    private static final double COVER_OFFSET   = 1.5;
    private static final double FLEE_DISTANCE  = 8.0;
    private static final int    RECALC_INTERVAL = 20;

    private final class_1308 mob;
    private final double speedModifier;

    private @Nullable class_1309 threat;
    private @Nullable class_243 hideTarget;
    private int recalcCooldown = 0;

    public HideBehindAdultGoal(class_1308 mob, double speedModifier) {
        this.mob = mob;
        this.speedModifier = speedModifier;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        if (!mob.method_6109()) return false;

        class_1309 nearest = findNearestThreat();
        if (nearest == null) return false;

        this.threat = nearest;
        this.hideTarget = computeHideTarget(nearest);
        this.recalcCooldown = RECALC_INTERVAL;
        return hideTarget != null;
    }

    @Override
    public boolean method_6266() {
        return threat != null && threat.method_5805()
                && mob.method_5858(threat) < THREAT_RANGE * THREAT_RANGE * 1.5;
    }

    @Override
    public void method_6270() {
        threat = null;
        hideTarget = null;
        mob.method_5942().method_6340();
    }

    @Override
    public void method_6268() {
        if (threat == null) return;

        class_243 awayDir = mob.method_19538().method_1020(threat.method_19538()).method_1029();
        class_243 lookAt = mob.method_19538().method_1019(awayDir);
        mob.method_5988().method_6230(lookAt.field_1352, lookAt.field_1351, lookAt.field_1350, 30.0F, 30.0F);

        if (--recalcCooldown <= 0) {
            hideTarget = computeHideTarget(threat);
            recalcCooldown = RECALC_INTERVAL;
        }

        if (hideTarget != null) {
            mob.method_5942().method_6337(hideTarget.field_1352, hideTarget.field_1351, hideTarget.field_1350, speedModifier);
        }
    }

    private @Nullable class_1309 findNearestThreat() {
        List<class_1309> threats = mob.method_37908().method_8390(
                class_1309.class,
                mob.method_5829().method_1014(THREAT_RANGE),
                e -> e.method_5805() && e != mob && !(e instanceof GhostEntity)
        );

        class_1309 nearest = null;
        double nearestDist = Double.MAX_VALUE;
        for (class_1309 e : threats) {
            double d = mob.method_5858(e);
            if (d < nearestDist) {
                nearestDist = d;
                nearest = e;
            }
        }
        return nearest;
    }

    private @Nullable class_243 computeHideTarget(class_1309 threat) {
        class_243 threatPos = threat.method_19538();

        GhostEntity adult = findNearestAdult();
        if (adult != null) {
            class_243 adultPos = adult.method_19538();
            class_243 shieldDir = adultPos.method_1020(threatPos).method_1029();
            return adultPos.method_1019(shieldDir.method_1021(HIDE_OFFSET)).method_1031(0, 0.5, 0);
        }

        class_243 fleeDir = mob.method_19538().method_1020(threatPos).method_1029();
        class_243 blockCover = findBlockCover(fleeDir);
        if (blockCover != null) return blockCover;

        return mob.method_19538().method_1019(fleeDir.method_1021(FLEE_DISTANCE));
    }

    private @Nullable GhostEntity findNearestAdult() {
        List<GhostEntity> adults = mob.method_37908().method_8390(
                GhostEntity.class,
                mob.method_5829().method_1014(ADULT_RANGE),
                g -> g != mob && g.method_5805() && !g.method_6109()
        );

        GhostEntity nearest = null;
        double nearestDist = Double.MAX_VALUE;
        for (GhostEntity g : adults) {
            double d = mob.method_5858(g);
            if (d < nearestDist) {
                nearestDist = d;
                nearest = g;
            }
        }
        return nearest;
    }

    private @Nullable class_243 findBlockCover(class_243 fleeDir) {
        class_243 origin = mob.method_19538();

        for (int step = 2; step <= 10; step++) {
            class_243 candidate = origin.method_1019(fleeDir.method_1021(step));
            class_2338 base = class_2338.method_49638(candidate);

            for (int dy = -1; dy <= 1; dy++) {
                class_2338 check = base.method_10086(dy);
                if (mob.method_37908().method_8320(check).method_51367()) {
                    class_243 coverPos = class_243.method_24953(check).method_1019(fleeDir.method_1021(COVER_OFFSET));
                    return coverPos;
                }
            }
        }
        return null;
    }
}
