package com.stonytark.usefultoolsmod.entity;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.entity.custom.GhostEntity;
import com.stonytark.usefultoolsmod.entity.custom.GrenadeEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModEntities {
    public static class_1299<GrenadeEntity> GRENADE;
    public static class_1299<GhostEntity> GHOST;

    public static void register() {
        GRENADE = class_2378.method_10230(class_7923.field_41177,
                new class_2960(UsefultoolsMod.MOD_ID, "grenade"),
                class_1299.class_1300.<GrenadeEntity>method_5903(GrenadeEntity::new, class_1311.field_17715)
                        .method_17687(0.25F, 0.25F)
                        .method_27299(4)
                        .method_27300(10)
                        .method_5905("usefultoolsmod"));

        GHOST = class_2378.method_10230(class_7923.field_41177,
                new class_2960(UsefultoolsMod.MOD_ID, "ghost"),
                class_1299.class_1300.<GhostEntity>method_5903(GhostEntity::new, class_1311.field_6302)
                        .method_17687(1.5f, 1.5f)
                        .method_27299(8)
                        .method_27300(3)
                        .method_5905("usefultoolsmod"));
    }
}
