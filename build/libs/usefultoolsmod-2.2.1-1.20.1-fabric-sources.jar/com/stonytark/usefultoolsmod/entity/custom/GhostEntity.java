package com.stonytark.usefultoolsmod.entity.custom;

import com.stonytark.usefultoolsmod.entity.ModEntities;
import com.stonytark.usefultoolsmod.entity.ai.goal.FollowActiveGhostGoal;
import com.stonytark.usefultoolsmod.entity.ai.goal.FollowPlayerGoal;
import com.stonytark.usefultoolsmod.entity.ai.goal.HideBehindAdultGoal;
import com.stonytark.usefultoolsmod.entity.ai.goal.ObserveFriendlyMobGoal;
import com.stonytark.usefultoolsmod.item.ModItems;
import com.stonytark.usefultoolsmod.item.custom.EctoplasmInfusionHelper;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1331;
import net.minecraft.class_1341;
import net.minecraft.class_1353;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1395;
import net.minecraft.class_1407;
import net.minecraft.class_1408;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_7094;
import net.minecraft.class_8103;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class GhostEntity extends class_1429 {

    public final class_7094 idleAnimationState = new class_7094();
    private int idleAnimationTimeout = 0;
    private int lifetime = 0;
    private static final int MAX_LIFETIME = 5 * 60 * 20; // 5 minutes
    private static final int MAX_SOLID_DEPTH = 3;

    public GhostEntity(class_1299<? extends class_1429> type, class_1937 world) {
        super(type, world);
        this.field_6207 = new class_1331(this, 10, true);
        this.method_5875(true);
        this.field_5960 = true;
    }

    /* ---------------- AI ---------------- */

    @Override
    protected void method_5959() {
        // ---- Baby-only goals (canStart() is gated by isBaby()) ----

        // Priority 0: Hide behind adult ghost (or block cover) when any non-ghost is nearby
        this.field_6201.method_6277(0, new HideBehindAdultGoal(this, 1.3D));

        // Priority 1: Follow a parent/adult ghost when not hiding (vanilla FollowParentGoal
        //             checks isAdult() internally, so it only fires for babies)
        this.field_6201.method_6277(1, new class_1353(this, 1.1D));

        // ---- Adult-only goals (canStart() returns false when isBaby()) ----

        // Priority 0: Seek a breeding partner when in love mode (only active during love mode)
        this.field_6201.method_6277(0, new class_1341(this, 1.0D));

        // Priority 0: Follow visible player (yields when in love mode)
        this.field_6201.method_6277(0, new FollowPlayerGoal(this, 1.2D, 10.0F, 1.0));

        // Priority 1: Observe nearby animals/villagers (ghosts excluded — prevents deadlock loops)
        this.field_6201.method_6277(1, new ObserveFriendlyMobGoal(this, 0.9D, 10.0F, GhostEntity.class));

        // Priority 2: Trail a nearby ghost that is already heading toward a real target
        this.field_6201.method_6277(2, new FollowActiveGhostGoal(this, 1.0D, 12.0F));

        // ---- Shared goals (all ages) ----

        // Priority 3: Gentle aerial wandering
        this.field_6201.method_6277(3, new class_1395(this, 1.0D));

        // Priority 4: Look at nearby players
        this.field_6201.method_6277(4, new class_1361(this, class_1657.class, 8.0F));

        // Priority 5: Occasional random look-around
        this.field_6201.method_6277(5, new class_1376(this));
    }

    @Override
    protected class_1408 method_5965(class_1937 world) {
        class_1407 nav = new class_1407(this, world);
        nav.method_6354(true);
        nav.method_6331(true);
        return nav;
    }

    /* --------------- Attributes --------------- */

    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 20.0D)
                .method_26868(class_5134.field_23720, 0.6D)
                .method_26868(class_5134.field_23719, 0.3D)
                .method_26868(class_5134.field_23717, 32.0D);
    }

    /* --------------- Spawn rules --------------- */

    public static boolean checkGhostSpawnRules(class_1299<? extends class_1429> type,
                                               net.minecraft.class_1936 world,
                                               net.minecraft.class_3730 reason,
                                               class_2338 pos,
                                               net.minecraft.class_5819 random) {
        // Allow spawning anywhere — no block or light restrictions.
        // Night-time propensity: 3× more likely at night (light level 0-3) vs daytime.
        int skyLight = world.method_22335(pos, 0);
        if (skyLight > 3) {
            // Daytime / bright area — only 1-in-3 attempts succeed
            return random.method_43048(3) == 0;
        }
        return true;
    }

    /* --------------- Immunities / Physics --------------- */

    @Override
    public void method_5773() {
        super.method_5773();

        if (!this.method_37908().field_9236) {
            this.method_5646();
            constrainPosition();

            lifetime++;
            if (lifetime > MAX_LIFETIME) {
                this.method_31472();
            }
        }

        // Gentle hovering drift
        if (this.field_5974.method_43057() < 0.02F) {
            this.method_18799(this.method_18798().method_1031(
                    (this.field_5974.method_43058() - 0.5D) * 0.05D,
                    (this.field_5974.method_43058() - 0.5D) * 0.05D,
                    (this.field_5974.method_43058() - 0.5D) * 0.05D
            ));
        }

        if (this.method_37908().method_8608()) {
            this.setupAnimationStates();
        }
    }

    /**
     * Prevents the ghost from becoming permanently embedded in thick solid geometry.
     *
     * Rules:
     * - If the ghost is inside a solid block AND there is air within 1-3 blocks in
     *   some direction, push the ghost gently toward that air (allows thin-wall clipping).
     * - If there is NO air within 3 blocks in ANY direction (completely buried), perform
     *   a broader search and teleport the ghost to the nearest open position.
     */
    private void constrainPosition() {
        class_1937 world = this.method_37908();
        class_2338 pos = this.method_24515();

        if (world.method_8320(pos).method_26215()) return; // In open air -- nothing to do

        class_2350 bestDir = null;
        int bestDist = MAX_SOLID_DEPTH + 1;

        for (class_2350 dir : class_2350.values()) {
            for (int dist = 1; dist <= MAX_SOLID_DEPTH; dist++) {
                class_2338 check = pos.method_10079(dir, dist);
                if (world.method_8320(check).method_26215()) {
                    if (dist < bestDist) {
                        bestDist = dist;
                        bestDir = dir;
                    }
                    break;
                }
            }
        }

        if (bestDir != null) {
            // Air is reachable -- push gently toward it so the ghost slides out naturally
            class_243 push = class_243.method_24954(bestDir.method_10163()).method_1029().method_1021(0.15 / bestDist);
            class_243 current = this.method_18798();
            this.method_18800(
                    current.field_1352 * 0.6 + push.field_1352,
                    current.field_1351 * 0.6 + push.field_1351,
                    current.field_1350 * 0.6 + push.field_1350
            );
        } else {
            // Completely buried (> 3 blocks of solid in every direction) -- teleport out
            teleportToNearestAir(pos);
        }
    }

    /** BFS-like search for the nearest air position within a reasonable radius. */
    private void teleportToNearestAir(class_2338 origin) {
        class_1937 world = this.method_37908();
        for (int r = MAX_SOLID_DEPTH + 1; r <= 16; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (Math.abs(dx) != r && Math.abs(dy) != r && Math.abs(dz) != r) continue;
                        class_2338 check = origin.method_10069(dx, dy, dz);
                        if (world.method_8320(check).method_26215()
                                && world.method_8320(check.method_10084()).method_26215()) {
                            this.method_5814(check.method_10263() + 0.5, check.method_10264() + 0.5, check.method_10260() + 0.5);
                            this.method_18799(class_243.field_1353);
                            return;
                        }
                    }
                }
            }
        }
    }

    @Override
    public boolean method_5747(float fallDistance, float damageMultiplier, class_1282 damageSource) {
        return false;
    }

    @Override
    protected void method_5623(double heightDifference, boolean onGround, class_2680 landedState, class_2338 landedPosition) {
        // No-op -- ghosts ignore fall distance
    }

    @Override
    public boolean method_5740() {
        return true;
    }

    @Override
    public boolean method_5679(class_1282 source) {
        if (source.method_48789(class_8103.field_42242)) return false;

        // Allow damage from ectoplasm-infused weapons
        class_1297 attacker = source.method_5529();
        if (attacker instanceof class_1309 living) {
            class_1799 weapon = living.method_6047();
            if (EctoplasmInfusionHelper.isInfused(weapon)) {
                return false;
            }
        }

        return true;
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        // Non-weapon infused tools deal practically no damage (half a heart)
        class_1297 attacker = source.method_5529();
        if (attacker instanceof class_1309 living) {
            class_1799 weapon = living.method_6047();
            if (EctoplasmInfusionHelper.isInfused(weapon)
                    && !(weapon.method_7909() instanceof class_1829)
                    && !(weapon.method_7909() instanceof class_1743)) {
                amount = 1.0f; // half a heart
            }
        }
        return super.method_5643(source, amount);
    }

    @Override
    protected void method_16077(class_1282 source, boolean causedByPlayer) {
        super.method_16077(source, causedByPlayer);
        int count;
        if (method_6109()) {
            // Babies drop 0-1 ectoplasm
            count = this.field_5974.method_43048(2);
        } else {
            // Adults drop 1-3 ectoplasm
            count = 1 + this.field_5974.method_43048(3);
        }
        if (count > 0) {
            this.method_5775(new class_1799(ModItems.ECTOPLASM, count));
        }
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 world, class_1296 other) {
        return (class_1296) ModEntities.GHOST.method_5883(world);
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(ModItems.ECTOPLASM);
    }

    private void setupAnimationStates() {
        if (this.idleAnimationTimeout <= 0) {
            this.idleAnimationTimeout = 110;
            this.idleAnimationState.method_41322(this.field_6012);
        } else {
            --this.idleAnimationTimeout;
        }
    }

    /* SOUNDS */

    @Nullable
    @Override
    protected class_3414 method_5994() {
        return class_3417.field_14566;
    }

    @Nullable
    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_15054;
    }

    @Nullable
    @Override
    protected class_3414 method_6002() {
        return class_3417.field_14648;
    }
}
