package com.stonytark.usefultoolsmod.trigger;

import net.minecraft.class_174;

/**
 * Registers all custom criterion triggers for UsefulToolsMod advancements.
 */
public class ModTriggers {

    public static final GhostNearbyTrigger GHOST_NEARBY =
            (GhostNearbyTrigger) class_174.method_767(new GhostNearbyTrigger());

    public static final CoalToolIgnitedTrigger COAL_TOOL_IGNITED =
            (CoalToolIgnitedTrigger) class_174.method_767(new CoalToolIgnitedTrigger());

    public static void register() {
        // Registration happens via the static initializers above
    }
}
