package com.stonytark.usefultoolsmod.trigger;

import com.google.gson.JsonObject;
import net.minecraft.class_195;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5257;
import net.minecraft.class_5258;

/**
 * Fires the first time a coal tool in a player's hand catches fire.
 * Called from ModEvents.handleCoalToolBurning() on the server.
 */
public class CoalToolIgnitedTrigger extends class_4558<CoalToolIgnitedTrigger.Conditions> {

    public static final class_2960 ID = new class_2960("usefultoolsmod", "coal_tool_ignited");

    @Override
    public class_2960 method_794() {
        return ID;
    }

    @Override
    protected Conditions method_27854(JsonObject obj, class_5258 playerPredicate,
                                            class_5257 deserializer) {
        return new Conditions(ID, playerPredicate);
    }

    public void trigger(class_3222 player) {
        this.method_22510(player, conditions -> true);
    }

    public static class Conditions extends class_195 {
        public Conditions(class_2960 id, class_5258 playerPredicate) {
            super(id, playerPredicate);
        }
    }
}
