package com.stonytark.usefultoolsmod.item;

import com.stonytark.usefultoolsmod.Config;
import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class ModCreativeModeTabs {

    public static void register() {
        // Custom creative tab with all mod items
        class_2378.method_10230(class_7923.field_44687,
                new class_2960(UsefultoolsMod.MOD_ID, "useful_tools_tab"),
                FabricItemGroup.builder()
                        .method_47321(class_2561.method_43471("creativetab.usefultoolsmod.useful_tools"))
                        .method_47320(() -> new class_1799(ModItems.RGOLD))
                        .method_47317((context, entries) -> {

                            // =============================================================
                            //  UTILITY
                            // =============================================================

                            if (Config.explosivesEnabled) {
                                entries.method_45421(ModItems.DYNAMITE);
                                entries.method_45421(ModItems.GRENADE);
                            }

                            // =============================================================
                            //  VANILLA VARIANT TOOLS (wood & stone tier reskins)
                            // =============================================================

                            // --- Leather ---
                            if (Config.leatherEnabled) {
                                entries.method_45421(ModItems.LEATHER_SWORD);
                                entries.method_45421(ModItems.LEATHER_PICKAXE);
                                entries.method_45421(ModItems.LEATHER_SHOVEL);
                                entries.method_45421(ModItems.LEATHER_AXE);
                                entries.method_45421(ModItems.LEATHER_HOE);
                            }

                            // --- Wood Variants ---
                            if (Config.woodVariantsEnabled) {
                                entries.method_45421(ModItems.OAK_SWORD);
                                entries.method_45421(ModItems.OAK_PICKAXE);
                                entries.method_45421(ModItems.OAK_SHOVEL);
                                entries.method_45421(ModItems.OAK_AXE);
                                entries.method_45421(ModItems.OAK_HOE);
                                entries.method_45421(ModItems.SPRUCE_SWORD);
                                entries.method_45421(ModItems.SPRUCE_PICKAXE);
                                entries.method_45421(ModItems.SPRUCE_SHOVEL);
                                entries.method_45421(ModItems.SPRUCE_AXE);
                                entries.method_45421(ModItems.SPRUCE_HOE);
                                entries.method_45421(ModItems.BIRCH_SWORD);
                                entries.method_45421(ModItems.BIRCH_PICKAXE);
                                entries.method_45421(ModItems.BIRCH_SHOVEL);
                                entries.method_45421(ModItems.BIRCH_AXE);
                                entries.method_45421(ModItems.BIRCH_HOE);
                                entries.method_45421(ModItems.JUNGLE_SWORD);
                                entries.method_45421(ModItems.JUNGLE_PICKAXE);
                                entries.method_45421(ModItems.JUNGLE_SHOVEL);
                                entries.method_45421(ModItems.JUNGLE_AXE);
                                entries.method_45421(ModItems.JUNGLE_HOE);
                                entries.method_45421(ModItems.ACACIA_SWORD);
                                entries.method_45421(ModItems.ACACIA_PICKAXE);
                                entries.method_45421(ModItems.ACACIA_SHOVEL);
                                entries.method_45421(ModItems.ACACIA_AXE);
                                entries.method_45421(ModItems.ACACIA_HOE);
                                entries.method_45421(ModItems.DARK_OAK_SWORD);
                                entries.method_45421(ModItems.DARK_OAK_PICKAXE);
                                entries.method_45421(ModItems.DARK_OAK_SHOVEL);
                                entries.method_45421(ModItems.DARK_OAK_AXE);
                                entries.method_45421(ModItems.DARK_OAK_HOE);
                                entries.method_45421(ModItems.MANGROVE_SWORD);
                                entries.method_45421(ModItems.MANGROVE_PICKAXE);
                                entries.method_45421(ModItems.MANGROVE_SHOVEL);
                                entries.method_45421(ModItems.MANGROVE_AXE);
                                entries.method_45421(ModItems.MANGROVE_HOE);
                                entries.method_45421(ModItems.CHERRY_SWORD);
                                entries.method_45421(ModItems.CHERRY_PICKAXE);
                                entries.method_45421(ModItems.CHERRY_SHOVEL);
                                entries.method_45421(ModItems.CHERRY_AXE);
                                entries.method_45421(ModItems.CHERRY_HOE);
                                entries.method_45421(ModItems.BAMBOO_SWORD);
                                entries.method_45421(ModItems.BAMBOO_PICKAXE);
                                entries.method_45421(ModItems.BAMBOO_SHOVEL);
                                entries.method_45421(ModItems.BAMBOO_AXE);
                                entries.method_45421(ModItems.BAMBOO_HOE);
                                entries.method_45421(ModItems.CRIMSON_SWORD);
                                entries.method_45421(ModItems.CRIMSON_PICKAXE);
                                entries.method_45421(ModItems.CRIMSON_SHOVEL);
                                entries.method_45421(ModItems.CRIMSON_AXE);
                                entries.method_45421(ModItems.CRIMSON_HOE);
                                entries.method_45421(ModItems.WARPED_SWORD);
                                entries.method_45421(ModItems.WARPED_PICKAXE);
                                entries.method_45421(ModItems.WARPED_SHOVEL);
                                entries.method_45421(ModItems.WARPED_AXE);
                                entries.method_45421(ModItems.WARPED_HOE);
                            }

                            // --- Stone Rock Variants ---
                            if (Config.stoneVariantsEnabled) {
                                entries.method_45421(ModItems.ANDESITE_SWORD);
                                entries.method_45421(ModItems.ANDESITE_PICKAXE);
                                entries.method_45421(ModItems.ANDESITE_SHOVEL);
                                entries.method_45421(ModItems.ANDESITE_AXE);
                                entries.method_45421(ModItems.ANDESITE_HOE);
                                entries.method_45421(ModItems.BASALT_SWORD);
                                entries.method_45421(ModItems.BASALT_PICKAXE);
                                entries.method_45421(ModItems.BASALT_SHOVEL);
                                entries.method_45421(ModItems.BASALT_AXE);
                                entries.method_45421(ModItems.BASALT_HOE);
                                entries.method_45421(ModItems.BLACKSTONE_SWORD);
                                entries.method_45421(ModItems.BLACKSTONE_PICKAXE);
                                entries.method_45421(ModItems.BLACKSTONE_SHOVEL);
                                entries.method_45421(ModItems.BLACKSTONE_AXE);
                                entries.method_45421(ModItems.BLACKSTONE_HOE);
                                entries.method_45421(ModItems.CALCITE_SWORD);
                                entries.method_45421(ModItems.CALCITE_PICKAXE);
                                entries.method_45421(ModItems.CALCITE_SHOVEL);
                                entries.method_45421(ModItems.CALCITE_AXE);
                                entries.method_45421(ModItems.CALCITE_HOE);
                                entries.method_45421(ModItems.DEEPSLATE_SWORD);
                                entries.method_45421(ModItems.DEEPSLATE_PICKAXE);
                                entries.method_45421(ModItems.DEEPSLATE_SHOVEL);
                                entries.method_45421(ModItems.DEEPSLATE_AXE);
                                entries.method_45421(ModItems.DEEPSLATE_HOE);
                                entries.method_45421(ModItems.DIORITE_SWORD);
                                entries.method_45421(ModItems.DIORITE_PICKAXE);
                                entries.method_45421(ModItems.DIORITE_SHOVEL);
                                entries.method_45421(ModItems.DIORITE_AXE);
                                entries.method_45421(ModItems.DIORITE_HOE);
                                entries.method_45421(ModItems.END_STONE_SWORD);
                                entries.method_45421(ModItems.END_STONE_PICKAXE);
                                entries.method_45421(ModItems.END_STONE_SHOVEL);
                                entries.method_45421(ModItems.END_STONE_AXE);
                                entries.method_45421(ModItems.END_STONE_HOE);
                                entries.method_45421(ModItems.GRANITE_SWORD);
                                entries.method_45421(ModItems.GRANITE_PICKAXE);
                                entries.method_45421(ModItems.GRANITE_SHOVEL);
                                entries.method_45421(ModItems.GRANITE_AXE);
                                entries.method_45421(ModItems.GRANITE_HOE);
                                entries.method_45421(ModItems.NETHERRACK_SWORD);
                                entries.method_45421(ModItems.NETHERRACK_PICKAXE);
                                entries.method_45421(ModItems.NETHERRACK_SHOVEL);
                                entries.method_45421(ModItems.NETHERRACK_AXE);
                                entries.method_45421(ModItems.NETHERRACK_HOE);
                                entries.method_45421(ModItems.SANDSTONE_SWORD);
                                entries.method_45421(ModItems.SANDSTONE_PICKAXE);
                                entries.method_45421(ModItems.SANDSTONE_SHOVEL);
                                entries.method_45421(ModItems.SANDSTONE_AXE);
                                entries.method_45421(ModItems.SANDSTONE_HOE);
                                entries.method_45421(ModItems.SMOOTH_BASALT_SWORD);
                                entries.method_45421(ModItems.SMOOTH_BASALT_PICKAXE);
                                entries.method_45421(ModItems.SMOOTH_BASALT_SHOVEL);
                                entries.method_45421(ModItems.SMOOTH_BASALT_AXE);
                                entries.method_45421(ModItems.SMOOTH_BASALT_HOE);
                                entries.method_45421(ModItems.TERRACOTTA_SWORD);
                                entries.method_45421(ModItems.TERRACOTTA_PICKAXE);
                                entries.method_45421(ModItems.TERRACOTTA_SHOVEL);
                                entries.method_45421(ModItems.TERRACOTTA_AXE);
                                entries.method_45421(ModItems.TERRACOTTA_HOE);
                                entries.method_45421(ModItems.TUFF_SWORD);
                                entries.method_45421(ModItems.TUFF_PICKAXE);
                                entries.method_45421(ModItems.TUFF_SHOVEL);
                                entries.method_45421(ModItems.TUFF_AXE);
                                entries.method_45421(ModItems.TUFF_HOE);
                            }

                            // =============================================================
                            //  NATURAL MATERIAL SETS (flint, coal)
                            // =============================================================

                            // --- Flint ---
                            if (Config.flintEnabled) {
                                entries.method_45421(ModItems.RFLINT_SWORD);
                                entries.method_45421(ModItems.RFLINT_PICKAXE);
                                entries.method_45421(ModItems.RFLINT_SHOVEL);
                                entries.method_45421(ModItems.RFLINT_AXE);
                                entries.method_45421(ModItems.RFLINT_HOE);
                            }

                            // --- Flint-Iron (FNI) ---
                            if (Config.fniEnabled) {
                                entries.method_45421(ModItems.FNI_SWORD);
                                entries.method_45421(ModItems.FNI_PICKAXE);
                                entries.method_45421(ModItems.FNI_SHOVEL);
                                entries.method_45421(ModItems.FNI_AXE);
                                entries.method_45421(ModItems.FNI_HOE);
                                entries.method_45421(ModItems.FNI_HELMET);
                                entries.method_45421(ModItems.FNI_CHESTPLATE);
                                entries.method_45421(ModItems.FNI_LEGGINGS);
                                entries.method_45421(ModItems.FNI_BOOTS);
                            }

                            // --- Coal ---
                            if (Config.coalEnabled) {
                                entries.method_45421(ModItems.COAL_DUST);
                                entries.method_45421(ModBlocks.COAL_DUST_BLOCK);
                                entries.method_45421(ModItems.HARDENED_COAL);
                                entries.method_45421(ModBlocks.HARDENED_COAL_BLOCK);
                                entries.method_45421(ModItems.COAL_SWORD);
                                entries.method_45421(ModItems.COAL_PICKAXE);
                                entries.method_45421(ModItems.COAL_SHOVEL);
                                entries.method_45421(ModItems.COAL_AXE);
                                entries.method_45421(ModItems.COAL_HOE);
                                entries.method_45421(ModItems.COAL_HELMET);
                                entries.method_45421(ModItems.COAL_CHESTPLATE);
                                entries.method_45421(ModItems.COAL_LEGGINGS);
                                entries.method_45421(ModItems.COAL_BOOTS);
                            }

                            // --- Raw Metal Rough ---
                            if (Config.rawMetalRoughEnabled) {
                                entries.method_45421(ModItems.RRAW_GOLD_SWORD);
                                entries.method_45421(ModItems.RRAW_GOLD_PICKAXE);
                                entries.method_45421(ModItems.RRAW_GOLD_SHOVEL);
                                entries.method_45421(ModItems.RRAW_GOLD_AXE);
                                entries.method_45421(ModItems.RRAW_GOLD_HOE);
                                entries.method_45421(ModItems.RRAW_COPPER_SWORD);
                                entries.method_45421(ModItems.RRAW_COPPER_PICKAXE);
                                entries.method_45421(ModItems.RRAW_COPPER_SHOVEL);
                                entries.method_45421(ModItems.RRAW_COPPER_AXE);
                                entries.method_45421(ModItems.RRAW_COPPER_HOE);
                                entries.method_45421(ModItems.RRAW_IRON_SWORD);
                                entries.method_45421(ModItems.RRAW_IRON_PICKAXE);
                                entries.method_45421(ModItems.RRAW_IRON_SHOVEL);
                                entries.method_45421(ModItems.RRAW_IRON_AXE);
                                entries.method_45421(ModItems.RRAW_IRON_HOE);
                                entries.method_45421(ModItems.RRAW_RGOLD_SWORD);
                                entries.method_45421(ModItems.RRAW_RGOLD_PICKAXE);
                                entries.method_45421(ModItems.RRAW_RGOLD_SHOVEL);
                                entries.method_45421(ModItems.RRAW_RGOLD_AXE);
                                entries.method_45421(ModItems.RRAW_RGOLD_HOE);
                                entries.method_45421(ModItems.RSCRAP_SWORD);
                                entries.method_45421(ModItems.RSCRAP_PICKAXE);
                                entries.method_45421(ModItems.RSCRAP_SHOVEL);
                                entries.method_45421(ModItems.RSCRAP_AXE);
                                entries.method_45421(ModItems.RSCRAP_HOE);
                            }

                            // =============================================================
                            //  CRYSTAL & ICE SETS
                            // =============================================================

                            // --- Crystal material items ---
                            if (Config.roughCrystalEnabled || Config.polishedCrystalEnabled) {
                                entries.method_45421(ModItems.CALCIFIED_AMETHYST);
                                entries.method_45421(ModBlocks.CALCIFIED_AMETHYST_BLOCK);
                                entries.method_45421(ModItems.POLISHED_QUARTZ);
                                entries.method_45421(ModBlocks.POLISHED_QUARTZ_BLOCK);
                            }
                            if (Config.iceEnabled || Config.snowEnabled) {
                                entries.method_45421(ModItems.GLACIAL_SHARD);
                                entries.method_45421(ModBlocks.GLACIAL_SHARD_BLOCK);
                            }
                            if (Config.roughCrystalEnabled || Config.pprismEnabled) {
                                entries.method_45421(ModItems.POLISHED_PRISMARINE);
                                entries.method_45421(ModBlocks.POLISHED_PRISMARINE_BLOCK);
                            }

                            // --- Rough Crystal ---
                            if (Config.roughCrystalEnabled) {
                                entries.method_45421(ModItems.RAMETHYST_SWORD);
                                entries.method_45421(ModItems.RAMETHYST_PICKAXE);
                                entries.method_45421(ModItems.RAMETHYST_SHOVEL);
                                entries.method_45421(ModItems.RAMETHYST_AXE);
                                entries.method_45421(ModItems.RAMETHYST_HOE);
                                entries.method_45421(ModItems.RQUARTZ_SWORD);
                                entries.method_45421(ModItems.RQUARTZ_PICKAXE);
                                entries.method_45421(ModItems.RQUARTZ_SHOVEL);
                                entries.method_45421(ModItems.RQUARTZ_AXE);
                                entries.method_45421(ModItems.RQUARTZ_HOE);
                                entries.method_45421(ModItems.RPRISM_SWORD);
                                entries.method_45421(ModItems.RPRISM_PICKAXE);
                                entries.method_45421(ModItems.RPRISM_SHOVEL);
                                entries.method_45421(ModItems.RPRISM_AXE);
                                entries.method_45421(ModItems.RPRISM_HOE);
                            }

                            // --- Snow ---
                            if (Config.snowEnabled) {
                                entries.method_45421(ModItems.SNOW_SWORD);
                                entries.method_45421(ModItems.SNOW_PICKAXE);
                                entries.method_45421(ModItems.SNOW_SHOVEL);
                                entries.method_45421(ModItems.SNOW_AXE);
                                entries.method_45421(ModItems.SNOW_HOE);
                            }

                            // --- Ice (Glacial) ---
                            if (Config.iceEnabled) {
                                entries.method_45421(ModItems.ICE_SWORD);
                                entries.method_45421(ModItems.ICE_PICKAXE);
                                entries.method_45421(ModItems.ICE_SHOVEL);
                                entries.method_45421(ModItems.ICE_AXE);
                                entries.method_45421(ModItems.ICE_HOE);
                                entries.method_45421(ModItems.ICE_HELMET);
                                entries.method_45421(ModItems.ICE_CHESTPLATE);
                                entries.method_45421(ModItems.ICE_LEGGINGS);
                                entries.method_45421(ModItems.ICE_BOOTS);
                            }

                            // --- Polished Crystal ---
                            if (Config.polishedCrystalEnabled) {
                                entries.method_45421(ModItems.CAMETHYST_SWORD);
                                entries.method_45421(ModItems.CAMETHYST_PICKAXE);
                                entries.method_45421(ModItems.CAMETHYST_SHOVEL);
                                entries.method_45421(ModItems.CAMETHYST_AXE);
                                entries.method_45421(ModItems.CAMETHYST_HOE);
                                entries.method_45421(ModItems.CAMETHYST_HELMET);
                                entries.method_45421(ModItems.CAMETHYST_CHESTPLATE);
                                entries.method_45421(ModItems.CAMETHYST_LEGGINGS);
                                entries.method_45421(ModItems.CAMETHYST_BOOTS);
                                entries.method_45421(ModItems.PQUARTZ_SWORD);
                                entries.method_45421(ModItems.PQUARTZ_PICKAXE);
                                entries.method_45421(ModItems.PQUARTZ_SHOVEL);
                                entries.method_45421(ModItems.PQUARTZ_AXE);
                                entries.method_45421(ModItems.PQUARTZ_HOE);
                                entries.method_45421(ModItems.PQUARTZ_HELMET);
                                entries.method_45421(ModItems.PQUARTZ_CHESTPLATE);
                                entries.method_45421(ModItems.PQUARTZ_LEGGINGS);
                                entries.method_45421(ModItems.PQUARTZ_BOOTS);
                            }

                            // --- Polished Prismarine ---
                            if (Config.pprismEnabled) {
                                entries.method_45421(ModItems.PPRISM_SWORD);
                                entries.method_45421(ModItems.PPRISM_PICKAXE);
                                entries.method_45421(ModItems.PPRISM_SHOVEL);
                                entries.method_45421(ModItems.PPRISM_AXE);
                                entries.method_45421(ModItems.PPRISM_HOE);
                                entries.method_45421(ModItems.PPRISM_HELMET);
                                entries.method_45421(ModItems.PPRISM_CHESTPLATE);
                                entries.method_45421(ModItems.PPRISM_LEGGINGS);
                                entries.method_45421(ModItems.PPRISM_BOOTS);
                            }

                            // =============================================================
                            //  METAL & GEM SETS
                            // =============================================================

                            // --- Ferrous Gold ---
                            if (Config.ferrousGoldEnabled) {
                                entries.method_45421(ModBlocks.RGOLDBLOCK);
                                entries.method_45421(ModBlocks.RAW_RGOLD_BLOCK);
                                entries.method_45421(ModBlocks.RGOLDORE);
                                entries.method_45421(ModBlocks.RGOLD_NETHER_ORE);
                                entries.method_45421(ModBlocks.RGOLD_END_ORE);
                                entries.method_45421(ModBlocks.RGOLD_DEEPSLATE_ORE);
                                entries.method_45421(ModItems.RAW_RGOLD);
                                entries.method_45421(ModItems.RGOLD);
                                entries.method_45421(ModItems.RGOLD_AXE);
                                entries.method_45421(ModItems.RGOLD_PICKAXE);
                                entries.method_45421(ModItems.RGOLD_SWORD);
                                entries.method_45421(ModItems.RGOLD_SHOVEL);
                                entries.method_45421(ModItems.RGOLD_HOE);
                                entries.method_45421(ModItems.RGOLD_HELMET);
                                entries.method_45421(ModItems.RGOLD_CHESTPLATE);
                                entries.method_45421(ModItems.RGOLD_LEGGINGS);
                                entries.method_45421(ModItems.RGOLD_BOOTS);
                            }

                            // --- Lapis ---
                            if (Config.lapisEnabled) {
                                entries.method_45421(ModBlocks.LBLOCK);
                                entries.method_45421(ModItems.RLAPIS);
                                entries.method_45421(ModItems.RLAPIS_AXE);
                                entries.method_45421(ModItems.RLAPIS_PICKAXE);
                                entries.method_45421(ModItems.RLAPIS_SWORD);
                                entries.method_45421(ModItems.RLAPIS_SHOVEL);
                                entries.method_45421(ModItems.RLAPIS_HOE);
                                entries.method_45421(ModItems.RLAPIS_HELMET);
                                entries.method_45421(ModItems.RLAPIS_CHESTPLATE);
                                entries.method_45421(ModItems.RLAPIS_LEGGINGS);
                                entries.method_45421(ModItems.RLAPIS_BOOTS);
                            }

                            // --- Hardened Redstone ---
                            if (Config.hardenedRedstoneEnabled) {
                                entries.method_45421(ModItems.HRED);
                                entries.method_45421(ModBlocks.HRBLOCK);
                                entries.method_45421(ModItems.HREDSTONE_AXE);
                                entries.method_45421(ModItems.HREDSTONE_PICKAXE);
                                entries.method_45421(ModItems.HREDSTONE_SWORD);
                                entries.method_45421(ModItems.HREDSTONE_SHOVEL);
                                entries.method_45421(ModItems.HREDSTONE_HOE);
                                entries.method_45421(ModItems.HRED_HELMET);
                                entries.method_45421(ModItems.HRED_CHESTPLATE);
                                entries.method_45421(ModItems.HRED_LEGGINGS);
                                entries.method_45421(ModItems.HRED_BOOTS);
                            }

                            // --- Hardened Glowstone ---
                            if (Config.hardenedGlowstoneEnabled) {
                                entries.method_45421(ModItems.HGLOW);
                                entries.method_45421(ModBlocks.HGLOW_BLOCK);
                                entries.method_45421(ModItems.HGLOWSTONE_AXE);
                                entries.method_45421(ModItems.HGLOWSTONE_PICKAXE);
                                entries.method_45421(ModItems.HGLOWSTONE_SWORD);
                                entries.method_45421(ModItems.HGLOWSTONE_SHOVEL);
                                entries.method_45421(ModItems.HGLOWSTONE_HOE);
                                entries.method_45421(ModItems.HGLOW_HELMET);
                                entries.method_45421(ModItems.HGLOW_CHESTPLATE);
                                entries.method_45421(ModItems.HGLOW_LEGGINGS);
                                entries.method_45421(ModItems.HGLOW_BOOTS);
                            }

                            // --- Emerald ---
                            if (Config.emeraldEnabled) {
                                entries.method_45421(ModBlocks.SEMBLOCK);
                                entries.method_45421(ModItems.SEM);
                                entries.method_45421(ModItems.PEMERALD_AXE);
                                entries.method_45421(ModItems.PEMERALD_PICKAXE);
                                entries.method_45421(ModItems.PEMERALD_SWORD);
                                entries.method_45421(ModItems.PEMERALD_SHOVEL);
                                entries.method_45421(ModItems.PEMERALD_HOE);
                                entries.method_45421(ModItems.REMERALD_AXE);
                                entries.method_45421(ModItems.REMERALD_PICKAXE);
                                entries.method_45421(ModItems.REMERALD_SWORD);
                                entries.method_45421(ModItems.REMERALD_SHOVEL);
                                entries.method_45421(ModItems.REMERALD_HOE);
                                entries.method_45421(ModItems.EMERALD_HELMET);
                                entries.method_45421(ModItems.EMERALD_CHESTPLATE);
                                entries.method_45421(ModItems.EMERALD_LEGGINGS);
                                entries.method_45421(ModItems.EMERALD_BOOTS);
                            }

                            // --- Obsidian ---
                            if (Config.obsidianEnabled) {
                                entries.method_45421(ModItems.OBINGOT);
                                entries.method_45421(ModItems.OBSHARD);
                                entries.method_45421(ModBlocks.SOBLOCK);
                                entries.method_45421(ModBlocks.OBSHARD_BLOCK);
                                entries.method_45421(ModItems.ROBSIDIAN_AXE);
                                entries.method_45421(ModItems.ROBSIDIAN_PICKAXE);
                                entries.method_45421(ModItems.ROBSIDIAN_SWORD);
                                entries.method_45421(ModItems.ROBSIDIAN_SHOVEL);
                                entries.method_45421(ModItems.ROBSIDIAN_HOE);
                                entries.method_45421(ModItems.POBSIDIAN_AXE);
                                entries.method_45421(ModItems.POBSIDIAN_PICKAXE);
                                entries.method_45421(ModItems.POBSIDIAN_SWORD);
                                entries.method_45421(ModItems.POBSIDIAN_SHOVEL);
                                entries.method_45421(ModItems.POBSIDIAN_HOE);
                                entries.method_45421(ModItems.OBSIDIAN_HELMET);
                                entries.method_45421(ModItems.OBSIDIAN_CHESTPLATE);
                                entries.method_45421(ModItems.OBSIDIAN_LEGGINGS);
                                entries.method_45421(ModItems.OBSIDIAN_BOOTS);
                            }

                            // =============================================================
                            //  GHOST & ECTOPLASM
                            // =============================================================

                            if (Config.ghostEnabled) {
                                entries.method_45421(ModItems.GHOST_SPAWN_EGG);
                                entries.method_45421(ModItems.ECTOPLASM);
                            }

                            if (Config.spectralInfuserEnabled) {
                                entries.method_45421(ModBlocks.SPECTRAL_INFUSER);
                            }

                            if (Config.ectoplasmSetEnabled) {
                                entries.method_45421(ModBlocks.ECTOPLASM_BLOCK);
                                entries.method_45421(ModItems.RECTO_SWORD);
                                entries.method_45421(ModItems.RECTO_PICKAXE);
                                entries.method_45421(ModItems.RECTO_SHOVEL);
                                entries.method_45421(ModItems.RECTO_AXE);
                                entries.method_45421(ModItems.RECTO_HOE);
                                entries.method_45421(ModItems.REFINED_ECTOPLASM);
                                entries.method_45421(ModBlocks.REFINED_ECTOPLASM_BLOCK);
                                entries.method_45421(ModItems.ECTO_SWORD);
                                entries.method_45421(ModItems.ECTO_PICKAXE);
                                entries.method_45421(ModItems.ECTO_SHOVEL);
                                entries.method_45421(ModItems.ECTO_AXE);
                                entries.method_45421(ModItems.ECTO_HOE);
                                entries.method_45421(ModItems.ECTO_HELMET);
                                entries.method_45421(ModItems.ECTO_CHESTPLATE);
                                entries.method_45421(ModItems.ECTO_LEGGINGS);
                                entries.method_45421(ModItems.ECTO_BOOTS);
                            }

                            // =============================================================
                            //  OVERPOWER (end-game)
                            // =============================================================

                            if (Config.overpowerEnabled) {
                                entries.method_45421(ModItems.OVERPOWER_AXE);
                                entries.method_45421(ModItems.OVERPOWER_PICKAXE);
                                entries.method_45421(ModItems.OVERPOWER_SWORD);
                                entries.method_45421(ModItems.OVERPOWER_SHOVEL);
                                entries.method_45421(ModItems.OVERPOWER_HELMET);
                                entries.method_45421(ModItems.OVERPOWER_CHESTPLATE);
                                entries.method_45421(ModItems.OVERPOWER_LEGGINGS);
                                entries.method_45421(ModItems.OVERPOWER_BOOTS);
                            }

                            // =============================================================
                            //  FOOD SETS (edible novelty -- weakest to strongest)
                            // =============================================================

                            // --- Cake ---
                            if (Config.cakeEnabled) {
                                entries.method_45421(ModItems.CAKE_SWORD);
                                entries.method_45421(ModItems.CAKE_PICKAXE);
                                entries.method_45421(ModItems.CAKE_SHOVEL);
                                entries.method_45421(ModItems.CAKE_AXE);
                                entries.method_45421(ModItems.CAKE_HOE);
                                entries.method_45421(ModItems.CAKE_HELMET);
                                entries.method_45421(ModItems.CAKE_CHESTPLATE);
                                entries.method_45421(ModItems.CAKE_LEGGINGS);
                                entries.method_45421(ModItems.CAKE_BOOTS);
                            }

                            // --- Dried Kelp ---
                            if (Config.driedKelpEnabled) {
                                entries.method_45421(ModItems.DRIED_KELP_SWORD);
                                entries.method_45421(ModItems.DRIED_KELP_PICKAXE);
                                entries.method_45421(ModItems.DRIED_KELP_SHOVEL);
                                entries.method_45421(ModItems.DRIED_KELP_AXE);
                                entries.method_45421(ModItems.DRIED_KELP_HOE);
                                entries.method_45421(ModItems.DRIED_KELP_HELMET);
                                entries.method_45421(ModItems.DRIED_KELP_CHESTPLATE);
                                entries.method_45421(ModItems.DRIED_KELP_LEGGINGS);
                                entries.method_45421(ModItems.DRIED_KELP_BOOTS);
                            }

                            // --- Rotten Flesh ---
                            if (Config.rottenFleshEnabled) {
                                entries.method_45421(ModItems.ROTTEN_FLESH_SWORD);
                                entries.method_45421(ModItems.ROTTEN_FLESH_PICKAXE);
                                entries.method_45421(ModItems.ROTTEN_FLESH_SHOVEL);
                                entries.method_45421(ModItems.ROTTEN_FLESH_AXE);
                                entries.method_45421(ModItems.ROTTEN_FLESH_HOE);
                                entries.method_45421(ModItems.ROTTEN_FLESH_HELMET);
                                entries.method_45421(ModItems.ROTTEN_FLESH_CHESTPLATE);
                                entries.method_45421(ModItems.ROTTEN_FLESH_LEGGINGS);
                                entries.method_45421(ModItems.ROTTEN_FLESH_BOOTS);
                            }

                            // --- Bread ---
                            if (Config.breadEnabled) {
                                entries.method_45421(ModItems.BREAD_SWORD);
                                entries.method_45421(ModItems.BREAD_PICKAXE);
                                entries.method_45421(ModItems.BREAD_SHOVEL);
                                entries.method_45421(ModItems.BREAD_AXE);
                                entries.method_45421(ModItems.BREAD_HOE);
                                entries.method_45421(ModItems.BREAD_HELMET);
                                entries.method_45421(ModItems.BREAD_CHESTPLATE);
                                entries.method_45421(ModItems.BREAD_LEGGINGS);
                                entries.method_45421(ModItems.BREAD_BOOTS);
                            }

                            // --- Sweet Berries ---
                            if (Config.sweetBerryEnabled) {
                                entries.method_45421(ModItems.SWEET_BERRY_SWORD);
                                entries.method_45421(ModItems.SWEET_BERRY_PICKAXE);
                                entries.method_45421(ModItems.SWEET_BERRY_SHOVEL);
                                entries.method_45421(ModItems.SWEET_BERRY_AXE);
                                entries.method_45421(ModItems.SWEET_BERRY_HOE);
                                entries.method_45421(ModItems.SWEET_BERRY_HELMET);
                                entries.method_45421(ModItems.SWEET_BERRY_CHESTPLATE);
                                entries.method_45421(ModItems.SWEET_BERRY_LEGGINGS);
                                entries.method_45421(ModItems.SWEET_BERRY_BOOTS);
                            }

                            // --- Pumpkin Pie ---
                            if (Config.pumpkinPieEnabled) {
                                entries.method_45421(ModItems.PUMPKIN_PIE_SWORD);
                                entries.method_45421(ModItems.PUMPKIN_PIE_PICKAXE);
                                entries.method_45421(ModItems.PUMPKIN_PIE_SHOVEL);
                                entries.method_45421(ModItems.PUMPKIN_PIE_AXE);
                                entries.method_45421(ModItems.PUMPKIN_PIE_HOE);
                                entries.method_45421(ModItems.PUMPKIN_PIE_HELMET);
                                entries.method_45421(ModItems.PUMPKIN_PIE_CHESTPLATE);
                                entries.method_45421(ModItems.PUMPKIN_PIE_LEGGINGS);
                                entries.method_45421(ModItems.PUMPKIN_PIE_BOOTS);
                            }

                            // --- Melon ---
                            if (Config.melonEnabled) {
                                entries.method_45421(ModItems.MELON_SWORD);
                                entries.method_45421(ModItems.MELON_PICKAXE);
                                entries.method_45421(ModItems.MELON_SHOVEL);
                                entries.method_45421(ModItems.MELON_AXE);
                                entries.method_45421(ModItems.MELON_HOE);
                                entries.method_45421(ModItems.MELON_HELMET);
                                entries.method_45421(ModItems.MELON_CHESTPLATE);
                                entries.method_45421(ModItems.MELON_LEGGINGS);
                                entries.method_45421(ModItems.MELON_BOOTS);
                            }

                            // --- Mushroom ---
                            if (Config.mushroomEnabled) {
                                entries.method_45421(ModItems.MUSHROOM_SWORD);
                                entries.method_45421(ModItems.MUSHROOM_PICKAXE);
                                entries.method_45421(ModItems.MUSHROOM_SHOVEL);
                                entries.method_45421(ModItems.MUSHROOM_AXE);
                                entries.method_45421(ModItems.MUSHROOM_HOE);
                                entries.method_45421(ModItems.MUSHROOM_HELMET);
                                entries.method_45421(ModItems.MUSHROOM_CHESTPLATE);
                                entries.method_45421(ModItems.MUSHROOM_LEGGINGS);
                                entries.method_45421(ModItems.MUSHROOM_BOOTS);
                            }

                            // --- Pufferfish ---
                            if (Config.pufferfishEnabled) {
                                entries.method_45421(ModItems.PUFFERFISH_SWORD);
                                entries.method_45421(ModItems.PUFFERFISH_PICKAXE);
                                entries.method_45421(ModItems.PUFFERFISH_SHOVEL);
                                entries.method_45421(ModItems.PUFFERFISH_AXE);
                                entries.method_45421(ModItems.PUFFERFISH_HOE);
                                entries.method_45421(ModItems.PUFFERFISH_HELMET);
                                entries.method_45421(ModItems.PUFFERFISH_CHESTPLATE);
                                entries.method_45421(ModItems.PUFFERFISH_LEGGINGS);
                                entries.method_45421(ModItems.PUFFERFISH_BOOTS);
                            }

                            // --- Honey ---
                            if (Config.honeyEnabled) {
                                entries.method_45421(ModItems.HONEY_SWORD);
                                entries.method_45421(ModItems.HONEY_PICKAXE);
                                entries.method_45421(ModItems.HONEY_SHOVEL);
                                entries.method_45421(ModItems.HONEY_AXE);
                                entries.method_45421(ModItems.HONEY_HOE);
                                entries.method_45421(ModItems.HONEY_HELMET);
                                entries.method_45421(ModItems.HONEY_CHESTPLATE);
                                entries.method_45421(ModItems.HONEY_LEGGINGS);
                                entries.method_45421(ModItems.HONEY_BOOTS);
                            }

                            // --- Chorus Fruit ---
                            if (Config.chorusFruitEnabled) {
                                entries.method_45421(ModItems.CHORUS_FRUIT_SWORD);
                                entries.method_45421(ModItems.CHORUS_FRUIT_PICKAXE);
                                entries.method_45421(ModItems.CHORUS_FRUIT_SHOVEL);
                                entries.method_45421(ModItems.CHORUS_FRUIT_AXE);
                                entries.method_45421(ModItems.CHORUS_FRUIT_HOE);
                                entries.method_45421(ModItems.CHORUS_FRUIT_HELMET);
                                entries.method_45421(ModItems.CHORUS_FRUIT_CHESTPLATE);
                                entries.method_45421(ModItems.CHORUS_FRUIT_LEGGINGS);
                                entries.method_45421(ModItems.CHORUS_FRUIT_BOOTS);
                            }

                            // --- Golden Apple ---
                            if (Config.goldenAppleEnabled) {
                                entries.method_45421(ModItems.GOLDEN_APPLE_SWORD);
                                entries.method_45421(ModItems.GOLDEN_APPLE_PICKAXE);
                                entries.method_45421(ModItems.GOLDEN_APPLE_SHOVEL);
                                entries.method_45421(ModItems.GOLDEN_APPLE_AXE);
                                entries.method_45421(ModItems.GOLDEN_APPLE_HOE);
                                entries.method_45421(ModItems.GOLDEN_APPLE_HELMET);
                                entries.method_45421(ModItems.GOLDEN_APPLE_CHESTPLATE);
                                entries.method_45421(ModItems.GOLDEN_APPLE_LEGGINGS);
                                entries.method_45421(ModItems.GOLDEN_APPLE_BOOTS);
                            }

                            // =============================================================
                            //  VANILLA MATERIAL SETS (25 sets, ordered by power tier)
                            // =============================================================

                            // --- Paper (tools only) ---
                            if (Config.paperEnabled) {
                                entries.method_45421(ModItems.PAPER_SWORD);
                                entries.method_45421(ModItems.PAPER_PICKAXE);
                                entries.method_45421(ModItems.PAPER_SHOVEL);
                                entries.method_45421(ModItems.PAPER_AXE);
                                entries.method_45421(ModItems.PAPER_HOE);
                            }

                            // --- Feather (tools only) ---
                            if (Config.featherEnabled) {
                                entries.method_45421(ModItems.FEATHER_SWORD);
                                entries.method_45421(ModItems.FEATHER_PICKAXE);
                                entries.method_45421(ModItems.FEATHER_SHOVEL);
                                entries.method_45421(ModItems.FEATHER_AXE);
                                entries.method_45421(ModItems.FEATHER_HOE);
                            }

                            // --- Glass (tools only) ---
                            if (Config.glassEnabled) {
                                entries.method_45421(ModItems.GLASS_SWORD);
                                entries.method_45421(ModItems.GLASS_PICKAXE);
                                entries.method_45421(ModItems.GLASS_SHOVEL);
                                entries.method_45421(ModItems.GLASS_AXE);
                                entries.method_45421(ModItems.GLASS_HOE);
                            }

                            // --- Rabbit Hide (armor only) ---
                            if (Config.rabbitHideEnabled) {
                                entries.method_45421(ModItems.RABBIT_HIDE_HELMET);
                                entries.method_45421(ModItems.RABBIT_HIDE_CHESTPLATE);
                                entries.method_45421(ModItems.RABBIT_HIDE_LEGGINGS);
                                entries.method_45421(ModItems.RABBIT_HIDE_BOOTS);
                            }

                            // --- Cactus (tools + armor) ---
                            if (Config.cactusEnabled) {
                                entries.method_45421(ModItems.CACTUS_SWORD);
                                entries.method_45421(ModItems.CACTUS_PICKAXE);
                                entries.method_45421(ModItems.CACTUS_SHOVEL);
                                entries.method_45421(ModItems.CACTUS_AXE);
                                entries.method_45421(ModItems.CACTUS_HOE);
                                entries.method_45421(ModItems.CACTUS_HELMET);
                                entries.method_45421(ModItems.CACTUS_CHESTPLATE);
                                entries.method_45421(ModItems.CACTUS_LEGGINGS);
                                entries.method_45421(ModItems.CACTUS_BOOTS);
                            }

                            // --- Sponge (tools only) ---
                            if (Config.spongeEnabled) {
                                entries.method_45421(ModItems.SPONGE_SWORD);
                                entries.method_45421(ModItems.SPONGE_PICKAXE);
                                entries.method_45421(ModItems.SPONGE_SHOVEL);
                                entries.method_45421(ModItems.SPONGE_AXE);
                                entries.method_45421(ModItems.SPONGE_HOE);
                            }

                            // --- Bone (tools + armor) ---
                            if (Config.boneEnabled) {
                                entries.method_45421(ModItems.BONE_SWORD);
                                entries.method_45421(ModItems.BONE_PICKAXE);
                                entries.method_45421(ModItems.BONE_SHOVEL);
                                entries.method_45421(ModItems.BONE_AXE);
                                entries.method_45421(ModItems.BONE_HOE);
                                entries.method_45421(ModItems.BONE_HELMET);
                                entries.method_45421(ModItems.BONE_CHESTPLATE);
                                entries.method_45421(ModItems.BONE_LEGGINGS);
                                entries.method_45421(ModItems.BONE_BOOTS);
                            }

                            // --- Clay (tools + armor) ---
                            if (Config.clayEnabled) {
                                entries.method_45421(ModItems.CLAY_SWORD);
                                entries.method_45421(ModItems.CLAY_PICKAXE);
                                entries.method_45421(ModItems.CLAY_SHOVEL);
                                entries.method_45421(ModItems.CLAY_AXE);
                                entries.method_45421(ModItems.CLAY_HOE);
                                entries.method_45421(ModItems.CLAY_HELMET);
                                entries.method_45421(ModItems.CLAY_CHESTPLATE);
                                entries.method_45421(ModItems.CLAY_LEGGINGS);
                                entries.method_45421(ModItems.CLAY_BOOTS);
                            }

                            // --- Nether Wart (tools only) ---
                            if (Config.netherWartEnabled) {
                                entries.method_45421(ModItems.NETHER_WART_SWORD);
                                entries.method_45421(ModItems.NETHER_WART_PICKAXE);
                                entries.method_45421(ModItems.NETHER_WART_SHOVEL);
                                entries.method_45421(ModItems.NETHER_WART_AXE);
                                entries.method_45421(ModItems.NETHER_WART_HOE);
                            }

                            // --- Brick (tools + armor) ---
                            if (Config.brickEnabled) {
                                entries.method_45421(ModItems.BRICK_SWORD);
                                entries.method_45421(ModItems.BRICK_PICKAXE);
                                entries.method_45421(ModItems.BRICK_SHOVEL);
                                entries.method_45421(ModItems.BRICK_AXE);
                                entries.method_45421(ModItems.BRICK_HOE);
                                entries.method_45421(ModItems.BRICK_HELMET);
                                entries.method_45421(ModItems.BRICK_CHESTPLATE);
                                entries.method_45421(ModItems.BRICK_LEGGINGS);
                                entries.method_45421(ModItems.BRICK_BOOTS);
                            }

                            // --- Nether Brick (tools + armor) ---
                            if (Config.netherBrickEnabled) {
                                entries.method_45421(ModItems.NETHER_BRICK_SWORD);
                                entries.method_45421(ModItems.NETHER_BRICK_PICKAXE);
                                entries.method_45421(ModItems.NETHER_BRICK_SHOVEL);
                                entries.method_45421(ModItems.NETHER_BRICK_AXE);
                                entries.method_45421(ModItems.NETHER_BRICK_HOE);
                                entries.method_45421(ModItems.NETHER_BRICK_HELMET);
                                entries.method_45421(ModItems.NETHER_BRICK_CHESTPLATE);
                                entries.method_45421(ModItems.NETHER_BRICK_LEGGINGS);
                                entries.method_45421(ModItems.NETHER_BRICK_BOOTS);
                            }

                            // --- Pointed Dripstone (tools only) ---
                            if (Config.pointedDripstoneEnabled) {
                                entries.method_45421(ModItems.POINTED_DRIPSTONE_SWORD);
                                entries.method_45421(ModItems.POINTED_DRIPSTONE_PICKAXE);
                                entries.method_45421(ModItems.POINTED_DRIPSTONE_SHOVEL);
                                entries.method_45421(ModItems.POINTED_DRIPSTONE_AXE);
                                entries.method_45421(ModItems.POINTED_DRIPSTONE_HOE);
                            }

                            // --- Copper (tools + armor) ---
                            if (Config.copperEnabled) {
                                entries.method_45421(ModItems.COPPER_SWORD);
                                entries.method_45421(ModItems.COPPER_PICKAXE);
                                entries.method_45421(ModItems.COPPER_SHOVEL);
                                entries.method_45421(ModItems.COPPER_AXE);
                                entries.method_45421(ModItems.COPPER_HOE);
                                entries.method_45421(ModItems.COPPER_HELMET);
                                entries.method_45421(ModItems.COPPER_CHESTPLATE);
                                entries.method_45421(ModItems.COPPER_LEGGINGS);
                                entries.method_45421(ModItems.COPPER_BOOTS);
                            }

                            // --- Phantom Membrane (tools + armor) ---
                            if (Config.phantomEnabled) {
                                entries.method_45421(ModItems.PHANTOM_SWORD);
                                entries.method_45421(ModItems.PHANTOM_PICKAXE);
                                entries.method_45421(ModItems.PHANTOM_SHOVEL);
                                entries.method_45421(ModItems.PHANTOM_AXE);
                                entries.method_45421(ModItems.PHANTOM_HOE);
                                entries.method_45421(ModItems.PHANTOM_HELMET);
                                entries.method_45421(ModItems.PHANTOM_CHESTPLATE);
                                entries.method_45421(ModItems.PHANTOM_LEGGINGS);
                                entries.method_45421(ModItems.PHANTOM_BOOTS);
                            }

                            // --- Magma Cream (tools + armor) ---
                            if (Config.magmaCreamEnabled) {
                                entries.method_45421(ModItems.MAGMA_CREAM_SWORD);
                                entries.method_45421(ModItems.MAGMA_CREAM_PICKAXE);
                                entries.method_45421(ModItems.MAGMA_CREAM_SHOVEL);
                                entries.method_45421(ModItems.MAGMA_CREAM_AXE);
                                entries.method_45421(ModItems.MAGMA_CREAM_HOE);
                                entries.method_45421(ModItems.MAGMA_CREAM_HELMET);
                                entries.method_45421(ModItems.MAGMA_CREAM_CHESTPLATE);
                                entries.method_45421(ModItems.MAGMA_CREAM_LEGGINGS);
                                entries.method_45421(ModItems.MAGMA_CREAM_BOOTS);
                            }

                            // --- Slime (tools + armor) ---
                            if (Config.slimeEnabled) {
                                entries.method_45421(ModItems.SLIME_SWORD);
                                entries.method_45421(ModItems.SLIME_PICKAXE);
                                entries.method_45421(ModItems.SLIME_SHOVEL);
                                entries.method_45421(ModItems.SLIME_AXE);
                                entries.method_45421(ModItems.SLIME_HOE);
                                entries.method_45421(ModItems.SLIME_HELMET);
                                entries.method_45421(ModItems.SLIME_CHESTPLATE);
                                entries.method_45421(ModItems.SLIME_LEGGINGS);
                                entries.method_45421(ModItems.SLIME_BOOTS);
                            }

                            // --- Blaze Rod (tools + armor) ---
                            if (Config.blazeEnabled) {
                                entries.method_45421(ModItems.BLAZE_SWORD);
                                entries.method_45421(ModItems.BLAZE_PICKAXE);
                                entries.method_45421(ModItems.BLAZE_SHOVEL);
                                entries.method_45421(ModItems.BLAZE_AXE);
                                entries.method_45421(ModItems.BLAZE_HOE);
                                entries.method_45421(ModItems.BLAZE_HELMET);
                                entries.method_45421(ModItems.BLAZE_CHESTPLATE);
                                entries.method_45421(ModItems.BLAZE_LEGGINGS);
                                entries.method_45421(ModItems.BLAZE_BOOTS);
                            }

                            // --- Nautilus Shell (tools + armor) ---
                            if (Config.nautilusEnabled) {
                                entries.method_45421(ModItems.NAUTILUS_SWORD);
                                entries.method_45421(ModItems.NAUTILUS_PICKAXE);
                                entries.method_45421(ModItems.NAUTILUS_SHOVEL);
                                entries.method_45421(ModItems.NAUTILUS_AXE);
                                entries.method_45421(ModItems.NAUTILUS_HOE);
                                entries.method_45421(ModItems.NAUTILUS_HELMET);
                                entries.method_45421(ModItems.NAUTILUS_CHESTPLATE);
                                entries.method_45421(ModItems.NAUTILUS_LEGGINGS);
                                entries.method_45421(ModItems.NAUTILUS_BOOTS);
                            }

                            // --- Purpur (tools + armor) ---
                            if (Config.purpurEnabled) {
                                entries.method_45421(ModItems.PURPUR_SWORD);
                                entries.method_45421(ModItems.PURPUR_PICKAXE);
                                entries.method_45421(ModItems.PURPUR_SHOVEL);
                                entries.method_45421(ModItems.PURPUR_AXE);
                                entries.method_45421(ModItems.PURPUR_HOE);
                                entries.method_45421(ModItems.PURPUR_HELMET);
                                entries.method_45421(ModItems.PURPUR_CHESTPLATE);
                                entries.method_45421(ModItems.PURPUR_LEGGINGS);
                                entries.method_45421(ModItems.PURPUR_BOOTS);
                            }

                            // --- Ghast Tear (tools + armor) ---
                            if (Config.ghastTearEnabled) {
                                entries.method_45421(ModItems.GHAST_TEAR_SWORD);
                                entries.method_45421(ModItems.GHAST_TEAR_PICKAXE);
                                entries.method_45421(ModItems.GHAST_TEAR_SHOVEL);
                                entries.method_45421(ModItems.GHAST_TEAR_AXE);
                                entries.method_45421(ModItems.GHAST_TEAR_HOE);
                                entries.method_45421(ModItems.GHAST_TEAR_HELMET);
                                entries.method_45421(ModItems.GHAST_TEAR_CHESTPLATE);
                                entries.method_45421(ModItems.GHAST_TEAR_LEGGINGS);
                                entries.method_45421(ModItems.GHAST_TEAR_BOOTS);
                            }

                            // --- Eye of Ender (tools + armor) ---
                            if (Config.eyeOfEnderEnabled) {
                                entries.method_45421(ModItems.EYE_OF_ENDER_SWORD);
                                entries.method_45421(ModItems.EYE_OF_ENDER_PICKAXE);
                                entries.method_45421(ModItems.EYE_OF_ENDER_SHOVEL);
                                entries.method_45421(ModItems.EYE_OF_ENDER_AXE);
                                entries.method_45421(ModItems.EYE_OF_ENDER_HOE);
                                entries.method_45421(ModItems.EYE_OF_ENDER_HELMET);
                                entries.method_45421(ModItems.EYE_OF_ENDER_CHESTPLATE);
                                entries.method_45421(ModItems.EYE_OF_ENDER_LEGGINGS);
                                entries.method_45421(ModItems.EYE_OF_ENDER_BOOTS);
                            }

                            // --- Shulker Shell (tools + armor) ---
                            if (Config.shulkerEnabled) {
                                entries.method_45421(ModItems.SHULKER_SWORD);
                                entries.method_45421(ModItems.SHULKER_PICKAXE);
                                entries.method_45421(ModItems.SHULKER_SHOVEL);
                                entries.method_45421(ModItems.SHULKER_AXE);
                                entries.method_45421(ModItems.SHULKER_HOE);
                                entries.method_45421(ModItems.SHULKER_HELMET);
                                entries.method_45421(ModItems.SHULKER_CHESTPLATE);
                                entries.method_45421(ModItems.SHULKER_LEGGINGS);
                                entries.method_45421(ModItems.SHULKER_BOOTS);
                            }

                            // --- Turtle Scute (armor only) ---
                            if (Config.turtleScuteEnabled) {
                                entries.method_45421(ModItems.TURTLE_SCUTE_HELMET);
                                entries.method_45421(ModItems.TURTLE_SCUTE_CHESTPLATE);
                                entries.method_45421(ModItems.TURTLE_SCUTE_LEGGINGS);
                                entries.method_45421(ModItems.TURTLE_SCUTE_BOOTS);
                            }

                            // --- Echo Shard (tools + armor) ---
                            if (Config.echoShardEnabled) {
                                entries.method_45421(ModItems.ECHO_SHARD_SWORD);
                                entries.method_45421(ModItems.ECHO_SHARD_PICKAXE);
                                entries.method_45421(ModItems.ECHO_SHARD_SHOVEL);
                                entries.method_45421(ModItems.ECHO_SHARD_AXE);
                                entries.method_45421(ModItems.ECHO_SHARD_HOE);
                                entries.method_45421(ModItems.ECHO_SHARD_HELMET);
                                entries.method_45421(ModItems.ECHO_SHARD_CHESTPLATE);
                                entries.method_45421(ModItems.ECHO_SHARD_LEGGINGS);
                                entries.method_45421(ModItems.ECHO_SHARD_BOOTS);
                            }

                            // --- Dragon's Breath (tools + armor) ---
                            if (Config.dragonBreathEnabled) {
                                entries.method_45421(ModItems.DRAGON_BREATH_SWORD);
                                entries.method_45421(ModItems.DRAGON_BREATH_PICKAXE);
                                entries.method_45421(ModItems.DRAGON_BREATH_SHOVEL);
                                entries.method_45421(ModItems.DRAGON_BREATH_AXE);
                                entries.method_45421(ModItems.DRAGON_BREATH_HOE);
                                entries.method_45421(ModItems.DRAGON_BREATH_HELMET);
                                entries.method_45421(ModItems.DRAGON_BREATH_CHESTPLATE);
                                entries.method_45421(ModItems.DRAGON_BREATH_LEGGINGS);
                                entries.method_45421(ModItems.DRAGON_BREATH_BOOTS);
                            }

                        })
                        .method_47324());

        // Also add to vanilla tabs
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(content -> {
            if (Config.ferrousGoldEnabled) {
                content.method_45421(ModItems.RGOLD);
                content.method_45421(ModItems.RAW_RGOLD);
            }
            if (Config.obsidianEnabled) {
                content.method_45421(ModItems.OBSHARD);
                content.method_45421(ModItems.OBINGOT);
            }
            if (Config.emeraldEnabled) {
                content.method_45421(ModItems.SEM);
            }
            if (Config.hardenedRedstoneEnabled) {
                content.method_45421(ModItems.HRED);
            }
            if (Config.hardenedGlowstoneEnabled) {
                content.method_45421(ModItems.HGLOW);
            }
            if (Config.lapisEnabled) {
                content.method_45421(ModItems.RLAPIS);
            }
            if (Config.coalEnabled) {
                content.method_45421(ModItems.COAL_DUST);
                content.method_45421(ModItems.HARDENED_COAL);
            }
            if (Config.roughCrystalEnabled || Config.polishedCrystalEnabled) {
                content.method_45421(ModItems.CALCIFIED_AMETHYST);
                content.method_45421(ModItems.POLISHED_QUARTZ);
            }
            if (Config.iceEnabled || Config.snowEnabled) {
                content.method_45421(ModItems.GLACIAL_SHARD);
            }
            if (Config.roughCrystalEnabled || Config.pprismEnabled) {
                content.method_45421(ModItems.POLISHED_PRISMARINE);
            }
            if (Config.ghostEnabled) {
                content.method_45421(ModItems.ECTOPLASM);
            }
            if (Config.ectoplasmSetEnabled) {
                content.method_45421(ModItems.REFINED_ECTOPLASM);
            }
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202).register(content -> {
            if (Config.explosivesEnabled) {
                content.method_45421(ModItems.GRENADE);
                content.method_45421(ModItems.DYNAMITE);
            }
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(content -> {
            if (Config.ferrousGoldEnabled) {
                content.method_45421(ModBlocks.RGOLDBLOCK);
                content.method_45421(ModBlocks.RAW_RGOLD_BLOCK);
            }
            if (Config.hardenedRedstoneEnabled) {
                content.method_45421(ModBlocks.HRBLOCK);
            }
            if (Config.hardenedGlowstoneEnabled) {
                content.method_45421(ModBlocks.HGLOW_BLOCK);
            }
            if (Config.emeraldEnabled) {
                content.method_45421(ModBlocks.SEMBLOCK);
            }
            if (Config.obsidianEnabled) {
                content.method_45421(ModBlocks.SOBLOCK);
                content.method_45421(ModBlocks.OBSHARD_BLOCK);
            }
            if (Config.lapisEnabled) {
                content.method_45421(ModBlocks.LBLOCK);
            }
            if (Config.coalEnabled) {
                content.method_45421(ModBlocks.COAL_DUST_BLOCK);
                content.method_45421(ModBlocks.HARDENED_COAL_BLOCK);
            }
            if (Config.roughCrystalEnabled || Config.polishedCrystalEnabled) {
                content.method_45421(ModBlocks.CALCIFIED_AMETHYST_BLOCK);
                content.method_45421(ModBlocks.POLISHED_QUARTZ_BLOCK);
            }
            if (Config.iceEnabled || Config.snowEnabled) {
                content.method_45421(ModBlocks.GLACIAL_SHARD_BLOCK);
            }
            if (Config.roughCrystalEnabled || Config.pprismEnabled) {
                content.method_45421(ModBlocks.POLISHED_PRISMARINE_BLOCK);
            }
            if (Config.ectoplasmSetEnabled) {
                content.method_45421(ModBlocks.ECTOPLASM_BLOCK);
                content.method_45421(ModBlocks.REFINED_ECTOPLASM_BLOCK);
            }
            if (Config.spectralInfuserEnabled) {
                content.method_45421(ModBlocks.SPECTRAL_INFUSER);
            }
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40743).register(content -> {
            if (Config.ferrousGoldEnabled) {
                content.method_45421(ModBlocks.RGOLDORE);
                content.method_45421(ModBlocks.RGOLD_DEEPSLATE_ORE);
                content.method_45421(ModBlocks.RGOLD_END_ORE);
                content.method_45421(ModBlocks.RGOLD_NETHER_ORE);
            }
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(content -> {
            if (Config.ghostEnabled) {
                content.method_45421(ModItems.GHOST_SPAWN_EGG);
            }
        });
    }
}
