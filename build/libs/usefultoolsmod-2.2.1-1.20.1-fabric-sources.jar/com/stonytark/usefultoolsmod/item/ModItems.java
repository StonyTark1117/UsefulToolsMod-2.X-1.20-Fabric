package com.stonytark.usefultoolsmod.item;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.entity.ModEntities;
import com.stonytark.usefultoolsmod.item.custom.*;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1826;
import net.minecraft.class_1829;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_7923;
import net.minecraft.item.*;

public class ModItems {
    public static class_1792 RGOLD;
    public static class_1792 RAW_RGOLD;
    public static class_1792 OBSHARD;
    public static class_1792 SEM;
    public static class_1792 OBINGOT;
    public static class_1792 GRENADE;
    public static class_1792 HRED;
    public static class_1792 HGLOW;
    public static class_1792 RLAPIS;
    public static class_1792 DYNAMITE;
    public static class_1792 REMERALD_SWORD;
    public static class_1792 REMERALD_PICKAXE;
    public static class_1792 REMERALD_SHOVEL;
    public static class_1792 REMERALD_AXE;
    public static class_1792 REMERALD_HOE;
    public static class_1792 PEMERALD_SWORD;
    public static class_1792 PEMERALD_PICKAXE;
    public static class_1792 PEMERALD_SHOVEL;
    public static class_1792 PEMERALD_AXE;
    public static class_1792 PEMERALD_HOE;
    public static class_1792 ROBSIDIAN_SWORD;
    public static class_1792 ROBSIDIAN_PICKAXE;
    public static class_1792 ROBSIDIAN_SHOVEL;
    public static class_1792 ROBSIDIAN_AXE;
    public static class_1792 ROBSIDIAN_HOE;
    public static class_1792 POBSIDIAN_SWORD;
    public static class_1792 POBSIDIAN_PICKAXE;
    public static class_1792 POBSIDIAN_SHOVEL;
    public static class_1792 POBSIDIAN_AXE;
    public static class_1792 POBSIDIAN_HOE;
    public static class_1792 OVERPOWER_SWORD;
    public static class_1792 OVERPOWER_PICKAXE;
    public static class_1792 OVERPOWER_SHOVEL;
    public static class_1792 OVERPOWER_AXE;
    public static class_1792 HREDSTONE_SWORD;
    public static class_1792 HREDSTONE_PICKAXE;
    public static class_1792 HREDSTONE_SHOVEL;
    public static class_1792 HREDSTONE_AXE;
    public static class_1792 HREDSTONE_HOE;
    public static class_1792 HGLOWSTONE_SWORD;
    public static class_1792 HGLOWSTONE_PICKAXE;
    public static class_1792 HGLOWSTONE_SHOVEL;
    public static class_1792 HGLOWSTONE_AXE;
    public static class_1792 HGLOWSTONE_HOE;
    public static class_1792 RGOLD_SWORD;
    public static class_1792 RGOLD_PICKAXE;
    public static class_1792 RGOLD_SHOVEL;
    public static class_1792 RGOLD_AXE;
    public static class_1792 RGOLD_HOE;
    public static class_1792 RLAPIS_SWORD;
    public static class_1792 RLAPIS_PICKAXE;
    public static class_1792 RLAPIS_SHOVEL;
    public static class_1792 RLAPIS_AXE;
    public static class_1792 RLAPIS_HOE;
    public static class_1792 EMERALD_HELMET;
    public static class_1792 EMERALD_CHESTPLATE;
    public static class_1792 EMERALD_LEGGINGS;
    public static class_1792 EMERALD_BOOTS;
    public static class_1792 HRED_HELMET;
    public static class_1792 HRED_CHESTPLATE;
    public static class_1792 HRED_LEGGINGS;
    public static class_1792 HRED_BOOTS;
    public static class_1792 HGLOW_HELMET;
    public static class_1792 HGLOW_CHESTPLATE;
    public static class_1792 HGLOW_LEGGINGS;
    public static class_1792 HGLOW_BOOTS;
    public static class_1792 OBSIDIAN_HELMET;
    public static class_1792 OBSIDIAN_CHESTPLATE;
    public static class_1792 OBSIDIAN_LEGGINGS;
    public static class_1792 OBSIDIAN_BOOTS;
    public static class_1792 RGOLD_HELMET;
    public static class_1792 RGOLD_CHESTPLATE;
    public static class_1792 RGOLD_LEGGINGS;
    public static class_1792 RGOLD_BOOTS;
    public static class_1792 RLAPIS_HELMET;
    public static class_1792 RLAPIS_CHESTPLATE;
    public static class_1792 RLAPIS_LEGGINGS;
    public static class_1792 RLAPIS_BOOTS;
    public static class_1792 OVERPOWER_HELMET;
    public static class_1792 OVERPOWER_CHESTPLATE;
    public static class_1792 OVERPOWER_LEGGINGS;
    public static class_1792 OVERPOWER_BOOTS;
    public static class_1792 GHOST_SPAWN_EGG;
    public static class_1792 ECTOPLASM;
    public static class_1792 RECTO_SWORD;
    public static class_1792 RECTO_PICKAXE;
    public static class_1792 RECTO_SHOVEL;
    public static class_1792 RECTO_AXE;
    public static class_1792 RECTO_HOE;
    public static class_1792 REFINED_ECTOPLASM;
    public static class_1792 ECTO_SWORD;
    public static class_1792 ECTO_PICKAXE;
    public static class_1792 ECTO_SHOVEL;
    public static class_1792 ECTO_AXE;
    public static class_1792 ECTO_HOE;
    public static class_1792 ECTO_HELMET;
    public static class_1792 ECTO_CHESTPLATE;
    public static class_1792 ECTO_LEGGINGS;
    public static class_1792 ECTO_BOOTS;
    public static class_1792 COAL_DUST;
    public static class_1792 HARDENED_COAL;
    public static class_1792 COAL_SWORD;
    public static class_1792 COAL_PICKAXE;
    public static class_1792 COAL_SHOVEL;
    public static class_1792 COAL_AXE;
    public static class_1792 COAL_HOE;
    public static class_1792 COAL_HELMET;
    public static class_1792 COAL_CHESTPLATE;
    public static class_1792 COAL_LEGGINGS;
    public static class_1792 COAL_BOOTS;
    public static class_1792 RRAW_GOLD_SWORD;
    public static class_1792 RRAW_GOLD_PICKAXE;
    public static class_1792 RRAW_GOLD_SHOVEL;
    public static class_1792 RRAW_GOLD_AXE;
    public static class_1792 RRAW_GOLD_HOE;
    public static class_1792 RRAW_COPPER_SWORD;
    public static class_1792 RRAW_COPPER_PICKAXE;
    public static class_1792 RRAW_COPPER_SHOVEL;
    public static class_1792 RRAW_COPPER_AXE;
    public static class_1792 RRAW_COPPER_HOE;
    public static class_1792 RRAW_IRON_SWORD;
    public static class_1792 RRAW_IRON_PICKAXE;
    public static class_1792 RRAW_IRON_SHOVEL;
    public static class_1792 RRAW_IRON_AXE;
    public static class_1792 RRAW_IRON_HOE;
    public static class_1792 RRAW_RGOLD_SWORD;
    public static class_1792 RRAW_RGOLD_PICKAXE;
    public static class_1792 RRAW_RGOLD_SHOVEL;
    public static class_1792 RRAW_RGOLD_AXE;
    public static class_1792 RRAW_RGOLD_HOE;
    public static class_1792 RSCRAP_SWORD;
    public static class_1792 RSCRAP_PICKAXE;
    public static class_1792 RSCRAP_SHOVEL;
    public static class_1792 RSCRAP_AXE;
    public static class_1792 RSCRAP_HOE;
    public static class_1792 CALCIFIED_AMETHYST;
    public static class_1792 GLACIAL_SHARD;
    public static class_1792 POLISHED_QUARTZ;
    public static class_1792 POLISHED_PRISMARINE;
    public static class_1792 RAMETHYST_SWORD;
    public static class_1792 RAMETHYST_PICKAXE;
    public static class_1792 RAMETHYST_SHOVEL;
    public static class_1792 RAMETHYST_AXE;
    public static class_1792 RAMETHYST_HOE;
    public static class_1792 SNOW_SWORD;
    public static class_1792 SNOW_PICKAXE;
    public static class_1792 SNOW_SHOVEL;
    public static class_1792 SNOW_AXE;
    public static class_1792 SNOW_HOE;
    public static class_1792 RQUARTZ_SWORD;
    public static class_1792 RQUARTZ_PICKAXE;
    public static class_1792 RQUARTZ_SHOVEL;
    public static class_1792 RQUARTZ_AXE;
    public static class_1792 RQUARTZ_HOE;
    public static class_1792 RPRISM_SWORD;
    public static class_1792 RPRISM_PICKAXE;
    public static class_1792 RPRISM_SHOVEL;
    public static class_1792 RPRISM_AXE;
    public static class_1792 RPRISM_HOE;
    public static class_1792 CAMETHYST_SWORD;
    public static class_1792 CAMETHYST_PICKAXE;
    public static class_1792 CAMETHYST_SHOVEL;
    public static class_1792 CAMETHYST_AXE;
    public static class_1792 CAMETHYST_HOE;
    public static class_1792 CAMETHYST_HELMET;
    public static class_1792 CAMETHYST_CHESTPLATE;
    public static class_1792 CAMETHYST_LEGGINGS;
    public static class_1792 CAMETHYST_BOOTS;
    public static class_1792 ICE_SWORD;
    public static class_1792 ICE_PICKAXE;
    public static class_1792 ICE_SHOVEL;
    public static class_1792 ICE_AXE;
    public static class_1792 ICE_HOE;
    public static class_1792 ICE_HELMET;
    public static class_1792 ICE_CHESTPLATE;
    public static class_1792 ICE_LEGGINGS;
    public static class_1792 ICE_BOOTS;
    public static class_1792 PQUARTZ_SWORD;
    public static class_1792 PQUARTZ_PICKAXE;
    public static class_1792 PQUARTZ_SHOVEL;
    public static class_1792 PQUARTZ_AXE;
    public static class_1792 PQUARTZ_HOE;
    public static class_1792 PQUARTZ_HELMET;
    public static class_1792 PQUARTZ_CHESTPLATE;
    public static class_1792 PQUARTZ_LEGGINGS;
    public static class_1792 PQUARTZ_BOOTS;
    public static class_1792 PPRISM_SWORD;
    public static class_1792 PPRISM_PICKAXE;
    public static class_1792 PPRISM_SHOVEL;
    public static class_1792 PPRISM_AXE;
    public static class_1792 PPRISM_HOE;
    public static class_1792 PPRISM_HELMET;
    public static class_1792 PPRISM_CHESTPLATE;
    public static class_1792 PPRISM_LEGGINGS;
    public static class_1792 PPRISM_BOOTS;
    public static class_1792 RFLINT_SWORD;
    public static class_1792 RFLINT_PICKAXE;
    public static class_1792 RFLINT_SHOVEL;
    public static class_1792 RFLINT_AXE;
    public static class_1792 RFLINT_HOE;
    public static class_1792 FNI_SWORD;
    public static class_1792 FNI_PICKAXE;
    public static class_1792 FNI_SHOVEL;
    public static class_1792 FNI_AXE;
    public static class_1792 FNI_HOE;
    public static class_1792 FNI_HELMET;
    public static class_1792 FNI_CHESTPLATE;
    public static class_1792 FNI_LEGGINGS;
    public static class_1792 FNI_BOOTS;
    public static class_1792 ANDESITE_SWORD;
    public static class_1792 ANDESITE_PICKAXE;
    public static class_1792 ANDESITE_SHOVEL;
    public static class_1792 ANDESITE_AXE;
    public static class_1792 ANDESITE_HOE;
    public static class_1792 BASALT_SWORD;
    public static class_1792 BASALT_PICKAXE;
    public static class_1792 BASALT_SHOVEL;
    public static class_1792 BASALT_AXE;
    public static class_1792 BASALT_HOE;
    public static class_1792 BLACKSTONE_SWORD;
    public static class_1792 BLACKSTONE_PICKAXE;
    public static class_1792 BLACKSTONE_SHOVEL;
    public static class_1792 BLACKSTONE_AXE;
    public static class_1792 BLACKSTONE_HOE;
    public static class_1792 CALCITE_SWORD;
    public static class_1792 CALCITE_PICKAXE;
    public static class_1792 CALCITE_SHOVEL;
    public static class_1792 CALCITE_AXE;
    public static class_1792 CALCITE_HOE;
    public static class_1792 DEEPSLATE_SWORD;
    public static class_1792 DEEPSLATE_PICKAXE;
    public static class_1792 DEEPSLATE_SHOVEL;
    public static class_1792 DEEPSLATE_AXE;
    public static class_1792 DEEPSLATE_HOE;
    public static class_1792 DIORITE_SWORD;
    public static class_1792 DIORITE_PICKAXE;
    public static class_1792 DIORITE_SHOVEL;
    public static class_1792 DIORITE_AXE;
    public static class_1792 DIORITE_HOE;
    public static class_1792 END_STONE_SWORD;
    public static class_1792 END_STONE_PICKAXE;
    public static class_1792 END_STONE_SHOVEL;
    public static class_1792 END_STONE_AXE;
    public static class_1792 END_STONE_HOE;
    public static class_1792 GRANITE_SWORD;
    public static class_1792 GRANITE_PICKAXE;
    public static class_1792 GRANITE_SHOVEL;
    public static class_1792 GRANITE_AXE;
    public static class_1792 GRANITE_HOE;
    public static class_1792 NETHERRACK_SWORD;
    public static class_1792 NETHERRACK_PICKAXE;
    public static class_1792 NETHERRACK_SHOVEL;
    public static class_1792 NETHERRACK_AXE;
    public static class_1792 NETHERRACK_HOE;
    public static class_1792 SANDSTONE_SWORD;
    public static class_1792 SANDSTONE_PICKAXE;
    public static class_1792 SANDSTONE_SHOVEL;
    public static class_1792 SANDSTONE_AXE;
    public static class_1792 SANDSTONE_HOE;
    public static class_1792 SMOOTH_BASALT_SWORD;
    public static class_1792 SMOOTH_BASALT_PICKAXE;
    public static class_1792 SMOOTH_BASALT_SHOVEL;
    public static class_1792 SMOOTH_BASALT_AXE;
    public static class_1792 SMOOTH_BASALT_HOE;
    public static class_1792 TERRACOTTA_SWORD;
    public static class_1792 TERRACOTTA_PICKAXE;
    public static class_1792 TERRACOTTA_SHOVEL;
    public static class_1792 TERRACOTTA_AXE;
    public static class_1792 TERRACOTTA_HOE;
    public static class_1792 TUFF_SWORD;
    public static class_1792 TUFF_PICKAXE;
    public static class_1792 TUFF_SHOVEL;
    public static class_1792 TUFF_AXE;
    public static class_1792 TUFF_HOE;
    public static class_1792 OAK_SWORD;
    public static class_1792 OAK_PICKAXE;
    public static class_1792 OAK_SHOVEL;
    public static class_1792 OAK_AXE;
    public static class_1792 OAK_HOE;
    public static class_1792 SPRUCE_SWORD;
    public static class_1792 SPRUCE_PICKAXE;
    public static class_1792 SPRUCE_SHOVEL;
    public static class_1792 SPRUCE_AXE;
    public static class_1792 SPRUCE_HOE;
    public static class_1792 BIRCH_SWORD;
    public static class_1792 BIRCH_PICKAXE;
    public static class_1792 BIRCH_SHOVEL;
    public static class_1792 BIRCH_AXE;
    public static class_1792 BIRCH_HOE;
    public static class_1792 JUNGLE_SWORD;
    public static class_1792 JUNGLE_PICKAXE;
    public static class_1792 JUNGLE_SHOVEL;
    public static class_1792 JUNGLE_AXE;
    public static class_1792 JUNGLE_HOE;
    public static class_1792 ACACIA_SWORD;
    public static class_1792 ACACIA_PICKAXE;
    public static class_1792 ACACIA_SHOVEL;
    public static class_1792 ACACIA_AXE;
    public static class_1792 ACACIA_HOE;
    public static class_1792 DARK_OAK_SWORD;
    public static class_1792 DARK_OAK_PICKAXE;
    public static class_1792 DARK_OAK_SHOVEL;
    public static class_1792 DARK_OAK_AXE;
    public static class_1792 DARK_OAK_HOE;
    public static class_1792 MANGROVE_SWORD;
    public static class_1792 MANGROVE_PICKAXE;
    public static class_1792 MANGROVE_SHOVEL;
    public static class_1792 MANGROVE_AXE;
    public static class_1792 MANGROVE_HOE;
    public static class_1792 CHERRY_SWORD;
    public static class_1792 CHERRY_PICKAXE;
    public static class_1792 CHERRY_SHOVEL;
    public static class_1792 CHERRY_AXE;
    public static class_1792 CHERRY_HOE;
    public static class_1792 BAMBOO_SWORD;
    public static class_1792 BAMBOO_PICKAXE;
    public static class_1792 BAMBOO_SHOVEL;
    public static class_1792 BAMBOO_AXE;
    public static class_1792 BAMBOO_HOE;
    public static class_1792 CRIMSON_SWORD;
    public static class_1792 CRIMSON_PICKAXE;
    public static class_1792 CRIMSON_SHOVEL;
    public static class_1792 CRIMSON_AXE;
    public static class_1792 CRIMSON_HOE;
    public static class_1792 WARPED_SWORD;
    public static class_1792 WARPED_PICKAXE;
    public static class_1792 WARPED_SHOVEL;
    public static class_1792 WARPED_AXE;
    public static class_1792 WARPED_HOE;
    public static class_1792 LEATHER_SWORD;
    public static class_1792 LEATHER_PICKAXE;
    public static class_1792 LEATHER_SHOVEL;
    public static class_1792 LEATHER_AXE;
    public static class_1792 LEATHER_HOE;
    public static class_1792 PAPER_SWORD;
    public static class_1792 PAPER_PICKAXE;
    public static class_1792 PAPER_SHOVEL;
    public static class_1792 PAPER_AXE;
    public static class_1792 PAPER_HOE;
    public static class_1792 FEATHER_SWORD;
    public static class_1792 FEATHER_PICKAXE;
    public static class_1792 FEATHER_SHOVEL;
    public static class_1792 FEATHER_AXE;
    public static class_1792 FEATHER_HOE;
    public static class_1792 GLASS_SWORD;
    public static class_1792 GLASS_PICKAXE;
    public static class_1792 GLASS_SHOVEL;
    public static class_1792 GLASS_AXE;
    public static class_1792 GLASS_HOE;
    public static class_1792 RABBIT_HIDE_HELMET;
    public static class_1792 RABBIT_HIDE_CHESTPLATE;
    public static class_1792 RABBIT_HIDE_LEGGINGS;
    public static class_1792 RABBIT_HIDE_BOOTS;
    public static class_1792 CACTUS_SWORD;
    public static class_1792 CACTUS_PICKAXE;
    public static class_1792 CACTUS_SHOVEL;
    public static class_1792 CACTUS_AXE;
    public static class_1792 CACTUS_HOE;
    public static class_1792 CACTUS_HELMET;
    public static class_1792 CACTUS_CHESTPLATE;
    public static class_1792 CACTUS_LEGGINGS;
    public static class_1792 CACTUS_BOOTS;
    public static class_1792 SPONGE_SWORD;
    public static class_1792 SPONGE_PICKAXE;
    public static class_1792 SPONGE_SHOVEL;
    public static class_1792 SPONGE_AXE;
    public static class_1792 SPONGE_HOE;
    public static class_1792 BONE_SWORD;
    public static class_1792 BONE_PICKAXE;
    public static class_1792 BONE_SHOVEL;
    public static class_1792 BONE_AXE;
    public static class_1792 BONE_HOE;
    public static class_1792 BONE_HELMET;
    public static class_1792 BONE_CHESTPLATE;
    public static class_1792 BONE_LEGGINGS;
    public static class_1792 BONE_BOOTS;
    public static class_1792 CLAY_SWORD;
    public static class_1792 CLAY_PICKAXE;
    public static class_1792 CLAY_SHOVEL;
    public static class_1792 CLAY_AXE;
    public static class_1792 CLAY_HOE;
    public static class_1792 CLAY_HELMET;
    public static class_1792 CLAY_CHESTPLATE;
    public static class_1792 CLAY_LEGGINGS;
    public static class_1792 CLAY_BOOTS;
    public static class_1792 NETHER_WART_SWORD;
    public static class_1792 NETHER_WART_PICKAXE;
    public static class_1792 NETHER_WART_SHOVEL;
    public static class_1792 NETHER_WART_AXE;
    public static class_1792 NETHER_WART_HOE;
    public static class_1792 BRICK_SWORD;
    public static class_1792 BRICK_PICKAXE;
    public static class_1792 BRICK_SHOVEL;
    public static class_1792 BRICK_AXE;
    public static class_1792 BRICK_HOE;
    public static class_1792 BRICK_HELMET;
    public static class_1792 BRICK_CHESTPLATE;
    public static class_1792 BRICK_LEGGINGS;
    public static class_1792 BRICK_BOOTS;
    public static class_1792 NETHER_BRICK_SWORD;
    public static class_1792 NETHER_BRICK_PICKAXE;
    public static class_1792 NETHER_BRICK_SHOVEL;
    public static class_1792 NETHER_BRICK_AXE;
    public static class_1792 NETHER_BRICK_HOE;
    public static class_1792 NETHER_BRICK_HELMET;
    public static class_1792 NETHER_BRICK_CHESTPLATE;
    public static class_1792 NETHER_BRICK_LEGGINGS;
    public static class_1792 NETHER_BRICK_BOOTS;
    public static class_1792 POINTED_DRIPSTONE_SWORD;
    public static class_1792 POINTED_DRIPSTONE_PICKAXE;
    public static class_1792 POINTED_DRIPSTONE_SHOVEL;
    public static class_1792 POINTED_DRIPSTONE_AXE;
    public static class_1792 POINTED_DRIPSTONE_HOE;
    public static class_1792 COPPER_SWORD;
    public static class_1792 COPPER_PICKAXE;
    public static class_1792 COPPER_SHOVEL;
    public static class_1792 COPPER_AXE;
    public static class_1792 COPPER_HOE;
    public static class_1792 COPPER_HELMET;
    public static class_1792 COPPER_CHESTPLATE;
    public static class_1792 COPPER_LEGGINGS;
    public static class_1792 COPPER_BOOTS;
    public static class_1792 PHANTOM_SWORD;
    public static class_1792 PHANTOM_PICKAXE;
    public static class_1792 PHANTOM_SHOVEL;
    public static class_1792 PHANTOM_AXE;
    public static class_1792 PHANTOM_HOE;
    public static class_1792 PHANTOM_HELMET;
    public static class_1792 PHANTOM_CHESTPLATE;
    public static class_1792 PHANTOM_LEGGINGS;
    public static class_1792 PHANTOM_BOOTS;
    public static class_1792 MAGMA_CREAM_SWORD;
    public static class_1792 MAGMA_CREAM_PICKAXE;
    public static class_1792 MAGMA_CREAM_SHOVEL;
    public static class_1792 MAGMA_CREAM_AXE;
    public static class_1792 MAGMA_CREAM_HOE;
    public static class_1792 MAGMA_CREAM_HELMET;
    public static class_1792 MAGMA_CREAM_CHESTPLATE;
    public static class_1792 MAGMA_CREAM_LEGGINGS;
    public static class_1792 MAGMA_CREAM_BOOTS;
    public static class_1792 SLIME_SWORD;
    public static class_1792 SLIME_PICKAXE;
    public static class_1792 SLIME_SHOVEL;
    public static class_1792 SLIME_AXE;
    public static class_1792 SLIME_HOE;
    public static class_1792 SLIME_HELMET;
    public static class_1792 SLIME_CHESTPLATE;
    public static class_1792 SLIME_LEGGINGS;
    public static class_1792 SLIME_BOOTS;
    public static class_1792 BLAZE_SWORD;
    public static class_1792 BLAZE_PICKAXE;
    public static class_1792 BLAZE_SHOVEL;
    public static class_1792 BLAZE_AXE;
    public static class_1792 BLAZE_HOE;
    public static class_1792 BLAZE_HELMET;
    public static class_1792 BLAZE_CHESTPLATE;
    public static class_1792 BLAZE_LEGGINGS;
    public static class_1792 BLAZE_BOOTS;
    public static class_1792 NAUTILUS_SWORD;
    public static class_1792 NAUTILUS_PICKAXE;
    public static class_1792 NAUTILUS_SHOVEL;
    public static class_1792 NAUTILUS_AXE;
    public static class_1792 NAUTILUS_HOE;
    public static class_1792 NAUTILUS_HELMET;
    public static class_1792 NAUTILUS_CHESTPLATE;
    public static class_1792 NAUTILUS_LEGGINGS;
    public static class_1792 NAUTILUS_BOOTS;
    public static class_1792 PURPUR_SWORD;
    public static class_1792 PURPUR_PICKAXE;
    public static class_1792 PURPUR_SHOVEL;
    public static class_1792 PURPUR_AXE;
    public static class_1792 PURPUR_HOE;
    public static class_1792 PURPUR_HELMET;
    public static class_1792 PURPUR_CHESTPLATE;
    public static class_1792 PURPUR_LEGGINGS;
    public static class_1792 PURPUR_BOOTS;
    public static class_1792 GHAST_TEAR_SWORD;
    public static class_1792 GHAST_TEAR_PICKAXE;
    public static class_1792 GHAST_TEAR_SHOVEL;
    public static class_1792 GHAST_TEAR_AXE;
    public static class_1792 GHAST_TEAR_HOE;
    public static class_1792 GHAST_TEAR_HELMET;
    public static class_1792 GHAST_TEAR_CHESTPLATE;
    public static class_1792 GHAST_TEAR_LEGGINGS;
    public static class_1792 GHAST_TEAR_BOOTS;
    public static class_1792 EYE_OF_ENDER_SWORD;
    public static class_1792 EYE_OF_ENDER_PICKAXE;
    public static class_1792 EYE_OF_ENDER_SHOVEL;
    public static class_1792 EYE_OF_ENDER_AXE;
    public static class_1792 EYE_OF_ENDER_HOE;
    public static class_1792 EYE_OF_ENDER_HELMET;
    public static class_1792 EYE_OF_ENDER_CHESTPLATE;
    public static class_1792 EYE_OF_ENDER_LEGGINGS;
    public static class_1792 EYE_OF_ENDER_BOOTS;
    public static class_1792 SHULKER_SWORD;
    public static class_1792 SHULKER_PICKAXE;
    public static class_1792 SHULKER_SHOVEL;
    public static class_1792 SHULKER_AXE;
    public static class_1792 SHULKER_HOE;
    public static class_1792 SHULKER_HELMET;
    public static class_1792 SHULKER_CHESTPLATE;
    public static class_1792 SHULKER_LEGGINGS;
    public static class_1792 SHULKER_BOOTS;
    public static class_1792 TURTLE_SCUTE_HELMET;
    public static class_1792 TURTLE_SCUTE_CHESTPLATE;
    public static class_1792 TURTLE_SCUTE_LEGGINGS;
    public static class_1792 TURTLE_SCUTE_BOOTS;
    public static class_1792 ECHO_SHARD_SWORD;
    public static class_1792 ECHO_SHARD_PICKAXE;
    public static class_1792 ECHO_SHARD_SHOVEL;
    public static class_1792 ECHO_SHARD_AXE;
    public static class_1792 ECHO_SHARD_HOE;
    public static class_1792 ECHO_SHARD_HELMET;
    public static class_1792 ECHO_SHARD_CHESTPLATE;
    public static class_1792 ECHO_SHARD_LEGGINGS;
    public static class_1792 ECHO_SHARD_BOOTS;
    public static class_1792 DRAGON_BREATH_SWORD;
    public static class_1792 DRAGON_BREATH_PICKAXE;
    public static class_1792 DRAGON_BREATH_SHOVEL;
    public static class_1792 DRAGON_BREATH_AXE;
    public static class_1792 DRAGON_BREATH_HOE;
    public static class_1792 DRAGON_BREATH_HELMET;
    public static class_1792 DRAGON_BREATH_CHESTPLATE;
    public static class_1792 DRAGON_BREATH_LEGGINGS;
    public static class_1792 DRAGON_BREATH_BOOTS;
    public static class_1792 CAKE_SWORD;
    public static class_1792 CAKE_PICKAXE;
    public static class_1792 CAKE_SHOVEL;
    public static class_1792 CAKE_AXE;
    public static class_1792 CAKE_HOE;
    public static class_1792 CAKE_HELMET;
    public static class_1792 CAKE_CHESTPLATE;
    public static class_1792 CAKE_LEGGINGS;
    public static class_1792 CAKE_BOOTS;
    public static class_1792 BREAD_SWORD;
    public static class_1792 BREAD_PICKAXE;
    public static class_1792 BREAD_SHOVEL;
    public static class_1792 BREAD_AXE;
    public static class_1792 BREAD_HOE;
    public static class_1792 BREAD_HELMET;
    public static class_1792 BREAD_CHESTPLATE;
    public static class_1792 BREAD_LEGGINGS;
    public static class_1792 BREAD_BOOTS;
    public static class_1792 DRIED_KELP_SWORD;
    public static class_1792 DRIED_KELP_PICKAXE;
    public static class_1792 DRIED_KELP_SHOVEL;
    public static class_1792 DRIED_KELP_AXE;
    public static class_1792 DRIED_KELP_HOE;
    public static class_1792 DRIED_KELP_HELMET;
    public static class_1792 DRIED_KELP_CHESTPLATE;
    public static class_1792 DRIED_KELP_LEGGINGS;
    public static class_1792 DRIED_KELP_BOOTS;
    public static class_1792 ROTTEN_FLESH_SWORD;
    public static class_1792 ROTTEN_FLESH_PICKAXE;
    public static class_1792 ROTTEN_FLESH_SHOVEL;
    public static class_1792 ROTTEN_FLESH_AXE;
    public static class_1792 ROTTEN_FLESH_HOE;
    public static class_1792 ROTTEN_FLESH_HELMET;
    public static class_1792 ROTTEN_FLESH_CHESTPLATE;
    public static class_1792 ROTTEN_FLESH_LEGGINGS;
    public static class_1792 ROTTEN_FLESH_BOOTS;
    public static class_1792 MELON_SWORD;
    public static class_1792 MELON_PICKAXE;
    public static class_1792 MELON_SHOVEL;
    public static class_1792 MELON_AXE;
    public static class_1792 MELON_HOE;
    public static class_1792 MELON_HELMET;
    public static class_1792 MELON_CHESTPLATE;
    public static class_1792 MELON_LEGGINGS;
    public static class_1792 MELON_BOOTS;
    public static class_1792 SWEET_BERRY_SWORD;
    public static class_1792 SWEET_BERRY_PICKAXE;
    public static class_1792 SWEET_BERRY_SHOVEL;
    public static class_1792 SWEET_BERRY_AXE;
    public static class_1792 SWEET_BERRY_HOE;
    public static class_1792 SWEET_BERRY_HELMET;
    public static class_1792 SWEET_BERRY_CHESTPLATE;
    public static class_1792 SWEET_BERRY_LEGGINGS;
    public static class_1792 SWEET_BERRY_BOOTS;
    public static class_1792 PUMPKIN_PIE_SWORD;
    public static class_1792 PUMPKIN_PIE_PICKAXE;
    public static class_1792 PUMPKIN_PIE_SHOVEL;
    public static class_1792 PUMPKIN_PIE_AXE;
    public static class_1792 PUMPKIN_PIE_HOE;
    public static class_1792 PUMPKIN_PIE_HELMET;
    public static class_1792 PUMPKIN_PIE_CHESTPLATE;
    public static class_1792 PUMPKIN_PIE_LEGGINGS;
    public static class_1792 PUMPKIN_PIE_BOOTS;
    public static class_1792 MUSHROOM_SWORD;
    public static class_1792 MUSHROOM_PICKAXE;
    public static class_1792 MUSHROOM_SHOVEL;
    public static class_1792 MUSHROOM_AXE;
    public static class_1792 MUSHROOM_HOE;
    public static class_1792 MUSHROOM_HELMET;
    public static class_1792 MUSHROOM_CHESTPLATE;
    public static class_1792 MUSHROOM_LEGGINGS;
    public static class_1792 MUSHROOM_BOOTS;
    public static class_1792 PUFFERFISH_SWORD;
    public static class_1792 PUFFERFISH_PICKAXE;
    public static class_1792 PUFFERFISH_SHOVEL;
    public static class_1792 PUFFERFISH_AXE;
    public static class_1792 PUFFERFISH_HOE;
    public static class_1792 PUFFERFISH_HELMET;
    public static class_1792 PUFFERFISH_CHESTPLATE;
    public static class_1792 PUFFERFISH_LEGGINGS;
    public static class_1792 PUFFERFISH_BOOTS;
    public static class_1792 HONEY_SWORD;
    public static class_1792 HONEY_PICKAXE;
    public static class_1792 HONEY_SHOVEL;
    public static class_1792 HONEY_AXE;
    public static class_1792 HONEY_HOE;
    public static class_1792 HONEY_HELMET;
    public static class_1792 HONEY_CHESTPLATE;
    public static class_1792 HONEY_LEGGINGS;
    public static class_1792 HONEY_BOOTS;
    public static class_1792 CHORUS_FRUIT_SWORD;
    public static class_1792 CHORUS_FRUIT_PICKAXE;
    public static class_1792 CHORUS_FRUIT_SHOVEL;
    public static class_1792 CHORUS_FRUIT_AXE;
    public static class_1792 CHORUS_FRUIT_HOE;
    public static class_1792 CHORUS_FRUIT_HELMET;
    public static class_1792 CHORUS_FRUIT_CHESTPLATE;
    public static class_1792 CHORUS_FRUIT_LEGGINGS;
    public static class_1792 CHORUS_FRUIT_BOOTS;
    public static class_1792 GOLDEN_APPLE_SWORD;
    public static class_1792 GOLDEN_APPLE_PICKAXE;
    public static class_1792 GOLDEN_APPLE_SHOVEL;
    public static class_1792 GOLDEN_APPLE_AXE;
    public static class_1792 GOLDEN_APPLE_HOE;
    public static class_1792 GOLDEN_APPLE_HELMET;
    public static class_1792 GOLDEN_APPLE_CHESTPLATE;
    public static class_1792 GOLDEN_APPLE_LEGGINGS;
    public static class_1792 GOLDEN_APPLE_BOOTS;

    public static void register() {
        RGOLD = reg("rgold", new class_1792(new class_1792.class_1793().method_7889(64)));
        RAW_RGOLD = reg("raw_rgold", new class_1792(new class_1792.class_1793().method_7889(64)));
        OBSHARD = reg("obshard", new class_1792(new class_1792.class_1793().method_7889(64)));
        SEM = reg("sem", new class_1792(new class_1792.class_1793().method_7889(64)));
        OBINGOT = reg("obingot", new class_1792(new class_1792.class_1793().method_7889(64)));
        GRENADE = reg("grenade", new Grenade(new class_1792.class_1793().method_7889(16)));
        HRED = reg("hred", new class_1792(new class_1792.class_1793().method_7889(64)));
        HGLOW = reg("hglow", new class_1792(new class_1792.class_1793().method_7889(64)));
        RLAPIS = reg("rlapis", new class_1792(new class_1792.class_1793().method_7889(64)));
        DYNAMITE = reg("dynamite", new Dynamite(new class_1792.class_1793()
                            .method_7889(16)
                            .method_24359()  // optional
                    ));
        REMERALD_SWORD = reg("remerald_sword", new class_1829(ModToolTiers.REMERALD, 3, -2.4f, new class_1792.class_1793()));
        REMERALD_PICKAXE = reg("remerald_pickaxe", new class_1810(ModToolTiers.REMERALD, 1, -2.8f, new class_1792.class_1793()));
        REMERALD_SHOVEL = reg("remerald_shovel", new class_1821(ModToolTiers.REMERALD, 1.5f, -3f, new class_1792.class_1793()));
        REMERALD_AXE = reg("remerald_axe", new class_1743(ModToolTiers.REMERALD, 6, -3.2f, new class_1792.class_1793()));
        REMERALD_HOE = reg("remerald_hoe", new class_1794(ModToolTiers.REMERALD, 0, -3f, new class_1792.class_1793()));
        PEMERALD_SWORD = reg("pemerald_sword", new class_1829(ModToolTiers.PEMERALD, 3, -2.4f, new class_1792.class_1793()));
        PEMERALD_PICKAXE = reg("pemerald_pickaxe", new class_1810(ModToolTiers.PEMERALD, 1, -2.8f, new class_1792.class_1793()));
        PEMERALD_SHOVEL = reg("pemerald_shovel", new class_1821(ModToolTiers.PEMERALD, 1.5f, -3f, new class_1792.class_1793()));
        PEMERALD_AXE = reg("pemerald_axe", new class_1743(ModToolTiers.PEMERALD, 6, -3.2f, new class_1792.class_1793()));
        PEMERALD_HOE = reg("pemerald_hoe", new class_1794(ModToolTiers.PEMERALD, 0, -3f, new class_1792.class_1793()));
        ROBSIDIAN_SWORD = reg("robsidian_sword", new class_1829(ModToolTiers.ROBSIDIAN, 3, -2.4f, new class_1792.class_1793()));
        ROBSIDIAN_PICKAXE = reg("robsidian_pickaxe", new class_1810(ModToolTiers.ROBSIDIAN, 1, -2.8f, new class_1792.class_1793()));
        ROBSIDIAN_SHOVEL = reg("robsidian_shovel", new class_1821(ModToolTiers.ROBSIDIAN, 1.5f, -3f, new class_1792.class_1793()));
        ROBSIDIAN_AXE = reg("robsidian_axe", new class_1743(ModToolTiers.ROBSIDIAN, 6, -3.2f, new class_1792.class_1793()));
        ROBSIDIAN_HOE = reg("robsidian_hoe", new class_1794(ModToolTiers.ROBSIDIAN, 0, -3f, new class_1792.class_1793()));
        POBSIDIAN_SWORD = reg("pobsidian_sword", new class_1829(ModToolTiers.POBSIDIAN, 3, -2.4f, new class_1792.class_1793()));
        POBSIDIAN_PICKAXE = reg("pobsidian_pickaxe", new class_1810(ModToolTiers.POBSIDIAN, 1, -2.8f, new class_1792.class_1793()));
        POBSIDIAN_SHOVEL = reg("pobsidian_shovel", new class_1821(ModToolTiers.POBSIDIAN, 1.5f, -3f, new class_1792.class_1793()));
        POBSIDIAN_AXE = reg("pobsidian_axe", new class_1743(ModToolTiers.POBSIDIAN, 6, -3.2f, new class_1792.class_1793()));
        POBSIDIAN_HOE = reg("pobsidian_hoe", new class_1794(ModToolTiers.POBSIDIAN, 0, -3f, new class_1792.class_1793()));
        OVERPOWER_SWORD = reg("overpower_sword", new class_1829(ModToolTiers.OVERPOWER, 3, -2.4f, new class_1792.class_1793()));
        OVERPOWER_PICKAXE = reg("overpower_pickaxe", new class_1810(ModToolTiers.OVERPOWER, 1, -2.8f, new class_1792.class_1793()));
        OVERPOWER_SHOVEL = reg("overpower_shovel", new class_1821(ModToolTiers.OVERPOWER, 1.5f, -3f, new class_1792.class_1793()));
        OVERPOWER_AXE = reg("overpower_axe", new class_1743(ModToolTiers.OVERPOWER, 6, -3.2f, new class_1792.class_1793()));
        HREDSTONE_SWORD = reg("hredstone_sword", new class_1829(ModToolTiers.HREDSTONE, 3, -2.4f, new class_1792.class_1793()));
        HREDSTONE_PICKAXE = reg("hredstone_pickaxe", new class_1810(ModToolTiers.HREDSTONE, 1, -2.8f, new class_1792.class_1793()));
        HREDSTONE_SHOVEL = reg("hredstone_shovel", new class_1821(ModToolTiers.HREDSTONE, 1.5f, -3f, new class_1792.class_1793()));
        HREDSTONE_AXE = reg("hredstone_axe", new class_1743(ModToolTiers.HREDSTONE, 6, -3.2f, new class_1792.class_1793()));
        HREDSTONE_HOE = reg("hredstone_hoe", new class_1794(ModToolTiers.HREDSTONE, 0, -3f, new class_1792.class_1793()));
        HGLOWSTONE_SWORD = reg("hglowstone_sword", new class_1829(ModToolTiers.HGLOWSTONE, 3, -2.4f, new class_1792.class_1793()));
        HGLOWSTONE_PICKAXE = reg("hglowstone_pickaxe", new class_1810(ModToolTiers.HGLOWSTONE, 1, -2.8f, new class_1792.class_1793()));
        HGLOWSTONE_SHOVEL = reg("hglowstone_shovel", new class_1821(ModToolTiers.HGLOWSTONE, 1.5f, -3f, new class_1792.class_1793()));
        HGLOWSTONE_AXE = reg("hglowstone_axe", new class_1743(ModToolTiers.HGLOWSTONE, 6, -3.2f, new class_1792.class_1793()));
        HGLOWSTONE_HOE = reg("hglowstone_hoe", new class_1794(ModToolTiers.HGLOWSTONE, 0, -3f, new class_1792.class_1793()));
        RGOLD_SWORD = reg("rgold_sword", new class_1829(ModToolTiers.RGOLD, 3, -2.4f, new class_1792.class_1793()));
        RGOLD_PICKAXE = reg("rgold_pickaxe", new class_1810(ModToolTiers.RGOLD, 1, -2.8f, new class_1792.class_1793()));
        RGOLD_SHOVEL = reg("rgold_shovel", new class_1821(ModToolTiers.RGOLD, 1.5f, -3f, new class_1792.class_1793()));
        RGOLD_AXE = reg("rgold_axe", new class_1743(ModToolTiers.RGOLD, 6, -3.2f, new class_1792.class_1793()));
        RGOLD_HOE = reg("rgold_hoe", new class_1794(ModToolTiers.RGOLD, 0, -3f, new class_1792.class_1793()));
        RLAPIS_SWORD = reg("rlapis_sword", new class_1829(ModToolTiers.RLAPIS, 3, -2.4f, new class_1792.class_1793()));
        RLAPIS_PICKAXE = reg("rlapis_pickaxe", new class_1810(ModToolTiers.RLAPIS, 1, -2.8f, new class_1792.class_1793()));
        RLAPIS_SHOVEL = reg("rlapis_shovel", new class_1821(ModToolTiers.RLAPIS, 1.5f, -3f, new class_1792.class_1793()));
        RLAPIS_AXE = reg("rlapis_axe", new class_1743(ModToolTiers.RLAPIS, 6, -3.2f, new class_1792.class_1793()));
        RLAPIS_HOE = reg("rlapis_hoe", new class_1794(ModToolTiers.RLAPIS, 0, -3f, new class_1792.class_1793()));
        EMERALD_HELMET = reg("emerald_helmet", new class_1738(ModArmorMaterials.EMERALD, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        EMERALD_CHESTPLATE = reg("emerald_chestplate", new class_1738(ModArmorMaterials.EMERALD, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        EMERALD_LEGGINGS = reg("emerald_leggings", new class_1738(ModArmorMaterials.EMERALD, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        EMERALD_BOOTS = reg("emerald_boots", new class_1738(ModArmorMaterials.EMERALD, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        HRED_HELMET = reg("hred_helmet", new class_1738(ModArmorMaterials.HRED, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        HRED_CHESTPLATE = reg("hred_chestplate", new class_1738(ModArmorMaterials.HRED, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        HRED_LEGGINGS = reg("hred_leggings", new class_1738(ModArmorMaterials.HRED, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        HRED_BOOTS = reg("hred_boots", new class_1738(ModArmorMaterials.HRED, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        HGLOW_HELMET = reg("hglow_helmet", new class_1738(ModArmorMaterials.HGLOW, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        HGLOW_CHESTPLATE = reg("hglow_chestplate", new class_1738(ModArmorMaterials.HGLOW, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        HGLOW_LEGGINGS = reg("hglow_leggings", new class_1738(ModArmorMaterials.HGLOW, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        HGLOW_BOOTS = reg("hglow_boots", new class_1738(ModArmorMaterials.HGLOW, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        OBSIDIAN_HELMET = reg("obsidian_helmet", new class_1738(ModArmorMaterials.OBSIDIAN, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        OBSIDIAN_CHESTPLATE = reg("obsidian_chestplate", new class_1738(ModArmorMaterials.OBSIDIAN, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        OBSIDIAN_LEGGINGS = reg("obsidian_leggings", new class_1738(ModArmorMaterials.OBSIDIAN, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        OBSIDIAN_BOOTS = reg("obsidian_boots", new class_1738(ModArmorMaterials.OBSIDIAN, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        RGOLD_HELMET = reg("rgold_helmet", new class_1738(ModArmorMaterials.RGOLD, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        RGOLD_CHESTPLATE = reg("rgold_chestplate", new class_1738(ModArmorMaterials.RGOLD, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        RGOLD_LEGGINGS = reg("rgold_leggings", new class_1738(ModArmorMaterials.RGOLD, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        RGOLD_BOOTS = reg("rgold_boots", new class_1738(ModArmorMaterials.RGOLD, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        RLAPIS_HELMET = reg("rlapis_helmet", new class_1738(ModArmorMaterials.RLAPIS, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        RLAPIS_CHESTPLATE = reg("rlapis_chestplate", new class_1738(ModArmorMaterials.RLAPIS, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        RLAPIS_LEGGINGS = reg("rlapis_leggings", new class_1738(ModArmorMaterials.RLAPIS, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        RLAPIS_BOOTS = reg("rlapis_boots", new class_1738(ModArmorMaterials.RLAPIS, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        OVERPOWER_HELMET = reg("overpower_helmet", new ModArmorItem(ModArmorMaterials.OVERPOWER, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        OVERPOWER_CHESTPLATE = reg("overpower_chestplate", new class_1738(ModArmorMaterials.OVERPOWER, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        OVERPOWER_LEGGINGS = reg("overpower_leggings", new class_1738(ModArmorMaterials.OVERPOWER, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        OVERPOWER_BOOTS = reg("overpower_boots", new class_1738(ModArmorMaterials.OVERPOWER, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        GHOST_SPAWN_EGG = reg("ghost_spawn_egg", new class_1826(ModEntities.GHOST, 0xFFFFFF, 0x999999, new class_1792.class_1793()));
        ECTOPLASM = reg("ectoplasm", new class_1792(new class_1792.class_1793().method_7889(64)));
        RECTO_SWORD = reg("recto_sword", new EctoSwordItem(ModToolTiers.RECTO, new class_1792.class_1793()));
        RECTO_PICKAXE = reg("recto_pickaxe", new EctoPickaxeItem(ModToolTiers.RECTO, new class_1792.class_1793()));
        RECTO_SHOVEL = reg("recto_shovel", new EctoShovelItem(ModToolTiers.RECTO, 1.5f, -3f, new class_1792.class_1793()));
        RECTO_AXE = reg("recto_axe", new EctoAxeItem(ModToolTiers.RECTO, new class_1792.class_1793()));
        RECTO_HOE = reg("recto_hoe", new EctoHoeItem(ModToolTiers.RECTO, 0, -3f, new class_1792.class_1793()));
        REFINED_ECTOPLASM = reg("refined_ectoplasm", new class_1792(new class_1792.class_1793().method_7889(64)));
        ECTO_SWORD = reg("ecto_sword", new EctoSwordItem(ModToolTiers.ECTOPLASM, new class_1792.class_1793()));
        ECTO_PICKAXE = reg("ecto_pickaxe", new EctoPickaxeItem(ModToolTiers.ECTOPLASM, new class_1792.class_1793()));
        ECTO_SHOVEL = reg("ecto_shovel", new EctoShovelItem(ModToolTiers.ECTOPLASM, 1.5f, -3f, new class_1792.class_1793()));
        ECTO_AXE = reg("ecto_axe", new EctoAxeItem(ModToolTiers.ECTOPLASM, new class_1792.class_1793()));
        ECTO_HOE = reg("ecto_hoe", new EctoHoeItem(ModToolTiers.ECTOPLASM, 0, -3f, new class_1792.class_1793()));
        ECTO_HELMET = reg("ecto_helmet", new class_1738(ModArmorMaterials.ECTO, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        ECTO_CHESTPLATE = reg("ecto_chestplate", new class_1738(ModArmorMaterials.ECTO, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        ECTO_LEGGINGS = reg("ecto_leggings", new class_1738(ModArmorMaterials.ECTO, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        ECTO_BOOTS = reg("ecto_boots", new class_1738(ModArmorMaterials.ECTO, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        COAL_DUST = reg("coal_dust", new class_1792(new class_1792.class_1793().method_7889(64)));
        HARDENED_COAL = reg("hardened_coal", new class_1792(new class_1792.class_1793().method_7889(64)));
        COAL_SWORD = reg("coal_sword", new CoalSwordItem(ModToolTiers.COAL_TOOL, 2, -2.4f, new class_1792.class_1793()));
        COAL_PICKAXE = reg("coal_pickaxe", new CoalPickaxeItem(ModToolTiers.COAL_TOOL, 1, -2.8f, new class_1792.class_1793()));
        COAL_SHOVEL = reg("coal_shovel", new CoalShovelItem(ModToolTiers.COAL_TOOL, 1.5f, -3f, new class_1792.class_1793()));
        COAL_AXE = reg("coal_axe", new CoalAxeItem(ModToolTiers.COAL_TOOL, 5, -3.2f, new class_1792.class_1793()));
        COAL_HOE = reg("coal_hoe", new CoalHoeItem(ModToolTiers.COAL_TOOL, 0, -3f, new class_1792.class_1793()));
        COAL_HELMET = reg("coal_helmet", new CoalArmorItem(ModArmorMaterials.COAL, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        COAL_CHESTPLATE = reg("coal_chestplate", new CoalArmorItem(ModArmorMaterials.COAL, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        COAL_LEGGINGS = reg("coal_leggings", new CoalArmorItem(ModArmorMaterials.COAL, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        COAL_BOOTS = reg("coal_boots", new CoalArmorItem(ModArmorMaterials.COAL, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        RRAW_GOLD_SWORD = reg("rraw_gold_sword", new class_1829(ModToolTiers.RRAW_GOLD, 3, -2.4f, new class_1792.class_1793()));
        RRAW_GOLD_PICKAXE = reg("rraw_gold_pickaxe", new class_1810(ModToolTiers.RRAW_GOLD, 1, -2.8f, new class_1792.class_1793()));
        RRAW_GOLD_SHOVEL = reg("rraw_gold_shovel", new class_1821(ModToolTiers.RRAW_GOLD, 1.5f, -3f, new class_1792.class_1793()));
        RRAW_GOLD_AXE = reg("rraw_gold_axe", new class_1743(ModToolTiers.RRAW_GOLD, 6, -3.2f, new class_1792.class_1793()));
        RRAW_GOLD_HOE = reg("rraw_gold_hoe", new class_1794(ModToolTiers.RRAW_GOLD, 0, -3f, new class_1792.class_1793()));
        RRAW_COPPER_SWORD = reg("rraw_copper_sword", new class_1829(ModToolTiers.RRAW_COPPER, 3, -2.4f, new class_1792.class_1793()));
        RRAW_COPPER_PICKAXE = reg("rraw_copper_pickaxe", new class_1810(ModToolTiers.RRAW_COPPER, 1, -2.8f, new class_1792.class_1793()));
        RRAW_COPPER_SHOVEL = reg("rraw_copper_shovel", new class_1821(ModToolTiers.RRAW_COPPER, 1.5f, -3f, new class_1792.class_1793()));
        RRAW_COPPER_AXE = reg("rraw_copper_axe", new class_1743(ModToolTiers.RRAW_COPPER, 6, -3.2f, new class_1792.class_1793()));
        RRAW_COPPER_HOE = reg("rraw_copper_hoe", new class_1794(ModToolTiers.RRAW_COPPER, 0, -3f, new class_1792.class_1793()));
        RRAW_IRON_SWORD = reg("rraw_iron_sword", new class_1829(ModToolTiers.RRAW_IRON, 3, -2.4f, new class_1792.class_1793()));
        RRAW_IRON_PICKAXE = reg("rraw_iron_pickaxe", new class_1810(ModToolTiers.RRAW_IRON, 1, -2.8f, new class_1792.class_1793()));
        RRAW_IRON_SHOVEL = reg("rraw_iron_shovel", new class_1821(ModToolTiers.RRAW_IRON, 1.5f, -3f, new class_1792.class_1793()));
        RRAW_IRON_AXE = reg("rraw_iron_axe", new class_1743(ModToolTiers.RRAW_IRON, 6, -3.2f, new class_1792.class_1793()));
        RRAW_IRON_HOE = reg("rraw_iron_hoe", new class_1794(ModToolTiers.RRAW_IRON, 0, -3f, new class_1792.class_1793()));
        RRAW_RGOLD_SWORD = reg("rraw_rgold_sword", new class_1829(ModToolTiers.RRAW_RGOLD, 3, -2.4f, new class_1792.class_1793()));
        RRAW_RGOLD_PICKAXE = reg("rraw_rgold_pickaxe", new class_1810(ModToolTiers.RRAW_RGOLD, 1, -2.8f, new class_1792.class_1793()));
        RRAW_RGOLD_SHOVEL = reg("rraw_rgold_shovel", new class_1821(ModToolTiers.RRAW_RGOLD, 1.5f, -3f, new class_1792.class_1793()));
        RRAW_RGOLD_AXE = reg("rraw_rgold_axe", new class_1743(ModToolTiers.RRAW_RGOLD, 6, -3.2f, new class_1792.class_1793()));
        RRAW_RGOLD_HOE = reg("rraw_rgold_hoe", new class_1794(ModToolTiers.RRAW_RGOLD, 0, -3f, new class_1792.class_1793()));
        RSCRAP_SWORD = reg("rscrap_sword", new class_1829(ModToolTiers.RSCRAP, 3, -2.4f, new class_1792.class_1793()));
        RSCRAP_PICKAXE = reg("rscrap_pickaxe", new class_1810(ModToolTiers.RSCRAP, 1, -2.8f, new class_1792.class_1793()));
        RSCRAP_SHOVEL = reg("rscrap_shovel", new class_1821(ModToolTiers.RSCRAP, 1.5f, -3f, new class_1792.class_1793()));
        RSCRAP_AXE = reg("rscrap_axe", new class_1743(ModToolTiers.RSCRAP, 6, -3.2f, new class_1792.class_1793()));
        RSCRAP_HOE = reg("rscrap_hoe", new class_1794(ModToolTiers.RSCRAP, 0, -3f, new class_1792.class_1793()));
        CALCIFIED_AMETHYST = reg("calcified_amethyst", new class_1792(new class_1792.class_1793().method_7889(64)));
        GLACIAL_SHARD = reg("glacial_shard", new class_1792(new class_1792.class_1793().method_7889(64)));
        POLISHED_QUARTZ = reg("polished_quartz", new class_1792(new class_1792.class_1793().method_7889(64)));
        POLISHED_PRISMARINE = reg("polished_prismarine", new class_1792(new class_1792.class_1793().method_7889(64)));
        RAMETHYST_SWORD = reg("ramethyst_sword", new class_1829(ModToolTiers.RAMETHYST, 3, -2.4f, new class_1792.class_1793()));
        RAMETHYST_PICKAXE = reg("ramethyst_pickaxe", new class_1810(ModToolTiers.RAMETHYST, 1, -2.8f, new class_1792.class_1793()));
        RAMETHYST_SHOVEL = reg("ramethyst_shovel", new class_1821(ModToolTiers.RAMETHYST, 1.5f, -3f, new class_1792.class_1793()));
        RAMETHYST_AXE = reg("ramethyst_axe", new class_1743(ModToolTiers.RAMETHYST, 6, -3.2f, new class_1792.class_1793()));
        RAMETHYST_HOE = reg("ramethyst_hoe", new class_1794(ModToolTiers.RAMETHYST, 0, -3f, new class_1792.class_1793()));
        SNOW_SWORD = reg("snow_sword", new class_1829(ModToolTiers.SNOW_TOOL, 3, -2.4f, new class_1792.class_1793()));
        SNOW_PICKAXE = reg("snow_pickaxe", new class_1810(ModToolTiers.SNOW_TOOL, 1, -2.8f, new class_1792.class_1793()));
        SNOW_SHOVEL = reg("snow_shovel", new class_1821(ModToolTiers.SNOW_TOOL, 1.5f, -3f, new class_1792.class_1793()));
        SNOW_AXE = reg("snow_axe", new class_1743(ModToolTiers.SNOW_TOOL, 6, -3.2f, new class_1792.class_1793()));
        SNOW_HOE = reg("snow_hoe", new class_1794(ModToolTiers.SNOW_TOOL, 0, -3f, new class_1792.class_1793()));
        RQUARTZ_SWORD = reg("rquartz_sword", new class_1829(ModToolTiers.RQUARTZ, 3, -2.4f, new class_1792.class_1793()));
        RQUARTZ_PICKAXE = reg("rquartz_pickaxe", new class_1810(ModToolTiers.RQUARTZ, 1, -2.8f, new class_1792.class_1793()));
        RQUARTZ_SHOVEL = reg("rquartz_shovel", new class_1821(ModToolTiers.RQUARTZ, 1.5f, -3f, new class_1792.class_1793()));
        RQUARTZ_AXE = reg("rquartz_axe", new class_1743(ModToolTiers.RQUARTZ, 6, -3.2f, new class_1792.class_1793()));
        RQUARTZ_HOE = reg("rquartz_hoe", new class_1794(ModToolTiers.RQUARTZ, 0, -3f, new class_1792.class_1793()));
        RPRISM_SWORD = reg("rprism_sword", new class_1829(ModToolTiers.RPRISM, 3, -2.4f, new class_1792.class_1793()));
        RPRISM_PICKAXE = reg("rprism_pickaxe", new class_1810(ModToolTiers.RPRISM, 1, -2.8f, new class_1792.class_1793()));
        RPRISM_SHOVEL = reg("rprism_shovel", new class_1821(ModToolTiers.RPRISM, 1.5f, -3f, new class_1792.class_1793()));
        RPRISM_AXE = reg("rprism_axe", new class_1743(ModToolTiers.RPRISM, 6, -3.2f, new class_1792.class_1793()));
        RPRISM_HOE = reg("rprism_hoe", new class_1794(ModToolTiers.RPRISM, 0, -3f, new class_1792.class_1793()));
        CAMETHYST_SWORD = reg("camethyst_sword", new class_1829(ModToolTiers.CAMETHYST, 3, -2.4f, new class_1792.class_1793()));
        CAMETHYST_PICKAXE = reg("camethyst_pickaxe", new class_1810(ModToolTiers.CAMETHYST, 1, -2.8f, new class_1792.class_1793()));
        CAMETHYST_SHOVEL = reg("camethyst_shovel", new class_1821(ModToolTiers.CAMETHYST, 1.5f, -3f, new class_1792.class_1793()));
        CAMETHYST_AXE = reg("camethyst_axe", new class_1743(ModToolTiers.CAMETHYST, 6, -3.2f, new class_1792.class_1793()));
        CAMETHYST_HOE = reg("camethyst_hoe", new class_1794(ModToolTiers.CAMETHYST, 0, -3f, new class_1792.class_1793()));
        CAMETHYST_HELMET = reg("camethyst_helmet", new class_1738(ModArmorMaterials.CAMETHYST, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        CAMETHYST_CHESTPLATE = reg("camethyst_chestplate", new class_1738(ModArmorMaterials.CAMETHYST, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        CAMETHYST_LEGGINGS = reg("camethyst_leggings", new class_1738(ModArmorMaterials.CAMETHYST, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        CAMETHYST_BOOTS = reg("camethyst_boots", new class_1738(ModArmorMaterials.CAMETHYST, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        ICE_SWORD = reg("ice_sword", new class_1829(ModToolTiers.ICE_TOOL, 3, -2.4f, new class_1792.class_1793()));
        ICE_PICKAXE = reg("ice_pickaxe", new class_1810(ModToolTiers.ICE_TOOL, 1, -2.8f, new class_1792.class_1793()));
        ICE_SHOVEL = reg("ice_shovel", new class_1821(ModToolTiers.ICE_TOOL, 1.5f, -3f, new class_1792.class_1793()));
        ICE_AXE = reg("ice_axe", new class_1743(ModToolTiers.ICE_TOOL, 6, -3.2f, new class_1792.class_1793()));
        ICE_HOE = reg("ice_hoe", new class_1794(ModToolTiers.ICE_TOOL, 0, -3f, new class_1792.class_1793()));
        ICE_HELMET = reg("ice_helmet", new class_1738(ModArmorMaterials.ICE, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        ICE_CHESTPLATE = reg("ice_chestplate", new class_1738(ModArmorMaterials.ICE, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        ICE_LEGGINGS = reg("ice_leggings", new class_1738(ModArmorMaterials.ICE, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        ICE_BOOTS = reg("ice_boots", new class_1738(ModArmorMaterials.ICE, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        PQUARTZ_SWORD = reg("pquartz_sword", new class_1829(ModToolTiers.PQUARTZ, 3, -2.4f, new class_1792.class_1793()));
        PQUARTZ_PICKAXE = reg("pquartz_pickaxe", new class_1810(ModToolTiers.PQUARTZ, 1, -2.8f, new class_1792.class_1793()));
        PQUARTZ_SHOVEL = reg("pquartz_shovel", new class_1821(ModToolTiers.PQUARTZ, 1.5f, -3f, new class_1792.class_1793()));
        PQUARTZ_AXE = reg("pquartz_axe", new class_1743(ModToolTiers.PQUARTZ, 6, -3.2f, new class_1792.class_1793()));
        PQUARTZ_HOE = reg("pquartz_hoe", new class_1794(ModToolTiers.PQUARTZ, 0, -3f, new class_1792.class_1793()));
        PQUARTZ_HELMET = reg("pquartz_helmet", new class_1738(ModArmorMaterials.PQUARTZ, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        PQUARTZ_CHESTPLATE = reg("pquartz_chestplate", new class_1738(ModArmorMaterials.PQUARTZ, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        PQUARTZ_LEGGINGS = reg("pquartz_leggings", new class_1738(ModArmorMaterials.PQUARTZ, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        PQUARTZ_BOOTS = reg("pquartz_boots", new class_1738(ModArmorMaterials.PQUARTZ, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        PPRISM_SWORD = reg("pprism_sword", new class_1829(ModToolTiers.PPRISM, 3, -2.4f, new class_1792.class_1793()));
        PPRISM_PICKAXE = reg("pprism_pickaxe", new class_1810(ModToolTiers.PPRISM, 1, -2.8f, new class_1792.class_1793()));
        PPRISM_SHOVEL = reg("pprism_shovel", new class_1821(ModToolTiers.PPRISM, 1.5f, -3f, new class_1792.class_1793()));
        PPRISM_AXE = reg("pprism_axe", new class_1743(ModToolTiers.PPRISM, 6, -3.2f, new class_1792.class_1793()));
        PPRISM_HOE = reg("pprism_hoe", new class_1794(ModToolTiers.PPRISM, 0, -3f, new class_1792.class_1793()));
        PPRISM_HELMET = reg("pprism_helmet", new class_1738(ModArmorMaterials.PPRISM, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        PPRISM_CHESTPLATE = reg("pprism_chestplate", new class_1738(ModArmorMaterials.PPRISM, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        PPRISM_LEGGINGS = reg("pprism_leggings", new class_1738(ModArmorMaterials.PPRISM, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        PPRISM_BOOTS = reg("pprism_boots", new class_1738(ModArmorMaterials.PPRISM, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        RFLINT_SWORD = reg("rflint_sword", new class_1829(ModToolTiers.RFLINT, 3, -2.4f, new class_1792.class_1793()));
        RFLINT_PICKAXE = reg("rflint_pickaxe", new class_1810(ModToolTiers.RFLINT, 1, -2.8f, new class_1792.class_1793()));
        RFLINT_SHOVEL = reg("rflint_shovel", new class_1821(ModToolTiers.RFLINT, 1.5f, -3f, new class_1792.class_1793()));
        RFLINT_AXE = reg("rflint_axe", new class_1743(ModToolTiers.RFLINT, 6, -3.2f, new class_1792.class_1793()));
        RFLINT_HOE = reg("rflint_hoe", new class_1794(ModToolTiers.RFLINT, 0, -3f, new class_1792.class_1793()));
        FNI_SWORD = reg("fni_sword", new class_1829(ModToolTiers.FNI_TOOLS, 3, -2.4f, new class_1792.class_1793()));
        FNI_PICKAXE = reg("fni_pickaxe", new class_1810(ModToolTiers.FNI_TOOLS, 1, -2.8f, new class_1792.class_1793()));
        FNI_SHOVEL = reg("fni_shovel", new class_1821(ModToolTiers.FNI_TOOLS, 1.5f, -3f, new class_1792.class_1793()));
        FNI_AXE = reg("fni_axe", new class_1743(ModToolTiers.FNI_TOOLS, 6, -3.2f, new class_1792.class_1793()));
        FNI_HOE = reg("fni_hoe", new class_1794(ModToolTiers.FNI_TOOLS, 0, -3f, new class_1792.class_1793()));
        FNI_HELMET = reg("fni_helmet", new class_1738(ModArmorMaterials.FNI, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        FNI_CHESTPLATE = reg("fni_chestplate", new class_1738(ModArmorMaterials.FNI, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        FNI_LEGGINGS = reg("fni_leggings", new class_1738(ModArmorMaterials.FNI, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        FNI_BOOTS = reg("fni_boots", new class_1738(ModArmorMaterials.FNI, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        ANDESITE_SWORD = reg("andesite_sword", new class_1829(ModToolTiers.STONE_ANDESITE, 3, -2.4f, new class_1792.class_1793()));
        ANDESITE_PICKAXE = reg("andesite_pickaxe", new class_1810(ModToolTiers.STONE_ANDESITE, 1, -2.8f, new class_1792.class_1793()));
        ANDESITE_SHOVEL = reg("andesite_shovel", new class_1821(ModToolTiers.STONE_ANDESITE, 1.5f, -3f, new class_1792.class_1793()));
        ANDESITE_AXE = reg("andesite_axe", new class_1743(ModToolTiers.STONE_ANDESITE, 6, -3.2f, new class_1792.class_1793()));
        ANDESITE_HOE = reg("andesite_hoe", new class_1794(ModToolTiers.STONE_ANDESITE, 0, -3f, new class_1792.class_1793()));
        BASALT_SWORD = reg("basalt_sword", new class_1829(ModToolTiers.STONE_BASALT, 3, -2.5f, new class_1792.class_1793()));
        BASALT_PICKAXE = reg("basalt_pickaxe", new class_1810(ModToolTiers.STONE_BASALT, 1, -2.9f, new class_1792.class_1793()));
        BASALT_SHOVEL = reg("basalt_shovel", new class_1821(ModToolTiers.STONE_BASALT, 2.0f, -3.1f, new class_1792.class_1793()));
        BASALT_AXE = reg("basalt_axe", new class_1743(ModToolTiers.STONE_BASALT, 7, -3.3f, new class_1792.class_1793()));
        BASALT_HOE = reg("basalt_hoe", new class_1794(ModToolTiers.STONE_BASALT, 0, -3.1f, new class_1792.class_1793()));
        BLACKSTONE_SWORD = reg("blackstone_sword", new class_1829(ModToolTiers.STONE_BLACKSTONE, 4, -2.5f, new class_1792.class_1793()));
        BLACKSTONE_PICKAXE = reg("blackstone_pickaxe", new class_1810(ModToolTiers.STONE_BLACKSTONE, 1, -2.9f, new class_1792.class_1793()));
        BLACKSTONE_SHOVEL = reg("blackstone_shovel", new class_1821(ModToolTiers.STONE_BLACKSTONE, 2.0f, -3.1f, new class_1792.class_1793()));
        BLACKSTONE_AXE = reg("blackstone_axe", new class_1743(ModToolTiers.STONE_BLACKSTONE, 7, -3.35f, new class_1792.class_1793()));
        BLACKSTONE_HOE = reg("blackstone_hoe", new class_1794(ModToolTiers.STONE_BLACKSTONE, 0, -3.1f, new class_1792.class_1793()));
        CALCITE_SWORD = reg("calcite_sword", new class_1829(ModToolTiers.STONE_CALCITE, 2, -2.2f, new class_1792.class_1793()));
        CALCITE_PICKAXE = reg("calcite_pickaxe", new class_1810(ModToolTiers.STONE_CALCITE, 1, -2.6f, new class_1792.class_1793()));
        CALCITE_SHOVEL = reg("calcite_shovel", new class_1821(ModToolTiers.STONE_CALCITE, 1.0f, -2.8f, new class_1792.class_1793()));
        CALCITE_AXE = reg("calcite_axe", new class_1743(ModToolTiers.STONE_CALCITE, 5, -3.0f, new class_1792.class_1793()));
        CALCITE_HOE = reg("calcite_hoe", new class_1794(ModToolTiers.STONE_CALCITE, 0, -2.6f, new class_1792.class_1793()));
        DEEPSLATE_SWORD = reg("deepslate_sword", new class_1829(ModToolTiers.STONE_DEEPSLATE, 4, -2.55f, new class_1792.class_1793()));
        DEEPSLATE_PICKAXE = reg("deepslate_pickaxe", new class_1810(ModToolTiers.STONE_DEEPSLATE, 1, -2.95f, new class_1792.class_1793()));
        DEEPSLATE_SHOVEL = reg("deepslate_shovel", new class_1821(ModToolTiers.STONE_DEEPSLATE, 2.0f, -3.15f, new class_1792.class_1793()));
        DEEPSLATE_AXE = reg("deepslate_axe", new class_1743(ModToolTiers.STONE_DEEPSLATE, 7, -3.4f, new class_1792.class_1793()));
        DEEPSLATE_HOE = reg("deepslate_hoe", new class_1794(ModToolTiers.STONE_DEEPSLATE, 0, -3.1f, new class_1792.class_1793()));
        DIORITE_SWORD = reg("diorite_sword", new class_1829(ModToolTiers.STONE_DIORITE, 3, -2.4f, new class_1792.class_1793()));
        DIORITE_PICKAXE = reg("diorite_pickaxe", new class_1810(ModToolTiers.STONE_DIORITE, 1, -2.8f, new class_1792.class_1793()));
        DIORITE_SHOVEL = reg("diorite_shovel", new class_1821(ModToolTiers.STONE_DIORITE, 1.5f, -3f, new class_1792.class_1793()));
        DIORITE_AXE = reg("diorite_axe", new class_1743(ModToolTiers.STONE_DIORITE, 6, -3.2f, new class_1792.class_1793()));
        DIORITE_HOE = reg("diorite_hoe", new class_1794(ModToolTiers.STONE_DIORITE, 0, -2.9f, new class_1792.class_1793()));
        END_STONE_SWORD = reg("end_stone_sword", new class_1829(ModToolTiers.STONE_END_STONE, 3, -2.35f, new class_1792.class_1793()));
        END_STONE_PICKAXE = reg("end_stone_pickaxe", new class_1810(ModToolTiers.STONE_END_STONE, 1, -2.75f, new class_1792.class_1793()));
        END_STONE_SHOVEL = reg("end_stone_shovel", new class_1821(ModToolTiers.STONE_END_STONE, 1.5f, -2.95f, new class_1792.class_1793()));
        END_STONE_AXE = reg("end_stone_axe", new class_1743(ModToolTiers.STONE_END_STONE, 6, -3.15f, new class_1792.class_1793()));
        END_STONE_HOE = reg("end_stone_hoe", new class_1794(ModToolTiers.STONE_END_STONE, 0, -2.8f, new class_1792.class_1793()));
        GRANITE_SWORD = reg("granite_sword", new class_1829(ModToolTiers.STONE_GRANITE, 3, -2.5f, new class_1792.class_1793()));
        GRANITE_PICKAXE = reg("granite_pickaxe", new class_1810(ModToolTiers.STONE_GRANITE, 1, -2.9f, new class_1792.class_1793()));
        GRANITE_SHOVEL = reg("granite_shovel", new class_1821(ModToolTiers.STONE_GRANITE, 2.0f, -3.1f, new class_1792.class_1793()));
        GRANITE_AXE = reg("granite_axe", new class_1743(ModToolTiers.STONE_GRANITE, 7, -3.3f, new class_1792.class_1793()));
        GRANITE_HOE = reg("granite_hoe", new class_1794(ModToolTiers.STONE_GRANITE, 0, -3.1f, new class_1792.class_1793()));
        NETHERRACK_SWORD = reg("netherrack_sword", new class_1829(ModToolTiers.STONE_NETHERRACK, 2, -2.2f, new class_1792.class_1793()));
        NETHERRACK_PICKAXE = reg("netherrack_pickaxe", new class_1810(ModToolTiers.STONE_NETHERRACK, 1, -2.6f, new class_1792.class_1793()));
        NETHERRACK_SHOVEL = reg("netherrack_shovel", new class_1821(ModToolTiers.STONE_NETHERRACK, 1.0f, -2.8f, new class_1792.class_1793()));
        NETHERRACK_AXE = reg("netherrack_axe", new class_1743(ModToolTiers.STONE_NETHERRACK, 5, -3.0f, new class_1792.class_1793()));
        NETHERRACK_HOE = reg("netherrack_hoe", new class_1794(ModToolTiers.STONE_NETHERRACK, 0, -2.5f, new class_1792.class_1793()));
        SANDSTONE_SWORD = reg("sandstone_sword", new class_1829(ModToolTiers.STONE_SANDSTONE, 2, -2.3f, new class_1792.class_1793()));
        SANDSTONE_PICKAXE = reg("sandstone_pickaxe", new class_1810(ModToolTiers.STONE_SANDSTONE, 1, -2.7f, new class_1792.class_1793()));
        SANDSTONE_SHOVEL = reg("sandstone_shovel", new class_1821(ModToolTiers.STONE_SANDSTONE, 1.0f, -2.9f, new class_1792.class_1793()));
        SANDSTONE_AXE = reg("sandstone_axe", new class_1743(ModToolTiers.STONE_SANDSTONE, 5, -3.1f, new class_1792.class_1793()));
        SANDSTONE_HOE = reg("sandstone_hoe", new class_1794(ModToolTiers.STONE_SANDSTONE, 0, -2.7f, new class_1792.class_1793()));
        SMOOTH_BASALT_SWORD = reg("smooth_basalt_sword", new class_1829(ModToolTiers.STONE_SMOOTH_BASALT, 3, -2.45f, new class_1792.class_1793()));
        SMOOTH_BASALT_PICKAXE = reg("smooth_basalt_pickaxe", new class_1810(ModToolTiers.STONE_SMOOTH_BASALT, 1, -2.85f, new class_1792.class_1793()));
        SMOOTH_BASALT_SHOVEL = reg("smooth_basalt_shovel", new class_1821(ModToolTiers.STONE_SMOOTH_BASALT, 1.5f, -3.05f, new class_1792.class_1793()));
        SMOOTH_BASALT_AXE = reg("smooth_basalt_axe", new class_1743(ModToolTiers.STONE_SMOOTH_BASALT, 6, -3.25f, new class_1792.class_1793()));
        SMOOTH_BASALT_HOE = reg("smooth_basalt_hoe", new class_1794(ModToolTiers.STONE_SMOOTH_BASALT, 0, -3.0f, new class_1792.class_1793()));
        TERRACOTTA_SWORD = reg("terracotta_sword", new class_1829(ModToolTiers.STONE_TERRACOTTA, 3, -2.35f, new class_1792.class_1793()));
        TERRACOTTA_PICKAXE = reg("terracotta_pickaxe", new class_1810(ModToolTiers.STONE_TERRACOTTA, 1, -2.75f, new class_1792.class_1793()));
        TERRACOTTA_SHOVEL = reg("terracotta_shovel", new class_1821(ModToolTiers.STONE_TERRACOTTA, 1.5f, -2.95f, new class_1792.class_1793()));
        TERRACOTTA_AXE = reg("terracotta_axe", new class_1743(ModToolTiers.STONE_TERRACOTTA, 6, -3.15f, new class_1792.class_1793()));
        TERRACOTTA_HOE = reg("terracotta_hoe", new class_1794(ModToolTiers.STONE_TERRACOTTA, 0, -2.8f, new class_1792.class_1793()));
        TUFF_SWORD = reg("tuff_sword", new class_1829(ModToolTiers.STONE_TUFF, 2, -2.35f, new class_1792.class_1793()));
        TUFF_PICKAXE = reg("tuff_pickaxe", new class_1810(ModToolTiers.STONE_TUFF, 1, -2.75f, new class_1792.class_1793()));
        TUFF_SHOVEL = reg("tuff_shovel", new class_1821(ModToolTiers.STONE_TUFF, 1.5f, -2.95f, new class_1792.class_1793()));
        TUFF_AXE = reg("tuff_axe", new class_1743(ModToolTiers.STONE_TUFF, 5, -3.15f, new class_1792.class_1793()));
        TUFF_HOE = reg("tuff_hoe", new class_1794(ModToolTiers.STONE_TUFF, 0, -2.8f, new class_1792.class_1793()));
        OAK_SWORD = reg("oak_sword", new class_1829(ModToolTiers.WOOD_OAK, 3, -2.4f, new class_1792.class_1793()));
        OAK_PICKAXE = reg("oak_pickaxe", new class_1810(ModToolTiers.WOOD_OAK, 1, -2.8f, new class_1792.class_1793()));
        OAK_SHOVEL = reg("oak_shovel", new class_1821(ModToolTiers.WOOD_OAK, 1.5f, -3f, new class_1792.class_1793()));
        OAK_AXE = reg("oak_axe", new class_1743(ModToolTiers.WOOD_OAK, 6, -3.2f, new class_1792.class_1793()));
        OAK_HOE = reg("oak_hoe", new class_1794(ModToolTiers.WOOD_OAK, 0, -3f, new class_1792.class_1793()));
        SPRUCE_SWORD = reg("spruce_sword", new class_1829(ModToolTiers.WOOD_SPRUCE, 3, -2.4f, new class_1792.class_1793()));
        SPRUCE_PICKAXE = reg("spruce_pickaxe", new class_1810(ModToolTiers.WOOD_SPRUCE, 1, -2.8f, new class_1792.class_1793()));
        SPRUCE_SHOVEL = reg("spruce_shovel", new class_1821(ModToolTiers.WOOD_SPRUCE, 1.5f, -3f, new class_1792.class_1793()));
        SPRUCE_AXE = reg("spruce_axe", new class_1743(ModToolTiers.WOOD_SPRUCE, 6, -3.2f, new class_1792.class_1793()));
        SPRUCE_HOE = reg("spruce_hoe", new class_1794(ModToolTiers.WOOD_SPRUCE, 0, -3f, new class_1792.class_1793()));
        BIRCH_SWORD = reg("birch_sword", new class_1829(ModToolTiers.WOOD_BIRCH, 3, -2.4f, new class_1792.class_1793()));
        BIRCH_PICKAXE = reg("birch_pickaxe", new class_1810(ModToolTiers.WOOD_BIRCH, 1, -2.8f, new class_1792.class_1793()));
        BIRCH_SHOVEL = reg("birch_shovel", new class_1821(ModToolTiers.WOOD_BIRCH, 1.5f, -3f, new class_1792.class_1793()));
        BIRCH_AXE = reg("birch_axe", new class_1743(ModToolTiers.WOOD_BIRCH, 6, -3.2f, new class_1792.class_1793()));
        BIRCH_HOE = reg("birch_hoe", new class_1794(ModToolTiers.WOOD_BIRCH, 0, -3f, new class_1792.class_1793()));
        JUNGLE_SWORD = reg("jungle_sword", new class_1829(ModToolTiers.WOOD_JUNGLE, 3, -2.4f, new class_1792.class_1793()));
        JUNGLE_PICKAXE = reg("jungle_pickaxe", new class_1810(ModToolTiers.WOOD_JUNGLE, 1, -2.8f, new class_1792.class_1793()));
        JUNGLE_SHOVEL = reg("jungle_shovel", new class_1821(ModToolTiers.WOOD_JUNGLE, 1.5f, -3f, new class_1792.class_1793()));
        JUNGLE_AXE = reg("jungle_axe", new class_1743(ModToolTiers.WOOD_JUNGLE, 6, -3.2f, new class_1792.class_1793()));
        JUNGLE_HOE = reg("jungle_hoe", new class_1794(ModToolTiers.WOOD_JUNGLE, 0, -3f, new class_1792.class_1793()));
        ACACIA_SWORD = reg("acacia_sword", new class_1829(ModToolTiers.WOOD_ACACIA, 3, -2.4f, new class_1792.class_1793()));
        ACACIA_PICKAXE = reg("acacia_pickaxe", new class_1810(ModToolTiers.WOOD_ACACIA, 1, -2.8f, new class_1792.class_1793()));
        ACACIA_SHOVEL = reg("acacia_shovel", new class_1821(ModToolTiers.WOOD_ACACIA, 1.5f, -3f, new class_1792.class_1793()));
        ACACIA_AXE = reg("acacia_axe", new class_1743(ModToolTiers.WOOD_ACACIA, 6, -3.2f, new class_1792.class_1793()));
        ACACIA_HOE = reg("acacia_hoe", new class_1794(ModToolTiers.WOOD_ACACIA, 0, -3f, new class_1792.class_1793()));
        DARK_OAK_SWORD = reg("dark_oak_sword", new class_1829(ModToolTiers.WOOD_DARK_OAK, 3, -2.4f, new class_1792.class_1793()));
        DARK_OAK_PICKAXE = reg("dark_oak_pickaxe", new class_1810(ModToolTiers.WOOD_DARK_OAK, 1, -2.8f, new class_1792.class_1793()));
        DARK_OAK_SHOVEL = reg("dark_oak_shovel", new class_1821(ModToolTiers.WOOD_DARK_OAK, 1.5f, -3f, new class_1792.class_1793()));
        DARK_OAK_AXE = reg("dark_oak_axe", new class_1743(ModToolTiers.WOOD_DARK_OAK, 6, -3.2f, new class_1792.class_1793()));
        DARK_OAK_HOE = reg("dark_oak_hoe", new class_1794(ModToolTiers.WOOD_DARK_OAK, 0, -3f, new class_1792.class_1793()));
        MANGROVE_SWORD = reg("mangrove_sword", new class_1829(ModToolTiers.WOOD_MANGROVE, 3, -2.4f, new class_1792.class_1793()));
        MANGROVE_PICKAXE = reg("mangrove_pickaxe", new class_1810(ModToolTiers.WOOD_MANGROVE, 1, -2.8f, new class_1792.class_1793()));
        MANGROVE_SHOVEL = reg("mangrove_shovel", new class_1821(ModToolTiers.WOOD_MANGROVE, 1.5f, -3f, new class_1792.class_1793()));
        MANGROVE_AXE = reg("mangrove_axe", new class_1743(ModToolTiers.WOOD_MANGROVE, 6, -3.2f, new class_1792.class_1793()));
        MANGROVE_HOE = reg("mangrove_hoe", new class_1794(ModToolTiers.WOOD_MANGROVE, 0, -3f, new class_1792.class_1793()));
        CHERRY_SWORD = reg("cherry_sword", new class_1829(ModToolTiers.WOOD_CHERRY, 3, -2.4f, new class_1792.class_1793()));
        CHERRY_PICKAXE = reg("cherry_pickaxe", new class_1810(ModToolTiers.WOOD_CHERRY, 1, -2.8f, new class_1792.class_1793()));
        CHERRY_SHOVEL = reg("cherry_shovel", new class_1821(ModToolTiers.WOOD_CHERRY, 1.5f, -3f, new class_1792.class_1793()));
        CHERRY_AXE = reg("cherry_axe", new class_1743(ModToolTiers.WOOD_CHERRY, 6, -3.2f, new class_1792.class_1793()));
        CHERRY_HOE = reg("cherry_hoe", new class_1794(ModToolTiers.WOOD_CHERRY, 0, -3f, new class_1792.class_1793()));
        BAMBOO_SWORD = reg("bamboo_sword", new class_1829(ModToolTiers.WOOD_BAMBOO, 3, -2.4f, new class_1792.class_1793()));
        BAMBOO_PICKAXE = reg("bamboo_pickaxe", new class_1810(ModToolTiers.WOOD_BAMBOO, 1, -2.8f, new class_1792.class_1793()));
        BAMBOO_SHOVEL = reg("bamboo_shovel", new class_1821(ModToolTiers.WOOD_BAMBOO, 1.5f, -3f, new class_1792.class_1793()));
        BAMBOO_AXE = reg("bamboo_axe", new class_1743(ModToolTiers.WOOD_BAMBOO, 6, -3.2f, new class_1792.class_1793()));
        BAMBOO_HOE = reg("bamboo_hoe", new class_1794(ModToolTiers.WOOD_BAMBOO, 0, -3f, new class_1792.class_1793()));
        CRIMSON_SWORD = reg("crimson_sword", new class_1829(ModToolTiers.WOOD_CRIMSON, 3, -2.4f, new class_1792.class_1793()));
        CRIMSON_PICKAXE = reg("crimson_pickaxe", new class_1810(ModToolTiers.WOOD_CRIMSON, 1, -2.8f, new class_1792.class_1793()));
        CRIMSON_SHOVEL = reg("crimson_shovel", new class_1821(ModToolTiers.WOOD_CRIMSON, 1.5f, -3f, new class_1792.class_1793()));
        CRIMSON_AXE = reg("crimson_axe", new class_1743(ModToolTiers.WOOD_CRIMSON, 6, -3.2f, new class_1792.class_1793()));
        CRIMSON_HOE = reg("crimson_hoe", new class_1794(ModToolTiers.WOOD_CRIMSON, 0, -3f, new class_1792.class_1793()));
        WARPED_SWORD = reg("warped_sword", new class_1829(ModToolTiers.WOOD_WARPED, 3, -2.4f, new class_1792.class_1793()));
        WARPED_PICKAXE = reg("warped_pickaxe", new class_1810(ModToolTiers.WOOD_WARPED, 1, -2.8f, new class_1792.class_1793()));
        WARPED_SHOVEL = reg("warped_shovel", new class_1821(ModToolTiers.WOOD_WARPED, 1.5f, -3f, new class_1792.class_1793()));
        WARPED_AXE = reg("warped_axe", new class_1743(ModToolTiers.WOOD_WARPED, 6, -3.2f, new class_1792.class_1793()));
        WARPED_HOE = reg("warped_hoe", new class_1794(ModToolTiers.WOOD_WARPED, 0, -3f, new class_1792.class_1793()));
        LEATHER_SWORD = reg("leather_sword", new class_1829(ModToolTiers.LEATHER, 3, -2.4f, new class_1792.class_1793()));
        LEATHER_PICKAXE = reg("leather_pickaxe", new class_1810(ModToolTiers.LEATHER, 1, -2.8f, new class_1792.class_1793()));
        LEATHER_SHOVEL = reg("leather_shovel", new class_1821(ModToolTiers.LEATHER, 1.5f, -3f, new class_1792.class_1793()));
        LEATHER_AXE = reg("leather_axe", new class_1743(ModToolTiers.LEATHER, 6, -3.2f, new class_1792.class_1793()));
        LEATHER_HOE = reg("leather_hoe", new class_1794(ModToolTiers.LEATHER, 0, -3f, new class_1792.class_1793()));
        PAPER_SWORD = reg("paper_sword", new class_1829(ModToolTiers.PAPER, 3, -2.4f, new class_1792.class_1793()));
        PAPER_PICKAXE = reg("paper_pickaxe", new class_1810(ModToolTiers.PAPER, 1, -2.8f, new class_1792.class_1793()));
        PAPER_SHOVEL = reg("paper_shovel", new class_1821(ModToolTiers.PAPER, 1.5f, -3f, new class_1792.class_1793()));
        PAPER_AXE = reg("paper_axe", new class_1743(ModToolTiers.PAPER, 6, -3.2f, new class_1792.class_1793()));
        PAPER_HOE = reg("paper_hoe", new class_1794(ModToolTiers.PAPER, 0, -3f, new class_1792.class_1793()));
        FEATHER_SWORD = reg("feather_sword", new class_1829(ModToolTiers.FEATHER, 3, -2.4f, new class_1792.class_1793()));
        FEATHER_PICKAXE = reg("feather_pickaxe", new class_1810(ModToolTiers.FEATHER, 1, -2.8f, new class_1792.class_1793()));
        FEATHER_SHOVEL = reg("feather_shovel", new class_1821(ModToolTiers.FEATHER, 1.5f, -3f, new class_1792.class_1793()));
        FEATHER_AXE = reg("feather_axe", new class_1743(ModToolTiers.FEATHER, 6, -3.2f, new class_1792.class_1793()));
        FEATHER_HOE = reg("feather_hoe", new class_1794(ModToolTiers.FEATHER, 0, -3f, new class_1792.class_1793()));
        GLASS_SWORD = reg("glass_sword", new class_1829(ModToolTiers.GLASS, 3, -2.4f, new class_1792.class_1793()));
        GLASS_PICKAXE = reg("glass_pickaxe", new class_1810(ModToolTiers.GLASS, 1, -2.8f, new class_1792.class_1793()));
        GLASS_SHOVEL = reg("glass_shovel", new class_1821(ModToolTiers.GLASS, 1.5f, -3f, new class_1792.class_1793()));
        GLASS_AXE = reg("glass_axe", new class_1743(ModToolTiers.GLASS, 6, -3.2f, new class_1792.class_1793()));
        GLASS_HOE = reg("glass_hoe", new class_1794(ModToolTiers.GLASS, 0, -3f, new class_1792.class_1793()));
        RABBIT_HIDE_HELMET = reg("rabbit_hide_helmet", new class_1738(ModArmorMaterials.RABBIT_HIDE, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        RABBIT_HIDE_CHESTPLATE = reg("rabbit_hide_chestplate", new class_1738(ModArmorMaterials.RABBIT_HIDE, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        RABBIT_HIDE_LEGGINGS = reg("rabbit_hide_leggings", new class_1738(ModArmorMaterials.RABBIT_HIDE, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        RABBIT_HIDE_BOOTS = reg("rabbit_hide_boots", new class_1738(ModArmorMaterials.RABBIT_HIDE, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        CACTUS_SWORD = reg("cactus_sword", new class_1829(ModToolTiers.CACTUS, 3, -2.4f, new class_1792.class_1793()));
        CACTUS_PICKAXE = reg("cactus_pickaxe", new class_1810(ModToolTiers.CACTUS, 1, -2.8f, new class_1792.class_1793()));
        CACTUS_SHOVEL = reg("cactus_shovel", new class_1821(ModToolTiers.CACTUS, 1.5f, -3f, new class_1792.class_1793()));
        CACTUS_AXE = reg("cactus_axe", new class_1743(ModToolTiers.CACTUS, 6, -3.2f, new class_1792.class_1793()));
        CACTUS_HOE = reg("cactus_hoe", new class_1794(ModToolTiers.CACTUS, 0, -3f, new class_1792.class_1793()));
        CACTUS_HELMET = reg("cactus_helmet", new class_1738(ModArmorMaterials.CACTUS, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        CACTUS_CHESTPLATE = reg("cactus_chestplate", new class_1738(ModArmorMaterials.CACTUS, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        CACTUS_LEGGINGS = reg("cactus_leggings", new class_1738(ModArmorMaterials.CACTUS, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        CACTUS_BOOTS = reg("cactus_boots", new class_1738(ModArmorMaterials.CACTUS, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        SPONGE_SWORD = reg("sponge_sword", new class_1829(ModToolTiers.SPONGE, 3, -2.4f, new class_1792.class_1793()));
        SPONGE_PICKAXE = reg("sponge_pickaxe", new class_1810(ModToolTiers.SPONGE, 1, -2.8f, new class_1792.class_1793()));
        SPONGE_SHOVEL = reg("sponge_shovel", new class_1821(ModToolTiers.SPONGE, 1.5f, -3f, new class_1792.class_1793()));
        SPONGE_AXE = reg("sponge_axe", new class_1743(ModToolTiers.SPONGE, 6, -3.2f, new class_1792.class_1793()));
        SPONGE_HOE = reg("sponge_hoe", new class_1794(ModToolTiers.SPONGE, 0, -3f, new class_1792.class_1793()));
        BONE_SWORD = reg("bone_sword", new class_1829(ModToolTiers.BONE, 3, -2.4f, new class_1792.class_1793()));
        BONE_PICKAXE = reg("bone_pickaxe", new class_1810(ModToolTiers.BONE, 1, -2.8f, new class_1792.class_1793()));
        BONE_SHOVEL = reg("bone_shovel", new class_1821(ModToolTiers.BONE, 1.5f, -3f, new class_1792.class_1793()));
        BONE_AXE = reg("bone_axe", new class_1743(ModToolTiers.BONE, 6, -3.2f, new class_1792.class_1793()));
        BONE_HOE = reg("bone_hoe", new class_1794(ModToolTiers.BONE, 0, -3f, new class_1792.class_1793()));
        BONE_HELMET = reg("bone_helmet", new class_1738(ModArmorMaterials.BONE, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        BONE_CHESTPLATE = reg("bone_chestplate", new class_1738(ModArmorMaterials.BONE, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        BONE_LEGGINGS = reg("bone_leggings", new class_1738(ModArmorMaterials.BONE, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        BONE_BOOTS = reg("bone_boots", new class_1738(ModArmorMaterials.BONE, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        CLAY_SWORD = reg("clay_sword", new class_1829(ModToolTiers.CLAY, 3, -2.4f, new class_1792.class_1793()));
        CLAY_PICKAXE = reg("clay_pickaxe", new class_1810(ModToolTiers.CLAY, 1, -2.8f, new class_1792.class_1793()));
        CLAY_SHOVEL = reg("clay_shovel", new class_1821(ModToolTiers.CLAY, 1.5f, -3f, new class_1792.class_1793()));
        CLAY_AXE = reg("clay_axe", new class_1743(ModToolTiers.CLAY, 6, -3.2f, new class_1792.class_1793()));
        CLAY_HOE = reg("clay_hoe", new class_1794(ModToolTiers.CLAY, 0, -3f, new class_1792.class_1793()));
        CLAY_HELMET = reg("clay_helmet", new class_1738(ModArmorMaterials.CLAY, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        CLAY_CHESTPLATE = reg("clay_chestplate", new class_1738(ModArmorMaterials.CLAY, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        CLAY_LEGGINGS = reg("clay_leggings", new class_1738(ModArmorMaterials.CLAY, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        CLAY_BOOTS = reg("clay_boots", new class_1738(ModArmorMaterials.CLAY, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        NETHER_WART_SWORD = reg("nether_wart_sword", new class_1829(ModToolTiers.NETHER_WART, 3, -2.4f, new class_1792.class_1793()));
        NETHER_WART_PICKAXE = reg("nether_wart_pickaxe", new class_1810(ModToolTiers.NETHER_WART, 1, -2.8f, new class_1792.class_1793()));
        NETHER_WART_SHOVEL = reg("nether_wart_shovel", new class_1821(ModToolTiers.NETHER_WART, 1.5f, -3f, new class_1792.class_1793()));
        NETHER_WART_AXE = reg("nether_wart_axe", new class_1743(ModToolTiers.NETHER_WART, 6, -3.2f, new class_1792.class_1793()));
        NETHER_WART_HOE = reg("nether_wart_hoe", new class_1794(ModToolTiers.NETHER_WART, 0, -3f, new class_1792.class_1793()));
        BRICK_SWORD = reg("brick_sword", new class_1829(ModToolTiers.BRICK, 3, -2.4f, new class_1792.class_1793()));
        BRICK_PICKAXE = reg("brick_pickaxe", new class_1810(ModToolTiers.BRICK, 1, -2.8f, new class_1792.class_1793()));
        BRICK_SHOVEL = reg("brick_shovel", new class_1821(ModToolTiers.BRICK, 1.5f, -3f, new class_1792.class_1793()));
        BRICK_AXE = reg("brick_axe", new class_1743(ModToolTiers.BRICK, 6, -3.2f, new class_1792.class_1793()));
        BRICK_HOE = reg("brick_hoe", new class_1794(ModToolTiers.BRICK, 0, -3f, new class_1792.class_1793()));
        BRICK_HELMET = reg("brick_helmet", new class_1738(ModArmorMaterials.BRICK, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        BRICK_CHESTPLATE = reg("brick_chestplate", new class_1738(ModArmorMaterials.BRICK, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        BRICK_LEGGINGS = reg("brick_leggings", new class_1738(ModArmorMaterials.BRICK, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        BRICK_BOOTS = reg("brick_boots", new class_1738(ModArmorMaterials.BRICK, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        NETHER_BRICK_SWORD = reg("nether_brick_sword", new class_1829(ModToolTiers.NETHER_BRICK, 3, -2.4f, new class_1792.class_1793()));
        NETHER_BRICK_PICKAXE = reg("nether_brick_pickaxe", new class_1810(ModToolTiers.NETHER_BRICK, 1, -2.8f, new class_1792.class_1793()));
        NETHER_BRICK_SHOVEL = reg("nether_brick_shovel", new class_1821(ModToolTiers.NETHER_BRICK, 1.5f, -3f, new class_1792.class_1793()));
        NETHER_BRICK_AXE = reg("nether_brick_axe", new class_1743(ModToolTiers.NETHER_BRICK, 6, -3.2f, new class_1792.class_1793()));
        NETHER_BRICK_HOE = reg("nether_brick_hoe", new class_1794(ModToolTiers.NETHER_BRICK, 0, -3f, new class_1792.class_1793()));
        NETHER_BRICK_HELMET = reg("nether_brick_helmet", new class_1738(ModArmorMaterials.NETHER_BRICK, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        NETHER_BRICK_CHESTPLATE = reg("nether_brick_chestplate", new class_1738(ModArmorMaterials.NETHER_BRICK, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        NETHER_BRICK_LEGGINGS = reg("nether_brick_leggings", new class_1738(ModArmorMaterials.NETHER_BRICK, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        NETHER_BRICK_BOOTS = reg("nether_brick_boots", new class_1738(ModArmorMaterials.NETHER_BRICK, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        POINTED_DRIPSTONE_SWORD = reg("pointed_dripstone_sword", new class_1829(ModToolTiers.POINTED_DRIPSTONE, 3, -2.4f, new class_1792.class_1793()));
        POINTED_DRIPSTONE_PICKAXE = reg("pointed_dripstone_pickaxe", new class_1810(ModToolTiers.POINTED_DRIPSTONE, 1, -2.8f, new class_1792.class_1793()));
        POINTED_DRIPSTONE_SHOVEL = reg("pointed_dripstone_shovel", new class_1821(ModToolTiers.POINTED_DRIPSTONE, 1.5f, -3f, new class_1792.class_1793()));
        POINTED_DRIPSTONE_AXE = reg("pointed_dripstone_axe", new class_1743(ModToolTiers.POINTED_DRIPSTONE, 6, -3.2f, new class_1792.class_1793()));
        POINTED_DRIPSTONE_HOE = reg("pointed_dripstone_hoe", new class_1794(ModToolTiers.POINTED_DRIPSTONE, 0, -3f, new class_1792.class_1793()));
        COPPER_SWORD = reg("copper_sword", new class_1829(ModToolTiers.COPPER, 3, -2.4f, new class_1792.class_1793()));
        COPPER_PICKAXE = reg("copper_pickaxe", new class_1810(ModToolTiers.COPPER, 1, -2.8f, new class_1792.class_1793()));
        COPPER_SHOVEL = reg("copper_shovel", new class_1821(ModToolTiers.COPPER, 1.5f, -3f, new class_1792.class_1793()));
        COPPER_AXE = reg("copper_axe", new class_1743(ModToolTiers.COPPER, 6, -3.2f, new class_1792.class_1793()));
        COPPER_HOE = reg("copper_hoe", new class_1794(ModToolTiers.COPPER, 0, -3f, new class_1792.class_1793()));
        COPPER_HELMET = reg("copper_helmet", new class_1738(ModArmorMaterials.COPPER, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        COPPER_CHESTPLATE = reg("copper_chestplate", new class_1738(ModArmorMaterials.COPPER, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        COPPER_LEGGINGS = reg("copper_leggings", new class_1738(ModArmorMaterials.COPPER, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        COPPER_BOOTS = reg("copper_boots", new class_1738(ModArmorMaterials.COPPER, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        PHANTOM_SWORD = reg("phantom_sword", new class_1829(ModToolTiers.PHANTOM_MEMBRANE, 3, -2.4f, new class_1792.class_1793()));
        PHANTOM_PICKAXE = reg("phantom_pickaxe", new class_1810(ModToolTiers.PHANTOM_MEMBRANE, 1, -2.8f, new class_1792.class_1793()));
        PHANTOM_SHOVEL = reg("phantom_shovel", new class_1821(ModToolTiers.PHANTOM_MEMBRANE, 1.5f, -3f, new class_1792.class_1793()));
        PHANTOM_AXE = reg("phantom_axe", new class_1743(ModToolTiers.PHANTOM_MEMBRANE, 6, -3.2f, new class_1792.class_1793()));
        PHANTOM_HOE = reg("phantom_hoe", new class_1794(ModToolTiers.PHANTOM_MEMBRANE, 0, -3f, new class_1792.class_1793()));
        PHANTOM_HELMET = reg("phantom_helmet", new class_1738(ModArmorMaterials.PHANTOM, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        PHANTOM_CHESTPLATE = reg("phantom_chestplate", new class_1738(ModArmorMaterials.PHANTOM, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        PHANTOM_LEGGINGS = reg("phantom_leggings", new class_1738(ModArmorMaterials.PHANTOM, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        PHANTOM_BOOTS = reg("phantom_boots", new class_1738(ModArmorMaterials.PHANTOM, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        MAGMA_CREAM_SWORD = reg("magma_cream_sword", new class_1829(ModToolTiers.MAGMA_CREAM, 3, -2.4f, new class_1792.class_1793()));
        MAGMA_CREAM_PICKAXE = reg("magma_cream_pickaxe", new class_1810(ModToolTiers.MAGMA_CREAM, 1, -2.8f, new class_1792.class_1793()));
        MAGMA_CREAM_SHOVEL = reg("magma_cream_shovel", new class_1821(ModToolTiers.MAGMA_CREAM, 1.5f, -3f, new class_1792.class_1793()));
        MAGMA_CREAM_AXE = reg("magma_cream_axe", new class_1743(ModToolTiers.MAGMA_CREAM, 6, -3.2f, new class_1792.class_1793()));
        MAGMA_CREAM_HOE = reg("magma_cream_hoe", new class_1794(ModToolTiers.MAGMA_CREAM, 0, -3f, new class_1792.class_1793()));
        MAGMA_CREAM_HELMET = reg("magma_cream_helmet", new class_1738(ModArmorMaterials.MAGMA_CREAM, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        MAGMA_CREAM_CHESTPLATE = reg("magma_cream_chestplate", new class_1738(ModArmorMaterials.MAGMA_CREAM, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        MAGMA_CREAM_LEGGINGS = reg("magma_cream_leggings", new class_1738(ModArmorMaterials.MAGMA_CREAM, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        MAGMA_CREAM_BOOTS = reg("magma_cream_boots", new class_1738(ModArmorMaterials.MAGMA_CREAM, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        SLIME_SWORD = reg("slime_sword", new class_1829(ModToolTiers.SLIME, 3, -2.4f, new class_1792.class_1793()));
        SLIME_PICKAXE = reg("slime_pickaxe", new class_1810(ModToolTiers.SLIME, 1, -2.8f, new class_1792.class_1793()));
        SLIME_SHOVEL = reg("slime_shovel", new class_1821(ModToolTiers.SLIME, 1.5f, -3f, new class_1792.class_1793()));
        SLIME_AXE = reg("slime_axe", new class_1743(ModToolTiers.SLIME, 6, -3.2f, new class_1792.class_1793()));
        SLIME_HOE = reg("slime_hoe", new class_1794(ModToolTiers.SLIME, 0, -3f, new class_1792.class_1793()));
        SLIME_HELMET = reg("slime_helmet", new class_1738(ModArmorMaterials.SLIME, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        SLIME_CHESTPLATE = reg("slime_chestplate", new class_1738(ModArmorMaterials.SLIME, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        SLIME_LEGGINGS = reg("slime_leggings", new class_1738(ModArmorMaterials.SLIME, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        SLIME_BOOTS = reg("slime_boots", new class_1738(ModArmorMaterials.SLIME, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        BLAZE_SWORD = reg("blaze_sword", new class_1829(ModToolTiers.BLAZE_ROD, 3, -2.4f, new class_1792.class_1793()));
        BLAZE_PICKAXE = reg("blaze_pickaxe", new class_1810(ModToolTiers.BLAZE_ROD, 1, -2.8f, new class_1792.class_1793()));
        BLAZE_SHOVEL = reg("blaze_shovel", new class_1821(ModToolTiers.BLAZE_ROD, 1.5f, -3f, new class_1792.class_1793()));
        BLAZE_AXE = reg("blaze_axe", new class_1743(ModToolTiers.BLAZE_ROD, 6, -3.2f, new class_1792.class_1793()));
        BLAZE_HOE = reg("blaze_hoe", new class_1794(ModToolTiers.BLAZE_ROD, 0, -3f, new class_1792.class_1793()));
        BLAZE_HELMET = reg("blaze_helmet", new class_1738(ModArmorMaterials.BLAZE, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        BLAZE_CHESTPLATE = reg("blaze_chestplate", new class_1738(ModArmorMaterials.BLAZE, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        BLAZE_LEGGINGS = reg("blaze_leggings", new class_1738(ModArmorMaterials.BLAZE, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        BLAZE_BOOTS = reg("blaze_boots", new class_1738(ModArmorMaterials.BLAZE, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        NAUTILUS_SWORD = reg("nautilus_sword", new class_1829(ModToolTiers.NAUTILUS_SHELL, 3, -2.4f, new class_1792.class_1793()));
        NAUTILUS_PICKAXE = reg("nautilus_pickaxe", new class_1810(ModToolTiers.NAUTILUS_SHELL, 1, -2.8f, new class_1792.class_1793()));
        NAUTILUS_SHOVEL = reg("nautilus_shovel", new class_1821(ModToolTiers.NAUTILUS_SHELL, 1.5f, -3f, new class_1792.class_1793()));
        NAUTILUS_AXE = reg("nautilus_axe", new class_1743(ModToolTiers.NAUTILUS_SHELL, 6, -3.2f, new class_1792.class_1793()));
        NAUTILUS_HOE = reg("nautilus_hoe", new class_1794(ModToolTiers.NAUTILUS_SHELL, 0, -3f, new class_1792.class_1793()));
        NAUTILUS_HELMET = reg("nautilus_helmet", new class_1738(ModArmorMaterials.NAUTILUS, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        NAUTILUS_CHESTPLATE = reg("nautilus_chestplate", new class_1738(ModArmorMaterials.NAUTILUS, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        NAUTILUS_LEGGINGS = reg("nautilus_leggings", new class_1738(ModArmorMaterials.NAUTILUS, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        NAUTILUS_BOOTS = reg("nautilus_boots", new class_1738(ModArmorMaterials.NAUTILUS, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        PURPUR_SWORD = reg("purpur_sword", new class_1829(ModToolTiers.PURPUR, 3, -2.4f, new class_1792.class_1793()));
        PURPUR_PICKAXE = reg("purpur_pickaxe", new class_1810(ModToolTiers.PURPUR, 1, -2.8f, new class_1792.class_1793()));
        PURPUR_SHOVEL = reg("purpur_shovel", new class_1821(ModToolTiers.PURPUR, 1.5f, -3f, new class_1792.class_1793()));
        PURPUR_AXE = reg("purpur_axe", new class_1743(ModToolTiers.PURPUR, 6, -3.2f, new class_1792.class_1793()));
        PURPUR_HOE = reg("purpur_hoe", new class_1794(ModToolTiers.PURPUR, 0, -3f, new class_1792.class_1793()));
        PURPUR_HELMET = reg("purpur_helmet", new class_1738(ModArmorMaterials.PURPUR, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        PURPUR_CHESTPLATE = reg("purpur_chestplate", new class_1738(ModArmorMaterials.PURPUR, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        PURPUR_LEGGINGS = reg("purpur_leggings", new class_1738(ModArmorMaterials.PURPUR, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        PURPUR_BOOTS = reg("purpur_boots", new class_1738(ModArmorMaterials.PURPUR, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        GHAST_TEAR_SWORD = reg("ghast_tear_sword", new class_1829(ModToolTiers.GHAST_TEAR, 3, -2.4f, new class_1792.class_1793()));
        GHAST_TEAR_PICKAXE = reg("ghast_tear_pickaxe", new class_1810(ModToolTiers.GHAST_TEAR, 1, -2.8f, new class_1792.class_1793()));
        GHAST_TEAR_SHOVEL = reg("ghast_tear_shovel", new class_1821(ModToolTiers.GHAST_TEAR, 1.5f, -3f, new class_1792.class_1793()));
        GHAST_TEAR_AXE = reg("ghast_tear_axe", new class_1743(ModToolTiers.GHAST_TEAR, 6, -3.2f, new class_1792.class_1793()));
        GHAST_TEAR_HOE = reg("ghast_tear_hoe", new class_1794(ModToolTiers.GHAST_TEAR, 0, -3f, new class_1792.class_1793()));
        GHAST_TEAR_HELMET = reg("ghast_tear_helmet", new class_1738(ModArmorMaterials.GHAST_TEAR, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        GHAST_TEAR_CHESTPLATE = reg("ghast_tear_chestplate", new class_1738(ModArmorMaterials.GHAST_TEAR, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        GHAST_TEAR_LEGGINGS = reg("ghast_tear_leggings", new class_1738(ModArmorMaterials.GHAST_TEAR, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        GHAST_TEAR_BOOTS = reg("ghast_tear_boots", new class_1738(ModArmorMaterials.GHAST_TEAR, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        EYE_OF_ENDER_SWORD = reg("eye_of_ender_sword", new class_1829(ModToolTiers.EYE_OF_ENDER, 3, -2.4f, new class_1792.class_1793()));
        EYE_OF_ENDER_PICKAXE = reg("eye_of_ender_pickaxe", new class_1810(ModToolTiers.EYE_OF_ENDER, 1, -2.8f, new class_1792.class_1793()));
        EYE_OF_ENDER_SHOVEL = reg("eye_of_ender_shovel", new class_1821(ModToolTiers.EYE_OF_ENDER, 1.5f, -3f, new class_1792.class_1793()));
        EYE_OF_ENDER_AXE = reg("eye_of_ender_axe", new class_1743(ModToolTiers.EYE_OF_ENDER, 6, -3.2f, new class_1792.class_1793()));
        EYE_OF_ENDER_HOE = reg("eye_of_ender_hoe", new class_1794(ModToolTiers.EYE_OF_ENDER, 0, -3f, new class_1792.class_1793()));
        EYE_OF_ENDER_HELMET = reg("eye_of_ender_helmet", new class_1738(ModArmorMaterials.EYE_OF_ENDER, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        EYE_OF_ENDER_CHESTPLATE = reg("eye_of_ender_chestplate", new class_1738(ModArmorMaterials.EYE_OF_ENDER, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        EYE_OF_ENDER_LEGGINGS = reg("eye_of_ender_leggings", new class_1738(ModArmorMaterials.EYE_OF_ENDER, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        EYE_OF_ENDER_BOOTS = reg("eye_of_ender_boots", new class_1738(ModArmorMaterials.EYE_OF_ENDER, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        SHULKER_SWORD = reg("shulker_sword", new class_1829(ModToolTiers.SHULKER_SHELL, 3, -2.4f, new class_1792.class_1793()));
        SHULKER_PICKAXE = reg("shulker_pickaxe", new class_1810(ModToolTiers.SHULKER_SHELL, 1, -2.8f, new class_1792.class_1793()));
        SHULKER_SHOVEL = reg("shulker_shovel", new class_1821(ModToolTiers.SHULKER_SHELL, 1.5f, -3f, new class_1792.class_1793()));
        SHULKER_AXE = reg("shulker_axe", new class_1743(ModToolTiers.SHULKER_SHELL, 6, -3.2f, new class_1792.class_1793()));
        SHULKER_HOE = reg("shulker_hoe", new class_1794(ModToolTiers.SHULKER_SHELL, 0, -3f, new class_1792.class_1793()));
        SHULKER_HELMET = reg("shulker_helmet", new class_1738(ModArmorMaterials.SHULKER, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        SHULKER_CHESTPLATE = reg("shulker_chestplate", new class_1738(ModArmorMaterials.SHULKER, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        SHULKER_LEGGINGS = reg("shulker_leggings", new class_1738(ModArmorMaterials.SHULKER, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        SHULKER_BOOTS = reg("shulker_boots", new class_1738(ModArmorMaterials.SHULKER, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        TURTLE_SCUTE_HELMET = reg("turtle_scute_helmet", new class_1738(ModArmorMaterials.TURTLE_SCUTE, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        TURTLE_SCUTE_CHESTPLATE = reg("turtle_scute_chestplate", new class_1738(ModArmorMaterials.TURTLE_SCUTE, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        TURTLE_SCUTE_LEGGINGS = reg("turtle_scute_leggings", new class_1738(ModArmorMaterials.TURTLE_SCUTE, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        TURTLE_SCUTE_BOOTS = reg("turtle_scute_boots", new class_1738(ModArmorMaterials.TURTLE_SCUTE, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        ECHO_SHARD_SWORD = reg("echo_shard_sword", new class_1829(ModToolTiers.ECHO_SHARD, 3, -2.4f, new class_1792.class_1793()));
        ECHO_SHARD_PICKAXE = reg("echo_shard_pickaxe", new class_1810(ModToolTiers.ECHO_SHARD, 1, -2.8f, new class_1792.class_1793()));
        ECHO_SHARD_SHOVEL = reg("echo_shard_shovel", new class_1821(ModToolTiers.ECHO_SHARD, 1.5f, -3f, new class_1792.class_1793()));
        ECHO_SHARD_AXE = reg("echo_shard_axe", new class_1743(ModToolTiers.ECHO_SHARD, 6, -3.2f, new class_1792.class_1793()));
        ECHO_SHARD_HOE = reg("echo_shard_hoe", new class_1794(ModToolTiers.ECHO_SHARD, 0, -3f, new class_1792.class_1793()));
        ECHO_SHARD_HELMET = reg("echo_shard_helmet", new class_1738(ModArmorMaterials.ECHO_SHARD, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        ECHO_SHARD_CHESTPLATE = reg("echo_shard_chestplate", new class_1738(ModArmorMaterials.ECHO_SHARD, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        ECHO_SHARD_LEGGINGS = reg("echo_shard_leggings", new class_1738(ModArmorMaterials.ECHO_SHARD, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        ECHO_SHARD_BOOTS = reg("echo_shard_boots", new class_1738(ModArmorMaterials.ECHO_SHARD, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        DRAGON_BREATH_SWORD = reg("dragon_breath_sword", new class_1829(ModToolTiers.DRAGON_BREATH, 3, -2.4f, new class_1792.class_1793()));
        DRAGON_BREATH_PICKAXE = reg("dragon_breath_pickaxe", new class_1810(ModToolTiers.DRAGON_BREATH, 1, -2.8f, new class_1792.class_1793()));
        DRAGON_BREATH_SHOVEL = reg("dragon_breath_shovel", new class_1821(ModToolTiers.DRAGON_BREATH, 1.5f, -3f, new class_1792.class_1793()));
        DRAGON_BREATH_AXE = reg("dragon_breath_axe", new class_1743(ModToolTiers.DRAGON_BREATH, 6, -3.2f, new class_1792.class_1793()));
        DRAGON_BREATH_HOE = reg("dragon_breath_hoe", new class_1794(ModToolTiers.DRAGON_BREATH, 0, -3f, new class_1792.class_1793()));
        DRAGON_BREATH_HELMET = reg("dragon_breath_helmet", new class_1738(ModArmorMaterials.DRAGON_BREATH, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()));
        DRAGON_BREATH_CHESTPLATE = reg("dragon_breath_chestplate", new class_1738(ModArmorMaterials.DRAGON_BREATH, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()));
        DRAGON_BREATH_LEGGINGS = reg("dragon_breath_leggings", new class_1738(ModArmorMaterials.DRAGON_BREATH, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()));
        DRAGON_BREATH_BOOTS = reg("dragon_breath_boots", new class_1738(ModArmorMaterials.DRAGON_BREATH, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()));
        CAKE_SWORD = reg("cake_sword", new EdibleSwordItem(ModToolTiers.CAKE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        CAKE_PICKAXE = reg("cake_pickaxe", new EdiblePickaxeItem(ModToolTiers.CAKE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        CAKE_SHOVEL = reg("cake_shovel", new EdibleShovelItem(ModToolTiers.CAKE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(2).method_19237(0.1f).method_19242())));
        CAKE_AXE = reg("cake_axe", new EdibleAxeItem(ModToolTiers.CAKE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        CAKE_HOE = reg("cake_hoe", new EdibleHoeItem(ModToolTiers.CAKE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        CAKE_HELMET = reg("cake_helmet", new EdibleArmorItem(ModArmorMaterials.CAKE, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(10).method_19237(0.1f).method_19242())));
        CAKE_CHESTPLATE = reg("cake_chestplate", new EdibleArmorItem(ModArmorMaterials.CAKE, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        CAKE_LEGGINGS = reg("cake_leggings", new EdibleArmorItem(ModArmorMaterials.CAKE, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        CAKE_BOOTS = reg("cake_boots", new EdibleArmorItem(ModArmorMaterials.CAKE, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(8).method_19237(0.1f).method_19242())));
        BREAD_SWORD = reg("bread_sword", new EdibleSwordItem(ModToolTiers.BREAD, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        BREAD_PICKAXE = reg("bread_pickaxe", new EdiblePickaxeItem(ModToolTiers.BREAD, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        BREAD_SHOVEL = reg("bread_shovel", new EdibleShovelItem(ModToolTiers.BREAD, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(2).method_19237(0.1f).method_19242())));
        BREAD_AXE = reg("bread_axe", new EdibleAxeItem(ModToolTiers.BREAD, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        BREAD_HOE = reg("bread_hoe", new EdibleHoeItem(ModToolTiers.BREAD, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        BREAD_HELMET = reg("bread_helmet", new EdibleArmorItem(ModArmorMaterials.BREAD, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(10).method_19237(0.1f).method_19242())));
        BREAD_CHESTPLATE = reg("bread_chestplate", new EdibleArmorItem(ModArmorMaterials.BREAD, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        BREAD_LEGGINGS = reg("bread_leggings", new EdibleArmorItem(ModArmorMaterials.BREAD, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        BREAD_BOOTS = reg("bread_boots", new EdibleArmorItem(ModArmorMaterials.BREAD, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(8).method_19237(0.1f).method_19242())));
        DRIED_KELP_SWORD = reg("dried_kelp_sword", new EdibleSwordItem(ModToolTiers.DRIED_KELP, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        DRIED_KELP_PICKAXE = reg("dried_kelp_pickaxe", new EdiblePickaxeItem(ModToolTiers.DRIED_KELP, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        DRIED_KELP_SHOVEL = reg("dried_kelp_shovel", new EdibleShovelItem(ModToolTiers.DRIED_KELP, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(2).method_19237(0.1f).method_19242())));
        DRIED_KELP_AXE = reg("dried_kelp_axe", new EdibleAxeItem(ModToolTiers.DRIED_KELP, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        DRIED_KELP_HOE = reg("dried_kelp_hoe", new EdibleHoeItem(ModToolTiers.DRIED_KELP, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        DRIED_KELP_HELMET = reg("dried_kelp_helmet", new EdibleArmorItem(ModArmorMaterials.DRIED_KELP, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(10).method_19237(0.1f).method_19242())));
        DRIED_KELP_CHESTPLATE = reg("dried_kelp_chestplate", new EdibleArmorItem(ModArmorMaterials.DRIED_KELP, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        DRIED_KELP_LEGGINGS = reg("dried_kelp_leggings", new EdibleArmorItem(ModArmorMaterials.DRIED_KELP, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        DRIED_KELP_BOOTS = reg("dried_kelp_boots", new EdibleArmorItem(ModArmorMaterials.DRIED_KELP, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(8).method_19237(0.1f).method_19242())));
        ROTTEN_FLESH_SWORD = reg("rotten_flesh_sword", new EdibleSwordItem(ModToolTiers.ROTTEN_FLESH, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        ROTTEN_FLESH_PICKAXE = reg("rotten_flesh_pickaxe", new EdiblePickaxeItem(ModToolTiers.ROTTEN_FLESH, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        ROTTEN_FLESH_SHOVEL = reg("rotten_flesh_shovel", new EdibleShovelItem(ModToolTiers.ROTTEN_FLESH, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(2).method_19237(0.1f).method_19242())));
        ROTTEN_FLESH_AXE = reg("rotten_flesh_axe", new EdibleAxeItem(ModToolTiers.ROTTEN_FLESH, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        ROTTEN_FLESH_HOE = reg("rotten_flesh_hoe", new EdibleHoeItem(ModToolTiers.ROTTEN_FLESH, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        ROTTEN_FLESH_HELMET = reg("rotten_flesh_helmet", new EdibleArmorItem(ModArmorMaterials.ROTTEN_FLESH, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(10).method_19237(0.1f).method_19242())));
        ROTTEN_FLESH_CHESTPLATE = reg("rotten_flesh_chestplate", new EdibleArmorItem(ModArmorMaterials.ROTTEN_FLESH, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        ROTTEN_FLESH_LEGGINGS = reg("rotten_flesh_leggings", new EdibleArmorItem(ModArmorMaterials.ROTTEN_FLESH, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        ROTTEN_FLESH_BOOTS = reg("rotten_flesh_boots", new EdibleArmorItem(ModArmorMaterials.ROTTEN_FLESH, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(8).method_19237(0.1f).method_19242())));
        MELON_SWORD = reg("melon_sword", new EdibleSwordItem(ModToolTiers.MELON, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        MELON_PICKAXE = reg("melon_pickaxe", new EdiblePickaxeItem(ModToolTiers.MELON, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        MELON_SHOVEL = reg("melon_shovel", new EdibleShovelItem(ModToolTiers.MELON, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(2).method_19237(0.1f).method_19242())));
        MELON_AXE = reg("melon_axe", new EdibleAxeItem(ModToolTiers.MELON, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        MELON_HOE = reg("melon_hoe", new EdibleHoeItem(ModToolTiers.MELON, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        MELON_HELMET = reg("melon_helmet", new EdibleArmorItem(ModArmorMaterials.MELON, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(10).method_19237(0.1f).method_19242())));
        MELON_CHESTPLATE = reg("melon_chestplate", new EdibleArmorItem(ModArmorMaterials.MELON, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        MELON_LEGGINGS = reg("melon_leggings", new EdibleArmorItem(ModArmorMaterials.MELON, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        MELON_BOOTS = reg("melon_boots", new EdibleArmorItem(ModArmorMaterials.MELON, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(8).method_19237(0.1f).method_19242())));
        SWEET_BERRY_SWORD = reg("sweet_berry_sword", new EdibleSwordItem(ModToolTiers.SWEET_BERRIES, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        SWEET_BERRY_PICKAXE = reg("sweet_berry_pickaxe", new EdiblePickaxeItem(ModToolTiers.SWEET_BERRIES, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        SWEET_BERRY_SHOVEL = reg("sweet_berry_shovel", new EdibleShovelItem(ModToolTiers.SWEET_BERRIES, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(2).method_19237(0.1f).method_19242())));
        SWEET_BERRY_AXE = reg("sweet_berry_axe", new EdibleAxeItem(ModToolTiers.SWEET_BERRIES, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        SWEET_BERRY_HOE = reg("sweet_berry_hoe", new EdibleHoeItem(ModToolTiers.SWEET_BERRIES, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        SWEET_BERRY_HELMET = reg("sweet_berry_helmet", new EdibleArmorItem(ModArmorMaterials.SWEET_BERRY, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(10).method_19237(0.1f).method_19242())));
        SWEET_BERRY_CHESTPLATE = reg("sweet_berry_chestplate", new EdibleArmorItem(ModArmorMaterials.SWEET_BERRY, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        SWEET_BERRY_LEGGINGS = reg("sweet_berry_leggings", new EdibleArmorItem(ModArmorMaterials.SWEET_BERRY, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        SWEET_BERRY_BOOTS = reg("sweet_berry_boots", new EdibleArmorItem(ModArmorMaterials.SWEET_BERRY, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(8).method_19237(0.1f).method_19242())));
        PUMPKIN_PIE_SWORD = reg("pumpkin_pie_sword", new EdibleSwordItem(ModToolTiers.PUMPKIN_PIE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        PUMPKIN_PIE_PICKAXE = reg("pumpkin_pie_pickaxe", new EdiblePickaxeItem(ModToolTiers.PUMPKIN_PIE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        PUMPKIN_PIE_SHOVEL = reg("pumpkin_pie_shovel", new EdibleShovelItem(ModToolTiers.PUMPKIN_PIE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(2).method_19237(0.1f).method_19242())));
        PUMPKIN_PIE_AXE = reg("pumpkin_pie_axe", new EdibleAxeItem(ModToolTiers.PUMPKIN_PIE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        PUMPKIN_PIE_HOE = reg("pumpkin_pie_hoe", new EdibleHoeItem(ModToolTiers.PUMPKIN_PIE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        PUMPKIN_PIE_HELMET = reg("pumpkin_pie_helmet", new EdibleArmorItem(ModArmorMaterials.PUMPKIN_PIE, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(10).method_19237(0.1f).method_19242())));
        PUMPKIN_PIE_CHESTPLATE = reg("pumpkin_pie_chestplate", new EdibleArmorItem(ModArmorMaterials.PUMPKIN_PIE, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        PUMPKIN_PIE_LEGGINGS = reg("pumpkin_pie_leggings", new EdibleArmorItem(ModArmorMaterials.PUMPKIN_PIE, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        PUMPKIN_PIE_BOOTS = reg("pumpkin_pie_boots", new EdibleArmorItem(ModArmorMaterials.PUMPKIN_PIE, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(8).method_19237(0.1f).method_19242())));
        MUSHROOM_SWORD = reg("mushroom_sword", new EdibleSwordItem(ModToolTiers.MUSHROOM, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        MUSHROOM_PICKAXE = reg("mushroom_pickaxe", new EdiblePickaxeItem(ModToolTiers.MUSHROOM, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        MUSHROOM_SHOVEL = reg("mushroom_shovel", new EdibleShovelItem(ModToolTiers.MUSHROOM, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(2).method_19237(0.1f).method_19242())));
        MUSHROOM_AXE = reg("mushroom_axe", new EdibleAxeItem(ModToolTiers.MUSHROOM, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        MUSHROOM_HOE = reg("mushroom_hoe", new EdibleHoeItem(ModToolTiers.MUSHROOM, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        MUSHROOM_HELMET = reg("mushroom_helmet", new EdibleArmorItem(ModArmorMaterials.MUSHROOM, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(10).method_19237(0.1f).method_19242())));
        MUSHROOM_CHESTPLATE = reg("mushroom_chestplate", new EdibleArmorItem(ModArmorMaterials.MUSHROOM, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        MUSHROOM_LEGGINGS = reg("mushroom_leggings", new EdibleArmorItem(ModArmorMaterials.MUSHROOM, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        MUSHROOM_BOOTS = reg("mushroom_boots", new EdibleArmorItem(ModArmorMaterials.MUSHROOM, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(8).method_19237(0.1f).method_19242())));
        PUFFERFISH_SWORD = reg("pufferfish_sword", new EdibleSwordItem(ModToolTiers.PUFFERFISH, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        PUFFERFISH_PICKAXE = reg("pufferfish_pickaxe", new EdiblePickaxeItem(ModToolTiers.PUFFERFISH, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        PUFFERFISH_SHOVEL = reg("pufferfish_shovel", new EdibleShovelItem(ModToolTiers.PUFFERFISH, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(2).method_19237(0.1f).method_19242())));
        PUFFERFISH_AXE = reg("pufferfish_axe", new EdibleAxeItem(ModToolTiers.PUFFERFISH, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        PUFFERFISH_HOE = reg("pufferfish_hoe", new EdibleHoeItem(ModToolTiers.PUFFERFISH, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        PUFFERFISH_HELMET = reg("pufferfish_helmet", new EdibleArmorItem(ModArmorMaterials.PUFFERFISH, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(10).method_19237(0.1f).method_19242())));
        PUFFERFISH_CHESTPLATE = reg("pufferfish_chestplate", new EdibleArmorItem(ModArmorMaterials.PUFFERFISH, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        PUFFERFISH_LEGGINGS = reg("pufferfish_leggings", new EdibleArmorItem(ModArmorMaterials.PUFFERFISH, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        PUFFERFISH_BOOTS = reg("pufferfish_boots", new EdibleArmorItem(ModArmorMaterials.PUFFERFISH, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(8).method_19237(0.1f).method_19242())));
        HONEY_SWORD = reg("honey_sword", new EdibleSwordItem(ModToolTiers.HONEY, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        HONEY_PICKAXE = reg("honey_pickaxe", new EdiblePickaxeItem(ModToolTiers.HONEY, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        HONEY_SHOVEL = reg("honey_shovel", new EdibleShovelItem(ModToolTiers.HONEY, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(2).method_19237(0.1f).method_19242())));
        HONEY_AXE = reg("honey_axe", new EdibleAxeItem(ModToolTiers.HONEY, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        HONEY_HOE = reg("honey_hoe", new EdibleHoeItem(ModToolTiers.HONEY, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        HONEY_HELMET = reg("honey_helmet", new EdibleArmorItem(ModArmorMaterials.HONEY, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(10).method_19237(0.1f).method_19242())));
        HONEY_CHESTPLATE = reg("honey_chestplate", new EdibleArmorItem(ModArmorMaterials.HONEY, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        HONEY_LEGGINGS = reg("honey_leggings", new EdibleArmorItem(ModArmorMaterials.HONEY, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        HONEY_BOOTS = reg("honey_boots", new EdibleArmorItem(ModArmorMaterials.HONEY, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(8).method_19237(0.1f).method_19242())));
        CHORUS_FRUIT_SWORD = reg("chorus_fruit_sword", new EdibleSwordItem(ModToolTiers.CHORUS_FRUIT, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        CHORUS_FRUIT_PICKAXE = reg("chorus_fruit_pickaxe", new EdiblePickaxeItem(ModToolTiers.CHORUS_FRUIT, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        CHORUS_FRUIT_SHOVEL = reg("chorus_fruit_shovel", new EdibleShovelItem(ModToolTiers.CHORUS_FRUIT, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(2).method_19237(0.1f).method_19242())));
        CHORUS_FRUIT_AXE = reg("chorus_fruit_axe", new EdibleAxeItem(ModToolTiers.CHORUS_FRUIT, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        CHORUS_FRUIT_HOE = reg("chorus_fruit_hoe", new EdibleHoeItem(ModToolTiers.CHORUS_FRUIT, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        CHORUS_FRUIT_HELMET = reg("chorus_fruit_helmet", new EdibleArmorItem(ModArmorMaterials.CHORUS_FRUIT, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(10).method_19237(0.1f).method_19242())));
        CHORUS_FRUIT_CHESTPLATE = reg("chorus_fruit_chestplate", new EdibleArmorItem(ModArmorMaterials.CHORUS_FRUIT, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        CHORUS_FRUIT_LEGGINGS = reg("chorus_fruit_leggings", new EdibleArmorItem(ModArmorMaterials.CHORUS_FRUIT, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        CHORUS_FRUIT_BOOTS = reg("chorus_fruit_boots", new EdibleArmorItem(ModArmorMaterials.CHORUS_FRUIT, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(8).method_19237(0.1f).method_19242())));
        GOLDEN_APPLE_SWORD = reg("golden_apple_sword", new EdibleSwordItem(ModToolTiers.GOLDEN_APPLE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        GOLDEN_APPLE_PICKAXE = reg("golden_apple_pickaxe", new EdiblePickaxeItem(ModToolTiers.GOLDEN_APPLE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        GOLDEN_APPLE_SHOVEL = reg("golden_apple_shovel", new EdibleShovelItem(ModToolTiers.GOLDEN_APPLE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(2).method_19237(0.1f).method_19242())));
        GOLDEN_APPLE_AXE = reg("golden_apple_axe", new EdibleAxeItem(ModToolTiers.GOLDEN_APPLE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(6).method_19237(0.1f).method_19242())));
        GOLDEN_APPLE_HOE = reg("golden_apple_hoe", new EdibleHoeItem(ModToolTiers.GOLDEN_APPLE, new class_1792.class_1793()
                    .method_19265(new class_4174.class_4175().method_19238(4).method_19237(0.1f).method_19242())));
        GOLDEN_APPLE_HELMET = reg("golden_apple_helmet", new EdibleArmorItem(ModArmorMaterials.GOLDEN_APPLE, class_1738.class_8051.field_41934,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(10).method_19237(0.1f).method_19242())));
        GOLDEN_APPLE_CHESTPLATE = reg("golden_apple_chestplate", new EdibleArmorItem(ModArmorMaterials.GOLDEN_APPLE, class_1738.class_8051.field_41935,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        GOLDEN_APPLE_LEGGINGS = reg("golden_apple_leggings", new EdibleArmorItem(ModArmorMaterials.GOLDEN_APPLE, class_1738.class_8051.field_41936,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(14).method_19237(0.1f).method_19242())));
        GOLDEN_APPLE_BOOTS = reg("golden_apple_boots", new EdibleArmorItem(ModArmorMaterials.GOLDEN_APPLE, class_1738.class_8051.field_41937,
                    new class_1792.class_1793()
                            .method_19265(new class_4174.class_4175().method_19238(8).method_19237(0.1f).method_19242())));
    }

    private static <T extends class_1792> T reg(String name, T item) {
        class_2378.method_10230(class_7923.field_41178, new class_2960(UsefultoolsMod.MOD_ID, name), item);
        return item;
    }
}
