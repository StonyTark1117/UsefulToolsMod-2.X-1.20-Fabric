package com.stonytark.usefultoolsmod.item;

import com.stonytark.usefultoolsmod.block.ModBlocks;
import java.util.function.Supplier;
import net.minecraft.class_1802;
import net.minecraft.class_1832;
import net.minecraft.class_1856;

public class ModToolTiers {
    // Mining levels: 0=wood, 1=stone, 2=iron, 3=diamond, 4=netherite

    // == MAIN CUSTOM TIERS ==
    public static final class_1832 REMERALD = create(3, 1361, 4.5f, 6, 22, () -> class_1856.method_8091(class_1802.field_8687));
    public static final class_1832 PEMERALD = create(3, 1561, 3.2f, 7, 30, () -> class_1856.method_8091(ModItems.SEM));
    public static final class_1832 ROBSIDIAN = create(4, 1650, 6f, 9, 15, () -> class_1856.method_8091(ModItems.OBSHARD));
    public static final class_1832 POBSIDIAN = create(4, 2031, 5f, 10, 18, () -> class_1856.method_8091(ModItems.OBINGOT));
    public static final class_1832 OVERPOWER = create(4, 9999, 30f, 25, 35, () -> class_1856.method_8091(ModBlocks.SOBLOCK.method_8389()));
    public static final class_1832 HREDSTONE = create(2, 600, 3f, 8, 20, () -> class_1856.method_8091(ModItems.HRED));
    public static final class_1832 HGLOWSTONE = create(2, 500, 2f, 7, 28, () -> class_1856.method_8091(ModItems.HGLOW));
    public static final class_1832 RGOLD = create(3, 1200, 3.5f, 8, 16, () -> class_1856.method_8091(ModItems.RGOLD));
    public static final class_1832 RLAPIS = create(3, 1100, 3.2f, 9, 32, () -> class_1856.method_8091(ModItems.RLAPIS));

    // == WOOD TIERS ==
    public static final class_1832 COAL_TOOL = create(0, 120, 3.0f, 0, 5, () -> class_1856.method_8091(ModItems.HARDENED_COAL));
    public static final class_1832 RRAW_GOLD = create(0, 80, 0.0f, 12, 25, () -> class_1856.method_8091(class_1802.field_33402));
    public static final class_1832 RRAW_COPPER = create(1, 170, 1.0f, 5, 10, () -> class_1856.method_8091(class_1802.field_33401));
    public static final class_1832 RRAW_IRON = create(2, 200, 1.5f, 5.5f, 10, () -> class_1856.method_8091(class_1802.field_33400));
    public static final class_1832 RRAW_RGOLD = create(2, 600, 2.0f, 7, 14, () -> class_1856.method_8091(ModItems.RAW_RGOLD));
    public static final class_1832 RSCRAP = create(3, 800, 2.5f, 7.5f, 12, () -> class_1856.method_8091(class_1802.field_22021));

    // == CRYSTAL ROUGH TIERS ==
    public static final class_1832 RAMETHYST = create(1, 250, 1.5f, 5, 12, () -> class_1856.method_8091(class_1802.field_27063));
    public static final class_1832 SNOW_TOOL = create(0, 45, 0.0f, 3, 4, () -> class_1856.method_8091(class_1802.field_8543));
    public static final class_1832 RQUARTZ = create(1, 310, 1.5f, 5.5f, 10, () -> class_1856.method_8091(class_1802.field_8155));
    public static final class_1832 RPRISM = create(1, 240, 1.5f, 4.5f, 8, () -> class_1856.method_8091(class_1802.field_8662));

    // == STONE VARIANTS ==
    public static final class_1832 STONE_ANDESITE = create(1, 131, 1.5f, 4, 5, () -> class_1856.method_8091(class_1802.field_20407));
    public static final class_1832 STONE_BASALT = create(1, 155, 2.0f, 3.8f, 4, () -> class_1856.method_8091(class_1802.field_22000));
    public static final class_1832 STONE_BLACKSTONE = create(1, 170, 2.0f, 3.7f, 5, () -> class_1856.method_8091(class_1802.field_23843));
    public static final class_1832 STONE_CALCITE = create(1, 75, 0.5f, 4.5f, 8, () -> class_1856.method_8091(class_1802.field_27020));
    public static final class_1832 STONE_DEEPSLATE = create(1, 178, 2.0f, 3.5f, 4, () -> class_1856.method_8091(class_1802.field_29025));
    public static final class_1832 STONE_DIORITE = create(1, 140, 1.5f, 3.9f, 6, () -> class_1856.method_8091(class_1802.field_20401));
    public static final class_1832 STONE_END_STONE = create(1, 145, 1.5f, 4.1f, 7, () -> class_1856.method_8091(class_1802.field_20399));
    public static final class_1832 STONE_GRANITE = create(1, 158, 2.0f, 3.7f, 5, () -> class_1856.method_8091(class_1802.field_20394));
    public static final class_1832 STONE_NETHERRACK = create(1, 80, 0.5f, 4.8f, 6, () -> class_1856.method_8091(class_1802.field_8328));
    public static final class_1832 STONE_SANDSTONE = create(1, 100, 0.5f, 4.2f, 5, () -> class_1856.method_8091(class_1802.field_20384));
    public static final class_1832 STONE_SMOOTH_BASALT = create(1, 148, 1.8f, 3.9f, 5, () -> class_1856.method_8091(class_1802.field_29024));
    public static final class_1832 STONE_TERRACOTTA = create(1, 120, 1.0f, 4.0f, 7, () -> class_1856.method_8091(class_1802.field_8260));
    public static final class_1832 STONE_TUFF = create(1, 110, 1.0f, 4.0f, 5, () -> class_1856.method_8091(class_1802.field_27021));

    // == WOOD VARIANTS ==
    public static final class_1832 WOOD_OAK = create(0, 59, 0.0f, 2.0f, 15, () -> class_1856.method_8091(class_1802.field_8118));
    public static final class_1832 WOOD_SPRUCE = create(0, 65, 0.0f, 2.0f, 14, () -> class_1856.method_8091(class_1802.field_8113));
    public static final class_1832 WOOD_BIRCH = create(0, 48, 0.0f, 2.3f, 18, () -> class_1856.method_8091(class_1802.field_8191));
    public static final class_1832 WOOD_JUNGLE = create(0, 62, 0.5f, 2.1f, 14, () -> class_1856.method_8091(class_1802.field_8842));
    public static final class_1832 WOOD_ACACIA = create(0, 68, 1.0f, 1.9f, 12, () -> class_1856.method_8091(class_1802.field_8651));
    public static final class_1832 WOOD_DARK_OAK = create(0, 75, 1.0f, 1.8f, 12, () -> class_1856.method_8091(class_1802.field_8404));
    public static final class_1832 WOOD_MANGROVE = create(0, 70, 0.5f, 1.9f, 13, () -> class_1856.method_8091(class_1802.field_37507));
    public static final class_1832 WOOD_CHERRY = create(0, 42, 0.0f, 2.4f, 20, () -> class_1856.method_8091(class_1802.field_42687));
    public static final class_1832 WOOD_BAMBOO = create(0, 35, 0.0f, 2.5f, 16, () -> class_1856.method_8091(class_1802.field_40213));
    public static final class_1832 WOOD_CRIMSON = create(0, 80, 1.5f, 1.8f, 10, () -> class_1856.method_8091(class_1802.field_22031));
    public static final class_1832 WOOD_WARPED = create(0, 72, 0.5f, 2.1f, 17, () -> class_1856.method_8091(class_1802.field_22032));

    // == FLINT & HYBRID TIERS ==
    public static final class_1832 RFLINT = create(1, 200, 0.5f, 4.5f, 5, () -> class_1856.method_8091(class_1802.field_8145));
    public static final class_1832 FNI_TOOLS = create(2, 220, 2.0f, 5.5f, 9, () -> class_1856.method_8091(class_1802.field_8145));

    // == POLISHED CRYSTAL TIERS ==
    public static final class_1832 CAMETHYST = create(2, 580, 2.5f, 6.5f, 14, () -> class_1856.method_8091(ModItems.CALCIFIED_AMETHYST));
    public static final class_1832 ICE_TOOL = create(1, 180, 1.0f, 4.0f, 6, () -> class_1856.method_8091(ModItems.GLACIAL_SHARD));
    public static final class_1832 PQUARTZ = create(2, 640, 2.5f, 7.0f, 10, () -> class_1856.method_8091(ModItems.POLISHED_QUARTZ));
    public static final class_1832 PPRISM = create(2, 560, 2.0f, 6.5f, 12, () -> class_1856.method_8091(ModItems.POLISHED_PRISMARINE));

    // == LEATHER & NOVELTY ==
    public static final class_1832 LEATHER = create(0, 15, 0.0f, 1.5f, 12, () -> class_1856.method_8091(class_1802.field_8745));
    public static final class_1832 CAKE = create(0, 30, 0.0f, 1.5f, 1, () -> class_1856.method_8091(class_1802.field_17534));
    public static final class_1832 BREAD = create(0, 25, 0.0f, 1.5f, 2, () -> class_1856.method_8091(class_1802.field_8229));
    public static final class_1832 DRIED_KELP = create(0, 15, 0.5f, 1.0f, 1, () -> class_1856.method_8091(class_1802.field_8551));
    public static final class_1832 ROTTEN_FLESH = create(0, 30, 0.0f, 0.5f, 3, () -> class_1856.method_8091(class_1802.field_8511));
    public static final class_1832 MELON = create(0, 50, 0.5f, 2.5f, 4, () -> class_1856.method_8091(class_1802.field_8497));
    public static final class_1832 SWEET_BERRIES = create(0, 45, 1.0f, 2.0f, 5, () -> class_1856.method_8091(class_1802.field_16998));
    public static final class_1832 PUMPKIN_PIE = create(0, 55, 0.5f, 2.0f, 7, () -> class_1856.method_8091(class_1802.field_8741));
    public static final class_1832 MUSHROOM = create(1, 100, 1.0f, 4.0f, 10, () -> class_1856.method_8091(class_1802.field_17517));
    public static final class_1832 PUFFERFISH = create(1, 80, 1.5f, 3.5f, 8, () -> class_1856.method_8091(class_1802.field_8323));
    public static final class_1832 HONEY = create(1, 120, 1.0f, 4.0f, 10, () -> class_1856.method_8091(class_1802.field_20417));
    public static final class_1832 CHORUS_FRUIT = create(2, 250, 2.0f, 6.0f, 15, () -> class_1856.method_8091(class_1802.field_8233));
    public static final class_1832 GOLDEN_APPLE = create(2, 300, 2.5f, 7.0f, 22, () -> class_1856.method_8091(class_1802.field_8463));

    // == VANILLA MATERIALS ==
    public static final class_1832 PAPER = create(0, 8, 0.0f, 1.0f, 8, () -> class_1856.method_8091(class_1802.field_8407));
    public static final class_1832 FEATHER = create(0, 10, 0.0f, 1.5f, 15, () -> class_1856.method_8091(class_1802.field_8153));
    public static final class_1832 GLASS = create(0, 5, 1.0f, 5.0f, 1, () -> class_1856.method_8091(class_1802.field_8141));
    public static final class_1832 CACTUS = create(0, 70, 1.5f, 2.5f, 5, () -> class_1856.method_8091(class_1802.field_17520));
    public static final class_1832 SPONGE = create(0, 40, 0.0f, 1.5f, 3, () -> class_1856.method_8091(class_1802.field_8535));
    public static final class_1832 BONE = create(1, 150, 1.0f, 3.5f, 6, () -> class_1856.method_8091(class_1802.field_8606));
    public static final class_1832 CLAY = create(1, 90, 0.5f, 2.5f, 8, () -> class_1856.method_8091(class_1802.field_8696));
    public static final class_1832 NETHER_WART = create(1, 100, 0.5f, 3.0f, 10, () -> class_1856.method_8091(class_1802.field_8790));
    public static final class_1832 BRICK = create(1, 200, 1.5f, 4.0f, 5, () -> class_1856.method_8091(class_1802.field_8621));
    public static final class_1832 NETHER_BRICK = create(1, 220, 1.5f, 4.0f, 5, () -> class_1856.method_8091(class_1802.field_8729));
    public static final class_1832 POINTED_DRIPSTONE = create(1, 160, 2.0f, 4.5f, 4, () -> class_1856.method_8091(class_1802.field_28042));
    public static final class_1832 COPPER = create(1, 200, 1.5f, 5.0f, 8, () -> class_1856.method_8091(class_1802.field_27022));
    public static final class_1832 PHANTOM_MEMBRANE = create(2, 250, 1.5f, 5.0f, 12, () -> class_1856.method_8091(class_1802.field_8614));
    public static final class_1832 MAGMA_CREAM = create(2, 200, 2.0f, 4.5f, 8, () -> class_1856.method_8091(class_1802.field_8135));
    public static final class_1832 SLIME = create(2, 180, 0.5f, 3.5f, 10, () -> class_1856.method_8091(class_1802.field_8777));
    public static final class_1832 BLAZE_ROD = create(2, 300, 2.0f, 6.0f, 10, () -> class_1856.method_8091(class_1802.field_8894));
    public static final class_1832 NAUTILUS_SHELL = create(2, 280, 2.0f, 5.5f, 14, () -> class_1856.method_8091(class_1802.field_8864));
    public static final class_1832 PURPUR = create(2, 320, 2.0f, 6.0f, 12, () -> class_1856.method_8091(class_1802.field_8882));
    public static final class_1832 GHAST_TEAR = create(2, 400, 2.5f, 6.5f, 18, () -> class_1856.method_8091(class_1802.field_8070));
    public static final class_1832 EYE_OF_ENDER = create(2, 450, 2.5f, 7.0f, 20, () -> class_1856.method_8091(class_1802.field_8449));
    public static final class_1832 SHULKER_SHELL = create(2, 500, 2.0f, 6.0f, 16, () -> class_1856.method_8091(class_1802.field_8815));
    public static final class_1832 ECHO_SHARD = create(3, 600, 3.0f, 7.5f, 18, () -> class_1856.method_8091(class_1802.field_38746));
    public static final class_1832 DRAGON_BREATH = create(3, 700, 3.5f, 8.0f, 20, () -> class_1856.method_8091(class_1802.field_8613));

    // == ECTOPLASM TIERS ==
    public static final class_1832 RECTO = create(1, 150, 1.5f, 4.5f, 10, () -> class_1856.method_8091(ModItems.ECTOPLASM));
    public static final class_1832 ECTOPLASM = create(2, 300, 2.5f, 6.5f, 16, () -> class_1856.method_8091(ModItems.REFINED_ECTOPLASM));

    private static class_1832 create(int miningLevel, int durability, float attackDamage,
                                       float miningSpeed, int enchantability, Supplier<class_1856> repairIngredient) {
        return new class_1832() {
            @Override
            public int method_8025() { return durability; }

            @Override
            public float method_8027() { return miningSpeed; }

            @Override
            public float method_8028() { return attackDamage; }

            @Override
            public int method_8024() { return miningLevel; }

            @Override
            public int method_8026() { return enchantability; }

            @Override
            public class_1856 method_8023() { return repairIngredient.get(); }
        };
    }
}
