package com.stonytark.usefultoolsmod.item;

import java.util.function.Supplier;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

// In Fabric 1.20.1, armor materials are enum-like implementations of the ArmorMaterial interface.
public enum ModArmorMaterials implements class_1741 {
    RGOLD("usefultoolsmod:rgold", 18,
            new int[]{3, 5, 5, 3}, 25,
            class_3417.field_14883, 2f, 0.1f,
            () -> class_1856.method_8091(ModItems.RGOLD)),

    OBSIDIAN("usefultoolsmod:obsidian", 45,
            new int[]{6, 7, 9, 6}, 10,
            class_3417.field_14883, 4f, 0.4f,
            () -> class_1856.method_8091(ModItems.OBINGOT)),

    EMERALD("usefultoolsmod:emerald", 33,
            new int[]{4, 6, 8, 4}, 30,
            class_3417.field_14883, 2f, 0.15f,
            () -> class_1856.method_8091(ModItems.SEM)),

    OVERPOWER("usefultoolsmod:overpower", 100,
            new int[]{15, 15, 15, 15}, 50,
            class_3417.field_14883, 8f, 1f,
            () -> class_1856.method_8091(ModItems.OBINGOT)),

    HRED("usefultoolsmod:hred", 20,
            new int[]{2, 4, 4, 3}, 23,
            class_3417.field_14883, 1.1f, 0.08f,
            () -> class_1856.method_8091(ModItems.HRED)),

    HGLOW("usefultoolsmod:hglow", 19,
            new int[]{1, 4, 5, 2}, 25,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(ModItems.HGLOW)),

    RLAPIS("usefultoolsmod:rlapis", 17,
            new int[]{3, 6, 4, 4}, 32,
            class_3417.field_14883, 1.6f, 0.15f,
            () -> class_1856.method_8091(ModItems.RLAPIS)),

    COAL("usefultoolsmod:coal", 8,
            new int[]{1, 2, 3, 1}, 8,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(ModItems.HARDENED_COAL)),

    FNI("usefultoolsmod:fni", 9,
            new int[]{1, 4, 5, 2}, 9,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8145)),

    CAMETHYST("usefultoolsmod:camethyst", 14,
            new int[]{2, 5, 6, 2}, 14,
            class_3417.field_14883, 0.5f, 0f,
            () -> class_1856.method_8091(ModItems.CALCIFIED_AMETHYST)),

    ICE("usefultoolsmod:ice", 8,
            new int[]{1, 3, 4, 1}, 8,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(ModItems.GLACIAL_SHARD)),

    PQUARTZ("usefultoolsmod:pquartz", 15,
            new int[]{2, 5, 6, 2}, 10,
            class_3417.field_14883, 0.5f, 0.05f,
            () -> class_1856.method_8091(ModItems.POLISHED_QUARTZ)),

    PPRISM("usefultoolsmod:pprism", 14,
            new int[]{2, 5, 6, 2}, 12,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(ModItems.POLISHED_PRISMARINE)),

    CAKE("usefultoolsmod:cake", 1,
            new int[]{0, 1, 1, 0}, 1,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_17534)),

    BREAD("usefultoolsmod:bread", 2,
            new int[]{0, 1, 2, 0}, 2,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8229)),

    DRIED_KELP("usefultoolsmod:dried_kelp", 1,
            new int[]{1, 1, 1, 0}, 1,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8551)),

    ROTTEN_FLESH("usefultoolsmod:rotten_flesh", 3,
            new int[]{0, 2, 1, 0}, 3,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8511)),

    MELON("usefultoolsmod:melon", 4,
            new int[]{1, 2, 3, 1}, 4,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8497)),

    SWEET_BERRY("usefultoolsmod:sweet_berry", 5,
            new int[]{1, 2, 2, 1}, 5,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_16998)),

    PUMPKIN_PIE("usefultoolsmod:pumpkin_pie", 7,
            new int[]{1, 2, 2, 2}, 7,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8741)),

    MUSHROOM("usefultoolsmod:mushroom", 10,
            new int[]{1, 3, 4, 2}, 10,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_17517)),

    PUFFERFISH("usefultoolsmod:pufferfish", 8,
            new int[]{1, 3, 3, 1}, 8,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8323)),

    HONEY("usefultoolsmod:honey", 10,
            new int[]{2, 3, 4, 2}, 10,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_20417)),

    CHORUS_FRUIT("usefultoolsmod:chorus_fruit", 15,
            new int[]{2, 5, 6, 2}, 15,
            class_3417.field_14883, 0.5f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8233)),

    GOLDEN_APPLE("usefultoolsmod:golden_apple", 22,
            new int[]{2, 5, 6, 3}, 22,
            class_3417.field_14883, 1f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8463)),

    ECTO("usefultoolsmod:ecto", 16,
            new int[]{2, 5, 6, 2}, 16,
            class_3417.field_14883, 0.5f, 0f,
            () -> class_1856.method_8091(ModItems.REFINED_ECTOPLASM)),

    // ── Vanilla material armor materials ───────────────────────────────────────

    /** Rabbit Hide — weak leather-equivalent, bunny hop full set. */
    RABBIT_HIDE("usefultoolsmod:rabbit_hide", 5,
            new int[]{1, 2, 3, 1}, 12,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8245)),

    /** Cactus — prickly weak armor, thorns on hit. */
    CACTUS("usefultoolsmod:cactus", 7,
            new int[]{1, 2, 3, 1}, 5,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_17520)),

    /** Bone — low-mid tier, undead bane synergy. */
    BONE("usefultoolsmod:bone", 10,
            new int[]{1, 3, 4, 1}, 6,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8606)),

    /** Clay — low-mid tier, enchantable. */
    CLAY("usefultoolsmod:clay", 8,
            new int[]{1, 2, 3, 1}, 8,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8696)),

    /** Brick — stone-tier, durable and tough. */
    BRICK("usefultoolsmod:brick", 12,
            new int[]{1, 4, 5, 2}, 5,
            class_3417.field_14883, 0.5f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8621)),

    /** Nether Brick — stone-tier, fire-themed. */
    NETHER_BRICK("usefultoolsmod:nether_brick", 12,
            new int[]{1, 4, 5, 2}, 5,
            class_3417.field_14883, 0.5f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8729)),

    /** Copper — stone-tier, oxidizes over time. */
    COPPER("usefultoolsmod:copper", 13,
            new int[]{2, 4, 5, 2}, 8,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_27022)),

    /** Phantom Membrane — upper-mid tier, slow falling. */
    PHANTOM("usefultoolsmod:phantom", 14,
            new int[]{2, 4, 5, 2}, 12,
            class_3417.field_14883, 0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8614)),

    /** Magma Cream — upper-mid tier, fire protection. */
    MAGMA_CREAM("usefultoolsmod:magma_cream", 13,
            new int[]{2, 4, 5, 2}, 8,
            class_3417.field_14883, 0.5f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8135)),

    /** Slime — upper-mid tier, bouncy. */
    SLIME("usefultoolsmod:slime", 12,
            new int[]{2, 3, 4, 2}, 10,
            class_3417.field_14883, 0f, 0.1f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8777)),

    /** Blaze Rod — iron-level, fire resistance. */
    BLAZE("usefultoolsmod:blaze", 15,
            new int[]{2, 5, 6, 2}, 10,
            class_3417.field_14883, 0.5f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8894)),

    /** Nautilus Shell — iron-level, conduit affinity. */
    NAUTILUS("usefultoolsmod:nautilus", 16,
            new int[]{2, 5, 6, 2}, 14,
            class_3417.field_14883, 0.5f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8864)),

    /** Purpur — iron-level, ender resilience. */
    PURPUR("usefultoolsmod:purpur", 15,
            new int[]{2, 5, 6, 2}, 12,
            class_3417.field_14883, 0.5f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8882)),

    /** Ghast Tear — above-iron, regeneration. */
    GHAST_TEAR("usefultoolsmod:ghast_tear", 20,
            new int[]{2, 5, 6, 3}, 18,
            class_3417.field_14883, 1.0f, 0f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8070)),

    /** Eye of Ender — above-iron, ender sight. */
    EYE_OF_ENDER("usefultoolsmod:eye_of_ender", 22,
            new int[]{2, 5, 7, 3}, 20,
            class_3417.field_14883, 1.0f, 0.05f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8449)),

    /** Shulker Shell — above-iron, levitation shield. */
    SHULKER("usefultoolsmod:shulker", 25,
            new int[]{3, 6, 7, 3}, 16,
            class_3417.field_14883, 1.5f, 0.1f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8815)),

    /** Turtle Scute — diamond-adjacent, ocean guardian. */
    TURTLE_SCUTE("usefultoolsmod:turtle_scute", 25,
            new int[]{2, 5, 7, 3}, 16,
            class_3417.field_14883, 1.5f, 0.05f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8161)),

    /** Echo Shard — diamond-adjacent, sculk resonance. */
    ECHO_SHARD("usefultoolsmod:echo_shard", 30,
            new int[]{3, 6, 7, 3}, 18,
            class_3417.field_14883, 2.0f, 0.05f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_38746)),

    /** Dragon's Breath — endgame, draconic aura. */
    DRAGON_BREATH("usefultoolsmod:dragon_breath", 35,
            new int[]{3, 6, 8, 3}, 20,
            class_3417.field_14883, 2.5f, 0.1f,
            () -> class_1856.method_8091(net.minecraft.class_1802.field_8613));

    // Base durability values (same as vanilla: boots, leggings, chestplate, helmet)
    private static final int[] BASE_DURABILITY = {13, 15, 16, 11};

    private final String name;
    private final int durabilityMultiplier;
    private final int[] protectionAmounts; // boots, leggings, chestplate, helmet
    private final int enchantability;
    private final class_3414 equipSound;
    private final float toughness;
    private final float knockbackResistance;
    private final Supplier<class_1856> repairIngredient;

    ModArmorMaterials(String name, int durabilityMultiplier,
                      int[] protectionAmounts, int enchantability,
                      class_3414 equipSound, float toughness,
                      float knockbackResistance, Supplier<class_1856> repairIngredient) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.protectionAmounts = protectionAmounts;
        this.enchantability = enchantability;
        this.equipSound = equipSound;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.repairIngredient = repairIngredient;
    }

    public static void register() {
        // Registration happens automatically for enum, but we can add this for clarity
    }

    @Override
    public int method_48402(class_1738.class_8051 type) {
        return BASE_DURABILITY[type.method_48399().method_5927()] * this.durabilityMultiplier;
    }

    @Override
    public int method_48403(class_1738.class_8051 type) {
        return this.protectionAmounts[type.method_48399().method_5927()];
    }

    @Override
    public int method_7699() {
        return this.enchantability;
    }

    @Override
    public class_3414 method_7698() {
        return this.equipSound;
    }

    @Override
    public class_1856 method_7695() {
        return this.repairIngredient.get();
    }

    @Override
    public String method_7694() {
        return this.name;
    }

    @Override
    public float method_7700() {
        return this.toughness;
    }

    @Override
    public float method_24355() {
        return this.knockbackResistance;
    }
}
