package com.stonytark.usefultoolsmod.item.custom;

import net.minecraft.class_1799;
import net.minecraft.class_2487;

public final class CoalBurningHelper {
    private static final String TAG_KEY = "coal_burning";

    private CoalBurningHelper() {}

    public static boolean isBurning(class_1799 stack) {
        if (stack.method_7960()) return false;
        class_2487 nbt = stack.method_7969();
        if (nbt == null) return false;
        return nbt.method_10577(TAG_KEY);
    }

    public static void setBurning(class_1799 stack, boolean burning) {
        if (stack.method_7960()) return;

        if (burning) {
            stack.method_7948().method_10556(TAG_KEY, true);
        } else {
            class_2487 nbt = stack.method_7969();
            if (nbt != null) {
                nbt.method_10551(TAG_KEY);
                if (nbt.method_33133()) {
                    stack.method_7980(null);
                }
            }
        }
    }
}
