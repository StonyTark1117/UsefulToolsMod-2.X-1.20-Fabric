package com.stonytark.usefultoolsmod.item.custom;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1821;
import net.minecraft.class_1832;

public class EctoShovelItem extends class_1821 {

    public EctoShovelItem(class_1832 material, float attackDamage, float attackSpeed, class_1792.class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

    @Override
    public class_1799 method_7854() {
        class_1799 stack = super.method_7854();
        EctoplasmInfusionHelper.setInfused(stack, true);
        return stack;
    }
}
