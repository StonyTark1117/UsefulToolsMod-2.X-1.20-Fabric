package com.stonytark.usefultoolsmod.item.custom;

import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1832;

public class CoalAxeItem extends class_1743 {

    public CoalAxeItem(class_1832 material, float attackDamage, float attackSpeed, class_1792.class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return CoalBurningHelper.isBurning(stack) || super.method_7886(stack);
    }
}
