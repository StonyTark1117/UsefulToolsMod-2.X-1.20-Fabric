package com.stonytark.usefultoolsmod.item.custom;

import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1821;
import net.minecraft.class_1832;
import net.minecraft.class_1937;

public class EdibleShovelItem extends class_1821 {
    public EdibleShovelItem(class_1832 material, class_1792.class_1793 settings) {
        super(material, 1.5f, -3f, settings);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        class_1799 result = super.method_7861(stack, world, user);
        result.method_7934(1);
        return result;
    }
}
