package com.stonytark.usefultoolsmod.item.custom;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;

public class EctoSwordItem extends class_1829 {

    public EctoSwordItem(class_1832 material, class_1792.class_1793 settings) {
        super(material, 3, -2.4f, settings);
    }

    @Override
    public class_1799 method_7854() {
        class_1799 stack = super.method_7854();
        EctoplasmInfusionHelper.setInfused(stack, true);
        return stack;
    }
}
