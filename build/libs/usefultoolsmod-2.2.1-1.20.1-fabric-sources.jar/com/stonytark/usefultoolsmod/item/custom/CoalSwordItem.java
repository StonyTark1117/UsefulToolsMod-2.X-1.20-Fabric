package com.stonytark.usefultoolsmod.item.custom;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;

public class CoalSwordItem extends class_1829 {

    public CoalSwordItem(class_1832 material, int attackDamage, float attackSpeed, class_1792.class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return CoalBurningHelper.isBurning(stack) || super.method_7886(stack);
    }
}
