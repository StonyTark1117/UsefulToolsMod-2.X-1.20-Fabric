package com.stonytark.usefultoolsmod.item.custom;

import net.minecraft.class_1741;

public class CakeArmorItem extends EdibleArmorItem {
    public CakeArmorItem(class_1741 material, class_8051 type, class_1793 settings) {
        super(material, type, settings);
    }
}
