package com.stonytark.usefultoolsmod.item.custom;

import com.google.common.collect.ImmutableMap;
import com.stonytark.usefultoolsmod.Config;
import com.stonytark.usefultoolsmod.item.ModArmorMaterials;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class ModArmorItem extends class_1738 {
    private static final Map<class_1741, List<class_1293>> MATERIAL_TO_EFFECT_MAP =
            (new ImmutableMap.Builder<class_1741, List<class_1293>>())
                    .put(ModArmorMaterials.OVERPOWER,
                            List.of(new class_1293(class_1294.field_5913, 200, 3, false, false),
                                    new class_1293(class_1294.field_5907, 200, 5, false, false),
                                    new class_1293(class_1294.field_5898, 200, 2, false, false),
                                    new class_1293(class_1294.field_5918, 200, 5, false, false),
                                    new class_1293(class_1294.field_5914, 200, 3, false, false),
                                    new class_1293(class_1294.field_5904, 200, 4, false, false),
                                    new class_1293(class_1294.field_5924, 200, 4, false, false)))
                    .build();

    public ModArmorItem(class_1741 material, class_8051 type, class_1793 settings) {
        super(material, type, settings);
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        if (entity instanceof class_1657 player && !world.method_8608() && hasFullSuitOfArmorOn(player)
                && Config.overpowerEnabled && Config.opArmorEffectsEnabled) {
            evaluateArmorEffects(player);
        }
    }

    private void evaluateArmorEffects(class_1657 player) {
        for (Map.Entry<class_1741, List<class_1293>> entry : MATERIAL_TO_EFFECT_MAP.entrySet()) {
            class_1741 mapArmorMaterial = entry.getKey();
            List<class_1293> mapEffect = entry.getValue();

            if (hasPlayerCorrectArmorOn(mapArmorMaterial, player)) {
                addEffectToPlayer(player, mapEffect);
            }
        }
    }

    private void addEffectToPlayer(class_1657 player, List<class_1293> mapEffect) {
        boolean hasPlayerEffect = mapEffect.stream().allMatch(effect -> player.method_6059(effect.method_5579()));

        if (!hasPlayerEffect) {
            for (class_1293 effect : mapEffect) {
                player.method_6092(new class_1293(effect.method_5579(),
                        effect.method_5584(), effect.method_5578(), effect.method_5591(), effect.method_5581()));
            }
        }
    }

    private boolean hasPlayerCorrectArmorOn(class_1741 mapArmorMaterial, class_1657 player) {
        for (class_1799 armorStack : player.method_5661()) {
            if (!(armorStack.method_7909() instanceof class_1738)) {
                return false;
            }
        }

        class_1738 boots = ((class_1738) player.method_31548().method_7372(0).method_7909());
        class_1738 leggings = ((class_1738) player.method_31548().method_7372(1).method_7909());
        class_1738 chestplate = ((class_1738) player.method_31548().method_7372(2).method_7909());
        class_1738 helmet = ((class_1738) player.method_31548().method_7372(3).method_7909());

        return boots.method_7686() == mapArmorMaterial && leggings.method_7686() == mapArmorMaterial
                && chestplate.method_7686() == mapArmorMaterial && helmet.method_7686() == mapArmorMaterial;
    }

    private boolean hasFullSuitOfArmorOn(class_1657 player) {
        class_1799 boots = player.method_31548().method_7372(0);
        class_1799 leggings = player.method_31548().method_7372(1);
        class_1799 chestplate = player.method_31548().method_7372(2);
        class_1799 helmet = player.method_31548().method_7372(3);

        return !boots.method_7960() && !leggings.method_7960() && !chestplate.method_7960() && !helmet.method_7960();
    }
}
