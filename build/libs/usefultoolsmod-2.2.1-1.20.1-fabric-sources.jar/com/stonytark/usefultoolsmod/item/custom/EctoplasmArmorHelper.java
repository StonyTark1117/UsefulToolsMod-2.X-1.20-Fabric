package com.stonytark.usefultoolsmod.item.custom;

import com.stonytark.usefultoolsmod.item.ModArmorMaterials;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1799;

/**
 * Utility for checking if a player is protected from ghost detection
 * by wearing ectoplasm armor or ectoplasm-infused armor.
 */
public final class EctoplasmArmorHelper {

    private EctoplasmArmorHelper() {}

    /**
     * Returns true if the player is "ghost-invisible" — ghosts will ignore them.
     * Condition: full set of ecto armor material, OR all 4 armor slots filled with ectoplasm-infused armor.
     */
    public static boolean isGhostInvisible(class_1657 player) {
        // Check for full ecto armor set (native ecto material)
        if (hasFullEctoArmorSet(player)) return true;

        // Check if ALL 4 armor slots are filled AND infused (any armor type, including modded)
        int slotCount = 0;
        for (class_1799 armorStack : player.method_5661()) {
            if (armorStack.method_7960() || !EctoplasmInfusionHelper.isInfused(armorStack)) {
                return false;
            }
            slotCount++;
        }
        return slotCount == 4;
    }

    public static boolean hasFullEctoArmorSet(class_1657 player) {
        for (class_1799 armorStack : player.method_5661()) {
            if (armorStack.method_7960()) return false;
            if (!(armorStack.method_7909() instanceof class_1738 armor)) return false;
            if (armor.method_7686() != ModArmorMaterials.ECTO) return false;
        }
        return true;
    }
}
