package com.stonytark.usefultoolsmod.item.custom;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2487;

public final class EctoplasmInfusionHelper {
    private static final String TAG_KEY = "ectoplasm_infused";

    private EctoplasmInfusionHelper() {}

    public static boolean isInfused(class_1799 stack) {
        if (stack.method_7960()) return false;
        // Ecto tools are inherently infused — no tag check needed
        if (isEctoItem(stack.method_7909())) return true;
        class_2487 nbt = stack.method_7969();
        if (nbt == null) return false;
        return nbt.method_10577(TAG_KEY);
    }

    /** Returns true if the item is an ecto tool class (always considered infused). */
    public static boolean isEctoItem(class_1792 item) {
        return item instanceof EctoSwordItem
            || item instanceof EctoPickaxeItem
            || item instanceof EctoAxeItem
            || item instanceof EctoShovelItem
            || item instanceof EctoHoeItem;
    }

    public static void setInfused(class_1799 stack, boolean infused) {
        if (stack.method_7960()) return;

        if (infused) {
            stack.method_7948().method_10556(TAG_KEY, true);
        } else {
            class_2487 nbt = stack.method_7969();
            if (nbt != null) {
                nbt.method_10551(TAG_KEY);
                if (nbt.method_33133()) {
                    stack.method_7980(null);
                }
            }
        }
    }
}
