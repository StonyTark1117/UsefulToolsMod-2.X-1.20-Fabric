package com.stonytark.usefultoolsmod.item.custom;

import com.stonytark.usefultoolsmod.entity.ModEntities;
import com.stonytark.usefultoolsmod.entity.custom.GrenadeEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class Grenade extends class_1792 {
    public Grenade(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                class_3417.field_15079, class_3419.field_15248,
                0.7F, 0.8F + world.field_9229.method_43057() * 0.2F);

        if (!world.field_9236) {
            GrenadeEntity grenade = new GrenadeEntity(ModEntities.GRENADE, world, player);
            grenade.method_24919(player, player.method_36455(), player.method_36454(), 0.0F, 1.1F, 1.0F);
            world.method_8649(grenade);
        }

        if (!player.method_31549().field_7477) {
            stack.method_7934(1);
        }

        return class_1271.method_29237(stack, world.method_8608());
    }
}
