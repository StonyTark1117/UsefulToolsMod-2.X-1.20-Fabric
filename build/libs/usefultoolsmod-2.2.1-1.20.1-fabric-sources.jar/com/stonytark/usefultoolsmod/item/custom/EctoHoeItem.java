package com.stonytark.usefultoolsmod.item.custom;

import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1832;

public class EctoHoeItem extends class_1794 {

    public EctoHoeItem(class_1832 material, int attackDamage, float attackSpeed, class_1792.class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

    @Override
    public class_1799 method_7854() {
        class_1799 stack = super.method_7854();
        EctoplasmInfusionHelper.setInfused(stack, true);
        return stack;
    }
}
