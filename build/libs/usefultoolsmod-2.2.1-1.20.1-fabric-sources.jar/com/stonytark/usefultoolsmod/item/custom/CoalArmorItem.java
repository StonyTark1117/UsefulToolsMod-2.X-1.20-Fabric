package com.stonytark.usefultoolsmod.item.custom;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class CoalArmorItem extends class_1738 {

    public CoalArmorItem(class_1741 material, class_8051 type, class_1793 settings) {
        super(material, type, settings);
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return CoalBurningHelper.isBurning(stack) || super.method_7886(stack);
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        if (!world.field_9236 && entity instanceof class_1657 player && CoalBurningHelper.isBurning(stack)) {
            // Coal armor custom behavior can be added here
        }
        super.method_7888(stack, world, entity, slot, selected);
    }
}
