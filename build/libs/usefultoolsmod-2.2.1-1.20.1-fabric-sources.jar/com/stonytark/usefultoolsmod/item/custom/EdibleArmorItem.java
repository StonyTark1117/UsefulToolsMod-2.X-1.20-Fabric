package com.stonytark.usefultoolsmod.item.custom;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_4174;

public class EdibleArmorItem extends class_1738 {

    public EdibleArmorItem(class_1741 material, class_8051 type, class_1793 settings) {
        super(material, type, settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        class_4174 food = stack.method_7909().method_19264();
        if (food != null && player.method_7332(food.method_19233())) {
            player.method_6019(hand);
            return class_1271.method_22428(stack);
        }
        return super.method_7836(world, player, hand);
    }

    @Override
    public int method_7881(class_1799 stack) {
        class_4174 food = stack.method_7909().method_19264();
        if (food != null) {
            return food.method_19234() ? 16 : 32;
        }
        return super.method_7881(stack);
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {
        if (stack.method_7909().method_19264() != null) {
            return class_1839.field_8950;
        }
        return super.method_7853(stack);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        if (user instanceof class_1657 player) {
            class_4174 food = stack.method_7909().method_19264();
            if (food != null) {
                player.method_7344().method_7579(stack.method_7909(), stack);
            }
        }
        stack.method_7934(1);
        return stack;
    }
}
