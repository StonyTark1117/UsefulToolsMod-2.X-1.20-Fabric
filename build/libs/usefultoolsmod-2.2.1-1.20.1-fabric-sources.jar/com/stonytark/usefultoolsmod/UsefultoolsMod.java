package com.stonytark.usefultoolsmod;

import com.stonytark.usefultoolsmod.block.ModBlocks;
import com.stonytark.usefultoolsmod.block.entity.ModBlockEntityTypes;
import com.stonytark.usefultoolsmod.block.entity.ModMenuTypes;
import com.stonytark.usefultoolsmod.entity.ModEntities;
import com.stonytark.usefultoolsmod.entity.custom.GhostEntity;
import com.stonytark.usefultoolsmod.event.ModEvents;
import com.stonytark.usefultoolsmod.item.ModArmorMaterials;
import com.stonytark.usefultoolsmod.item.ModCreativeModeTabs;
import com.stonytark.usefultoolsmod.item.ModItems;
import com.stonytark.usefultoolsmod.trigger.ModTriggers;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1311;
import net.minecraft.class_1317;
import net.minecraft.class_2893;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UsefultoolsMod implements ModInitializer {
    public static final String MOD_ID = "usefultoolsmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Useful Tools Mod (Fabric 1.20.1)");

        // Load config before registration so flags are available
        Config.load();

        // Register in correct dependency order
        ModEntities.register();
        ModArmorMaterials.register();
        ModBlocks.register();
        ModItems.register();
        ModCreativeModeTabs.register();

        // Register block entities and menus
        ModBlockEntityTypes.register();
        ModMenuTypes.register();

        // Register triggers
        ModTriggers.register();

        // Register entity attributes
        FabricDefaultAttributeRegistry.register(ModEntities.GHOST, GhostEntity.createAttributes());

        // Register spawn placements - NO_RESTRICTIONS allows ghosts to spawn floating
        class_1317.method_20637(ModEntities.GHOST,
                class_1317.class_1319.field_19350,
                class_2902.class_2903.field_13203,
                GhostEntity::checkGhostSpawnRules);

        // Register events
        ModEvents.register();

        // Register worldgen (biome modifications)
        registerWorldgen();
    }

    private void registerWorldgen() {
        // Overworld rgold ore
        BiomeModifications.addFeature(
                BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176,
                class_5321.method_29179(class_7924.field_41245,
                        new class_2960(MOD_ID, "rgold_ore_placed")));

        // Nether rgold ore
        BiomeModifications.addFeature(
                BiomeSelectors.foundInTheNether(),
                class_2893.class_2895.field_13176,
                class_5321.method_29179(class_7924.field_41245,
                        new class_2960(MOD_ID, "nether_rgold_ore_placed")));

        // End rgold ore
        BiomeModifications.addFeature(
                BiomeSelectors.foundInTheEnd(),
                class_2893.class_2895.field_13176,
                class_5321.method_29179(class_7924.field_41245,
                        new class_2960(MOD_ID, "end_rgold_ore_placed")));

        // Note: deepslate rgold ore is included in the rgold_ore configured feature
        // (targets both stone_ore_replaceables and deepslate_ore_replaceables)

        // Ghost spawn (overworld)
        BiomeModifications.addSpawn(
                BiomeSelectors.foundInOverworld(),
                class_1311.field_6302,
                ModEntities.GHOST,
                5, 1, 3);
    }
}
