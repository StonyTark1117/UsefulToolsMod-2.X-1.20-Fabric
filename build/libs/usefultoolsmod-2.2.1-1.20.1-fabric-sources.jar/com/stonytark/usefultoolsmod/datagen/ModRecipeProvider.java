package com.stonytark.usefultoolsmod.datagen;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.block.ModBlocks;
import com.stonytark.usefultoolsmod.item.ModItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2444;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2454;
import net.minecraft.class_2960;
import net.minecraft.class_7800;
import java.util.List;
import java.util.function.Consumer;

/**
 * Fabric 1.20.1 Recipe Data Generator
 * Generates ALL crafting recipes for blocks and items
 */
public class ModRecipeProvider extends FabricRecipeProvider {
    public ModRecipeProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void method_10419(Consumer<class_2444> exporter) {
        // =====================================================================
        // Material crafting recipes
        // =====================================================================

        // Reinforced Lapis: 8 iron nuggets around lapis lazuli
        class_2447.method_10437(class_7800.field_40642, ModItems.RLAPIS)
                .method_10439("AAA")
                .method_10439("ABA")
                .method_10439("AAA")
                .method_10434('A', class_1802.field_8675).method_10434('B', class_1802.field_8759)
                .method_10429(method_32807(class_1802.field_8759), method_10426(class_1802.field_8759)).method_10431(exporter);

        // Hardened Redstone: 4 clay balls in + around redstone
        class_2447.method_10437(class_7800.field_40642, ModItems.HRED)
                .method_10439(" A ")
                .method_10439("ABA")
                .method_10439(" A ")
                .method_10434('A', class_1802.field_8696).method_10434('B', class_1802.field_8725)
                .method_10429(method_32807(class_1802.field_8725), method_10426(class_1802.field_8725)).method_10431(exporter);

        // Hardened Glowstone: 4 glowstone dust in + around a blaze rod
        class_2447.method_10437(class_7800.field_40642, ModItems.HGLOW)
                .method_10439(" A ")
                .method_10439("ABA")
                .method_10439(" A ")
                .method_10434('A', class_1802.field_8601).method_10434('B', class_1802.field_8894)
                .method_10429(method_32807(class_1802.field_8601), method_10426(class_1802.field_8601)).method_10431(exporter);

        // Super Emerald (SEM): 4 iron ingots in + around emerald
        class_2447.method_10437(class_7800.field_40642, ModItems.SEM)
                .method_10439(" A ")
                .method_10439("ABA")
                .method_10439(" A ")
                .method_10434('A', class_1802.field_8620).method_10434('B', class_1802.field_8687)
                .method_10429(method_32807(class_1802.field_8725), method_10426(class_1802.field_8725)).method_10431(exporter);

        // Obsidian Ingot: 4 iron ingots in + around obsidian shard
        class_2447.method_10437(class_7800.field_40642, ModItems.OBINGOT)
                .method_10439(" A ")
                .method_10439("ABA")
                .method_10439(" A ")
                .method_10434('A', class_1802.field_8620).method_10434('B', ModItems.OBSHARD)
                .method_10429(method_32807(ModItems.OBSHARD), method_10426(ModItems.OBSHARD)).method_10431(exporter);

        // Ferrous Gold: 8 iron nuggets around gold ingot
        class_2447.method_10437(class_7800.field_40642, ModItems.RGOLD)
                .method_10439("AAA")
                .method_10439("ABA")
                .method_10439("AAA")
                .method_10434('A', class_1802.field_8675).method_10434('B', class_1802.field_8695)
                .method_10429(method_32807(class_1802.field_8695), method_10426(class_1802.field_8695)).method_10431(exporter);

        // Obsidian -> 3 Obsidian Shards
        class_2450.method_10448(class_7800.field_40642, ModItems.OBSHARD, 3)
                .method_10454(class_1802.field_8281)
                .method_10442(method_32807(class_1802.field_8281), method_10426(class_1802.field_8281))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "obshard_from_block"));

        // Ectoplasm from phantom membrane
        class_2450.method_10448(class_7800.field_40642, ModItems.ECTOPLASM, 2)
                .method_10454(class_1802.field_8614)
                .method_10454(class_1802.field_8601)
                .method_10442(method_32807(class_1802.field_8614), method_10426(class_1802.field_8614))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "ectoplasm_from_membrane"));

        // Refined Ectoplasm: 4 ectoplasm (cross) + 1 diamond (center)
        class_2447.method_10437(class_7800.field_40642, ModItems.REFINED_ECTOPLASM)
                .method_10439(" A ")
                .method_10439("ABA")
                .method_10439(" A ")
                .method_10434('A', ModItems.ECTOPLASM)
                .method_10434('B', class_1802.field_8477)
                .method_10429(method_32807(ModItems.ECTOPLASM), method_10426(ModItems.ECTOPLASM))
                .method_10431(exporter);

        // 1 Coal -> 4 Coal Dust
        class_2450.method_10448(class_7800.field_40642, ModItems.COAL_DUST, 4)
                .method_10454(class_1802.field_8713)
                .method_10442(method_32807(class_1802.field_8713), method_10426(class_1802.field_8713))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "coal_dust_from_coal"));

        // 1 Charcoal -> 4 Coal Dust
        class_2450.method_10448(class_7800.field_40642, ModItems.COAL_DUST, 4)
                .method_10454(class_1802.field_8665)
                .method_10442(method_32807(class_1802.field_8665), method_10426(class_1802.field_8665))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "coal_dust_from_charcoal"));

        // Hardened Coal: Coal Dust surrounded by Clay Balls
        class_2447.method_10437(class_7800.field_40642, ModItems.HARDENED_COAL)
                .method_10439(" A ")
                .method_10439("ABA")
                .method_10439(" A ")
                .method_10434('A', class_1802.field_8696)
                .method_10434('B', ModItems.COAL_DUST)
                .method_10429(method_32807(ModItems.COAL_DUST), method_10426(ModItems.COAL_DUST))
                .method_10431(exporter);

        // Calcified Amethyst: + pattern with amethyst shards around calcite
        class_2447.method_10437(class_7800.field_40642, ModItems.CALCIFIED_AMETHYST)
                .method_10439(" A ")
                .method_10439("ABA")
                .method_10439(" A ")
                .method_10434('A', class_1802.field_27063)
                .method_10434('B', class_2246.field_27114.method_8389())
                .method_10429(method_32807(class_1802.field_27063), method_10426(class_1802.field_27063))
                .method_10431(exporter);

        // Glacial Shard: packed ice surrounding blue ice
        class_2447.method_10437(class_7800.field_40642, ModItems.GLACIAL_SHARD)
                .method_10439("AAA")
                .method_10439("ABA")
                .method_10439("AAA")
                .method_10434('A', class_1802.field_8081)
                .method_10434('B', class_1802.field_8178)
                .method_10429(method_32807(class_1802.field_8081), method_10426(class_1802.field_8081))
                .method_10431(exporter);

        // Polished Quartz: + pattern with quartz around smooth quartz block
        class_2447.method_10437(class_7800.field_40642, ModItems.POLISHED_QUARTZ)
                .method_10439(" A ")
                .method_10439("ABA")
                .method_10439(" A ")
                .method_10434('A', class_1802.field_8155)
                .method_10434('B', class_2246.field_9978.method_8389())
                .method_10429(method_32807(class_1802.field_8155), method_10426(class_1802.field_8155))
                .method_10431(exporter);

        // Polished Prismarine: + pattern with prismarine shards around prismarine crystals
        class_2447.method_10437(class_7800.field_40642, ModItems.POLISHED_PRISMARINE)
                .method_10439(" A ")
                .method_10439("ABA")
                .method_10439(" A ")
                .method_10434('A', class_1802.field_8662)
                .method_10434('B', class_1802.field_8434)
                .method_10429(method_32807(class_1802.field_8662), method_10426(class_1802.field_8662))
                .method_10431(exporter);

        // =====================================================================
        // Storage block recipes (9 items -> 1 block)
        // =====================================================================

        class_2447.method_10437(class_7800.field_40642, ModBlocks.RGOLDBLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.RGOLD)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.HRBLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.HRED)
                .method_10429(method_32807(ModItems.HRED), method_10426(ModItems.HRED)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.SEMBLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.SEM)
                .method_10429(method_32807(ModItems.SEM), method_10426(ModItems.SEM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.SOBLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.OBINGOT)
                .method_10429(method_32807(ModItems.OBINGOT), method_10426(ModItems.OBINGOT)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.LBLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.RLAPIS)
                .method_10429(method_32807(ModItems.RLAPIS), method_10426(ModItems.RLAPIS)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.HGLOW_BLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.HGLOW)
                .method_10429(method_32807(ModItems.HGLOW), method_10426(ModItems.HGLOW)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.RAW_RGOLD_BLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.RAW_RGOLD)
                .method_10429(method_32807(ModItems.RAW_RGOLD), method_10426(ModItems.RAW_RGOLD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.ECTOPLASM_BLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.ECTOPLASM)
                .method_10429(method_32807(ModItems.ECTOPLASM), method_10426(ModItems.ECTOPLASM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.REFINED_ECTOPLASM_BLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.REFINED_ECTOPLASM)
                .method_10429(method_32807(ModItems.REFINED_ECTOPLASM), method_10426(ModItems.REFINED_ECTOPLASM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.HARDENED_COAL_BLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.HARDENED_COAL)
                .method_10429(method_32807(ModItems.HARDENED_COAL), method_10426(ModItems.HARDENED_COAL)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.COAL_DUST_BLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.COAL_DUST)
                .method_10429(method_32807(ModItems.COAL_DUST), method_10426(ModItems.COAL_DUST)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.OBSHARD_BLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.OBSHARD)
                .method_10429(method_32807(ModItems.OBSHARD), method_10426(ModItems.OBSHARD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.CALCIFIED_AMETHYST_BLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.CALCIFIED_AMETHYST)
                .method_10429(method_32807(ModItems.CALCIFIED_AMETHYST), method_10426(ModItems.CALCIFIED_AMETHYST)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.GLACIAL_SHARD_BLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.GLACIAL_SHARD)
                .method_10429(method_32807(ModItems.GLACIAL_SHARD), method_10426(ModItems.GLACIAL_SHARD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.POLISHED_QUARTZ_BLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.POLISHED_QUARTZ)
                .method_10429(method_32807(ModItems.POLISHED_QUARTZ), method_10426(ModItems.POLISHED_QUARTZ)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40642, ModBlocks.POLISHED_PRISMARINE_BLOCK)
                .method_10439("AAA").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.POLISHED_PRISMARINE)
                .method_10429(method_32807(ModItems.POLISHED_PRISMARINE), method_10426(ModItems.POLISHED_PRISMARINE)).method_10431(exporter);

        // =====================================================================
        // Reverse storage block recipes (1 block -> 9 items)
        // =====================================================================

        class_2450.method_10448(class_7800.field_40642, ModItems.RGOLD, 9)
                .method_10454(ModBlocks.RGOLDBLOCK)
                .method_10442(method_32807(ModBlocks.RGOLDBLOCK), method_10426(ModBlocks.RGOLDBLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "rgold_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.HRED, 9)
                .method_10454(ModBlocks.HRBLOCK)
                .method_10442(method_32807(ModBlocks.HRBLOCK), method_10426(ModBlocks.HRBLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "hred_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.OBINGOT, 9)
                .method_10454(ModBlocks.SOBLOCK)
                .method_10442(method_32807(ModBlocks.SOBLOCK), method_10426(ModBlocks.SOBLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "sobingot_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.RLAPIS, 9)
                .method_10454(ModBlocks.LBLOCK)
                .method_10442(method_32807(ModBlocks.LBLOCK), method_10426(ModBlocks.LBLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "rlapis_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.SEM, 9)
                .method_10454(ModBlocks.SEMBLOCK)
                .method_10442(method_32807(ModBlocks.SEMBLOCK), method_10426(ModBlocks.SEMBLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "sem_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.HGLOW, 9)
                .method_10454(ModBlocks.HGLOW_BLOCK)
                .method_10442(method_32807(ModBlocks.HGLOW_BLOCK), method_10426(ModBlocks.HGLOW_BLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "hglow_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.RAW_RGOLD, 9)
                .method_10454(ModBlocks.RAW_RGOLD_BLOCK)
                .method_10442(method_32807(ModBlocks.RAW_RGOLD_BLOCK), method_10426(ModBlocks.RAW_RGOLD_BLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "raw_rgold_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.ECTOPLASM, 9)
                .method_10454(ModBlocks.ECTOPLASM_BLOCK)
                .method_10442(method_32807(ModBlocks.ECTOPLASM_BLOCK), method_10426(ModBlocks.ECTOPLASM_BLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "ectoplasm_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.REFINED_ECTOPLASM, 9)
                .method_10454(ModBlocks.REFINED_ECTOPLASM_BLOCK)
                .method_10442(method_32807(ModBlocks.REFINED_ECTOPLASM_BLOCK), method_10426(ModBlocks.REFINED_ECTOPLASM_BLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "refined_ectoplasm_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.HARDENED_COAL, 9)
                .method_10454(ModBlocks.HARDENED_COAL_BLOCK)
                .method_10442(method_32807(ModBlocks.HARDENED_COAL_BLOCK), method_10426(ModBlocks.HARDENED_COAL_BLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "hardened_coal_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.COAL_DUST, 9)
                .method_10454(ModBlocks.COAL_DUST_BLOCK)
                .method_10442(method_32807(ModBlocks.COAL_DUST_BLOCK), method_10426(ModBlocks.COAL_DUST_BLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "coal_dust_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.OBSHARD, 9)
                .method_10454(ModBlocks.OBSHARD_BLOCK)
                .method_10442(method_32807(ModBlocks.OBSHARD_BLOCK), method_10426(ModBlocks.OBSHARD_BLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "obshard_from_obshard_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.CALCIFIED_AMETHYST, 9)
                .method_10454(ModBlocks.CALCIFIED_AMETHYST_BLOCK)
                .method_10442(method_32807(ModBlocks.CALCIFIED_AMETHYST_BLOCK), method_10426(ModBlocks.CALCIFIED_AMETHYST_BLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "calcified_amethyst_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.GLACIAL_SHARD, 9)
                .method_10454(ModBlocks.GLACIAL_SHARD_BLOCK)
                .method_10442(method_32807(ModBlocks.GLACIAL_SHARD_BLOCK), method_10426(ModBlocks.GLACIAL_SHARD_BLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "glacial_shard_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.POLISHED_QUARTZ, 9)
                .method_10454(ModBlocks.POLISHED_QUARTZ_BLOCK)
                .method_10442(method_32807(ModBlocks.POLISHED_QUARTZ_BLOCK), method_10426(ModBlocks.POLISHED_QUARTZ_BLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "polished_quartz_from_block"));

        class_2450.method_10448(class_7800.field_40642, ModItems.POLISHED_PRISMARINE, 9)
                .method_10454(ModBlocks.POLISHED_PRISMARINE_BLOCK)
                .method_10442(method_32807(ModBlocks.POLISHED_PRISMARINE_BLOCK), method_10426(ModBlocks.POLISHED_PRISMARINE_BLOCK))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "polished_prismarine_from_block"));

        // =====================================================================
        // Ore recipes (reverse crafting + smelting/blasting)
        // =====================================================================

        class_2447.method_10437(class_7800.field_40642, ModBlocks.RGOLDORE)
                .method_10439("AAA").method_10439("ABA").method_10439("AAA")
                .method_10434('A', class_1802.field_20391).method_10434('B', ModItems.RGOLD)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "reverse_rgoldore"));

        class_2447.method_10437(class_7800.field_40642, ModBlocks.RGOLD_END_ORE)
                .method_10439("AAA").method_10439("ABA").method_10439("AAA")
                .method_10434('A', class_1802.field_20399).method_10434('B', ModItems.RGOLD)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "reverse_rgold_end_ore"));

        class_2447.method_10437(class_7800.field_40642, ModBlocks.RGOLD_NETHER_ORE)
                .method_10439("AAA").method_10439("ABA").method_10439("AAA")
                .method_10434('A', class_1802.field_8328).method_10434('B', ModItems.RGOLD)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "reverse_rgold_nether_ore"));

        class_2447.method_10437(class_7800.field_40642, ModBlocks.RGOLD_DEEPSLATE_ORE)
                .method_10439("AAA").method_10439("ABA").method_10439("AAA")
                .method_10434('A', class_1802.field_29025).method_10434('B', ModItems.RGOLD)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "reverse_rgold_deepslate_ore"));

        // Ore smelting and blasting
        List<class_1935> RGOLD_SMELTABLES = List.of(ModItems.RAW_RGOLD, ModBlocks.RGOLDORE, ModBlocks.RGOLD_END_ORE, ModBlocks.RGOLD_NETHER_ORE, ModBlocks.RGOLD_DEEPSLATE_ORE);

        for (class_1935 input : RGOLD_SMELTABLES) {
            class_2454.method_17802(class_1856.method_8091(input), class_7800.field_40642, ModItems.RGOLD, 0.25f, 200)
                    .method_35917("rgold")
                    .method_10469(method_32807(input), method_10426(input))
                    .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, method_33716(ModItems.RGOLD) + "_from_smelting_" + method_33716(input)));

            class_2454.method_10473(class_1856.method_8091(input), class_7800.field_40642, ModItems.RGOLD, 0.25f, 100)
                    .method_35917("rgold")
                    .method_10469(method_32807(input), method_10426(input))
                    .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, method_33716(ModItems.RGOLD) + "_from_blasting_" + method_33716(input)));
        }

        // =====================================================================
        // Ice crafting recipe
        // =====================================================================

        class_2447.method_10437(class_7800.field_40634, class_2246.field_10295)
                .method_10439("SSS")
                .method_10439("SSS")
                .method_10439("SSS")
                .method_10434('S', class_1802.field_8543)
                .method_10429(method_32807(class_1802.field_8543), method_10426(class_1802.field_8543)).method_10431(exporter);

        // Blue Ice -> 9 Packed Ice
        class_2450.method_10448(class_7800.field_40642, class_1802.field_8081, 9)
                .method_10454(class_1802.field_8178)
                .method_10442(method_32807(class_1802.field_8178), method_10426(class_1802.field_8178))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "packed_ice_from_blue_ice"));

        // Packed Ice -> 9 Ice
        class_2450.method_10448(class_7800.field_40642, class_1802.field_8426, 9)
                .method_10454(class_1802.field_8081)
                .method_10442(method_32807(class_1802.field_8081), method_10426(class_1802.field_8081))
                .method_17972(exporter, new class_2960(UsefultoolsMod.MOD_ID, "ice_from_packed_ice"));

        // =====================================================================
        // Spectral Infuser block recipe
        // =====================================================================

        class_2447.method_10437(class_7800.field_40642, ModBlocks.SPECTRAL_INFUSER)
                .method_10439("EEE")
                .method_10439("EBE")
                .method_10439("SSS")
                .method_10434('E', ModItems.ECTOPLASM)
                .method_10434('B', class_1802.field_8894)
                .method_10434('S', class_2246.field_10360)
                .method_10429(method_32807(ModItems.ECTOPLASM), method_10426(ModItems.ECTOPLASM))
                .method_10431(exporter);

        // =====================================================================
        // Emerald tool recipes (raw emerald - remerald)
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.REMERALD_HOE)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', class_1802.field_8687).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8687), method_10426(class_1802.field_8687)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.REMERALD_AXE)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', class_1802.field_8687).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8687), method_10426(class_1802.field_8687)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.REMERALD_SHOVEL)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', class_1802.field_8687).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8687), method_10426(class_1802.field_8687)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.REMERALD_PICKAXE)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', class_1802.field_8687).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8687), method_10426(class_1802.field_8687)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.REMERALD_SWORD)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', class_1802.field_8687).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8687), method_10426(class_1802.field_8687)).method_10431(exporter);

        // =====================================================================
        // Super Emerald (pemerald) tools
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.PEMERALD_HOE)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.SEM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.SEM), method_10426(ModItems.SEM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.PEMERALD_AXE)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', ModItems.SEM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.SEM), method_10426(ModItems.SEM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.PEMERALD_SHOVEL)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.SEM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.SEM), method_10426(ModItems.SEM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.PEMERALD_PICKAXE)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.SEM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.SEM), method_10426(ModItems.SEM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.PEMERALD_SWORD)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', ModItems.SEM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.SEM), method_10426(ModItems.SEM)).method_10431(exporter);

        // =====================================================================
        // Polished Obsidian (pobsidian) tools
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.POBSIDIAN_HOE)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.OBINGOT).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.OBINGOT), method_10426(ModItems.OBINGOT)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.POBSIDIAN_AXE)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', ModItems.OBINGOT).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.OBINGOT), method_10426(ModItems.OBINGOT)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.POBSIDIAN_SHOVEL)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.OBINGOT).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.OBINGOT), method_10426(ModItems.OBINGOT)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.POBSIDIAN_PICKAXE)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.OBINGOT).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.OBINGOT), method_10426(ModItems.OBINGOT)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.POBSIDIAN_SWORD)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', ModItems.OBINGOT).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.OBINGOT), method_10426(ModItems.OBINGOT)).method_10431(exporter);

        // =====================================================================
        // Rough Obsidian (robsidian) tools
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.ROBSIDIAN_HOE)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.OBSHARD).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.OBSHARD), method_10426(ModItems.OBSHARD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.ROBSIDIAN_AXE)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', ModItems.OBSHARD).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.OBSHARD), method_10426(ModItems.OBSHARD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.ROBSIDIAN_SHOVEL)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.OBSHARD).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.OBSHARD), method_10426(ModItems.OBSHARD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.ROBSIDIAN_PICKAXE)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.OBSHARD).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.OBSHARD), method_10426(ModItems.OBSHARD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.ROBSIDIAN_SWORD)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', ModItems.OBSHARD).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.OBSHARD), method_10426(ModItems.OBSHARD)).method_10431(exporter);

        // =====================================================================
        // Overpower tools
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.OVERPOWER_AXE)
                .method_10439("AAE").method_10439("DBD").method_10439("CB ")
                .method_10434('C', ModBlocks.SOBLOCK).method_10434('B', class_1802.field_8600).method_10434('A', class_2246.field_10201).method_10434('D', ModItems.RGOLD).method_10434('E', ModItems.SEM)
                .method_10429(method_32807(ModBlocks.SOBLOCK), method_10426(ModBlocks.SOBLOCK)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.OVERPOWER_SHOVEL)
                .method_10439("EAE").method_10439("DBD").method_10439("CB ")
                .method_10434('C', ModBlocks.SOBLOCK).method_10434('B', class_1802.field_8600).method_10434('A', class_2246.field_10201).method_10434('D', ModItems.RGOLD).method_10434('E', ModItems.SEM)
                .method_10429(method_32807(ModBlocks.SOBLOCK), method_10426(ModBlocks.SOBLOCK)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.OVERPOWER_PICKAXE)
                .method_10439("AAA").method_10439("DBE").method_10439("CB ")
                .method_10434('C', ModBlocks.SOBLOCK).method_10434('B', class_1802.field_8600).method_10434('A', class_2246.field_10201).method_10434('D', ModItems.RGOLD).method_10434('E', ModItems.SEM)
                .method_10429(method_32807(ModBlocks.SOBLOCK), method_10426(ModBlocks.SOBLOCK)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.OVERPOWER_SWORD)
                .method_10439("EAE").method_10439("DAD").method_10439("CB ")
                .method_10434('C', ModBlocks.SOBLOCK).method_10434('B', class_1802.field_8600).method_10434('A', class_2246.field_10201).method_10434('D', ModItems.RGOLD).method_10434('E', ModItems.SEM)
                .method_10429(method_32807(ModBlocks.SOBLOCK), method_10426(ModBlocks.SOBLOCK)).method_10431(exporter);

        // =====================================================================
        // Hardened Redstone tools
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.HREDSTONE_HOE)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.HRED).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HRED), method_10426(ModItems.HRED)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.HREDSTONE_AXE)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', ModItems.HRED).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HRED), method_10426(ModItems.HRED)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.HREDSTONE_SHOVEL)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.HRED).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HRED), method_10426(ModItems.HRED)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.HREDSTONE_PICKAXE)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.HRED).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HRED), method_10426(ModItems.HRED)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.HREDSTONE_SWORD)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', ModItems.HRED).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HRED), method_10426(ModItems.HRED)).method_10431(exporter);

        // =====================================================================
        // Hardened Glowstone tools
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.HGLOWSTONE_HOE)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.HGLOW).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HGLOW), method_10426(ModItems.HGLOW)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.HGLOWSTONE_AXE)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', ModItems.HGLOW).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HGLOW), method_10426(ModItems.HGLOW)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.HGLOWSTONE_SHOVEL)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.HGLOW).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HGLOW), method_10426(ModItems.HGLOW)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.HGLOWSTONE_PICKAXE)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.HGLOW).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HGLOW), method_10426(ModItems.HGLOW)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.HGLOWSTONE_SWORD)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', ModItems.HGLOW).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HGLOW), method_10426(ModItems.HGLOW)).method_10431(exporter);

        // =====================================================================
        // Ferrous Gold tools
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.RGOLD_HOE)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.RGOLD).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.RGOLD_AXE)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', ModItems.RGOLD).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.RGOLD_SHOVEL)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.RGOLD).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.RGOLD_PICKAXE)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.RGOLD).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.RGOLD_SWORD)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', ModItems.RGOLD).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD)).method_10431(exporter);

        // =====================================================================
        // Reinforced Lapis tools
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.RLAPIS_HOE)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.RLAPIS).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.RLAPIS), method_10426(ModItems.RLAPIS)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.RLAPIS_AXE)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', ModItems.RLAPIS).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.RLAPIS), method_10426(ModItems.RLAPIS)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.RLAPIS_SHOVEL)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.RLAPIS).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.RLAPIS), method_10426(ModItems.RLAPIS)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.RLAPIS_PICKAXE)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.RLAPIS).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.RLAPIS), method_10426(ModItems.RLAPIS)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.RLAPIS_SWORD)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', ModItems.RLAPIS).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.RLAPIS), method_10426(ModItems.RLAPIS)).method_10431(exporter);

        // =====================================================================
        // Rough Ecto tools (raw ectoplasm)
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.RECTO_SWORD)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', ModItems.ECTOPLASM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.ECTOPLASM), method_10426(ModItems.ECTOPLASM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.RECTO_PICKAXE)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.ECTOPLASM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.ECTOPLASM), method_10426(ModItems.ECTOPLASM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.RECTO_AXE)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', ModItems.ECTOPLASM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.ECTOPLASM), method_10426(ModItems.ECTOPLASM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.RECTO_SHOVEL)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.ECTOPLASM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.ECTOPLASM), method_10426(ModItems.ECTOPLASM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.RECTO_HOE)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.ECTOPLASM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.ECTOPLASM), method_10426(ModItems.ECTOPLASM)).method_10431(exporter);

        // =====================================================================
        // Ecto tools (refined ectoplasm)
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.ECTO_SWORD)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', ModItems.REFINED_ECTOPLASM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.REFINED_ECTOPLASM), method_10426(ModItems.REFINED_ECTOPLASM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.ECTO_PICKAXE)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.REFINED_ECTOPLASM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.REFINED_ECTOPLASM), method_10426(ModItems.REFINED_ECTOPLASM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.ECTO_AXE)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', ModItems.REFINED_ECTOPLASM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.REFINED_ECTOPLASM), method_10426(ModItems.REFINED_ECTOPLASM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.ECTO_SHOVEL)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.REFINED_ECTOPLASM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.REFINED_ECTOPLASM), method_10426(ModItems.REFINED_ECTOPLASM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.ECTO_HOE)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.REFINED_ECTOPLASM).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.REFINED_ECTOPLASM), method_10426(ModItems.REFINED_ECTOPLASM)).method_10431(exporter);

        // =====================================================================
        // Coal tools
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.COAL_SWORD)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', ModItems.HARDENED_COAL).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HARDENED_COAL), method_10426(ModItems.HARDENED_COAL)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.COAL_PICKAXE)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.HARDENED_COAL).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HARDENED_COAL), method_10426(ModItems.HARDENED_COAL)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.COAL_SHOVEL)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.HARDENED_COAL).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HARDENED_COAL), method_10426(ModItems.HARDENED_COAL)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.COAL_AXE)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', ModItems.HARDENED_COAL).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HARDENED_COAL), method_10426(ModItems.HARDENED_COAL)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.COAL_HOE)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', ModItems.HARDENED_COAL).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(ModItems.HARDENED_COAL), method_10426(ModItems.HARDENED_COAL)).method_10431(exporter);

        // =====================================================================
        // Leather tools
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.LEATHER_SWORD)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', class_1802.field_8745).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8745), method_10426(class_1802.field_8745)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.LEATHER_PICKAXE)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', class_1802.field_8745).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8745), method_10426(class_1802.field_8745)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.LEATHER_SHOVEL)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', class_1802.field_8745).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8745), method_10426(class_1802.field_8745)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.LEATHER_AXE)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', class_1802.field_8745).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8745), method_10426(class_1802.field_8745)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.LEATHER_HOE)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', class_1802.field_8745).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8745), method_10426(class_1802.field_8745)).method_10431(exporter);

        // =====================================================================
        // Cake tools + armor
        // =====================================================================

        class_2447.method_10437(class_7800.field_40638, ModItems.CAKE_SWORD)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', class_1802.field_17534).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_17534), method_10426(class_1802.field_17534)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.CAKE_PICKAXE)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', class_1802.field_17534).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_17534), method_10426(class_1802.field_17534)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.CAKE_SHOVEL)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', class_1802.field_17534).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_17534), method_10426(class_1802.field_17534)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.CAKE_AXE)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', class_1802.field_17534).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_17534), method_10426(class_1802.field_17534)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.CAKE_HOE)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', class_1802.field_17534).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_17534), method_10426(class_1802.field_17534)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.CAKE_HELMET)
                .method_10439("AAA").method_10439("A A").method_10439("   ")
                .method_10434('A', class_1802.field_17534)
                .method_10429(method_32807(class_1802.field_17534), method_10426(class_1802.field_17534)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.CAKE_CHESTPLATE)
                .method_10439("A A").method_10439("AAA").method_10439("AAA")
                .method_10434('A', class_1802.field_17534)
                .method_10429(method_32807(class_1802.field_17534), method_10426(class_1802.field_17534)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.CAKE_LEGGINGS)
                .method_10439("AAA").method_10439("A A").method_10439("A A")
                .method_10434('A', class_1802.field_17534)
                .method_10429(method_32807(class_1802.field_17534), method_10426(class_1802.field_17534)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.CAKE_BOOTS)
                .method_10439("   ").method_10439("A A").method_10439("A A")
                .method_10434('A', class_1802.field_17534)
                .method_10429(method_32807(class_1802.field_17534), method_10426(class_1802.field_17534)).method_10431(exporter);

        // =====================================================================
        // Raw metal rough tool recipes
        // =====================================================================

        // Rough Raw Gold tools
        stoneVariantTools(exporter, ModItems.RRAW_GOLD_SWORD, ModItems.RRAW_GOLD_PICKAXE, ModItems.RRAW_GOLD_SHOVEL, ModItems.RRAW_GOLD_AXE, ModItems.RRAW_GOLD_HOE, class_1802.field_33402);

        // Rough Raw Copper tools
        stoneVariantTools(exporter, ModItems.RRAW_COPPER_SWORD, ModItems.RRAW_COPPER_PICKAXE, ModItems.RRAW_COPPER_SHOVEL, ModItems.RRAW_COPPER_AXE, ModItems.RRAW_COPPER_HOE, class_1802.field_33401);

        // Rough Raw Iron tools
        stoneVariantTools(exporter, ModItems.RRAW_IRON_SWORD, ModItems.RRAW_IRON_PICKAXE, ModItems.RRAW_IRON_SHOVEL, ModItems.RRAW_IRON_AXE, ModItems.RRAW_IRON_HOE, class_1802.field_33400);

        // Rough Raw Ferrous Gold tools
        stoneVariantTools(exporter, ModItems.RRAW_RGOLD_SWORD, ModItems.RRAW_RGOLD_PICKAXE, ModItems.RRAW_RGOLD_SHOVEL, ModItems.RRAW_RGOLD_AXE, ModItems.RRAW_RGOLD_HOE, ModItems.RAW_RGOLD);

        // Rough Netherite Scrap tools
        stoneVariantTools(exporter, ModItems.RSCRAP_SWORD, ModItems.RSCRAP_PICKAXE, ModItems.RSCRAP_SHOVEL, ModItems.RSCRAP_AXE, ModItems.RSCRAP_HOE, class_1802.field_22021);

        // =====================================================================
        // Rough Amethyst tools
        // =====================================================================

        stoneVariantTools(exporter, ModItems.RAMETHYST_SWORD, ModItems.RAMETHYST_PICKAXE, ModItems.RAMETHYST_SHOVEL, ModItems.RAMETHYST_AXE, ModItems.RAMETHYST_HOE, class_1802.field_27063);

        // =====================================================================
        // Snow tools
        // =====================================================================

        stoneVariantTools(exporter, ModItems.SNOW_SWORD, ModItems.SNOW_PICKAXE, ModItems.SNOW_SHOVEL, ModItems.SNOW_AXE, ModItems.SNOW_HOE, class_1802.field_8543);

        // =====================================================================
        // Rough Quartz tools
        // =====================================================================

        stoneVariantTools(exporter, ModItems.RQUARTZ_SWORD, ModItems.RQUARTZ_PICKAXE, ModItems.RQUARTZ_SHOVEL, ModItems.RQUARTZ_AXE, ModItems.RQUARTZ_HOE, class_1802.field_8155);

        // =====================================================================
        // Rough Prismarine tools
        // =====================================================================

        stoneVariantTools(exporter, ModItems.RPRISM_SWORD, ModItems.RPRISM_PICKAXE, ModItems.RPRISM_SHOVEL, ModItems.RPRISM_AXE, ModItems.RPRISM_HOE, class_1802.field_8662);

        // =====================================================================
        // Calcified Amethyst tools + armor
        // =====================================================================

        buildFullSet(exporter, ModItems.CALCIFIED_AMETHYST,
                ModItems.CAMETHYST_SWORD, ModItems.CAMETHYST_PICKAXE, ModItems.CAMETHYST_SHOVEL,
                ModItems.CAMETHYST_AXE, ModItems.CAMETHYST_HOE,
                ModItems.CAMETHYST_HELMET, ModItems.CAMETHYST_CHESTPLATE,
                ModItems.CAMETHYST_LEGGINGS, ModItems.CAMETHYST_BOOTS);

        // =====================================================================
        // Ice (Glacial) tools + armor
        // =====================================================================

        buildFullSet(exporter, ModItems.GLACIAL_SHARD,
                ModItems.ICE_SWORD, ModItems.ICE_PICKAXE, ModItems.ICE_SHOVEL,
                ModItems.ICE_AXE, ModItems.ICE_HOE,
                ModItems.ICE_HELMET, ModItems.ICE_CHESTPLATE,
                ModItems.ICE_LEGGINGS, ModItems.ICE_BOOTS);

        // =====================================================================
        // Polished Quartz tools + armor
        // =====================================================================

        buildFullSet(exporter, ModItems.POLISHED_QUARTZ,
                ModItems.PQUARTZ_SWORD, ModItems.PQUARTZ_PICKAXE, ModItems.PQUARTZ_SHOVEL,
                ModItems.PQUARTZ_AXE, ModItems.PQUARTZ_HOE,
                ModItems.PQUARTZ_HELMET, ModItems.PQUARTZ_CHESTPLATE,
                ModItems.PQUARTZ_LEGGINGS, ModItems.PQUARTZ_BOOTS);

        // =====================================================================
        // Polished Prismarine tools + armor
        // =====================================================================

        buildFullSet(exporter, ModItems.POLISHED_PRISMARINE,
                ModItems.PPRISM_SWORD, ModItems.PPRISM_PICKAXE, ModItems.PPRISM_SHOVEL,
                ModItems.PPRISM_AXE, ModItems.PPRISM_HOE,
                ModItems.PPRISM_HELMET, ModItems.PPRISM_CHESTPLATE,
                ModItems.PPRISM_LEGGINGS, ModItems.PPRISM_BOOTS);

        // =====================================================================
        // All armor sets
        // =====================================================================

        // Emerald armor
        class_2447.method_10437(class_7800.field_40639, ModItems.EMERALD_CHESTPLATE)
                .method_10439("A A").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.SEM)
                .method_10429(method_32807(ModItems.SEM), method_10426(ModItems.SEM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.EMERALD_BOOTS)
                .method_10439("   ").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.SEM)
                .method_10429(method_32807(ModItems.SEM), method_10426(ModItems.SEM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.EMERALD_LEGGINGS)
                .method_10439("AAA").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.SEM)
                .method_10429(method_32807(ModItems.SEM), method_10426(ModItems.SEM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.EMERALD_HELMET)
                .method_10439("AAA").method_10439("A A").method_10439("   ")
                .method_10434('A', ModItems.SEM)
                .method_10429(method_32807(ModItems.SEM), method_10426(ModItems.SEM)).method_10431(exporter);

        // Hardened Redstone armor
        class_2447.method_10437(class_7800.field_40639, ModItems.HRED_CHESTPLATE)
                .method_10439("A A").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.HRED)
                .method_10429(method_32807(ModItems.HRED), method_10426(ModItems.HRED)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.HRED_BOOTS)
                .method_10439("   ").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.HRED)
                .method_10429(method_32807(ModItems.HRED), method_10426(ModItems.HRED)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.HRED_LEGGINGS)
                .method_10439("AAA").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.HRED)
                .method_10429(method_32807(ModItems.HRED), method_10426(ModItems.HRED)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.HRED_HELMET)
                .method_10439("AAA").method_10439("A A").method_10439("   ")
                .method_10434('A', ModItems.HRED)
                .method_10429(method_32807(ModItems.HRED), method_10426(ModItems.HRED)).method_10431(exporter);

        // Hardened Glowstone armor
        class_2447.method_10437(class_7800.field_40639, ModItems.HGLOW_CHESTPLATE)
                .method_10439("A A").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.HGLOW)
                .method_10429(method_32807(ModItems.HGLOW), method_10426(ModItems.HGLOW)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.HGLOW_BOOTS)
                .method_10439("   ").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.HGLOW)
                .method_10429(method_32807(ModItems.HGLOW), method_10426(ModItems.HGLOW)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.HGLOW_LEGGINGS)
                .method_10439("AAA").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.HGLOW)
                .method_10429(method_32807(ModItems.HGLOW), method_10426(ModItems.HGLOW)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.HGLOW_HELMET)
                .method_10439("AAA").method_10439("A A").method_10439("   ")
                .method_10434('A', ModItems.HGLOW)
                .method_10429(method_32807(ModItems.HGLOW), method_10426(ModItems.HGLOW)).method_10431(exporter);

        // Obsidian armor
        class_2447.method_10437(class_7800.field_40639, ModItems.OBSIDIAN_CHESTPLATE)
                .method_10439("A A").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.OBINGOT)
                .method_10429(method_32807(ModItems.OBINGOT), method_10426(ModItems.OBINGOT)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.OBSIDIAN_BOOTS)
                .method_10439("   ").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.OBINGOT)
                .method_10429(method_32807(ModItems.OBINGOT), method_10426(ModItems.OBINGOT)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.OBSIDIAN_LEGGINGS)
                .method_10439("AAA").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.OBINGOT)
                .method_10429(method_32807(ModItems.OBINGOT), method_10426(ModItems.OBINGOT)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.OBSIDIAN_HELMET)
                .method_10439("AAA").method_10439("A A").method_10439("   ")
                .method_10434('A', ModItems.OBINGOT)
                .method_10429(method_32807(ModItems.OBINGOT), method_10426(ModItems.OBINGOT)).method_10431(exporter);

        // Ferrous Gold armor
        class_2447.method_10437(class_7800.field_40639, ModItems.RGOLD_CHESTPLATE)
                .method_10439("A A").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.RGOLD)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.RGOLD_BOOTS)
                .method_10439("   ").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.RGOLD)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.RGOLD_LEGGINGS)
                .method_10439("AAA").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.RGOLD)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.RGOLD_HELMET)
                .method_10439("AAA").method_10439("A A").method_10439("   ")
                .method_10434('A', ModItems.RGOLD)
                .method_10429(method_32807(ModItems.RGOLD), method_10426(ModItems.RGOLD)).method_10431(exporter);

        // Reinforced Lapis armor
        class_2447.method_10437(class_7800.field_40639, ModItems.RLAPIS_CHESTPLATE)
                .method_10439("A A").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.RLAPIS)
                .method_10429(method_32807(ModItems.RLAPIS), method_10426(ModItems.RLAPIS)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.RLAPIS_BOOTS)
                .method_10439("   ").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.RLAPIS)
                .method_10429(method_32807(ModItems.RLAPIS), method_10426(ModItems.RLAPIS)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.RLAPIS_LEGGINGS)
                .method_10439("AAA").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.RLAPIS)
                .method_10429(method_32807(ModItems.RLAPIS), method_10426(ModItems.RLAPIS)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.RLAPIS_HELMET)
                .method_10439("AAA").method_10439("A A").method_10439("   ")
                .method_10434('A', ModItems.RLAPIS)
                .method_10429(method_32807(ModItems.RLAPIS), method_10426(ModItems.RLAPIS)).method_10431(exporter);

        // Overpower armor
        class_2447.method_10437(class_7800.field_40639, ModItems.OVERPOWER_CHESTPLATE)
                .method_10439("ACA").method_10439("ABA").method_10439("ADB")
                .method_10434('A', class_1802.field_8603).method_10434('B', ModItems.OBINGOT).method_10434('C', ModItems.SEM).method_10434('D', ModItems.RGOLD)
                .method_10429(method_32807(class_1802.field_8603), method_10426(class_1802.field_8603)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.OVERPOWER_BOOTS)
                .method_10439("ACA").method_10439("ABA").method_10439(" D ")
                .method_10434('A', class_1802.field_8603).method_10434('B', ModItems.OBINGOT).method_10434('C', ModItems.SEM).method_10434('D', ModItems.RGOLD)
                .method_10429(method_32807(class_1802.field_8603), method_10426(class_1802.field_8603)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.OVERPOWER_LEGGINGS)
                .method_10439("AAA").method_10439("ABA").method_10439("ACA")
                .method_10434('A', class_1802.field_8603).method_10434('B', ModItems.OBINGOT).method_10434('C', ModItems.SEM)
                .method_10429(method_32807(class_1802.field_8603), method_10426(class_1802.field_8603)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.OVERPOWER_HELMET)
                .method_10439("AAA").method_10439("ABA").method_10439("CDC")
                .method_10434('A', class_1802.field_8603).method_10434('B', ModItems.OBINGOT).method_10434('C', ModItems.SEM).method_10434('D', ModItems.RGOLD)
                .method_10429(method_32807(class_1802.field_8603), method_10426(class_1802.field_8603)).method_10431(exporter);

        // Ecto armor
        class_2447.method_10437(class_7800.field_40639, ModItems.ECTO_HELMET)
                .method_10439("AAA").method_10439("A A").method_10439("   ")
                .method_10434('A', ModItems.REFINED_ECTOPLASM)
                .method_10429(method_32807(ModItems.REFINED_ECTOPLASM), method_10426(ModItems.REFINED_ECTOPLASM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.ECTO_CHESTPLATE)
                .method_10439("A A").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.REFINED_ECTOPLASM)
                .method_10429(method_32807(ModItems.REFINED_ECTOPLASM), method_10426(ModItems.REFINED_ECTOPLASM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.ECTO_LEGGINGS)
                .method_10439("AAA").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.REFINED_ECTOPLASM)
                .method_10429(method_32807(ModItems.REFINED_ECTOPLASM), method_10426(ModItems.REFINED_ECTOPLASM)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.ECTO_BOOTS)
                .method_10439("   ").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.REFINED_ECTOPLASM)
                .method_10429(method_32807(ModItems.REFINED_ECTOPLASM), method_10426(ModItems.REFINED_ECTOPLASM)).method_10431(exporter);

        // Coal armor
        class_2447.method_10437(class_7800.field_40639, ModItems.COAL_HELMET)
                .method_10439("AAA").method_10439("A A").method_10439("   ")
                .method_10434('A', ModItems.HARDENED_COAL)
                .method_10429(method_32807(ModItems.HARDENED_COAL), method_10426(ModItems.HARDENED_COAL)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.COAL_CHESTPLATE)
                .method_10439("A A").method_10439("AAA").method_10439("AAA")
                .method_10434('A', ModItems.HARDENED_COAL)
                .method_10429(method_32807(ModItems.HARDENED_COAL), method_10426(ModItems.HARDENED_COAL)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.COAL_LEGGINGS)
                .method_10439("AAA").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.HARDENED_COAL)
                .method_10429(method_32807(ModItems.HARDENED_COAL), method_10426(ModItems.HARDENED_COAL)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.COAL_BOOTS)
                .method_10439("   ").method_10439("A A").method_10439("A A")
                .method_10434('A', ModItems.HARDENED_COAL)
                .method_10429(method_32807(ModItems.HARDENED_COAL), method_10426(ModItems.HARDENED_COAL)).method_10431(exporter);

        // =====================================================================
        // Food tool + armor sets (11 sets)
        // =====================================================================

        buildFullSet(exporter, class_1802.field_8229,
                ModItems.BREAD_SWORD, ModItems.BREAD_PICKAXE, ModItems.BREAD_SHOVEL,
                ModItems.BREAD_AXE, ModItems.BREAD_HOE,
                ModItems.BREAD_HELMET, ModItems.BREAD_CHESTPLATE,
                ModItems.BREAD_LEGGINGS, ModItems.BREAD_BOOTS);

        buildFullSet(exporter, class_1802.field_8551,
                ModItems.DRIED_KELP_SWORD, ModItems.DRIED_KELP_PICKAXE, ModItems.DRIED_KELP_SHOVEL,
                ModItems.DRIED_KELP_AXE, ModItems.DRIED_KELP_HOE,
                ModItems.DRIED_KELP_HELMET, ModItems.DRIED_KELP_CHESTPLATE,
                ModItems.DRIED_KELP_LEGGINGS, ModItems.DRIED_KELP_BOOTS);

        buildFullSet(exporter, class_1802.field_8511,
                ModItems.ROTTEN_FLESH_SWORD, ModItems.ROTTEN_FLESH_PICKAXE, ModItems.ROTTEN_FLESH_SHOVEL,
                ModItems.ROTTEN_FLESH_AXE, ModItems.ROTTEN_FLESH_HOE,
                ModItems.ROTTEN_FLESH_HELMET, ModItems.ROTTEN_FLESH_CHESTPLATE,
                ModItems.ROTTEN_FLESH_LEGGINGS, ModItems.ROTTEN_FLESH_BOOTS);

        buildFullSet(exporter, class_1802.field_8497,
                ModItems.MELON_SWORD, ModItems.MELON_PICKAXE, ModItems.MELON_SHOVEL,
                ModItems.MELON_AXE, ModItems.MELON_HOE,
                ModItems.MELON_HELMET, ModItems.MELON_CHESTPLATE,
                ModItems.MELON_LEGGINGS, ModItems.MELON_BOOTS);

        buildFullSet(exporter, class_1802.field_16998,
                ModItems.SWEET_BERRY_SWORD, ModItems.SWEET_BERRY_PICKAXE, ModItems.SWEET_BERRY_SHOVEL,
                ModItems.SWEET_BERRY_AXE, ModItems.SWEET_BERRY_HOE,
                ModItems.SWEET_BERRY_HELMET, ModItems.SWEET_BERRY_CHESTPLATE,
                ModItems.SWEET_BERRY_LEGGINGS, ModItems.SWEET_BERRY_BOOTS);

        buildFullSet(exporter, class_1802.field_8741,
                ModItems.PUMPKIN_PIE_SWORD, ModItems.PUMPKIN_PIE_PICKAXE, ModItems.PUMPKIN_PIE_SHOVEL,
                ModItems.PUMPKIN_PIE_AXE, ModItems.PUMPKIN_PIE_HOE,
                ModItems.PUMPKIN_PIE_HELMET, ModItems.PUMPKIN_PIE_CHESTPLATE,
                ModItems.PUMPKIN_PIE_LEGGINGS, ModItems.PUMPKIN_PIE_BOOTS);

        buildFullSet(exporter, class_1802.field_17517,
                ModItems.MUSHROOM_SWORD, ModItems.MUSHROOM_PICKAXE, ModItems.MUSHROOM_SHOVEL,
                ModItems.MUSHROOM_AXE, ModItems.MUSHROOM_HOE,
                ModItems.MUSHROOM_HELMET, ModItems.MUSHROOM_CHESTPLATE,
                ModItems.MUSHROOM_LEGGINGS, ModItems.MUSHROOM_BOOTS);

        buildFullSet(exporter, class_1802.field_8323,
                ModItems.PUFFERFISH_SWORD, ModItems.PUFFERFISH_PICKAXE, ModItems.PUFFERFISH_SHOVEL,
                ModItems.PUFFERFISH_AXE, ModItems.PUFFERFISH_HOE,
                ModItems.PUFFERFISH_HELMET, ModItems.PUFFERFISH_CHESTPLATE,
                ModItems.PUFFERFISH_LEGGINGS, ModItems.PUFFERFISH_BOOTS);

        buildFullSet(exporter, class_1802.field_20417,
                ModItems.HONEY_SWORD, ModItems.HONEY_PICKAXE, ModItems.HONEY_SHOVEL,
                ModItems.HONEY_AXE, ModItems.HONEY_HOE,
                ModItems.HONEY_HELMET, ModItems.HONEY_CHESTPLATE,
                ModItems.HONEY_LEGGINGS, ModItems.HONEY_BOOTS);

        buildFullSet(exporter, class_1802.field_8233,
                ModItems.CHORUS_FRUIT_SWORD, ModItems.CHORUS_FRUIT_PICKAXE, ModItems.CHORUS_FRUIT_SHOVEL,
                ModItems.CHORUS_FRUIT_AXE, ModItems.CHORUS_FRUIT_HOE,
                ModItems.CHORUS_FRUIT_HELMET, ModItems.CHORUS_FRUIT_CHESTPLATE,
                ModItems.CHORUS_FRUIT_LEGGINGS, ModItems.CHORUS_FRUIT_BOOTS);

        buildFullSet(exporter, class_1802.field_8463,
                ModItems.GOLDEN_APPLE_SWORD, ModItems.GOLDEN_APPLE_PICKAXE, ModItems.GOLDEN_APPLE_SHOVEL,
                ModItems.GOLDEN_APPLE_AXE, ModItems.GOLDEN_APPLE_HOE,
                ModItems.GOLDEN_APPLE_HELMET, ModItems.GOLDEN_APPLE_CHESTPLATE,
                ModItems.GOLDEN_APPLE_LEGGINGS, ModItems.GOLDEN_APPLE_BOOTS);

        // =====================================================================
        // Vanilla material tool+armor sets (tools only where indicated)
        // =====================================================================

        // Tools-only sets
        stoneVariantTools(exporter, ModItems.PAPER_SWORD, ModItems.PAPER_PICKAXE, ModItems.PAPER_SHOVEL, ModItems.PAPER_AXE, ModItems.PAPER_HOE, class_1802.field_8407);
        stoneVariantTools(exporter, ModItems.FEATHER_SWORD, ModItems.FEATHER_PICKAXE, ModItems.FEATHER_SHOVEL, ModItems.FEATHER_AXE, ModItems.FEATHER_HOE, class_1802.field_8153);
        stoneVariantTools(exporter, ModItems.GLASS_SWORD, ModItems.GLASS_PICKAXE, ModItems.GLASS_SHOVEL, ModItems.GLASS_AXE, ModItems.GLASS_HOE, class_1802.field_8141);
        stoneVariantTools(exporter, ModItems.SPONGE_SWORD, ModItems.SPONGE_PICKAXE, ModItems.SPONGE_SHOVEL, ModItems.SPONGE_AXE, ModItems.SPONGE_HOE, class_1802.field_8535);
        stoneVariantTools(exporter, ModItems.NETHER_WART_SWORD, ModItems.NETHER_WART_PICKAXE, ModItems.NETHER_WART_SHOVEL, ModItems.NETHER_WART_AXE, ModItems.NETHER_WART_HOE, class_1802.field_8790);
        stoneVariantTools(exporter, ModItems.POINTED_DRIPSTONE_SWORD, ModItems.POINTED_DRIPSTONE_PICKAXE, ModItems.POINTED_DRIPSTONE_SHOVEL, ModItems.POINTED_DRIPSTONE_AXE, ModItems.POINTED_DRIPSTONE_HOE, class_1802.field_28042);

        // Armor-only sets: Rabbit Hide
        class_2447.method_10437(class_7800.field_40639, ModItems.RABBIT_HIDE_HELMET)
                .method_10439("AAA").method_10439("A A").method_10439("   ")
                .method_10434('A', class_1802.field_8245)
                .method_10429(method_32807(class_1802.field_8245), method_10426(class_1802.field_8245)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.RABBIT_HIDE_CHESTPLATE)
                .method_10439("A A").method_10439("AAA").method_10439("AAA")
                .method_10434('A', class_1802.field_8245)
                .method_10429(method_32807(class_1802.field_8245), method_10426(class_1802.field_8245)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.RABBIT_HIDE_LEGGINGS)
                .method_10439("AAA").method_10439("A A").method_10439("A A")
                .method_10434('A', class_1802.field_8245)
                .method_10429(method_32807(class_1802.field_8245), method_10426(class_1802.field_8245)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.RABBIT_HIDE_BOOTS)
                .method_10439("   ").method_10439("A A").method_10439("A A")
                .method_10434('A', class_1802.field_8245)
                .method_10429(method_32807(class_1802.field_8245), method_10426(class_1802.field_8245)).method_10431(exporter);

        // Armor-only sets: Turtle Scute
        class_2447.method_10437(class_7800.field_40639, ModItems.TURTLE_SCUTE_HELMET)
                .method_10439("AAA").method_10439("A A").method_10439("   ")
                .method_10434('A', class_1802.field_8161)
                .method_10429(method_32807(class_1802.field_8161), method_10426(class_1802.field_8161)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.TURTLE_SCUTE_CHESTPLATE)
                .method_10439("A A").method_10439("AAA").method_10439("AAA")
                .method_10434('A', class_1802.field_8161)
                .method_10429(method_32807(class_1802.field_8161), method_10426(class_1802.field_8161)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.TURTLE_SCUTE_LEGGINGS)
                .method_10439("AAA").method_10439("A A").method_10439("A A")
                .method_10434('A', class_1802.field_8161)
                .method_10429(method_32807(class_1802.field_8161), method_10426(class_1802.field_8161)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.TURTLE_SCUTE_BOOTS)
                .method_10439("   ").method_10439("A A").method_10439("A A")
                .method_10434('A', class_1802.field_8161)
                .method_10429(method_32807(class_1802.field_8161), method_10426(class_1802.field_8161)).method_10431(exporter);

        // Tools+Armor sets using vanilla materials
        buildFullSet(exporter, class_1802.field_17520,
                ModItems.CACTUS_SWORD, ModItems.CACTUS_PICKAXE, ModItems.CACTUS_SHOVEL,
                ModItems.CACTUS_AXE, ModItems.CACTUS_HOE,
                ModItems.CACTUS_HELMET, ModItems.CACTUS_CHESTPLATE,
                ModItems.CACTUS_LEGGINGS, ModItems.CACTUS_BOOTS);

        buildFullSet(exporter, class_1802.field_8606,
                ModItems.BONE_SWORD, ModItems.BONE_PICKAXE, ModItems.BONE_SHOVEL,
                ModItems.BONE_AXE, ModItems.BONE_HOE,
                ModItems.BONE_HELMET, ModItems.BONE_CHESTPLATE,
                ModItems.BONE_LEGGINGS, ModItems.BONE_BOOTS);

        buildFullSet(exporter, class_1802.field_8696,
                ModItems.CLAY_SWORD, ModItems.CLAY_PICKAXE, ModItems.CLAY_SHOVEL,
                ModItems.CLAY_AXE, ModItems.CLAY_HOE,
                ModItems.CLAY_HELMET, ModItems.CLAY_CHESTPLATE,
                ModItems.CLAY_LEGGINGS, ModItems.CLAY_BOOTS);

        buildFullSet(exporter, class_1802.field_8621,
                ModItems.BRICK_SWORD, ModItems.BRICK_PICKAXE, ModItems.BRICK_SHOVEL,
                ModItems.BRICK_AXE, ModItems.BRICK_HOE,
                ModItems.BRICK_HELMET, ModItems.BRICK_CHESTPLATE,
                ModItems.BRICK_LEGGINGS, ModItems.BRICK_BOOTS);

        buildFullSet(exporter, class_1802.field_8729,
                ModItems.NETHER_BRICK_SWORD, ModItems.NETHER_BRICK_PICKAXE, ModItems.NETHER_BRICK_SHOVEL,
                ModItems.NETHER_BRICK_AXE, ModItems.NETHER_BRICK_HOE,
                ModItems.NETHER_BRICK_HELMET, ModItems.NETHER_BRICK_CHESTPLATE,
                ModItems.NETHER_BRICK_LEGGINGS, ModItems.NETHER_BRICK_BOOTS);

        buildFullSet(exporter, class_1802.field_27022,
                ModItems.COPPER_SWORD, ModItems.COPPER_PICKAXE, ModItems.COPPER_SHOVEL,
                ModItems.COPPER_AXE, ModItems.COPPER_HOE,
                ModItems.COPPER_HELMET, ModItems.COPPER_CHESTPLATE,
                ModItems.COPPER_LEGGINGS, ModItems.COPPER_BOOTS);

        buildFullSet(exporter, class_1802.field_8614,
                ModItems.PHANTOM_SWORD, ModItems.PHANTOM_PICKAXE, ModItems.PHANTOM_SHOVEL,
                ModItems.PHANTOM_AXE, ModItems.PHANTOM_HOE,
                ModItems.PHANTOM_HELMET, ModItems.PHANTOM_CHESTPLATE,
                ModItems.PHANTOM_LEGGINGS, ModItems.PHANTOM_BOOTS);

        buildFullSet(exporter, class_1802.field_8135,
                ModItems.MAGMA_CREAM_SWORD, ModItems.MAGMA_CREAM_PICKAXE, ModItems.MAGMA_CREAM_SHOVEL,
                ModItems.MAGMA_CREAM_AXE, ModItems.MAGMA_CREAM_HOE,
                ModItems.MAGMA_CREAM_HELMET, ModItems.MAGMA_CREAM_CHESTPLATE,
                ModItems.MAGMA_CREAM_LEGGINGS, ModItems.MAGMA_CREAM_BOOTS);

        buildFullSet(exporter, class_1802.field_8777,
                ModItems.SLIME_SWORD, ModItems.SLIME_PICKAXE, ModItems.SLIME_SHOVEL,
                ModItems.SLIME_AXE, ModItems.SLIME_HOE,
                ModItems.SLIME_HELMET, ModItems.SLIME_CHESTPLATE,
                ModItems.SLIME_LEGGINGS, ModItems.SLIME_BOOTS);

        buildFullSet(exporter, class_1802.field_8894,
                ModItems.BLAZE_SWORD, ModItems.BLAZE_PICKAXE, ModItems.BLAZE_SHOVEL,
                ModItems.BLAZE_AXE, ModItems.BLAZE_HOE,
                ModItems.BLAZE_HELMET, ModItems.BLAZE_CHESTPLATE,
                ModItems.BLAZE_LEGGINGS, ModItems.BLAZE_BOOTS);

        buildFullSet(exporter, class_1802.field_8864,
                ModItems.NAUTILUS_SWORD, ModItems.NAUTILUS_PICKAXE, ModItems.NAUTILUS_SHOVEL,
                ModItems.NAUTILUS_AXE, ModItems.NAUTILUS_HOE,
                ModItems.NAUTILUS_HELMET, ModItems.NAUTILUS_CHESTPLATE,
                ModItems.NAUTILUS_LEGGINGS, ModItems.NAUTILUS_BOOTS);

        buildFullSet(exporter, class_1802.field_8882,
                ModItems.PURPUR_SWORD, ModItems.PURPUR_PICKAXE, ModItems.PURPUR_SHOVEL,
                ModItems.PURPUR_AXE, ModItems.PURPUR_HOE,
                ModItems.PURPUR_HELMET, ModItems.PURPUR_CHESTPLATE,
                ModItems.PURPUR_LEGGINGS, ModItems.PURPUR_BOOTS);

        buildFullSet(exporter, class_1802.field_8070,
                ModItems.GHAST_TEAR_SWORD, ModItems.GHAST_TEAR_PICKAXE, ModItems.GHAST_TEAR_SHOVEL,
                ModItems.GHAST_TEAR_AXE, ModItems.GHAST_TEAR_HOE,
                ModItems.GHAST_TEAR_HELMET, ModItems.GHAST_TEAR_CHESTPLATE,
                ModItems.GHAST_TEAR_LEGGINGS, ModItems.GHAST_TEAR_BOOTS);

        buildFullSet(exporter, class_1802.field_8449,
                ModItems.EYE_OF_ENDER_SWORD, ModItems.EYE_OF_ENDER_PICKAXE, ModItems.EYE_OF_ENDER_SHOVEL,
                ModItems.EYE_OF_ENDER_AXE, ModItems.EYE_OF_ENDER_HOE,
                ModItems.EYE_OF_ENDER_HELMET, ModItems.EYE_OF_ENDER_CHESTPLATE,
                ModItems.EYE_OF_ENDER_LEGGINGS, ModItems.EYE_OF_ENDER_BOOTS);

        buildFullSet(exporter, class_1802.field_8815,
                ModItems.SHULKER_SWORD, ModItems.SHULKER_PICKAXE, ModItems.SHULKER_SHOVEL,
                ModItems.SHULKER_AXE, ModItems.SHULKER_HOE,
                ModItems.SHULKER_HELMET, ModItems.SHULKER_CHESTPLATE,
                ModItems.SHULKER_LEGGINGS, ModItems.SHULKER_BOOTS);

        buildFullSet(exporter, class_1802.field_38746,
                ModItems.ECHO_SHARD_SWORD, ModItems.ECHO_SHARD_PICKAXE, ModItems.ECHO_SHARD_SHOVEL,
                ModItems.ECHO_SHARD_AXE, ModItems.ECHO_SHARD_HOE,
                ModItems.ECHO_SHARD_HELMET, ModItems.ECHO_SHARD_CHESTPLATE,
                ModItems.ECHO_SHARD_LEGGINGS, ModItems.ECHO_SHARD_BOOTS);

        buildFullSet(exporter, class_1802.field_8613,
                ModItems.DRAGON_BREATH_SWORD, ModItems.DRAGON_BREATH_PICKAXE, ModItems.DRAGON_BREATH_SHOVEL,
                ModItems.DRAGON_BREATH_AXE, ModItems.DRAGON_BREATH_HOE,
                ModItems.DRAGON_BREATH_HELMET, ModItems.DRAGON_BREATH_CHESTPLATE,
                ModItems.DRAGON_BREATH_LEGGINGS, ModItems.DRAGON_BREATH_BOOTS);

        // =====================================================================
        // Flint Tools (rough)
        // =====================================================================

        stoneVariantTools(exporter, ModItems.RFLINT_SWORD, ModItems.RFLINT_PICKAXE, ModItems.RFLINT_SHOVEL, ModItems.RFLINT_AXE, ModItems.RFLINT_HOE, class_1802.field_8145);

        // =====================================================================
        // Flint-Iron (FNI) Tools
        // =====================================================================

        class_2447.method_10437(class_7800.field_40639, ModItems.FNI_SWORD)
                .method_10439(" F ").method_10439(" I ").method_10439(" S ")
                .method_10434('F', class_1802.field_8145).method_10434('I', class_1802.field_8620).method_10434('S', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8145), method_10426(class_1802.field_8145)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.FNI_PICKAXE)
                .method_10439("IFI").method_10439(" S ").method_10439(" S ")
                .method_10434('F', class_1802.field_8145).method_10434('I', class_1802.field_8620).method_10434('S', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8145), method_10426(class_1802.field_8145)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.FNI_SHOVEL)
                .method_10439(" I ").method_10439(" F ").method_10439(" S ")
                .method_10434('F', class_1802.field_8145).method_10434('I', class_1802.field_8620).method_10434('S', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8145), method_10426(class_1802.field_8145)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.FNI_AXE)
                .method_10439("FI ").method_10439("FS ").method_10439(" S ")
                .method_10434('F', class_1802.field_8145).method_10434('I', class_1802.field_8620).method_10434('S', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8145), method_10426(class_1802.field_8145)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40638, ModItems.FNI_HOE)
                .method_10439("FI ").method_10439(" S ").method_10439(" S ")
                .method_10434('F', class_1802.field_8145).method_10434('I', class_1802.field_8620).method_10434('S', class_1802.field_8600)
                .method_10429(method_32807(class_1802.field_8145), method_10426(class_1802.field_8145)).method_10431(exporter);

        // Flint-Iron (FNI) Armor
        class_2447.method_10437(class_7800.field_40639, ModItems.FNI_HELMET)
                .method_10439("IFI").method_10439("I I").method_10439("   ")
                .method_10434('F', class_1802.field_8145).method_10434('I', class_1802.field_8620)
                .method_10429(method_32807(class_1802.field_8145), method_10426(class_1802.field_8145)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.FNI_CHESTPLATE)
                .method_10439("I I").method_10439("IFI").method_10439("III")
                .method_10434('F', class_1802.field_8145).method_10434('I', class_1802.field_8620)
                .method_10429(method_32807(class_1802.field_8145), method_10426(class_1802.field_8145)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.FNI_LEGGINGS)
                .method_10439("IFI").method_10439("I I").method_10439("I I")
                .method_10434('F', class_1802.field_8145).method_10434('I', class_1802.field_8620)
                .method_10429(method_32807(class_1802.field_8145), method_10426(class_1802.field_8145)).method_10431(exporter);

        class_2447.method_10437(class_7800.field_40639, ModItems.FNI_BOOTS)
                .method_10439("   ").method_10439("IFI").method_10439("I I")
                .method_10434('F', class_1802.field_8145).method_10434('I', class_1802.field_8620)
                .method_10429(method_32807(class_1802.field_8145), method_10426(class_1802.field_8145)).method_10431(exporter);

        // =====================================================================
        // Stone Rock Variant Tools
        // =====================================================================

        stoneVariantTools(exporter, ModItems.ANDESITE_SWORD, ModItems.ANDESITE_PICKAXE, ModItems.ANDESITE_SHOVEL, ModItems.ANDESITE_AXE, ModItems.ANDESITE_HOE, class_1802.field_20407);
        stoneVariantTools(exporter, ModItems.BASALT_SWORD, ModItems.BASALT_PICKAXE, ModItems.BASALT_SHOVEL, ModItems.BASALT_AXE, ModItems.BASALT_HOE, class_1802.field_22000);
        stoneVariantTools(exporter, ModItems.BLACKSTONE_SWORD, ModItems.BLACKSTONE_PICKAXE, ModItems.BLACKSTONE_SHOVEL, ModItems.BLACKSTONE_AXE, ModItems.BLACKSTONE_HOE, class_1802.field_23843);
        stoneVariantTools(exporter, ModItems.CALCITE_SWORD, ModItems.CALCITE_PICKAXE, ModItems.CALCITE_SHOVEL, ModItems.CALCITE_AXE, ModItems.CALCITE_HOE, class_1802.field_27020);
        stoneVariantTools(exporter, ModItems.DEEPSLATE_SWORD, ModItems.DEEPSLATE_PICKAXE, ModItems.DEEPSLATE_SHOVEL, ModItems.DEEPSLATE_AXE, ModItems.DEEPSLATE_HOE, class_1802.field_29025);
        stoneVariantTools(exporter, ModItems.DIORITE_SWORD, ModItems.DIORITE_PICKAXE, ModItems.DIORITE_SHOVEL, ModItems.DIORITE_AXE, ModItems.DIORITE_HOE, class_1802.field_20401);
        stoneVariantTools(exporter, ModItems.END_STONE_SWORD, ModItems.END_STONE_PICKAXE, ModItems.END_STONE_SHOVEL, ModItems.END_STONE_AXE, ModItems.END_STONE_HOE, class_1802.field_20399);
        stoneVariantTools(exporter, ModItems.GRANITE_SWORD, ModItems.GRANITE_PICKAXE, ModItems.GRANITE_SHOVEL, ModItems.GRANITE_AXE, ModItems.GRANITE_HOE, class_1802.field_20394);
        stoneVariantTools(exporter, ModItems.NETHERRACK_SWORD, ModItems.NETHERRACK_PICKAXE, ModItems.NETHERRACK_SHOVEL, ModItems.NETHERRACK_AXE, ModItems.NETHERRACK_HOE, class_1802.field_8328);
        stoneVariantTools(exporter, ModItems.SANDSTONE_SWORD, ModItems.SANDSTONE_PICKAXE, ModItems.SANDSTONE_SHOVEL, ModItems.SANDSTONE_AXE, ModItems.SANDSTONE_HOE, class_1802.field_20384);
        stoneVariantTools(exporter, ModItems.SMOOTH_BASALT_SWORD, ModItems.SMOOTH_BASALT_PICKAXE, ModItems.SMOOTH_BASALT_SHOVEL, ModItems.SMOOTH_BASALT_AXE, ModItems.SMOOTH_BASALT_HOE, class_1802.field_29024);
        stoneVariantTools(exporter, ModItems.TERRACOTTA_SWORD, ModItems.TERRACOTTA_PICKAXE, ModItems.TERRACOTTA_SHOVEL, ModItems.TERRACOTTA_AXE, ModItems.TERRACOTTA_HOE, class_1802.field_8260);
        stoneVariantTools(exporter, ModItems.TUFF_SWORD, ModItems.TUFF_PICKAXE, ModItems.TUFF_SHOVEL, ModItems.TUFF_AXE, ModItems.TUFF_HOE, class_1802.field_27021);

        // =====================================================================
        // Wood Variant Tools
        // =====================================================================

        stoneVariantTools(exporter, ModItems.OAK_SWORD, ModItems.OAK_PICKAXE, ModItems.OAK_SHOVEL, ModItems.OAK_AXE, ModItems.OAK_HOE, class_1802.field_8118);
        stoneVariantTools(exporter, ModItems.SPRUCE_SWORD, ModItems.SPRUCE_PICKAXE, ModItems.SPRUCE_SHOVEL, ModItems.SPRUCE_AXE, ModItems.SPRUCE_HOE, class_1802.field_8113);
        stoneVariantTools(exporter, ModItems.BIRCH_SWORD, ModItems.BIRCH_PICKAXE, ModItems.BIRCH_SHOVEL, ModItems.BIRCH_AXE, ModItems.BIRCH_HOE, class_1802.field_8191);
        stoneVariantTools(exporter, ModItems.JUNGLE_SWORD, ModItems.JUNGLE_PICKAXE, ModItems.JUNGLE_SHOVEL, ModItems.JUNGLE_AXE, ModItems.JUNGLE_HOE, class_1802.field_8842);
        stoneVariantTools(exporter, ModItems.ACACIA_SWORD, ModItems.ACACIA_PICKAXE, ModItems.ACACIA_SHOVEL, ModItems.ACACIA_AXE, ModItems.ACACIA_HOE, class_1802.field_8651);
        stoneVariantTools(exporter, ModItems.DARK_OAK_SWORD, ModItems.DARK_OAK_PICKAXE, ModItems.DARK_OAK_SHOVEL, ModItems.DARK_OAK_AXE, ModItems.DARK_OAK_HOE, class_1802.field_8404);
        stoneVariantTools(exporter, ModItems.MANGROVE_SWORD, ModItems.MANGROVE_PICKAXE, ModItems.MANGROVE_SHOVEL, ModItems.MANGROVE_AXE, ModItems.MANGROVE_HOE, class_1802.field_37507);
        stoneVariantTools(exporter, ModItems.CHERRY_SWORD, ModItems.CHERRY_PICKAXE, ModItems.CHERRY_SHOVEL, ModItems.CHERRY_AXE, ModItems.CHERRY_HOE, class_1802.field_42687);
        stoneVariantTools(exporter, ModItems.BAMBOO_SWORD, ModItems.BAMBOO_PICKAXE, ModItems.BAMBOO_SHOVEL, ModItems.BAMBOO_AXE, ModItems.BAMBOO_HOE, class_1802.field_40213);
        stoneVariantTools(exporter, ModItems.CRIMSON_SWORD, ModItems.CRIMSON_PICKAXE, ModItems.CRIMSON_SHOVEL, ModItems.CRIMSON_AXE, ModItems.CRIMSON_HOE, class_1802.field_22031);
        stoneVariantTools(exporter, ModItems.WARPED_SWORD, ModItems.WARPED_PICKAXE, ModItems.WARPED_SHOVEL, ModItems.WARPED_AXE, ModItems.WARPED_HOE, class_1802.field_22032);
    }

    // =========================================================================
    // Helper: standard 5-tool set (sword, pickaxe, shovel, axe, hoe)
    // =========================================================================
    private static void stoneVariantTools(Consumer<class_2444> out,
                                          class_1935 sword, class_1935 pickaxe,
                                          class_1935 shovel, class_1935 axe,
                                          class_1935 hoe, class_1935 material) {
        class_2447.method_10437(class_7800.field_40639, sword)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', material).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
        class_2447.method_10437(class_7800.field_40638, pickaxe)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', material).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
        class_2447.method_10437(class_7800.field_40638, shovel)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', material).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
        class_2447.method_10437(class_7800.field_40638, axe)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', material).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
        class_2447.method_10437(class_7800.field_40638, hoe)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', material).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
    }

    // =========================================================================
    // Helper: full set (5 tools + 4 armor)
    // =========================================================================
    private static void buildFullSet(Consumer<class_2444> out, class_1935 material,
                                     class_1935 sword, class_1935 pickaxe,
                                     class_1935 shovel, class_1935 axe, class_1935 hoe,
                                     class_1935 helmet, class_1935 chestplate,
                                     class_1935 leggings, class_1935 boots) {
        // Tools
        class_2447.method_10437(class_7800.field_40638, sword)
                .method_10439(" A ").method_10439(" A ").method_10439(" B ")
                .method_10434('A', material).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
        class_2447.method_10437(class_7800.field_40638, pickaxe)
                .method_10439("AAA").method_10439(" B ").method_10439(" B ")
                .method_10434('A', material).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
        class_2447.method_10437(class_7800.field_40638, shovel)
                .method_10439(" A ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', material).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
        class_2447.method_10437(class_7800.field_40638, axe)
                .method_10439("AA ").method_10439("AB ").method_10439(" B ")
                .method_10434('A', material).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
        class_2447.method_10437(class_7800.field_40638, hoe)
                .method_10439("AA ").method_10439(" B ").method_10439(" B ")
                .method_10434('A', material).method_10434('B', class_1802.field_8600)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
        // Armor
        class_2447.method_10437(class_7800.field_40639, helmet)
                .method_10439("AAA").method_10439("A A").method_10439("   ")
                .method_10434('A', material)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
        class_2447.method_10437(class_7800.field_40639, chestplate)
                .method_10439("A A").method_10439("AAA").method_10439("AAA")
                .method_10434('A', material)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
        class_2447.method_10437(class_7800.field_40639, leggings)
                .method_10439("AAA").method_10439("A A").method_10439("A A")
                .method_10434('A', material)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
        class_2447.method_10437(class_7800.field_40639, boots)
                .method_10439("   ").method_10439("A A").method_10439("A A")
                .method_10434('A', material)
                .method_10429(method_32807(material), method_10426(material)).method_10431(out);
    }

    // =========================================================================
    // Helper: get item registry path for recipe naming
    // =========================================================================
    // getItemPath is inherited from RecipeProvider
}
