package com.stonytark.usefultoolsmod.datagen;

import com.stonytark.usefultoolsmod.block.ModBlocks;
import com.stonytark.usefultoolsmod.util.ModTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_2246;
import net.minecraft.class_3481;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

/**
 * Fabric 1.20.1 Block Tag Data Generator
 * Generates block tags for mining levels, material types, etc.
 */
public class ModBlockTagProvider extends FabricTagProvider.BlockTagProvider {
    public ModBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 registries) {
        // Add ore blocks to the correct mining tag
        method_10512(class_3481.field_33715)
                .add(ModBlocks.RGOLDORE)
                .add(ModBlocks.RGOLD_NETHER_ORE)
                .add(ModBlocks.RGOLD_END_ORE)
                .add(ModBlocks.RGOLD_DEEPSLATE_ORE);

        // Storage blocks can be mined with pickaxe
        method_10512(class_3481.field_33715)
                .add(ModBlocks.RGOLDBLOCK)
                .add(ModBlocks.HRBLOCK)
                .add(ModBlocks.SEMBLOCK)
                .add(ModBlocks.SOBLOCK)
                .add(ModBlocks.LBLOCK)
                .add(ModBlocks.HGLOW_BLOCK)
                .add(ModBlocks.RAW_RGOLD_BLOCK)
                .add(ModBlocks.ECTOPLASM_BLOCK)
                .add(ModBlocks.REFINED_ECTOPLASM_BLOCK)
                .add(ModBlocks.HARDENED_COAL_BLOCK)
                .add(ModBlocks.COAL_DUST_BLOCK)
                .add(ModBlocks.OBSHARD_BLOCK)
                .add(ModBlocks.CALCIFIED_AMETHYST_BLOCK)
                .add(ModBlocks.GLACIAL_SHARD_BLOCK)
                .add(ModBlocks.POLISHED_QUARTZ_BLOCK)
                .add(ModBlocks.POLISHED_PRISMARINE_BLOCK)
                .add(ModBlocks.SPECTRAL_INFUSER);

        // Ore blocks that require a specific mining level
        method_10512(class_3481.field_33718)
                .add(ModBlocks.RGOLDBLOCK)
                .add(ModBlocks.LBLOCK)
                .add(ModBlocks.HRBLOCK);

        method_10512(class_3481.field_33719)
                .add(ModBlocks.RGOLDORE)
                .add(ModBlocks.RGOLD_NETHER_ORE)
                .add(ModBlocks.RGOLD_END_ORE)
                .add(ModBlocks.RGOLD_DEEPSLATE_ORE);

        method_10512(class_3481.field_33717)
                .add(ModBlocks.SOBLOCK)
                .add(ModBlocks.SEMBLOCK);

        // Custom tool requirement tags
        method_10512(ModTags.Blocks.NEEDS_HRED_TOOL)
                .forceAddTag(class_3481.field_33718);

        method_10512(ModTags.Blocks.NEEDS_JEM_TOOL)
                .forceAddTag(class_3481.field_33717);

        method_10512(ModTags.Blocks.NEEDS_JOB_TOOL)
                .forceAddTag(class_3481.field_33717);

        method_10512(ModTags.Blocks.NEEDS_OP_TOOL)
                .forceAddTag(class_3481.field_33717)
                .add(class_2246.field_9987);

        method_10512(ModTags.Blocks.NEEDS_RGOLD_TOOL)
                .forceAddTag(class_3481.field_33718);

        method_10512(ModTags.Blocks.NEEDS_RLAPIS_TOOL)
                .forceAddTag(class_3481.field_33718);

        method_10512(ModTags.Blocks.NEEDS_SEM_TOOL)
                .forceAddTag(class_3481.field_33717);

        method_10512(ModTags.Blocks.NEEDS_SOB_TOOL)
                .forceAddTag(class_3481.field_33717)
                .add(class_2246.field_9987);
    }
}
