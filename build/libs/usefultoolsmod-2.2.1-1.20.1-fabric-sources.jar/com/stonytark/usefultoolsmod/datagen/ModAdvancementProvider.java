package com.stonytark.usefultoolsmod.datagen;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.block.ModBlocks;
import com.stonytark.usefultoolsmod.item.ModItems;
import com.stonytark.usefultoolsmod.trigger.CoalToolIgnitedTrigger;
import com.stonytark.usefultoolsmod.trigger.GhostNearbyTrigger;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricAdvancementProvider;
import net.minecraft.class_161;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_189;
import net.minecraft.class_193;
import net.minecraft.class_1935;
import net.minecraft.class_2010;
import net.minecraft.class_2066;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5258;
import java.util.function.Consumer;

/**
 * Fabric 1.20.1 Advancement Data Generator
 * Generates custom advancement/achievement JSON files
 */
public class ModAdvancementProvider extends FabricAdvancementProvider {

    private static final class_2960 BACKGROUND =
            new class_2960("textures/block/netherrack.png");

    public ModAdvancementProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateAdvancement(Consumer<class_161> consumer) {

        // ==================================================================
        // ROOT
        // ==================================================================
        class_161 root = class_161.class_162.method_707()
                .method_697(
                        ModItems.RAW_RGOLD,
                        title("root"),
                        desc("root"),
                        BACKGROUND,
                        class_189.field_1254,
                        false, false, false
                )
                .method_709("has_raw_rgold", class_2066.class_2068.method_8959(ModItems.RAW_RGOLD))
                .method_694(consumer, id("root"));

        // ==================================================================
        // RGOLD ingot (smelt raw ore -> ingot) -- bridges root to tools/armor
        // ==================================================================
        class_161 rgold = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.RGOLD, title("rgold"), desc("rgold"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rgold",
                        class_2066.class_2068.method_8959(ModItems.RGOLD))
                .method_694(consumer, id("rgold"));

        // ==================================================================
        // BRANCH: Ore Discovery (from root)
        // ==================================================================
        class_161 oreFound = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModBlocks.RGOLDORE, title("ore_found"), desc("ore_found"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rgold_ore",
                        class_2066.class_2068.method_8959(ModBlocks.RGOLDORE))
                .method_694(consumer, id("ore_found"));

        class_161.class_162.method_707()
                .method_701(oreFound)
                .method_697(ModBlocks.RGOLD_NETHER_ORE, title("nether_ore"), desc("nether_ore"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_nether_ore",
                        class_2066.class_2068.method_8959(ModBlocks.RGOLD_NETHER_ORE))
                .method_694(consumer, id("nether_ore"));

        class_161.class_162.method_707()
                .method_701(oreFound)
                .method_697(ModBlocks.RGOLD_END_ORE, title("end_ore"), desc("end_ore"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_end_ore",
                        class_2066.class_2068.method_8959(ModBlocks.RGOLD_END_ORE))
                .method_694(consumer, id("end_ore"));

        class_161.class_162.method_707()
                .method_701(oreFound)
                .method_697(ModBlocks.RGOLD_DEEPSLATE_ORE, title("deepslate_ore"), desc("deepslate_ore"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_deepslate_ore",
                        class_2066.class_2068.method_8959(ModBlocks.RGOLD_DEEPSLATE_ORE))
                .method_694(consumer, id("deepslate_ore"));

        // ==================================================================
        // BRANCH: Reinforced Gold Tools / Armor (from rgold ingot)
        // ==================================================================
        class_161 rgoldSword = class_161.class_162.method_707()
                .method_701(rgold)
                .method_697(ModItems.RGOLD_SWORD, title("rgold_tools"), desc("rgold_tools"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rgold_sword",
                        class_2066.class_2068.method_8959(ModItems.RGOLD_SWORD))
                .method_694(consumer, id("rgold_tools"));

        class_161.class_162.method_707()
                .method_701(rgoldSword)
                .method_697(ModItems.RGOLD_HELMET, title("rgold_armor"), desc("rgold_armor"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rgold_helmet",
                        class_2066.class_2068.method_8959(ModItems.RGOLD_HELMET))
                .method_694(consumer, id("rgold_armor"));

        // ==================================================================
        // BRANCH: Obsidian (from root)
        // ==================================================================
        class_161 obshard = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.OBSHARD, title("obshard"), desc("obshard"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_obshard",
                        class_2066.class_2068.method_8959(ModItems.OBSHARD))
                .method_694(consumer, id("obshard"));

        class_161 obingot = class_161.class_162.method_707()
                .method_701(obshard)
                .method_697(ModItems.OBINGOT, title("obingot"), desc("obingot"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_obingot",
                        class_2066.class_2068.method_8959(ModItems.OBINGOT))
                .method_694(consumer, id("obingot"));

        class_161.class_162.method_707()
                .method_701(obingot)
                .method_697(ModItems.ROBSIDIAN_SWORD, title("robsidian"), desc("robsidian"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_robsidian_sword",
                        class_2066.class_2068.method_8959(ModItems.ROBSIDIAN_SWORD))
                .method_694(consumer, id("robsidian"));

        class_161.class_162.method_707()
                .method_701(obingot)
                .method_697(ModItems.POBSIDIAN_SWORD, title("pobsidian"), desc("pobsidian"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_pobsidian_sword",
                        class_2066.class_2068.method_8959(ModItems.POBSIDIAN_SWORD))
                .method_694(consumer, id("pobsidian"));

        // Full Obsidian armor (CHALLENGE -- requires all 4 pieces)
        class_161.class_162.method_707()
                .method_701(obingot)
                .method_697(ModItems.OBSIDIAN_CHESTPLATE, title("obsidian_armor"), desc("obsidian_armor"),
                        null, class_189.field_1250, true, true, false)
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.OBSIDIAN_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.OBSIDIAN_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.OBSIDIAN_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.OBSIDIAN_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("obsidian_armor"));

        // ==================================================================
        // BRANCH: Polished Emerald (from root)
        // ==================================================================
        class_161 sem = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.SEM, title("sem"), desc("sem"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_sem",
                        class_2066.class_2068.method_8959(ModItems.SEM))
                .method_694(consumer, id("sem"));

        class_161.class_162.method_707()
                .method_701(sem)
                .method_697(ModItems.REMERALD_SWORD, title("remerald"), desc("remerald"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_remerald_sword",
                        class_2066.class_2068.method_8959(ModItems.REMERALD_SWORD))
                .method_694(consumer, id("remerald"));

        class_161.class_162.method_707()
                .method_701(sem)
                .method_697(ModItems.PEMERALD_SWORD, title("pemerald"), desc("pemerald"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_pemerald_sword",
                        class_2066.class_2068.method_8959(ModItems.PEMERALD_SWORD))
                .method_694(consumer, id("pemerald"));

        class_161.class_162.method_707()
                .method_701(sem)
                .method_697(ModItems.EMERALD_HELMET, title("emerald_armor"), desc("emerald_armor"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.EMERALD_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.EMERALD_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.EMERALD_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.EMERALD_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("emerald_armor"));

        // ==================================================================
        // BRANCH: Hardened Redstone (from root)
        // ==================================================================
        class_161 hred = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.HRED, title("hred"), desc("hred"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_hred",
                        class_2066.class_2068.method_8959(ModItems.HRED))
                .method_694(consumer, id("hred"));

        class_161.class_162.method_707()
                .method_701(hred)
                .method_697(ModItems.HREDSTONE_SWORD, title("hredstone_tools"), desc("hredstone_tools"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_hredstone_sword",
                        class_2066.class_2068.method_8959(ModItems.HREDSTONE_SWORD))
                .method_694(consumer, id("hredstone_tools"));

        class_161.class_162.method_707()
                .method_701(hred)
                .method_697(ModItems.HRED_HELMET, title("hred_armor"), desc("hred_armor"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.HRED_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.HRED_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.HRED_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.HRED_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("hred_armor"));

        // ==================================================================
        // BRANCH: Hardened Glowstone (from root)
        // ==================================================================
        class_161 hglow = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.HGLOW, title("hglow"), desc("hglow"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_hglow",
                        class_2066.class_2068.method_8959(ModItems.HGLOW))
                .method_694(consumer, id("hglow"));

        class_161.class_162.method_707()
                .method_701(hglow)
                .method_697(ModItems.HGLOWSTONE_SWORD, title("hglowstone_tools"), desc("hglowstone_tools"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_hglowstone_sword",
                        class_2066.class_2068.method_8959(ModItems.HGLOWSTONE_SWORD))
                .method_694(consumer, id("hglowstone_tools"));

        class_161.class_162.method_707()
                .method_701(hglow)
                .method_697(ModItems.HGLOW_HELMET, title("hglow_armor"), desc("hglow_armor"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.HGLOW_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.HGLOW_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.HGLOW_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.HGLOW_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("hglow_armor"));

        // ==================================================================
        // BRANCH: Reinforced Lapis (from root)
        // ==================================================================
        class_161 rlapis = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.RLAPIS, title("rlapis"), desc("rlapis"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rlapis",
                        class_2066.class_2068.method_8959(ModItems.RLAPIS))
                .method_694(consumer, id("rlapis"));

        class_161.class_162.method_707()
                .method_701(rlapis)
                .method_697(ModItems.RLAPIS_SWORD, title("rlapis_tools"), desc("rlapis_tools"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rlapis_sword",
                        class_2066.class_2068.method_8959(ModItems.RLAPIS_SWORD))
                .method_694(consumer, id("rlapis_tools"));

        class_161.class_162.method_707()
                .method_701(rlapis)
                .method_697(ModItems.RLAPIS_HELMET, title("rlapis_armor"), desc("rlapis_armor"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.RLAPIS_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.RLAPIS_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.RLAPIS_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.RLAPIS_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("rlapis_armor"));

        // ==================================================================
        // BRANCH: Coal Tools / Armor (from root)
        // ==================================================================
        class_161 coalDust = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.COAL_DUST, title("coal_dust"), desc("coal_dust"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_coal_dust",
                        class_2066.class_2068.method_8959(ModItems.COAL_DUST))
                .method_694(consumer, id("coal_dust"));

        class_161 hardenedCoal = class_161.class_162.method_707()
                .method_701(coalDust)
                .method_697(ModItems.HARDENED_COAL, title("hardened_coal"), desc("hardened_coal"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_hardened_coal",
                        class_2066.class_2068.method_8959(ModItems.HARDENED_COAL))
                .method_694(consumer, id("hardened_coal"));

        class_161 coalTools = class_161.class_162.method_707()
                .method_701(hardenedCoal)
                .method_697(ModItems.COAL_PICKAXE, title("coal_tools"), desc("coal_tools"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.COAL_PICKAXE))
                .method_694(consumer, id("coal_tools"));

        // Trial by Fire -- custom trigger (CHALLENGE)
        class_161.class_162.method_707()
                .method_701(coalTools)
                .method_697(ModItems.COAL_SWORD, title("coal_trial_by_fire"), desc("coal_trial_by_fire"),
                        null, class_189.field_1250, true, true, false)
                .method_709("coal_tool_ignited",
                        new CoalToolIgnitedTrigger.Conditions(CoalToolIgnitedTrigger.ID, class_5258.field_24388))
                .method_694(consumer, id("coal_trial_by_fire"));

        class_161 coalArmor = class_161.class_162.method_707()
                .method_701(hardenedCoal)
                .method_697(ModItems.COAL_HELMET, title("coal_armor"), desc("coal_armor"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_coal_helmet",
                        class_2066.class_2068.method_8959(ModItems.COAL_HELMET))
                .method_694(consumer, id("coal_armor"));

        // Burning Commitment -- full coal armor set (CHALLENGE)
        class_161.class_162.method_707()
                .method_701(coalArmor)
                .method_697(ModItems.COAL_CHESTPLATE, title("coal_full_set"), desc("coal_full_set"),
                        null, class_189.field_1250, true, true, true)
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.COAL_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.COAL_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.COAL_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.COAL_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("coal_full_set"));

        // ==================================================================
        // BRANCH: Explosives (from root)
        // ==================================================================
        class_161 grenade = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.GRENADE, title("grenade"), desc("grenade"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_grenade",
                        class_2066.class_2068.method_8959(ModItems.GRENADE))
                .method_694(consumer, id("grenade"));

        class_161.class_162.method_707()
                .method_701(grenade)
                .method_697(ModItems.DYNAMITE, title("dynamite"), desc("dynamite"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_dynamite",
                        class_2066.class_2068.method_8959(ModItems.DYNAMITE))
                .method_694(consumer, id("dynamite"));

        // ==================================================================
        // BRANCH: Ghost (from root)
        // ==================================================================
        class_161 ghostEncounter = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.GHOST_SPAWN_EGG, title("ghost_encounter"), desc("ghost_encounter"),
                        null, class_189.field_1254, true, true, false)
                .method_709("ghost_nearby",
                        new GhostNearbyTrigger.Conditions(GhostNearbyTrigger.ID, class_5258.field_24388))
                .method_694(consumer, id("ghost_encounter"));

        class_161 ghostCompanion = class_161.class_162.method_707()
                .method_701(ghostEncounter)
                .method_697(ModItems.GHOST_SPAWN_EGG, title("ghost_companion"), desc("ghost_companion"),
                        null, class_189.field_1249, true, true, true)
                .method_709("ghost_nearby_again",
                        new GhostNearbyTrigger.Conditions(GhostNearbyTrigger.ID, class_5258.field_24388))
                .method_694(consumer, id("ghost_companion"));

        // ------------------------------------------------------------------
        // SUB-BRANCH: Ectoplasm -> Refined Ectoplasm -> Ecto tools/armor
        //                                             -> Spectral Infuser
        // ------------------------------------------------------------------
        class_161 ectoplasmAdv = class_161.class_162.method_707()
                .method_701(ghostCompanion)
                .method_697(ModItems.ECTOPLASM, title("ectoplasm"), desc("ectoplasm"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_ectoplasm",
                        class_2066.class_2068.method_8959(ModItems.ECTOPLASM))
                .method_694(consumer, id("ectoplasm"));

        class_161.class_162.method_707()
                .method_701(ectoplasmAdv)
                .method_697(ModItems.RECTO_SWORD, title("recto"), desc("recto"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_recto_sword",
                        class_2066.class_2068.method_8959(ModItems.RECTO_SWORD))
                .method_694(consumer, id("recto"));

        class_161 refinedEctoplasm = class_161.class_162.method_707()
                .method_701(ectoplasmAdv)
                .method_697(ModItems.REFINED_ECTOPLASM, title("refined_ectoplasm"), desc("refined_ectoplasm"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_refined_ectoplasm",
                        class_2066.class_2068.method_8959(ModItems.REFINED_ECTOPLASM))
                .method_694(consumer, id("refined_ectoplasm"));

        class_161 ectoTools = class_161.class_162.method_707()
                .method_701(refinedEctoplasm)
                .method_697(ModItems.ECTO_SWORD, title("ecto_tools"), desc("ecto_tools"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_ecto_sword",
                        class_2066.class_2068.method_8959(ModItems.ECTO_SWORD))
                .method_694(consumer, id("ecto_tools"));

        class_161.class_162.method_707()
                .method_701(ectoTools)
                .method_697(ModItems.ECTO_HELMET, title("ecto_set"), desc("ecto_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.ECTO_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.ECTO_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.ECTO_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.ECTO_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.ECTO_HOE))
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.ECTO_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.ECTO_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.ECTO_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.ECTO_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("ecto_set"));

        // Spectral Infuser (from ectoplasm branch)
        class_161.class_162.method_707()
                .method_701(ectoplasmAdv)
                .method_697(ModBlocks.SPECTRAL_INFUSER, title("spectral_infuser"), desc("spectral_infuser"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_spectral_infuser",
                        class_2066.class_2068.method_8959(ModBlocks.SPECTRAL_INFUSER))
                .method_694(consumer, id("spectral_infuser"));

        // ==================================================================
        // BRANCH: Raw Metal Rough Tools (all from root)
        // ==================================================================

        // Raw Gold -> Rough Raw Gold tools -> full set
        class_161 rrawGold = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.RRAW_GOLD_SWORD, title("rraw_gold"), desc("rraw_gold"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rraw_gold_sword",
                        class_2066.class_2068.method_8959(ModItems.RRAW_GOLD_SWORD))
                .method_694(consumer, id("rraw_gold"));

        class_161.class_162.method_707()
                .method_701(rrawGold)
                .method_697(ModItems.RRAW_GOLD_PICKAXE, title("rraw_gold_set"), desc("rraw_gold_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.RRAW_GOLD_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.RRAW_GOLD_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.RRAW_GOLD_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.RRAW_GOLD_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.RRAW_GOLD_HOE))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("rraw_gold_set"));

        // Raw Copper -> Rough Raw Copper tools -> full set
        class_161 rrawCopper = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.RRAW_COPPER_SWORD, title("rraw_copper"), desc("rraw_copper"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rraw_copper_sword",
                        class_2066.class_2068.method_8959(ModItems.RRAW_COPPER_SWORD))
                .method_694(consumer, id("rraw_copper"));

        class_161.class_162.method_707()
                .method_701(rrawCopper)
                .method_697(ModItems.RRAW_COPPER_PICKAXE, title("rraw_copper_set"), desc("rraw_copper_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.RRAW_COPPER_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.RRAW_COPPER_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.RRAW_COPPER_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.RRAW_COPPER_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.RRAW_COPPER_HOE))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("rraw_copper_set"));

        // Raw Iron -> Rough Raw Iron tools -> full set
        class_161 rrawIron = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.RRAW_IRON_SWORD, title("rraw_iron"), desc("rraw_iron"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rraw_iron_sword",
                        class_2066.class_2068.method_8959(ModItems.RRAW_IRON_SWORD))
                .method_694(consumer, id("rraw_iron"));

        class_161.class_162.method_707()
                .method_701(rrawIron)
                .method_697(ModItems.RRAW_IRON_PICKAXE, title("rraw_iron_set"), desc("rraw_iron_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.RRAW_IRON_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.RRAW_IRON_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.RRAW_IRON_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.RRAW_IRON_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.RRAW_IRON_HOE))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("rraw_iron_set"));

        // Raw Ferrous Gold -> Rough Raw Ferrous Gold tools -> full set
        class_161 rrawRgold = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.RRAW_RGOLD_SWORD, title("rraw_rgold"), desc("rraw_rgold"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rraw_rgold_sword",
                        class_2066.class_2068.method_8959(ModItems.RRAW_RGOLD_SWORD))
                .method_694(consumer, id("rraw_rgold"));

        class_161.class_162.method_707()
                .method_701(rrawRgold)
                .method_697(ModItems.RRAW_RGOLD_PICKAXE, title("rraw_rgold_set"), desc("rraw_rgold_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.RRAW_RGOLD_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.RRAW_RGOLD_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.RRAW_RGOLD_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.RRAW_RGOLD_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.RRAW_RGOLD_HOE))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("rraw_rgold_set"));

        // Netherite Scrap -> Rough Scrap tools -> full set
        class_161 rscrap = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.RSCRAP_SWORD, title("rscrap"), desc("rscrap"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rscrap_sword",
                        class_2066.class_2068.method_8959(ModItems.RSCRAP_SWORD))
                .method_694(consumer, id("rscrap"));

        class_161.class_162.method_707()
                .method_701(rscrap)
                .method_697(ModItems.RSCRAP_PICKAXE, title("rscrap_set"), desc("rscrap_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.RSCRAP_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.RSCRAP_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.RSCRAP_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.RSCRAP_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.RSCRAP_HOE))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("rscrap_set"));

        // ==================================================================
        // BRANCH: Crystal / element sets (all from root)
        // ==================================================================

        // Rough Amethyst
        class_161 ramethyst = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.RAMETHYST_SWORD, title("ramethyst"), desc("ramethyst"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_ramethyst_sword",
                        class_2066.class_2068.method_8959(ModItems.RAMETHYST_SWORD))
                .method_694(consumer, id("ramethyst"));

        class_161.class_162.method_707()
                .method_701(ramethyst)
                .method_697(ModItems.RAMETHYST_PICKAXE, title("ramethyst_set"), desc("ramethyst_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.RAMETHYST_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.RAMETHYST_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.RAMETHYST_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.RAMETHYST_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.RAMETHYST_HOE))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("ramethyst_set"));

        // Snow tools
        class_161 snowTools = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.SNOW_SWORD, title("snow_tools"), desc("snow_tools"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_snow_sword",
                        class_2066.class_2068.method_8959(ModItems.SNOW_SWORD))
                .method_694(consumer, id("snow_tools"));

        class_161.class_162.method_707()
                .method_701(snowTools)
                .method_697(ModItems.SNOW_PICKAXE, title("snow_set"), desc("snow_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.SNOW_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.SNOW_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.SNOW_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.SNOW_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.SNOW_HOE))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("snow_set"));

        // Rough Quartz
        class_161 rquartz = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.RQUARTZ_SWORD, title("rquartz"), desc("rquartz"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rquartz_sword",
                        class_2066.class_2068.method_8959(ModItems.RQUARTZ_SWORD))
                .method_694(consumer, id("rquartz"));

        class_161.class_162.method_707()
                .method_701(rquartz)
                .method_697(ModItems.RQUARTZ_PICKAXE, title("rquartz_set"), desc("rquartz_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.RQUARTZ_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.RQUARTZ_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.RQUARTZ_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.RQUARTZ_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.RQUARTZ_HOE))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("rquartz_set"));

        // Rough Prismarine
        class_161 rprism = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.RPRISM_SWORD, title("rprism"), desc("rprism"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rprism_sword",
                        class_2066.class_2068.method_8959(ModItems.RPRISM_SWORD))
                .method_694(consumer, id("rprism"));

        class_161.class_162.method_707()
                .method_701(rprism)
                .method_697(ModItems.RPRISM_PICKAXE, title("rprism_set"), desc("rprism_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.RPRISM_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.RPRISM_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.RPRISM_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.RPRISM_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.RPRISM_HOE))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("rprism_set"));

        // Calcified Amethyst (polished) -- material + tools/armor
        class_161 calciteAmethyst = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.CALCIFIED_AMETHYST, title("calcified_amethyst"), desc("calcified_amethyst"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_calcified_amethyst",
                        class_2066.class_2068.method_8959(ModItems.CALCIFIED_AMETHYST))
                .method_694(consumer, id("calcified_amethyst"));

        class_161 camethystTools = class_161.class_162.method_707()
                .method_701(calciteAmethyst)
                .method_697(ModItems.CAMETHYST_SWORD, title("camethyst_tools"), desc("camethyst_tools"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_camethyst_sword",
                        class_2066.class_2068.method_8959(ModItems.CAMETHYST_SWORD))
                .method_694(consumer, id("camethyst_tools"));

        class_161.class_162.method_707()
                .method_701(camethystTools)
                .method_697(ModItems.CAMETHYST_HELMET, title("camethyst_set"), desc("camethyst_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.CAMETHYST_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.CAMETHYST_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.CAMETHYST_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.CAMETHYST_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.CAMETHYST_HOE))
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.CAMETHYST_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.CAMETHYST_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.CAMETHYST_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.CAMETHYST_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("camethyst_set"));

        // Ice / Glacial (polished) -- material + tools/armor
        class_161 glacialShard = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.GLACIAL_SHARD, title("glacial_shard"), desc("glacial_shard"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_glacial_shard",
                        class_2066.class_2068.method_8959(ModItems.GLACIAL_SHARD))
                .method_694(consumer, id("glacial_shard"));

        class_161 iceTools = class_161.class_162.method_707()
                .method_701(glacialShard)
                .method_697(ModItems.ICE_SWORD, title("ice_tools"), desc("ice_tools"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_ice_sword",
                        class_2066.class_2068.method_8959(ModItems.ICE_SWORD))
                .method_694(consumer, id("ice_tools"));

        class_161.class_162.method_707()
                .method_701(iceTools)
                .method_697(ModItems.ICE_HELMET, title("ice_set"), desc("ice_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.ICE_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.ICE_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.ICE_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.ICE_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.ICE_HOE))
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.ICE_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.ICE_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.ICE_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.ICE_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("ice_set"));

        // Polished Quartz -- material + tools/armor
        class_161 polishedQuartz = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.POLISHED_QUARTZ, title("polished_quartz"), desc("polished_quartz"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_polished_quartz",
                        class_2066.class_2068.method_8959(ModItems.POLISHED_QUARTZ))
                .method_694(consumer, id("polished_quartz"));

        class_161 pquartzTools = class_161.class_162.method_707()
                .method_701(polishedQuartz)
                .method_697(ModItems.PQUARTZ_SWORD, title("pquartz_tools"), desc("pquartz_tools"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_pquartz_sword",
                        class_2066.class_2068.method_8959(ModItems.PQUARTZ_SWORD))
                .method_694(consumer, id("pquartz_tools"));

        class_161.class_162.method_707()
                .method_701(pquartzTools)
                .method_697(ModItems.PQUARTZ_HELMET, title("pquartz_set"), desc("pquartz_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.PQUARTZ_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.PQUARTZ_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.PQUARTZ_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.PQUARTZ_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.PQUARTZ_HOE))
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.PQUARTZ_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.PQUARTZ_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.PQUARTZ_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.PQUARTZ_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("pquartz_set"));

        // Polished Prismarine -- material + tools/armor
        class_161 polishedPrismarine = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.POLISHED_PRISMARINE, title("polished_prismarine"), desc("polished_prismarine"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_polished_prismarine",
                        class_2066.class_2068.method_8959(ModItems.POLISHED_PRISMARINE))
                .method_694(consumer, id("polished_prismarine"));

        class_161 pprismTools = class_161.class_162.method_707()
                .method_701(polishedPrismarine)
                .method_697(ModItems.PPRISM_SWORD, title("pprism_tools"), desc("pprism_tools"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_pprism_sword",
                        class_2066.class_2068.method_8959(ModItems.PPRISM_SWORD))
                .method_694(consumer, id("pprism_tools"));

        class_161.class_162.method_707()
                .method_701(pprismTools)
                .method_697(ModItems.PPRISM_HELMET, title("pprism_set"), desc("pprism_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.PPRISM_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.PPRISM_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.PPRISM_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.PPRISM_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.PPRISM_HOE))
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.PPRISM_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.PPRISM_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.PPRISM_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.PPRISM_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("pprism_set"));

        // ==================================================================
        // BRANCH: Overpower (from root) -- CHALLENGE
        // ==================================================================
        class_161 overpowerSword = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.OVERPOWER_SWORD, title("overpower"), desc("overpower"),
                        null, class_189.field_1250, true, true, false)
                .method_709("has_overpower_sword",
                        class_2066.class_2068.method_8959(ModItems.OVERPOWER_SWORD))
                .method_694(consumer, id("overpower"));

        // Full Overpower set (GOAL)
        class_161.class_162.method_707()
                .method_701(overpowerSword)
                .method_697(ModItems.OVERPOWER_HELMET, title("overpower_set"), desc("overpower_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.OVERPOWER_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.OVERPOWER_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.OVERPOWER_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.OVERPOWER_AXE))
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.OVERPOWER_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.OVERPOWER_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.OVERPOWER_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.OVERPOWER_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("overpower_set"));

        // ==================================================================
        // BRANCH: Flint / FNI (from root)
        // ==================================================================
        class_161 rflintSword = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.RFLINT_SWORD, title("rflint"), desc("rflint"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_rflint_sword",
                        class_2066.class_2068.method_8959(ModItems.RFLINT_SWORD))
                .method_694(consumer, id("rflint"));

        class_161 fniSword = class_161.class_162.method_707()
                .method_701(rflintSword)
                .method_697(ModItems.FNI_SWORD, title("fni_tools"), desc("fni_tools"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_fni_sword",
                        class_2066.class_2068.method_8959(ModItems.FNI_SWORD))
                .method_694(consumer, id("fni_tools"));

        class_161.class_162.method_707()
                .method_701(fniSword)
                .method_697(ModItems.FNI_BOOTS, title("fni_set"), desc("fni_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.FNI_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.FNI_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.FNI_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.FNI_AXE))
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.FNI_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.FNI_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.FNI_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.FNI_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("fni_set"));

        // ==================================================================
        // BRANCH: Stone Toolkit (from root) -- CHALLENGE
        // Collect a pickaxe crafted from every rock variant
        // ==================================================================
        class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.GRANITE_PICKAXE, title("stone_toolkit"), desc("stone_toolkit"),
                        null, class_189.field_1250, true, true, false)
                .method_709("has_andesite_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.ANDESITE_PICKAXE))
                .method_709("has_basalt_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.BASALT_PICKAXE))
                .method_709("has_blackstone_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.BLACKSTONE_PICKAXE))
                .method_709("has_calcite_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.CALCITE_PICKAXE))
                .method_709("has_deepslate_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.DEEPSLATE_PICKAXE))
                .method_709("has_diorite_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.DIORITE_PICKAXE))
                .method_709("has_end_stone_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.END_STONE_PICKAXE))
                .method_709("has_granite_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.GRANITE_PICKAXE))
                .method_709("has_netherrack_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.NETHERRACK_PICKAXE))
                .method_709("has_sandstone_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.SANDSTONE_PICKAXE))
                .method_709("has_smooth_basalt_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.SMOOTH_BASALT_PICKAXE))
                .method_709("has_terracotta_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.TERRACOTTA_PICKAXE))
                .method_709("has_tuff_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.TUFF_PICKAXE))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("stone_toolkit"));

        // ==================================================================
        // BRANCH: Wood Toolkit (from root) -- CHALLENGE
        // Collect a sword crafted from every wood variant
        // ==================================================================
        class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.OAK_SWORD, title("wood_toolkit"), desc("wood_toolkit"),
                        null, class_189.field_1250, true, true, false)
                .method_709("has_oak_sword",
                        class_2066.class_2068.method_8959(ModItems.OAK_SWORD))
                .method_709("has_spruce_sword",
                        class_2066.class_2068.method_8959(ModItems.SPRUCE_SWORD))
                .method_709("has_birch_sword",
                        class_2066.class_2068.method_8959(ModItems.BIRCH_SWORD))
                .method_709("has_jungle_sword",
                        class_2066.class_2068.method_8959(ModItems.JUNGLE_SWORD))
                .method_709("has_acacia_sword",
                        class_2066.class_2068.method_8959(ModItems.ACACIA_SWORD))
                .method_709("has_dark_oak_sword",
                        class_2066.class_2068.method_8959(ModItems.DARK_OAK_SWORD))
                .method_709("has_mangrove_sword",
                        class_2066.class_2068.method_8959(ModItems.MANGROVE_SWORD))
                .method_709("has_cherry_sword",
                        class_2066.class_2068.method_8959(ModItems.CHERRY_SWORD))
                .method_709("has_bamboo_sword",
                        class_2066.class_2068.method_8959(ModItems.BAMBOO_SWORD))
                .method_709("has_crimson_sword",
                        class_2066.class_2068.method_8959(ModItems.CRIMSON_SWORD))
                .method_709("has_warped_sword",
                        class_2066.class_2068.method_8959(ModItems.WARPED_SWORD))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("wood_toolkit"));

        // ==================================================================
        // BRANCH: Vanilla Material Sets (from root)
        // ==================================================================

        // --- Tools-only sets (5 items each) ---
        buildVanillaToolAdv(consumer, root, "paper_craft", "paper_set",
                ModItems.PAPER_SWORD,
                ModItems.PAPER_SWORD, ModItems.PAPER_PICKAXE,
                ModItems.PAPER_AXE, ModItems.PAPER_SHOVEL, ModItems.PAPER_HOE);

        buildVanillaToolAdv(consumer, root, "feather_craft", "feather_set",
                ModItems.FEATHER_SWORD,
                ModItems.FEATHER_SWORD, ModItems.FEATHER_PICKAXE,
                ModItems.FEATHER_AXE, ModItems.FEATHER_SHOVEL, ModItems.FEATHER_HOE);

        buildVanillaToolAdv(consumer, root, "glass_craft", "glass_set",
                ModItems.GLASS_SWORD,
                ModItems.GLASS_SWORD, ModItems.GLASS_PICKAXE,
                ModItems.GLASS_AXE, ModItems.GLASS_SHOVEL, ModItems.GLASS_HOE);

        buildVanillaToolAdv(consumer, root, "sponge_craft", "sponge_set",
                ModItems.SPONGE_SWORD,
                ModItems.SPONGE_SWORD, ModItems.SPONGE_PICKAXE,
                ModItems.SPONGE_AXE, ModItems.SPONGE_SHOVEL, ModItems.SPONGE_HOE);

        buildVanillaToolAdv(consumer, root, "nether_wart_craft", "nether_wart_set",
                ModItems.NETHER_WART_SWORD,
                ModItems.NETHER_WART_SWORD, ModItems.NETHER_WART_PICKAXE,
                ModItems.NETHER_WART_AXE, ModItems.NETHER_WART_SHOVEL, ModItems.NETHER_WART_HOE);

        buildVanillaToolAdv(consumer, root, "pointed_dripstone_craft", "pointed_dripstone_set",
                ModItems.POINTED_DRIPSTONE_SWORD,
                ModItems.POINTED_DRIPSTONE_SWORD, ModItems.POINTED_DRIPSTONE_PICKAXE,
                ModItems.POINTED_DRIPSTONE_AXE, ModItems.POINTED_DRIPSTONE_SHOVEL, ModItems.POINTED_DRIPSTONE_HOE);

        // --- Armor-only sets (4 items each) ---
        class_161 rabbitHideCraft = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.RABBIT_HIDE_HELMET, title("rabbit_hide_craft"), desc("rabbit_hide_craft"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.RABBIT_HIDE_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.RABBIT_HIDE_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.RABBIT_HIDE_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.RABBIT_HIDE_BOOTS))
                .method_704(class_193.field_1257)
                .method_694(consumer, id("rabbit_hide_craft"));

        class_161.class_162.method_707()
                .method_701(rabbitHideCraft)
                .method_697(ModItems.RABBIT_HIDE_CHESTPLATE, title("rabbit_hide_set"), desc("rabbit_hide_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.RABBIT_HIDE_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.RABBIT_HIDE_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.RABBIT_HIDE_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.RABBIT_HIDE_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("rabbit_hide_set"));

        class_161 turtleScuteCraft = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.TURTLE_SCUTE_HELMET, title("turtle_scute_craft"), desc("turtle_scute_craft"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.TURTLE_SCUTE_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.TURTLE_SCUTE_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.TURTLE_SCUTE_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.TURTLE_SCUTE_BOOTS))
                .method_704(class_193.field_1257)
                .method_694(consumer, id("turtle_scute_craft"));

        class_161.class_162.method_707()
                .method_701(turtleScuteCraft)
                .method_697(ModItems.TURTLE_SCUTE_CHESTPLATE, title("turtle_scute_set"), desc("turtle_scute_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_helmet",
                        class_2066.class_2068.method_8959(ModItems.TURTLE_SCUTE_HELMET))
                .method_709("has_chestplate",
                        class_2066.class_2068.method_8959(ModItems.TURTLE_SCUTE_CHESTPLATE))
                .method_709("has_leggings",
                        class_2066.class_2068.method_8959(ModItems.TURTLE_SCUTE_LEGGINGS))
                .method_709("has_boots",
                        class_2066.class_2068.method_8959(ModItems.TURTLE_SCUTE_BOOTS))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("turtle_scute_set"));

        // --- Tools+Armor sets (9 items each) ---
        buildVanillaSetAdv(consumer, root, "cactus_craft", "cactus_set",
                ModItems.CACTUS_SWORD,
                ModItems.CACTUS_SWORD, ModItems.CACTUS_PICKAXE,
                ModItems.CACTUS_AXE, ModItems.CACTUS_SHOVEL, ModItems.CACTUS_HOE,
                ModItems.CACTUS_HELMET, ModItems.CACTUS_CHESTPLATE,
                ModItems.CACTUS_LEGGINGS, ModItems.CACTUS_BOOTS);

        buildVanillaSetAdv(consumer, root, "bone_craft", "bone_set",
                ModItems.BONE_SWORD,
                ModItems.BONE_SWORD, ModItems.BONE_PICKAXE,
                ModItems.BONE_AXE, ModItems.BONE_SHOVEL, ModItems.BONE_HOE,
                ModItems.BONE_HELMET, ModItems.BONE_CHESTPLATE,
                ModItems.BONE_LEGGINGS, ModItems.BONE_BOOTS);

        buildVanillaSetAdv(consumer, root, "clay_craft", "clay_set",
                ModItems.CLAY_SWORD,
                ModItems.CLAY_SWORD, ModItems.CLAY_PICKAXE,
                ModItems.CLAY_AXE, ModItems.CLAY_SHOVEL, ModItems.CLAY_HOE,
                ModItems.CLAY_HELMET, ModItems.CLAY_CHESTPLATE,
                ModItems.CLAY_LEGGINGS, ModItems.CLAY_BOOTS);

        buildVanillaSetAdv(consumer, root, "brick_craft", "brick_set",
                ModItems.BRICK_SWORD,
                ModItems.BRICK_SWORD, ModItems.BRICK_PICKAXE,
                ModItems.BRICK_AXE, ModItems.BRICK_SHOVEL, ModItems.BRICK_HOE,
                ModItems.BRICK_HELMET, ModItems.BRICK_CHESTPLATE,
                ModItems.BRICK_LEGGINGS, ModItems.BRICK_BOOTS);

        buildVanillaSetAdv(consumer, root, "nether_brick_craft", "nether_brick_set",
                ModItems.NETHER_BRICK_SWORD,
                ModItems.NETHER_BRICK_SWORD, ModItems.NETHER_BRICK_PICKAXE,
                ModItems.NETHER_BRICK_AXE, ModItems.NETHER_BRICK_SHOVEL, ModItems.NETHER_BRICK_HOE,
                ModItems.NETHER_BRICK_HELMET, ModItems.NETHER_BRICK_CHESTPLATE,
                ModItems.NETHER_BRICK_LEGGINGS, ModItems.NETHER_BRICK_BOOTS);

        buildVanillaSetAdv(consumer, root, "copper_craft", "copper_set",
                ModItems.COPPER_SWORD,
                ModItems.COPPER_SWORD, ModItems.COPPER_PICKAXE,
                ModItems.COPPER_AXE, ModItems.COPPER_SHOVEL, ModItems.COPPER_HOE,
                ModItems.COPPER_HELMET, ModItems.COPPER_CHESTPLATE,
                ModItems.COPPER_LEGGINGS, ModItems.COPPER_BOOTS);

        buildVanillaSetAdv(consumer, root, "phantom_craft", "phantom_set",
                ModItems.PHANTOM_SWORD,
                ModItems.PHANTOM_SWORD, ModItems.PHANTOM_PICKAXE,
                ModItems.PHANTOM_AXE, ModItems.PHANTOM_SHOVEL, ModItems.PHANTOM_HOE,
                ModItems.PHANTOM_HELMET, ModItems.PHANTOM_CHESTPLATE,
                ModItems.PHANTOM_LEGGINGS, ModItems.PHANTOM_BOOTS);

        buildVanillaSetAdv(consumer, root, "magma_cream_craft", "magma_cream_set",
                ModItems.MAGMA_CREAM_SWORD,
                ModItems.MAGMA_CREAM_SWORD, ModItems.MAGMA_CREAM_PICKAXE,
                ModItems.MAGMA_CREAM_AXE, ModItems.MAGMA_CREAM_SHOVEL, ModItems.MAGMA_CREAM_HOE,
                ModItems.MAGMA_CREAM_HELMET, ModItems.MAGMA_CREAM_CHESTPLATE,
                ModItems.MAGMA_CREAM_LEGGINGS, ModItems.MAGMA_CREAM_BOOTS);

        buildVanillaSetAdv(consumer, root, "slime_craft", "slime_set",
                ModItems.SLIME_SWORD,
                ModItems.SLIME_SWORD, ModItems.SLIME_PICKAXE,
                ModItems.SLIME_AXE, ModItems.SLIME_SHOVEL, ModItems.SLIME_HOE,
                ModItems.SLIME_HELMET, ModItems.SLIME_CHESTPLATE,
                ModItems.SLIME_LEGGINGS, ModItems.SLIME_BOOTS);

        buildVanillaSetAdv(consumer, root, "blaze_craft", "blaze_set",
                ModItems.BLAZE_SWORD,
                ModItems.BLAZE_SWORD, ModItems.BLAZE_PICKAXE,
                ModItems.BLAZE_AXE, ModItems.BLAZE_SHOVEL, ModItems.BLAZE_HOE,
                ModItems.BLAZE_HELMET, ModItems.BLAZE_CHESTPLATE,
                ModItems.BLAZE_LEGGINGS, ModItems.BLAZE_BOOTS);

        buildVanillaSetAdv(consumer, root, "nautilus_craft", "nautilus_set",
                ModItems.NAUTILUS_SWORD,
                ModItems.NAUTILUS_SWORD, ModItems.NAUTILUS_PICKAXE,
                ModItems.NAUTILUS_AXE, ModItems.NAUTILUS_SHOVEL, ModItems.NAUTILUS_HOE,
                ModItems.NAUTILUS_HELMET, ModItems.NAUTILUS_CHESTPLATE,
                ModItems.NAUTILUS_LEGGINGS, ModItems.NAUTILUS_BOOTS);

        buildVanillaSetAdv(consumer, root, "purpur_craft", "purpur_set",
                ModItems.PURPUR_SWORD,
                ModItems.PURPUR_SWORD, ModItems.PURPUR_PICKAXE,
                ModItems.PURPUR_AXE, ModItems.PURPUR_SHOVEL, ModItems.PURPUR_HOE,
                ModItems.PURPUR_HELMET, ModItems.PURPUR_CHESTPLATE,
                ModItems.PURPUR_LEGGINGS, ModItems.PURPUR_BOOTS);

        buildVanillaSetAdv(consumer, root, "ghast_tear_craft", "ghast_tear_set",
                ModItems.GHAST_TEAR_SWORD,
                ModItems.GHAST_TEAR_SWORD, ModItems.GHAST_TEAR_PICKAXE,
                ModItems.GHAST_TEAR_AXE, ModItems.GHAST_TEAR_SHOVEL, ModItems.GHAST_TEAR_HOE,
                ModItems.GHAST_TEAR_HELMET, ModItems.GHAST_TEAR_CHESTPLATE,
                ModItems.GHAST_TEAR_LEGGINGS, ModItems.GHAST_TEAR_BOOTS);

        buildVanillaSetAdv(consumer, root, "eye_of_ender_craft", "eye_of_ender_set",
                ModItems.EYE_OF_ENDER_SWORD,
                ModItems.EYE_OF_ENDER_SWORD, ModItems.EYE_OF_ENDER_PICKAXE,
                ModItems.EYE_OF_ENDER_AXE, ModItems.EYE_OF_ENDER_SHOVEL, ModItems.EYE_OF_ENDER_HOE,
                ModItems.EYE_OF_ENDER_HELMET, ModItems.EYE_OF_ENDER_CHESTPLATE,
                ModItems.EYE_OF_ENDER_LEGGINGS, ModItems.EYE_OF_ENDER_BOOTS);

        buildVanillaSetAdv(consumer, root, "shulker_craft", "shulker_set",
                ModItems.SHULKER_SWORD,
                ModItems.SHULKER_SWORD, ModItems.SHULKER_PICKAXE,
                ModItems.SHULKER_AXE, ModItems.SHULKER_SHOVEL, ModItems.SHULKER_HOE,
                ModItems.SHULKER_HELMET, ModItems.SHULKER_CHESTPLATE,
                ModItems.SHULKER_LEGGINGS, ModItems.SHULKER_BOOTS);

        buildVanillaSetAdv(consumer, root, "echo_shard_craft", "echo_shard_set",
                ModItems.ECHO_SHARD_SWORD,
                ModItems.ECHO_SHARD_SWORD, ModItems.ECHO_SHARD_PICKAXE,
                ModItems.ECHO_SHARD_AXE, ModItems.ECHO_SHARD_SHOVEL, ModItems.ECHO_SHARD_HOE,
                ModItems.ECHO_SHARD_HELMET, ModItems.ECHO_SHARD_CHESTPLATE,
                ModItems.ECHO_SHARD_LEGGINGS, ModItems.ECHO_SHARD_BOOTS);

        buildVanillaSetAdv(consumer, root, "dragon_breath_craft", "dragon_breath_set",
                ModItems.DRAGON_BREATH_SWORD,
                ModItems.DRAGON_BREATH_SWORD, ModItems.DRAGON_BREATH_PICKAXE,
                ModItems.DRAGON_BREATH_AXE, ModItems.DRAGON_BREATH_SHOVEL, ModItems.DRAGON_BREATH_HOE,
                ModItems.DRAGON_BREATH_HELMET, ModItems.DRAGON_BREATH_CHESTPLATE,
                ModItems.DRAGON_BREATH_LEGGINGS, ModItems.DRAGON_BREATH_BOOTS);

        // ---------------------------------------------------------------
        // Leather tools (from root)
        // ---------------------------------------------------------------
        class_161 leatherCraft = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.LEATHER_SWORD, title("leather_craft"), desc("leather_craft"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_leather_sword",
                        class_2066.class_2068.method_8959(ModItems.LEATHER_SWORD))
                .method_709("has_leather_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.LEATHER_PICKAXE))
                .method_709("has_leather_axe",
                        class_2066.class_2068.method_8959(ModItems.LEATHER_AXE))
                .method_709("has_leather_shovel",
                        class_2066.class_2068.method_8959(ModItems.LEATHER_SHOVEL))
                .method_709("has_leather_hoe",
                        class_2066.class_2068.method_8959(ModItems.LEATHER_HOE))
                .method_704(class_193.field_1257)
                .method_694(consumer, id("leather_craft"));

        class_161.class_162.method_707()
                .method_701(leatherCraft)
                .method_697(ModItems.LEATHER_PICKAXE, title("leather_set"), desc("leather_set"),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword",
                        class_2066.class_2068.method_8959(ModItems.LEATHER_SWORD))
                .method_709("has_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.LEATHER_PICKAXE))
                .method_709("has_shovel",
                        class_2066.class_2068.method_8959(ModItems.LEATHER_SHOVEL))
                .method_709("has_axe",
                        class_2066.class_2068.method_8959(ModItems.LEATHER_AXE))
                .method_709("has_hoe",
                        class_2066.class_2068.method_8959(ModItems.LEATHER_HOE))
                .method_704(class_193.field_16882)
                .method_694(consumer, id("leather_set"));

        // ---------------------------------------------------------------
        // Cake -- novelty branch (from root)
        // ---------------------------------------------------------------
        class_161 cakeAdv = class_161.class_162.method_707()
                .method_701(root)
                .method_697(ModItems.CAKE_SWORD, title("let_them_eat_cake"), desc("let_them_eat_cake"),
                        null, class_189.field_1254, true, true, false)
                .method_709("has_cake_sword",
                        class_2066.class_2068.method_8959(ModItems.CAKE_SWORD))
                .method_709("has_cake_pickaxe",
                        class_2066.class_2068.method_8959(ModItems.CAKE_PICKAXE))
                .method_709("has_cake_axe",
                        class_2066.class_2068.method_8959(ModItems.CAKE_AXE))
                .method_709("has_cake_shovel",
                        class_2066.class_2068.method_8959(ModItems.CAKE_SHOVEL))
                .method_709("has_cake_hoe",
                        class_2066.class_2068.method_8959(ModItems.CAKE_HOE))
                .method_704(class_193.field_1257)
                .method_694(consumer, id("let_them_eat_cake"));

        class_161.class_162.method_707()
                .method_701(cakeAdv)
                .method_697(class_1802.field_17534, title("the_cake_is_a_lie"), desc("the_cake_is_a_lie"),
                        null, class_189.field_1254, true, true, true)
                .method_709("eat_cake_sword",
                        class_2010.class_2012.method_8828(ModItems.CAKE_SWORD))
                .method_709("eat_cake_pickaxe",
                        class_2010.class_2012.method_8828(ModItems.CAKE_PICKAXE))
                .method_709("eat_cake_axe",
                        class_2010.class_2012.method_8828(ModItems.CAKE_AXE))
                .method_709("eat_cake_shovel",
                        class_2010.class_2012.method_8828(ModItems.CAKE_SHOVEL))
                .method_709("eat_cake_hoe",
                        class_2010.class_2012.method_8828(ModItems.CAKE_HOE))
                .method_704(class_193.field_1257)
                .method_694(consumer, id("the_cake_is_a_lie"));

        // ---------------------------------------------------------------
        // Food sets -- craft + eat advancements (from cake branch)
        // ---------------------------------------------------------------
        buildFoodAdv(consumer, cakeAdv, "bread_craft", "bread_eat", "bread_full_set",
                ModItems.BREAD_SWORD, class_1802.field_8229,
                ModItems.BREAD_SWORD, ModItems.BREAD_PICKAXE,
                ModItems.BREAD_AXE, ModItems.BREAD_SHOVEL, ModItems.BREAD_HOE,
                ModItems.BREAD_HELMET, ModItems.BREAD_CHESTPLATE,
                ModItems.BREAD_LEGGINGS, ModItems.BREAD_BOOTS);

        buildFoodAdv(consumer, cakeAdv, "dried_kelp_craft", "dried_kelp_eat", "dried_kelp_full_set",
                ModItems.DRIED_KELP_SWORD, class_1802.field_8551,
                ModItems.DRIED_KELP_SWORD, ModItems.DRIED_KELP_PICKAXE,
                ModItems.DRIED_KELP_AXE, ModItems.DRIED_KELP_SHOVEL, ModItems.DRIED_KELP_HOE,
                ModItems.DRIED_KELP_HELMET, ModItems.DRIED_KELP_CHESTPLATE,
                ModItems.DRIED_KELP_LEGGINGS, ModItems.DRIED_KELP_BOOTS);

        buildFoodAdv(consumer, cakeAdv, "rotten_flesh_craft", "rotten_flesh_eat", "rotten_flesh_full_set",
                ModItems.ROTTEN_FLESH_SWORD, class_1802.field_8511,
                ModItems.ROTTEN_FLESH_SWORD, ModItems.ROTTEN_FLESH_PICKAXE,
                ModItems.ROTTEN_FLESH_AXE, ModItems.ROTTEN_FLESH_SHOVEL, ModItems.ROTTEN_FLESH_HOE,
                ModItems.ROTTEN_FLESH_HELMET, ModItems.ROTTEN_FLESH_CHESTPLATE,
                ModItems.ROTTEN_FLESH_LEGGINGS, ModItems.ROTTEN_FLESH_BOOTS);

        buildFoodAdv(consumer, cakeAdv, "melon_craft", "melon_eat", "melon_full_set",
                ModItems.MELON_SWORD, class_1802.field_8497,
                ModItems.MELON_SWORD, ModItems.MELON_PICKAXE,
                ModItems.MELON_AXE, ModItems.MELON_SHOVEL, ModItems.MELON_HOE,
                ModItems.MELON_HELMET, ModItems.MELON_CHESTPLATE,
                ModItems.MELON_LEGGINGS, ModItems.MELON_BOOTS);

        buildFoodAdv(consumer, cakeAdv, "sweet_berry_craft", "sweet_berry_eat", "sweet_berry_full_set",
                ModItems.SWEET_BERRY_SWORD, class_1802.field_16998,
                ModItems.SWEET_BERRY_SWORD, ModItems.SWEET_BERRY_PICKAXE,
                ModItems.SWEET_BERRY_AXE, ModItems.SWEET_BERRY_SHOVEL, ModItems.SWEET_BERRY_HOE,
                ModItems.SWEET_BERRY_HELMET, ModItems.SWEET_BERRY_CHESTPLATE,
                ModItems.SWEET_BERRY_LEGGINGS, ModItems.SWEET_BERRY_BOOTS);

        buildFoodAdv(consumer, cakeAdv, "pumpkin_pie_craft", "pumpkin_pie_eat", "pumpkin_pie_full_set",
                ModItems.PUMPKIN_PIE_SWORD, class_1802.field_8741,
                ModItems.PUMPKIN_PIE_SWORD, ModItems.PUMPKIN_PIE_PICKAXE,
                ModItems.PUMPKIN_PIE_AXE, ModItems.PUMPKIN_PIE_SHOVEL, ModItems.PUMPKIN_PIE_HOE,
                ModItems.PUMPKIN_PIE_HELMET, ModItems.PUMPKIN_PIE_CHESTPLATE,
                ModItems.PUMPKIN_PIE_LEGGINGS, ModItems.PUMPKIN_PIE_BOOTS);

        buildFoodAdv(consumer, cakeAdv, "mushroom_craft", "mushroom_eat", "mushroom_full_set",
                ModItems.MUSHROOM_SWORD, class_1802.field_17517,
                ModItems.MUSHROOM_SWORD, ModItems.MUSHROOM_PICKAXE,
                ModItems.MUSHROOM_AXE, ModItems.MUSHROOM_SHOVEL, ModItems.MUSHROOM_HOE,
                ModItems.MUSHROOM_HELMET, ModItems.MUSHROOM_CHESTPLATE,
                ModItems.MUSHROOM_LEGGINGS, ModItems.MUSHROOM_BOOTS);

        buildFoodAdv(consumer, cakeAdv, "pufferfish_craft", "pufferfish_eat", "pufferfish_full_set",
                ModItems.PUFFERFISH_SWORD, class_1802.field_8323,
                ModItems.PUFFERFISH_SWORD, ModItems.PUFFERFISH_PICKAXE,
                ModItems.PUFFERFISH_AXE, ModItems.PUFFERFISH_SHOVEL, ModItems.PUFFERFISH_HOE,
                ModItems.PUFFERFISH_HELMET, ModItems.PUFFERFISH_CHESTPLATE,
                ModItems.PUFFERFISH_LEGGINGS, ModItems.PUFFERFISH_BOOTS);

        buildFoodAdv(consumer, cakeAdv, "honey_craft", "honey_eat", "honey_full_set",
                ModItems.HONEY_SWORD, class_1802.field_20417,
                ModItems.HONEY_SWORD, ModItems.HONEY_PICKAXE,
                ModItems.HONEY_AXE, ModItems.HONEY_SHOVEL, ModItems.HONEY_HOE,
                ModItems.HONEY_HELMET, ModItems.HONEY_CHESTPLATE,
                ModItems.HONEY_LEGGINGS, ModItems.HONEY_BOOTS);

        buildFoodAdv(consumer, cakeAdv, "chorus_fruit_craft", "chorus_fruit_eat", "chorus_fruit_full_set",
                ModItems.CHORUS_FRUIT_SWORD, class_1802.field_8233,
                ModItems.CHORUS_FRUIT_SWORD, ModItems.CHORUS_FRUIT_PICKAXE,
                ModItems.CHORUS_FRUIT_AXE, ModItems.CHORUS_FRUIT_SHOVEL, ModItems.CHORUS_FRUIT_HOE,
                ModItems.CHORUS_FRUIT_HELMET, ModItems.CHORUS_FRUIT_CHESTPLATE,
                ModItems.CHORUS_FRUIT_LEGGINGS, ModItems.CHORUS_FRUIT_BOOTS);

        buildFoodAdv(consumer, cakeAdv, "golden_apple_craft", "golden_apple_eat", "golden_apple_full_set",
                ModItems.GOLDEN_APPLE_SWORD, class_1802.field_8463,
                ModItems.GOLDEN_APPLE_SWORD, ModItems.GOLDEN_APPLE_PICKAXE,
                ModItems.GOLDEN_APPLE_AXE, ModItems.GOLDEN_APPLE_SHOVEL, ModItems.GOLDEN_APPLE_HOE,
                ModItems.GOLDEN_APPLE_HELMET, ModItems.GOLDEN_APPLE_CHESTPLATE,
                ModItems.GOLDEN_APPLE_LEGGINGS, ModItems.GOLDEN_APPLE_BOOTS);
    }

    // -----------------------------------------------------------------------
    // Food advancement helper
    // -----------------------------------------------------------------------

    private static void buildFoodAdv(Consumer<class_161> consumer, class_161 parent,
                                     String craftKey, String eatKey, String fullSetKey,
                                     class_1792 displayItem, class_1935 eatIcon,
                                     class_1792 sword, class_1792 pickaxe,
                                     class_1792 axe, class_1792 shovel,
                                     class_1792 hoe,
                                     class_1792 helmet, class_1792 chestplate,
                                     class_1792 leggings, class_1792 boots) {
        class_1792[] tools = {sword, pickaxe, axe, shovel, hoe};

        // Craft advancement -- OR of any tool
        class_161.class_162 craft = class_161.class_162.method_707()
                .method_701(parent)
                .method_697(displayItem, title(craftKey), desc(craftKey),
                        null, class_189.field_1254, true, true, false);
        for (int i = 0; i < tools.length; i++) {
            craft.method_709("has_tool_" + i, class_2066.class_2068.method_8959(tools[i]));
        }
        class_161 craftAdv = craft.method_704(class_193.field_1257)
                .method_694(consumer, id(craftKey));

        // Eat advancement -- OR of consuming any of the 5 tools
        class_161.class_162 eat = class_161.class_162.method_707()
                .method_701(craftAdv)
                .method_697(eatIcon, title(eatKey), desc(eatKey),
                        null, class_189.field_1254, true, true, true);
        for (int i = 0; i < tools.length; i++) {
            eat.method_709("eat_tool_" + i,
                    class_2010.class_2012.method_8828(tools[i]));
        }
        class_161 eatAdv = eat.method_704(class_193.field_1257)
                .method_694(consumer, id(eatKey));

        // Full set advancement -- AND of all 9 items
        class_161.class_162.method_707()
                .method_701(eatAdv)
                .method_697(chestplate, title(fullSetKey), desc(fullSetKey),
                        null, class_189.field_1249, true, true, false)
                .method_709("has_sword", class_2066.class_2068.method_8959(sword))
                .method_709("has_pickaxe", class_2066.class_2068.method_8959(pickaxe))
                .method_709("has_axe", class_2066.class_2068.method_8959(axe))
                .method_709("has_shovel", class_2066.class_2068.method_8959(shovel))
                .method_709("has_hoe", class_2066.class_2068.method_8959(hoe))
                .method_709("has_helmet", class_2066.class_2068.method_8959(helmet))
                .method_709("has_chestplate", class_2066.class_2068.method_8959(chestplate))
                .method_709("has_leggings", class_2066.class_2068.method_8959(leggings))
                .method_709("has_boots", class_2066.class_2068.method_8959(boots))
                .method_704(class_193.field_16882)
                .method_694(consumer, id(fullSetKey));
    }

    // -----------------------------------------------------------------------
    // Vanilla material set helpers
    // -----------------------------------------------------------------------

    /** Tools-only set: craft (OR any tool) + full set (AND all 5 tools). */
    private static void buildVanillaToolAdv(Consumer<class_161> consumer, class_161 parent,
                                            String craftKey, String setKey,
                                            class_1792 displayItem,
                                            class_1792... tools) {
        class_161.class_162 craft = class_161.class_162.method_707()
                .method_701(parent)
                .method_697(displayItem, title(craftKey), desc(craftKey),
                        null, class_189.field_1254, true, true, false);
        for (int i = 0; i < tools.length; i++) {
            craft.method_709("has_tool_" + i, class_2066.class_2068.method_8959(tools[i]));
        }
        class_161 craftAdv = craft.method_704(class_193.field_1257)
                .method_694(consumer, id(craftKey));

        class_161.class_162 set = class_161.class_162.method_707()
                .method_701(craftAdv)
                .method_697(tools[1], title(setKey), desc(setKey),
                        null, class_189.field_1249, true, true, false);
        for (int i = 0; i < tools.length; i++) {
            set.method_709("has_tool_" + i, class_2066.class_2068.method_8959(tools[i]));
        }
        set.method_704(class_193.field_16882)
                .method_694(consumer, id(setKey));
    }

    /** Tools+Armor set: craft (OR any of 9 items) + full set (AND all 9 items). */
    private static void buildVanillaSetAdv(Consumer<class_161> consumer, class_161 parent,
                                           String craftKey, String setKey,
                                           class_1792 displayItem,
                                           class_1792 sword, class_1792 pickaxe,
                                           class_1792 axe, class_1792 shovel,
                                           class_1792 hoe,
                                           class_1792 helmet, class_1792 chestplate,
                                           class_1792 leggings, class_1792 boots) {
        class_1792[] all = {sword, pickaxe, axe, shovel, hoe, helmet, chestplate, leggings, boots};

        class_161.class_162 craft = class_161.class_162.method_707()
                .method_701(parent)
                .method_697(displayItem, title(craftKey), desc(craftKey),
                        null, class_189.field_1254, true, true, false);
        for (int i = 0; i < all.length; i++) {
            craft.method_709("has_item_" + i, class_2066.class_2068.method_8959(all[i]));
        }
        class_161 craftAdv = craft.method_704(class_193.field_1257)
                .method_694(consumer, id(craftKey));

        class_161.class_162 set = class_161.class_162.method_707()
                .method_701(craftAdv)
                .method_697(chestplate, title(setKey), desc(setKey),
                        null, class_189.field_1249, true, true, false);
        for (int i = 0; i < all.length; i++) {
            set.method_709("has_item_" + i, class_2066.class_2068.method_8959(all[i]));
        }
        set.method_704(class_193.field_16882)
                .method_694(consumer, id(setKey));
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    private static String id(String path) {
        return UsefultoolsMod.MOD_ID + ":" + path;
    }

    private static class_2561 title(String key) {
        return class_2561.method_43471("advancements." + UsefultoolsMod.MOD_ID + "." + key + ".title");
    }

    private static class_2561 desc(String key) {
        return class_2561.method_43471("advancements." + UsefultoolsMod.MOD_ID + "." + key + ".description");
    }
}
