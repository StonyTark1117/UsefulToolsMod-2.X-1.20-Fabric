package com.stonytark.usefultoolsmod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

/**
 * Fabric 1.20.1 Datapack Entries Data Generator
 * Placeholder for any custom datapack content generation
 * (This would typically handle worldgen features, structures, etc.)
 */
public class ModDatapackEntries extends FabricDynamicRegistryProvider {
    public ModDatapackEntries(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void configure(class_7225.class_7874 registries, Entries entries) {
        // Register custom worldgen features, biomes, structures, etc. here
        // Currently a placeholder - add entries as needed
    }

    @Override
    public String method_10321() {
        return "Useful Tools Datapack Entries";
    }
}
