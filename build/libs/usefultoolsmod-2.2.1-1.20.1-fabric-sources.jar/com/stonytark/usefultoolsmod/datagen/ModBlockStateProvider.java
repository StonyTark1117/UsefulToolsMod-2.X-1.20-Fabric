package com.stonytark.usefultoolsmod.datagen;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.block.ModBlocks;
import com.stonytark.usefultoolsmod.block.custom.SpectralInfuserBlock;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4935;
import net.minecraft.class_4936;
import net.minecraft.class_4941;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.minecraft.data.client.*;

/**
 * Fabric 1.20.1 Block State Data Generator
 * Generates block state JSON files for all blocks
 */
public class ModBlockStateProvider extends FabricModelProvider {
    public ModBlockStateProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        // Register simple cube blocks with item models
        blockStateModelGenerator.method_25641(ModBlocks.RGOLDBLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.HRBLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.RGOLDORE);
        blockStateModelGenerator.method_25641(ModBlocks.RGOLD_NETHER_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.RGOLD_END_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.RGOLD_DEEPSLATE_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.SEMBLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.SOBLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.LBLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.HGLOW_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.RAW_RGOLD_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.ECTOPLASM_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.REFINED_ECTOPLASM_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.HARDENED_COAL_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.COAL_DUST_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.OBSHARD_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.CALCIFIED_AMETHYST_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.GLACIAL_SHARD_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.POLISHED_QUARTZ_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.POLISHED_PRISMARINE_BLOCK);

        // Spectral Infuser - orientable block with LIT state
        registerSpectralInfuser(blockStateModelGenerator);
    }

    private void registerSpectralInfuser(class_4910 blockStateModelGenerator) {
        class_2960 side = new class_2960(UsefultoolsMod.MOD_ID, "block/spectral_infuser_side");
        class_2960 front = new class_2960(UsefultoolsMod.MOD_ID, "block/spectral_infuser_front");
        class_2960 frontOn = new class_2960(UsefultoolsMod.MOD_ID, "block/spectral_infuser_front_on");
        class_2960 top = new class_2960(UsefultoolsMod.MOD_ID, "block/spectral_infuser_top");

        class_4944 offTextures = new class_4944()
                .method_25868(class_4945.field_23018, side)
                .method_25868(class_4945.field_23016, front)
                .method_25868(class_4945.field_23015, top);

        class_4944 onTextures = new class_4944()
                .method_25868(class_4945.field_23018, side)
                .method_25868(class_4945.field_23016, frontOn)
                .method_25868(class_4945.field_23015, top);

        class_2960 offModel = class_4943.field_22978.method_25846(ModBlocks.SPECTRAL_INFUSER, offTextures,
                blockStateModelGenerator.field_22831);
        class_2960 onModel = class_4943.field_22978.method_25852(
                class_4941.method_25843(ModBlocks.SPECTRAL_INFUSER, "_on"), onTextures,
                blockStateModelGenerator.field_22831);

        blockStateModelGenerator.field_22830.accept(
                class_4925.method_25769(ModBlocks.SPECTRAL_INFUSER)
                        .method_25775(class_4926.method_25784(class_2741.field_12481, class_2741.field_12548)
                                .method_25797(class_2350.field_11043, false, class_4935.method_25824()
                                        .method_25828(class_4936.field_22887, offModel))
                                .method_25797(class_2350.field_11043, true, class_4935.method_25824()
                                        .method_25828(class_4936.field_22887, onModel))
                                .method_25797(class_2350.field_11035, false, class_4935.method_25824()
                                        .method_25828(class_4936.field_22887, offModel)
                                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                                .method_25797(class_2350.field_11035, true, class_4935.method_25824()
                                        .method_25828(class_4936.field_22887, onModel)
                                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22892))
                                .method_25797(class_2350.field_11039, false, class_4935.method_25824()
                                        .method_25828(class_4936.field_22887, offModel)
                                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                                .method_25797(class_2350.field_11039, true, class_4935.method_25824()
                                        .method_25828(class_4936.field_22887, onModel)
                                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22893))
                                .method_25797(class_2350.field_11034, false, class_4935.method_25824()
                                        .method_25828(class_4936.field_22887, offModel)
                                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                                .method_25797(class_2350.field_11034, true, class_4935.method_25824()
                                        .method_25828(class_4936.field_22887, onModel)
                                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        )
        );

        // Register the block item model to use the off model
        blockStateModelGenerator.method_25623(ModBlocks.SPECTRAL_INFUSER, offModel);
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        // Item models are generated in ModItemModelProvider
    }
}
