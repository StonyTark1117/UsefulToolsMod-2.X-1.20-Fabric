package com.stonytark.usefultoolsmod.datagen;

import com.stonytark.usefultoolsmod.block.ModBlocks;
import com.stonytark.usefultoolsmod.item.ModItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;

/**
 * Fabric 1.20.1 Block Loot Table Data Generator
 * Generates loot tables for blocks
 */
public class ModBlockLootTableProvider extends FabricBlockLootTableProvider {
    public ModBlockLootTableProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void method_10379() {
        // Ore blocks drop RAW_RGOLD (like vanilla gold ore drops raw gold)
        method_45988(ModBlocks.RGOLDORE, method_45981(ModBlocks.RGOLDORE, ModItems.RAW_RGOLD));
        method_45988(ModBlocks.RGOLD_NETHER_ORE, method_45981(ModBlocks.RGOLD_NETHER_ORE, ModItems.RAW_RGOLD));
        method_45988(ModBlocks.RGOLD_END_ORE, method_45981(ModBlocks.RGOLD_END_ORE, ModItems.RAW_RGOLD));
        method_45988(ModBlocks.RGOLD_DEEPSLATE_ORE, method_45981(ModBlocks.RGOLD_DEEPSLATE_ORE, ModItems.RAW_RGOLD));

        // Storage blocks drop themselves
        method_46025(ModBlocks.RGOLDBLOCK);
        method_46025(ModBlocks.HRBLOCK);
        method_46025(ModBlocks.SEMBLOCK);
        method_46025(ModBlocks.SOBLOCK);
        method_46025(ModBlocks.LBLOCK);
        method_46025(ModBlocks.HGLOW_BLOCK);
        method_46025(ModBlocks.RAW_RGOLD_BLOCK);
        method_46025(ModBlocks.ECTOPLASM_BLOCK);
        method_46025(ModBlocks.REFINED_ECTOPLASM_BLOCK);
        method_46025(ModBlocks.HARDENED_COAL_BLOCK);
        method_46025(ModBlocks.COAL_DUST_BLOCK);
        method_46025(ModBlocks.OBSHARD_BLOCK);
        method_46025(ModBlocks.CALCIFIED_AMETHYST_BLOCK);
        method_46025(ModBlocks.GLACIAL_SHARD_BLOCK);
        method_46025(ModBlocks.POLISHED_QUARTZ_BLOCK);
        method_46025(ModBlocks.POLISHED_PRISMARINE_BLOCK);

        // Spectral Infuser drops itself
        method_46025(ModBlocks.SPECTRAL_INFUSER);
    }
}
