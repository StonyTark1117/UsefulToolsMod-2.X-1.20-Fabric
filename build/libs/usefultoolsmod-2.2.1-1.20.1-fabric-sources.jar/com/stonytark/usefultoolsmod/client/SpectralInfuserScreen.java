package com.stonytark.usefultoolsmod.client;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.block.entity.SpectralInfuserMenu;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class SpectralInfuserScreen extends class_465<SpectralInfuserMenu> {
    private static final class_2960 TEXTURE =
            new class_2960(UsefultoolsMod.MOD_ID, "textures/gui/spectral_infuser.png");

    public SpectralInfuserScreen(SpectralInfuserMenu menu, class_1661 inv, class_2561 title) {
        super(menu, inv, title);
    }

    @Override
    protected void method_2389(class_332 context, float partialTick, int mouseX, int mouseY) {
        int x = (this.field_22789 - this.field_2792) / 2;
        int y = (this.field_22790 - this.field_2779) / 2;
        context.method_25302(TEXTURE, x, y, 0, 0, this.field_2792, this.field_2779);

        // Progress arrow
        if (this.field_2797.isCrafting()) {
            context.method_25302(TEXTURE, x + 79, y + 35, 176, 0,
                    this.field_2797.getScaledProgress(), 16);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float partialTick) {
        this.method_25420(context);
        super.method_25394(context, mouseX, mouseY, partialTick);
        this.method_2380(context, mouseX, mouseY);
    }
}
