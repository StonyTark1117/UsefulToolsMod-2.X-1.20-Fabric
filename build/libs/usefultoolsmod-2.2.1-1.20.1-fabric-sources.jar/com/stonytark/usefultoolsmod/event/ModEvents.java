package com.stonytark.usefultoolsmod.event;

import com.stonytark.usefultoolsmod.Config;
import com.stonytark.usefultoolsmod.entity.custom.GhostEntity;
import com.stonytark.usefultoolsmod.item.ModArmorMaterials;
import com.stonytark.usefultoolsmod.item.ModItems;
import com.stonytark.usefultoolsmod.item.custom.CoalArmorItem;
import com.stonytark.usefultoolsmod.item.custom.CoalBurningHelper;
import com.stonytark.usefultoolsmod.item.custom.EctoplasmArmorHelper;
import com.stonytark.usefultoolsmod.item.custom.EctoplasmInfusionHelper;
import com.stonytark.usefultoolsmod.trigger.ModTriggers;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1295;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1547;
import net.minecraft.class_1551;
import net.minecraft.class_1560;
import net.minecraft.class_1577;
import net.minecraft.class_1593;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2358;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4770;
import net.minecraft.class_7260;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import java.util.*;
import java.util.function.Predicate;

public class ModEvents {

    // -----------------------------------------------------------------------
    // Coal burning state
    // -----------------------------------------------------------------------

    /** Players currently holding at least one burning coal item (tool or armor in hand). */
    private static final Set<UUID> COAL_TOOL_BURNING = new HashSet<>();
    /** Players whose worn coal armor is burning. */
    private static final Set<UUID> COAL_ARMOR_BURNING = new HashSet<>();

    /**
     * Burning coal items (tools OR armor) that are lying on the ground as item entities.
     * Key = entity UUID, Value = dimension registry key.
     */
    private static final Map<UUID, net.minecraft.class_5321<class_1937>> BURNING_DROPPED_ITEMS = new HashMap<>();

    // -----------------------------------------------------------------------
    // Registration — all Fabric event callbacks
    // -----------------------------------------------------------------------

    public static void register() {
        // Per-player tick via server tick
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                if (player.method_7325()) continue;
                onPlayerTick(player);
            }
        });

        // World tick — processes burning coal items on the ground
        ServerTickEvents.END_WORLD_TICK.register(ModEvents::onWorldTick);

        // Entity load — detect burning coal items entering the world
        ServerEntityEvents.ENTITY_LOAD.register(ModEvents::onEntityLoad);

        // Player death — handle burning coal armor/tool on death
        ServerLivingEntityEvents.AFTER_DEATH.register(ModEvents::onLivingDeath);

        // Ghost spawn gating — check in entity load
        // (already handled in onEntityLoad)

        // Furnace fuel values for coal items
        registerFuelValues();

        // FNI right-click fire
        UseBlockCallback.EVENT.register(ModEvents::onUseBlock);

        // Item tooltips (client-only)
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            registerClientTooltips();
        }

        // Damage events — offensive tool hits + defensive armor effects
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(ModEvents::onAllowDamage);
        AttackEntityCallback.EVENT.register(ModEvents::onAttackEntity);
    }

    // -----------------------------------------------------------------------
    // Per-player tick
    // -----------------------------------------------------------------------

    private static void onPlayerTick(class_1657 player) {
        if (player == null || player.method_7325()) return;

        if (Config.overpowerEnabled && Config.opToolEffectsEnabled) {
            handleOpToolEffects(player, player.method_6047());
            handleOpToolEffects(player, player.method_6079());
        }
        // Note: OP armor aura particles are handled client-side in UsefultoolsModClient

        if (!player.method_37908().method_8608()) {
            if (Config.coalEnabled && Config.coalFireEffects) {
                handleCoalToolBurning(player);
                handleCoalArmorBurning(player);
            }
            if (Config.snowEnabled && Config.snowMeltEffects) {
                handleSnowMelt(player);
                handleSnowFireProtection(player);
            }
            if (Config.iceEnabled && Config.iceEffects) {
                handleIceMelt(player);
                handleIceFireProtection(player);
            }
            if (Config.pprismEnabled && Config.pprismWaterEffects) {
                handlePprismWaterEffects(player);
            }
            if (Config.fniEnabled && Config.fniFireEffects) {
                handleFniBootsFire(player);
                handleFniArmorBonus(player);
            }
            if (Config.ectoplasmSetEnabled && Config.ectoplasmWallPhasing) {
                handleEctoWallPhasing(player);
            }
            if (Config.spectralInfuserEnabled && Config.infusedToolEffects) {
                handleInfusedToolEffects(player);
            }
            if (Config.foodHungerDrain) {
                handleFoodHungerDrain(player);
            }
            if (Config.cakeEnabled && Config.cakeArmorEffects) {
                handleCakeArmorEffects(player);
            }
            // Food set armor effects
            if (Config.breadEnabled && Config.breadArmorEffects) handleBreadArmorEffects(player);
            if (Config.driedKelpEnabled && Config.driedKelpArmorEffects) handleDriedKelpArmorEffects(player);
            if (Config.rottenFleshEnabled && Config.rottenFleshArmorEffects) handleRottenFleshArmorEffects(player);
            if (Config.melonEnabled && Config.melonArmorEffects) handleMelonArmorEffects(player);
            if (Config.sweetBerryEnabled && Config.sweetBerryArmorEffects) handleSweetBerryArmorEffects(player);
            if (Config.pumpkinPieEnabled && Config.pumpkinPieArmorEffects) handlePumpkinPieArmorEffects(player);
            if (Config.mushroomEnabled && Config.mushroomArmorEffects) handleMushroomArmorEffects(player);
            if (Config.pufferfishEnabled && Config.pufferfishArmorEffects) handlePufferfishArmorEffects(player);
            if (Config.honeyEnabled && Config.honeyArmorEffects) handleHoneyArmorEffects(player);
            if (Config.chorusFruitEnabled && Config.chorusFruitArmorEffects) handleChorusFruitArmorEffects(player);
            if (Config.goldenAppleEnabled && Config.goldenAppleArmorEffects) handleGoldenAppleArmorEffects(player);
            // Vanilla material set effects
            if (Config.paperEnabled && Config.paperEffects) handlePaperPassive(player);
            if (Config.featherEnabled && Config.featherEffects) handleFeatherPassive(player);
            if (Config.spongeEnabled && Config.spongeEffects) handleSpongePassive(player);
            if (Config.netherWartEnabled && Config.netherWartEffects) handleNetherWartPassive(player);
            if (Config.rabbitHideEnabled && Config.rabbitHideEffects) handleRabbitHideArmor(player);
            if (Config.cactusEnabled && Config.cactusEffects) handleCactusAura(player);
            if (Config.boneEnabled && Config.boneEffects) handleBoneArmor(player);
            if (Config.clayEnabled && Config.clayEffects) handleClayArmor(player);
            if (Config.netherBrickEnabled && Config.netherBrickEffects) handleNetherBrickArmor(player);
            if (Config.copperEnabled && Config.copperEffects) handleCopperArmor(player);
            if (Config.phantomEnabled && Config.phantomEffects) handlePhantomEffects(player);
            if (Config.magmaCreamEnabled && Config.magmaCreamEffects) handleMagmaCreamArmor(player);
            if (Config.slimeEnabled && Config.slimeEffects) handleSlimeEffects(player);
            if (Config.blazeEnabled && Config.blazeEffects) handleBlazeArmor(player);
            if (Config.nautilusEnabled && Config.nautilusEffects) handleNautilusEffects(player);
            if (Config.purpurEnabled && Config.purpurEffects) handlePurpurEffects(player);
            if (Config.ghastTearEnabled && Config.ghastTearEffects) handleGhastTearEffects(player);
            if (Config.eyeOfEnderEnabled && Config.eyeOfEnderEffects) handleEyeOfEnderEffects(player);
            if (Config.shulkerEnabled && Config.shulkerEffects) handleShulkerEffects(player);
            if (Config.turtleScuteEnabled && Config.turtleScuteEffects) handleTurtleScuteArmor(player);
            if (Config.echoShardEnabled && Config.echoShardEffects) handleEchoShardEffects(player);
            if (Config.dragonBreathEnabled && Config.dragonBreathEffects) handleDragonBreathEffects(player);
        }
    }

    // -----------------------------------------------------------------------
    // World tick — processes burning coal items lying on the ground
    // -----------------------------------------------------------------------

    private static void onWorldTick(class_3218 serverWorld) {
        if (BURNING_DROPPED_ITEMS.isEmpty()) return;

        net.minecraft.class_5321<class_1937> thisDim = serverWorld.method_27983();

        BURNING_DROPPED_ITEMS.entrySet().removeIf(entry -> {
            // Only process entries that belong to this dimension this tick
            if (!entry.getValue().equals(thisDim)) return false;

            class_1297 entity = serverWorld.method_14190(entry.getKey());
            if (entity == null) return false;          // chunk unloaded — keep tracking
            if (!(entity instanceof class_1542 itemEntity) || !itemEntity.method_5805()) return true;

            class_1799 item = itemEntity.method_6983();
            if (!(isCoalTool(item) || isCoalArmor(item)) || !CoalBurningHelper.isBurning(item)) return true;

            // Water extinguishes the item
            if (itemEntity.method_5799()) {
                CoalBurningHelper.setBurning(item, false);
                return true;
            }

            // Durability drain once per second
            if (serverWorld.method_8510() % 20 == 0) {
                int newDmg = item.method_7919() + 2;
                if (newDmg >= item.method_7936()) {
                    itemEntity.method_31472();
                    return true;
                }
                item.method_7974(newDmg);
            }

            // Smoke particles from the burning item on the ground
            if (serverWorld.method_8510() % 5 == 0) {
                serverWorld.method_14199(class_2398.field_11251,
                        itemEntity.method_23317(), itemEntity.method_23318() + 0.3, itemEntity.method_23321(),
                        1, 0.1, 0.1, 0.1, 0.01);
            }

            return false;
        });
    }

    // -----------------------------------------------------------------------
    // Detect burning coal items entering the world (drops, throws, chunk loads)
    // + Ghost spawn gating
    // -----------------------------------------------------------------------

    private static void onEntityLoad(class_1297 entity, class_3218 serverWorld) {
        // Burning coal items on the ground
        if (entity instanceof class_1542 itemEntity) {
            class_1799 item = itemEntity.method_6983();
            if ((isCoalTool(item) || isCoalArmor(item)) && CoalBurningHelper.isBurning(item)) {
                BURNING_DROPPED_ITEMS.put(itemEntity.method_5667(), serverWorld.method_27983());
            }
        }

        // Ghost spawn gating
        if (entity instanceof GhostEntity) {
            if (!Config.ghostEnabled
                    || serverWorld.field_9229.method_43058() > Config.ghostSpawnChance) {
                entity.method_31472();
            }
        }
    }

    // -----------------------------------------------------------------------
    // Player death — handle burning coal armor/tool on death
    // -----------------------------------------------------------------------

    private static void onLivingDeath(class_1309 entity, class_1282 source) {
        if (!(entity instanceof class_1657 player)) return;
        if (player.method_37908().method_8608()) return;

        UUID uuid = player.method_5667();
        boolean keepInventory = player.method_37908().method_8450().method_8355(class_1928.field_19389);

        // --- Burning armor ---
        if (COAL_ARMOR_BURNING.contains(uuid)) {
            COAL_ARMOR_BURNING.remove(uuid);
            if (keepInventory) {
                clearArmorBurning(player);
            }
        }

        // --- Burning tool ---
        if (COAL_TOOL_BURNING.contains(uuid)) {
            COAL_TOOL_BURNING.remove(uuid);
            if (keepInventory) {
                clearBurningIfCoalTool(player.method_6047());
                clearBurningIfCoalTool(player.method_6079());
            }
        }
    }

    // -----------------------------------------------------------------------
    // OP Tool effects
    // -----------------------------------------------------------------------

    private static void handleOpToolEffects(class_1657 player, class_1799 held) {
        if (held.method_7960()) return;

        if (held.method_31574(ModItems.OVERPOWER_SWORD)) {
            applyEffects(player,
                    new class_1293(class_1294.field_5910, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5904, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5913, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5907, 10, 3, false, false, false));
        } else if (held.method_31574(ModItems.OVERPOWER_PICKAXE)) {
            applyEffects(player,
                    new class_1293(class_1294.field_5917, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5910, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5913, 10, 10, false, false, false));
        } else if (held.method_31574(ModItems.OVERPOWER_SHOVEL)) {
            applyEffects(player,
                    new class_1293(class_1294.field_5917, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5910, 10, 1, false, false, false),
                    new class_1293(class_1294.field_5913, 10, 5, false, false, false));
        } else if (held.method_31574(ModItems.OVERPOWER_AXE)) {
            applyEffects(player,
                    new class_1293(class_1294.field_5924, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5910, 10, 3, false, false, false),
                    new class_1293(class_1294.field_5913, 10, 10, false, false, false));
        }
    }

    // -----------------------------------------------------------------------
    // Coal tool burning (held by a player)
    // -----------------------------------------------------------------------

    private static void handleCoalToolBurning(class_1657 player) {

        UUID uuid = player.method_5667();
        class_1799 main = player.method_6047();
        class_1799 off = player.method_6079();

        // Coal armor held in hand behaves identically to a burning coal tool
        boolean mainIsCoal = isCoalTool(main) || isCoalArmor(main);
        boolean offIsCoal = isCoalTool(off) || isCoalArmor(off);
        boolean mainBurning = mainIsCoal && CoalBurningHelper.isBurning(main);
        boolean offBurning = offIsCoal && CoalBurningHelper.isBurning(off);

        // Water extinguishes any burning coal item in hand
        if (player.method_5799()) {
            if (mainIsCoal) CoalBurningHelper.setBurning(main, false);
            if (offIsCoal) CoalBurningHelper.setBurning(off, false);
            COAL_TOOL_BURNING.remove(uuid);
            return;
        }

        // Ignite: player catches fire while holding an unlit coal item
        if (player.method_5809()) {
            boolean justIgnitedTool = false;
            if (mainIsCoal && !CoalBurningHelper.isBurning(main)) {
                CoalBurningHelper.setBurning(main, true);
                mainBurning = true;
                if (isCoalTool(main)) justIgnitedTool = true;
            }
            if (offIsCoal && !CoalBurningHelper.isBurning(off)) {
                CoalBurningHelper.setBurning(off, true);
                offBurning = true;
                if (isCoalTool(off)) justIgnitedTool = true;
            }
            if (mainIsCoal || offIsCoal) COAL_TOOL_BURNING.add(uuid);
            // Advancement trigger fires only when a coal tool (not armor) first ignites
            if (justIgnitedTool && player instanceof class_3222 sp) {
                ModTriggers.COAL_TOOL_IGNITED.trigger(sp);
            }
        }

        // Re-register if player picked up an already-burning coal item
        if ((mainBurning || offBurning) && !COAL_TOOL_BURNING.contains(uuid)) {
            COAL_TOOL_BURNING.add(uuid);
        }

        // No burning coal item in hand — clear held effects
        if (!mainBurning && !offBurning) {
            COAL_TOOL_BURNING.remove(uuid);
            return;
        }

        if (!COAL_TOOL_BURNING.contains(uuid)) return;

        // Once per second: damage player and drain item durability
        if (player.field_6012 % 20 == 0) {
            player.method_5643(player.method_48923().method_48794(), 0.5f);

            if (mainBurning) {
                main.method_7956(2, player, (p) -> p.method_20235(class_1304.field_6173));
                if (main.method_7960() && !offBurning) {
                    COAL_TOOL_BURNING.remove(uuid);
                    return;
                }
            }
            if (offBurning) {
                off.method_7956(2, player, (p) -> p.method_20235(class_1304.field_6171));
                if (off.method_7960() && !mainBurning) {
                    COAL_TOOL_BURNING.remove(uuid);
                    return;
                }
            }
        }

        // Smoke particles from the held burning item
        if (player.field_6012 % 4 == 0 && player.method_37908() instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11251,
                    player.method_23317(), player.method_23318() + 1.2, player.method_23321(),
                    1, 0.15, 0.1, 0.15, 0.01);
        }
    }

    // -----------------------------------------------------------------------
    // Coal armor burning (worn by a player)
    // -----------------------------------------------------------------------

    private static final class_1304[] ARMOR_SLOTS = {
            class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166
    };

    private static void handleCoalArmorBurning(class_1657 player) {
        UUID uuid = player.method_5667();

        // Water extinguishes worn armor burning
        if (player.method_5799()) {
            if (COAL_ARMOR_BURNING.contains(uuid)) {
                COAL_ARMOR_BURNING.remove(uuid);
                clearArmorBurning(player);
            }
            return;
        }

        // Ignite: player catches fire while wearing coal armor
        if (player.method_5809() && isWearingAnyCoalArmor(player) && !COAL_ARMOR_BURNING.contains(uuid)) {
            COAL_ARMOR_BURNING.add(uuid);
            for (class_1304 slot : ARMOR_SLOTS) {
                class_1799 piece = player.method_6118(slot);
                if (isCoalArmor(piece)) CoalBurningHelper.setBurning(piece, true);
            }
        }

        if (!COAL_ARMOR_BURNING.contains(uuid)) return;

        // Stop if no burning coal armor is worn anymore
        if (!isWearingAnyBurningCoalArmor(player)) {
            COAL_ARMOR_BURNING.remove(uuid);
            return;
        }

        // Keep player on fire while wearing burning coal armor
        if (player.method_20802() < 40) {
            player.method_20803(100);
        }

        // Damage player and drain durability once per second
        if (player.field_6012 % 20 == 0) {
            player.method_5643(player.method_48923().method_48794(), 0.5f);
            for (class_1304 slot : ARMOR_SLOTS) {
                class_1799 piece = player.method_6118(slot);
                if (isCoalArmor(piece) && CoalBurningHelper.isBurning(piece)) {
                    piece.method_7956(1, player, (p) -> p.method_20235(slot));
                }
            }
        }

        // Smoke particles
        if (player.field_6012 % 3 == 0 && player.method_37908() instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11251,
                    player.method_23317(), player.method_23318() + 1.5, player.method_23321(),
                    3, 0.3, 0.3, 0.3, 0.01);
        }
    }

    // -----------------------------------------------------------------------
    // Furnace fuel values for coal items
    // -----------------------------------------------------------------------

    private static void registerFuelValues() {
        FuelRegistry.INSTANCE.add(ModItems.COAL_DUST, 200);
        FuelRegistry.INSTANCE.add(ModItems.HARDENED_COAL, 400);
        FuelRegistry.INSTANCE.add(ModItems.COAL_SWORD, 800);
        FuelRegistry.INSTANCE.add(ModItems.COAL_PICKAXE, 1200);
        FuelRegistry.INSTANCE.add(ModItems.COAL_SHOVEL, 400);
        FuelRegistry.INSTANCE.add(ModItems.COAL_AXE, 1200);
        FuelRegistry.INSTANCE.add(ModItems.COAL_HOE, 800);
        FuelRegistry.INSTANCE.add(ModItems.COAL_HELMET, 2000);
        FuelRegistry.INSTANCE.add(ModItems.COAL_CHESTPLATE, 3200);
        FuelRegistry.INSTANCE.add(ModItems.COAL_LEGGINGS, 2800);
        FuelRegistry.INSTANCE.add(ModItems.COAL_BOOTS, 1600);
    }

    // -----------------------------------------------------------------------
    // Snow melt mechanics
    // -----------------------------------------------------------------------

    private static void handleSnowMelt(class_1657 player) {
        if (!(player.method_37908() instanceof class_3218 serverWorld)) return;

        // Snow tools melt every 40 ticks when held
        if (player.field_6012 % 40 == 0) {
            class_1799 main = player.method_6047();
            class_1799 off = player.method_6079();
            boolean melted = false;
            if (isSnowTool(main)) { main.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6173)); melted = true; }
            if (isSnowTool(off)) { off.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6171)); melted = true; }
            if (melted) spawnMeltParticles(player, serverWorld);
        }
    }

    // -----------------------------------------------------------------------
    // Snow fire protection — absorbs fire at heavy durability cost
    // -----------------------------------------------------------------------

    private static void handleSnowFireProtection(class_1657 player) {
        if (!(player.method_37908() instanceof class_3218 serverWorld)) return;
        if (!player.method_5809()) return;

        class_1799 main = player.method_6047();
        class_1799 off = player.method_6079();

        boolean hasProtector = isSnowTool(main) || isSnowTool(off);
        if (!hasProtector) return;

        player.method_5646();

        if (player.field_6012 % 20 == 0) {
            if (isSnowTool(main)) main.method_7956(5, player, (p) -> p.method_20235(class_1304.field_6173));
            if (isSnowTool(off)) off.method_7956(5, player, (p) -> p.method_20235(class_1304.field_6171));
        }

        if (player.field_6012 % 8 == 0) {
            serverWorld.method_14199(class_2398.field_18306,
                    player.method_23317(), player.method_23318() + 1.0, player.method_23321(),
                    6, 0.4, 0.4, 0.4, 0.05);
        }
    }

    // -----------------------------------------------------------------------
    // Ice melt mechanics
    // -----------------------------------------------------------------------

    private static void handleIceMelt(class_1657 player) {
        if (!(player.method_37908() instanceof class_3218 serverWorld)) return;

        // Ice tools + armor melt every 60 ticks
        if (player.field_6012 % 60 == 0) {
            class_1799 main = player.method_6047();
            class_1799 off = player.method_6079();
            boolean melted = false;
            if (isIceTool(main)) { main.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6173)); melted = true; }
            if (isIceTool(off)) { off.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6171)); melted = true; }

            for (class_1304 slot : ARMOR_SLOTS) {
                class_1799 piece = player.method_6118(slot);
                if (isIceArmor(piece)) {
                    piece.method_7956(1, player, (p) -> p.method_20235(slot));
                    melted = true;
                    // On break: 10% chance to place a water source at the player's feet
                    if (piece.method_7960() && serverWorld.field_9229.method_43057() < 0.1f) {
                        class_2338 feet = player.method_24515();
                        if (serverWorld.method_8320(feet).method_26215()) {
                            serverWorld.method_8652(feet, class_2246.field_10382.method_9564(), 3);
                        }
                    }
                }
            }
            if (melted) spawnMeltParticles(player, serverWorld);
        }
    }

    private static void spawnMeltParticles(class_1657 player, class_3218 world) {
        world.method_14199(class_2398.field_18306,
                player.method_23317(), player.method_23318() + 1.2, player.method_23321(),
                4, 0.3, 0.3, 0.3, 0.02);
    }

    // -----------------------------------------------------------------------
    // Ice fire protection — absorbs fire at heavy durability cost
    // -----------------------------------------------------------------------

    private static void handleIceFireProtection(class_1657 player) {
        if (!(player.method_37908() instanceof class_3218 serverWorld)) return;
        if (!player.method_5809()) return;

        class_1799 main = player.method_6047();
        class_1799 off = player.method_6079();

        boolean hasProtector = isIceTool(main) || isIceTool(off);
        if (!hasProtector) {
            for (class_1304 slot : ARMOR_SLOTS) {
                if (isIceArmor(player.method_6118(slot))) { hasProtector = true; break; }
            }
        }
        if (!hasProtector) return;

        player.method_5646();

        if (player.field_6012 % 20 == 0) {
            if (isIceTool(main)) main.method_7956(5, player, (p) -> p.method_20235(class_1304.field_6173));
            if (isIceTool(off)) off.method_7956(5, player, (p) -> p.method_20235(class_1304.field_6171));
            for (class_1304 slot : ARMOR_SLOTS) {
                class_1799 piece = player.method_6118(slot);
                if (isIceArmor(piece)) piece.method_7956(5, player, (p) -> p.method_20235(slot));
            }
        }

        if (player.field_6012 % 8 == 0) {
            serverWorld.method_14199(class_2398.field_18306,
                    player.method_23317(), player.method_23318() + 1.0, player.method_23321(),
                    6, 0.4, 0.4, 0.4, 0.05);
        }
    }

    // -----------------------------------------------------------------------
    // Polished Prismarine water benefits
    // -----------------------------------------------------------------------

    private static void handlePprismWaterEffects(class_1657 player) {
        if (!player.method_5799()) return;

        // Pprism tool in hand -> Haste I (cancels underwater mining penalty)
        if (isPprismTool(player.method_6047()) || isPprismTool(player.method_6079())) {
            player.method_6092(new class_1293(class_1294.field_5917, 60, 0, false, false, false));
        }

        // Per-slot armor benefits while in water
        // Helmet -> Water Breathing
        if (isPprismArmor(player.method_6118(class_1304.field_6169))) {
            player.method_6092(new class_1293(class_1294.field_5923, 60, 0, false, false, false));
        }
        // Chestplate -> Resistance I (ocean's protective pressure)
        if (isPprismArmor(player.method_6118(class_1304.field_6174))) {
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, false));
        }
        // Leggings -> Haste I (removes underwater mining penalty)
        if (isPprismArmor(player.method_6118(class_1304.field_6172))) {
            player.method_6092(new class_1293(class_1294.field_5917, 60, 0, false, false, false));
        }
        // Boots -> Slow Falling (buoyancy — rise through water effortlessly)
        if (isPprismArmor(player.method_6118(class_1304.field_6166))) {
            player.method_6092(new class_1293(class_1294.field_5906, 60, 0, false, false, false));
        }

        // Full 4-piece -> Dolphins Grace
        boolean fullSet = isPprismArmor(player.method_6118(class_1304.field_6169))
                && isPprismArmor(player.method_6118(class_1304.field_6174))
                && isPprismArmor(player.method_6118(class_1304.field_6172))
                && isPprismArmor(player.method_6118(class_1304.field_6166));
        if (fullSet) {
            player.method_6092(new class_1293(class_1294.field_5900, 60, 0, false, false, false));
        }
    }

    // -----------------------------------------------------------------------
    // FNI fire mechanics
    // -----------------------------------------------------------------------

    /**
     * Sneak + right-click a block while holding any Flint-Iron tool in the main hand
     * to start a fire on the clicked face (identical behaviour to vanilla Flint and Steel).
     * Consumes 1 durability per use.
     */
    private static class_1269 onUseBlock(class_1657 player, class_1937 world, class_1268 hand,
                                            net.minecraft.class_3965 hitResult) {
        if (!Config.fniEnabled || !Config.fniFireEffects) return class_1269.field_5811;
        if (!player.method_5715()) return class_1269.field_5811;
        if (hand != class_1268.field_5808) return class_1269.field_5811;

        class_1799 held = player.method_6047();
        if (!isFniTool(held)) return class_1269.field_5811;

        if (world.method_8608()) return class_1269.field_5811;

        class_2338 clickedPos = hitResult.method_17777();
        class_2350 face = hitResult.method_17780();

        class_2338 firePos = clickedPos.method_10093(face);
        class_2680 target = world.method_8320(firePos);
        if (target.method_26215() || target.method_45474()) {
            world.method_8652(firePos, class_4770.method_24416(world, firePos), 11);
            world.method_8396(null, firePos, class_3417.field_15145,
                    class_3419.field_15245, 1.0f, world.field_9229.method_43057() * 0.4f + 0.8f);
            held.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6173));
            return class_1269.field_5812;
        }
        return class_1269.field_5811;
    }

    /**
     * FNI boots: small chance (4% per 10 ticks) to ignite flammable blocks underfoot.
     * Fire appears beside the player to avoid immediately burning them.
     */
    private static void handleFniBootsFire(class_1657 player) {
        if (!player.method_6118(class_1304.field_6166).method_31574(ModItems.FNI_BOOTS)) return;
        if (player.field_6012 % 10 != 0) return;
        if (!player.method_24828()) return;

        class_1937 world = player.method_37908();
        class_2338 feetPos = player.method_24515();
        class_2680 floorState = world.method_8320(feetPos.method_10074());

        if (((class_2358) class_2246.field_10036).method_10191(floorState) > 0
                && world.field_9229.method_43057() < 0.04f) {
            class_2350[] dirs = {class_2350.field_11043, class_2350.field_11035, class_2350.field_11034, class_2350.field_11039};
            class_2350 randDir = dirs[world.field_9229.method_43048(4)];
            class_2338 firePos = feetPos.method_10093(randDir);
            if (world.method_8320(firePos).method_26215()) {
                world.method_8652(firePos, class_4770.method_24416(world, firePos), 11);
            }
        }
    }

    /**
     * Full FNI set bonus: drains fire ticks one extra per tick on top of vanilla's own
     * decrement, cutting effective burn duration roughly in half.
     */
    private static void handleFniArmorBonus(class_1657 player) {
        if (!isWearingFullFniArmor(player)) return;
        int fireTicks = player.method_20802();
        if (fireTicks > 0) {
            player.method_20803(fireTicks - 1);
        }
    }

    private static boolean isWearingFullFniArmor(class_1657 player) {
        return player.method_6118(class_1304.field_6169).method_31574(ModItems.FNI_HELMET)
            && player.method_6118(class_1304.field_6174).method_31574(ModItems.FNI_CHESTPLATE)
            && player.method_6118(class_1304.field_6172).method_31574(ModItems.FNI_LEGGINGS)
            && player.method_6118(class_1304.field_6166).method_31574(ModItems.FNI_BOOTS);
    }

    // -----------------------------------------------------------------------
    // Item tooltips (client-only registration)
    // -----------------------------------------------------------------------

    private static void registerClientTooltips() {
        net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback.EVENT.register(ModEvents::onItemTooltip);
    }

    private static void onItemTooltip(class_1799 stack, net.minecraft.class_1836 context,
                                       List<class_2561> tips) {
        // --- Ectoplasm-infused items ---
        if (EctoplasmInfusionHelper.isInfused(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.ectoplasm_infused")
                    .method_27692(class_124.field_1062));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.ecto_can_damage_ghosts")
                    .method_27692(class_124.field_1080));
            if (stack.method_7909() instanceof class_1810) {
                tips.add(class_2561.method_43471("tooltip.usefultoolsmod.spectral_sight")
                        .method_27692(class_124.field_1080));
            } else if (stack.method_7909() instanceof class_1821) {
                tips.add(class_2561.method_43471("tooltip.usefultoolsmod.spectral_efficiency")
                        .method_27692(class_124.field_1080));
            } else if (stack.method_7909() instanceof class_1794) {
                tips.add(class_2561.method_43471("tooltip.usefultoolsmod.spectral_fortune")
                        .method_27692(class_124.field_1080));
            }
        }

        // --- Coal tools / armor ---
        if (isCoalTool(stack) || isCoalArmor(stack)) {
            if (CoalBurningHelper.isBurning(stack)) {
                tips.add(class_2561.method_43471("tooltip.usefultoolsmod.burning")
                        .method_27692(class_124.field_1061));
                double drainPerSecond = isCoalTool(stack) ? 2.0 : 1.0;
                addTimeRemaining(tips, stack, drainPerSecond);
            } else {
                tips.add(class_2561.method_43471("tooltip.usefultoolsmod.flammable")
                        .method_27692(class_124.field_1065));
            }
        }

        // --- Snow tools ---
        if (isSnowTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.melts_when_held")
                    .method_27692(class_124.field_1075));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.fire_protection")
                    .method_27692(class_124.field_1080));
            addTimeRemaining(tips, stack, 0.5);
        }

        // --- Ice tools ---
        if (isIceTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.melts_when_held")
                    .method_27692(class_124.field_1075));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.fire_protection")
                    .method_27692(class_124.field_1080));
            addTimeRemaining(tips, stack, 1.0 / 3.0);
        }

        // --- Ice armor ---
        if (isIceArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.melts_when_worn")
                    .method_27692(class_124.field_1075));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.ice_armor_fire_prot")
                    .method_27692(class_124.field_1080));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.ice_armor_water")
                    .method_27692(class_124.field_1080));
            addTimeRemaining(tips, stack, 1.0 / 3.0);
        }

        // --- OP tools ---
        if (isOpTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.op_header")
                    .method_27692(class_124.field_1076));
            String key = stack.method_31574(ModItems.OVERPOWER_SWORD) ? "op_sword"
                    : stack.method_31574(ModItems.OVERPOWER_PICKAXE) ? "op_pickaxe"
                    : stack.method_31574(ModItems.OVERPOWER_SHOVEL) ? "op_shovel" : "op_axe";
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod." + key)
                    .method_27692(class_124.field_1080));
        }

        // --- OP armor ---
        if (isOpArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.op_header")
                    .method_27692(class_124.field_1076));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.op_armor")
                    .method_27692(class_124.field_1080));
        }

        // --- Polished Prismarine tools ---
        if (isPprismTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.pprism_header")
                    .method_27692(class_124.field_1062));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.pprism_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Polished Prismarine armor ---
        if (isPprismArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.pprism_header")
                    .method_27692(class_124.field_1062));
            addArmorSlotTooltip(tips, stack, "pprism");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.pprism_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- FNI tools ---
        if (isFniTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.fni_header")
                    .method_27692(class_124.field_1065));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.fni_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- FNI armor ---
        if (isFniArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.fni_header")
                    .method_27692(class_124.field_1065));
            if (stack.method_7909() instanceof class_1738 a) {
                if (a.method_7685() == class_1304.field_6166) {
                    tips.add(class_2561.method_43471("tooltip.usefultoolsmod.fni_boots")
                            .method_27692(class_124.field_1080));
                }
            }
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.fni_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Ecto armor ---
        if (isEctoArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.ecto_header")
                    .method_27692(class_124.field_1062));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.ecto_ghost_avoid")
                    .method_27692(class_124.field_1080));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.ecto_wall_phase")
                    .method_27692(class_124.field_1077));
        }

        // --- Cake armor ---
        if (isCakeArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.cake_header")
                    .method_27692(class_124.field_1076));
            addArmorSlotTooltip(tips, stack, "cake");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.cake_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Food tools (on-hit effects) ---
        addFoodToolTooltip(tips, stack);

        // --- Food armor (per-slot + full set) ---
        addFoodArmorTooltip(tips, stack);

        // --- All food tools/armor: edible + hunger drain ---
        if ((isFoodTool(stack) || isFoodArmor(stack)) && stack.method_7963()) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.food_edible")
                    .method_27692(class_124.field_1060));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.food_hunger_drain")
                    .method_27692(class_124.field_1080));
        }

        // --- Grenade ---
        if (stack.method_31574(ModItems.GRENADE)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.grenade_throw")
                    .method_27692(class_124.field_1061));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.grenade_radius")
                    .method_27692(class_124.field_1080));
        }

        // --- Dynamite ---
        if (stack.method_31574(ModItems.DYNAMITE)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.dynamite_use")
                    .method_27692(class_124.field_1079));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.dynamite_radius")
                    .method_27692(class_124.field_1080));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.dynamite_warning")
                    .method_27692(class_124.field_1061));
        }

        // --- Paper tools ---
        if (isPaperTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.paper_header")
                    .method_27692(class_124.field_1068));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.paper_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Feather tools ---
        if (isFeatherTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.feather_header")
                    .method_27692(class_124.field_1068));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.feather_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Glass tools ---
        if (isGlassTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.glass_header")
                    .method_27692(class_124.field_1075));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.glass_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Sponge tools ---
        if (isSpongeTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.sponge_header")
                    .method_27692(class_124.field_1054));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.sponge_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Nether Wart tools ---
        if (isNetherWartTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.nether_wart_header")
                    .method_27692(class_124.field_1079));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.nether_wart_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Pointed Dripstone tools ---
        if (isDripstoneTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.dripstone_header")
                    .method_27692(class_124.field_1065));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.dripstone_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Rabbit Hide armor ---
        if (isRabbitHideArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.rabbit_hide_header")
                    .method_27692(class_124.field_1065));
            addArmorSlotTooltip(tips, stack, "rabbit_hide");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.rabbit_hide_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Cactus tools ---
        if (isCactusTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.cactus_header")
                    .method_27692(class_124.field_1060));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.cactus_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Cactus armor ---
        if (isCactusArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.cactus_header")
                    .method_27692(class_124.field_1060));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.cactus_armor")
                    .method_27692(class_124.field_1080));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.cactus_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Bone tools ---
        if (isBoneTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.bone_header")
                    .method_27692(class_124.field_1068));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.bone_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Bone armor ---
        if (isBoneArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.bone_header")
                    .method_27692(class_124.field_1068));
            addArmorSlotTooltip(tips, stack, "bone");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.bone_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Clay armor ---
        if (isClayArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.clay_header")
                    .method_27692(class_124.field_1065));
            addArmorSlotTooltip(tips, stack, "clay");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.clay_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Nether Brick tools ---
        if (isNetherBrickTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.nether_brick_header")
                    .method_27692(class_124.field_1079));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.nether_brick_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Nether Brick armor ---
        if (isNetherBrickArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.nether_brick_header")
                    .method_27692(class_124.field_1079));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.nether_brick_armor")
                    .method_27692(class_124.field_1080));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.nether_brick_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Copper armor ---
        if (isCopperArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.copper_header")
                    .method_27692(class_124.field_1065));
            addArmorSlotTooltip(tips, stack, "copper");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.copper_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Phantom tools ---
        if (isPhantomTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.phantom_header")
                    .method_27692(class_124.field_1080));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.phantom_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Phantom armor ---
        if (isPhantomArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.phantom_header")
                    .method_27692(class_124.field_1080));
            addArmorSlotTooltip(tips, stack, "phantom");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.phantom_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Magma Cream tools ---
        if (isMagmaCreamTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.magma_cream_header")
                    .method_27692(class_124.field_1061));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.magma_cream_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Magma Cream armor ---
        if (isMagmaCreamArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.magma_cream_header")
                    .method_27692(class_124.field_1061));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.magma_cream_armor")
                    .method_27692(class_124.field_1080));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.magma_cream_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Slime tools ---
        if (isSlimeTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.slime_header")
                    .method_27692(class_124.field_1060));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.slime_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Slime armor ---
        if (isSlimeArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.slime_header")
                    .method_27692(class_124.field_1060));
            addArmorSlotTooltip(tips, stack, "slime");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.slime_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Blaze tools ---
        if (isBlazeTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.blaze_header")
                    .method_27692(class_124.field_1065));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.blaze_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Blaze armor ---
        if (isBlazeArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.blaze_header")
                    .method_27692(class_124.field_1065));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.blaze_armor")
                    .method_27692(class_124.field_1080));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.blaze_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Nautilus tools ---
        if (isNautilusTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.nautilus_header")
                    .method_27692(class_124.field_1062));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.nautilus_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Nautilus armor ---
        if (isNautilusArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.nautilus_header")
                    .method_27692(class_124.field_1062));
            addArmorSlotTooltip(tips, stack, "nautilus");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.nautilus_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Purpur tools ---
        if (isPurpurTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.purpur_header")
                    .method_27692(class_124.field_1076));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.purpur_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Purpur armor ---
        if (isPurpurArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.purpur_header")
                    .method_27692(class_124.field_1076));
            addArmorSlotTooltip(tips, stack, "purpur");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.purpur_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Ghast Tear tools ---
        if (isGhastTearTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.ghast_tear_header")
                    .method_27692(class_124.field_1068));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.ghast_tear_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Ghast Tear armor ---
        if (isGhastTearArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.ghast_tear_header")
                    .method_27692(class_124.field_1068));
            addArmorSlotTooltip(tips, stack, "ghast_tear");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.ghast_tear_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Eye of Ender tools ---
        if (isEyeOfEnderTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.eye_of_ender_header")
                    .method_27692(class_124.field_1060));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.eye_of_ender_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Eye of Ender armor ---
        if (isEyeOfEnderArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.eye_of_ender_header")
                    .method_27692(class_124.field_1060));
            addArmorSlotTooltip(tips, stack, "eye_of_ender");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.eye_of_ender_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Shulker tools ---
        if (isShulkerTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.shulker_header")
                    .method_27692(class_124.field_1076));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.shulker_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Shulker armor ---
        if (isShulkerArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.shulker_header")
                    .method_27692(class_124.field_1076));
            addArmorSlotTooltip(tips, stack, "shulker");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.shulker_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Turtle Scute armor ---
        if (isTurtleScuteArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.turtle_scute_header")
                    .method_27692(class_124.field_1060));
            addArmorSlotTooltip(tips, stack, "turtle_scute");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.turtle_scute_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Echo Shard tools ---
        if (isEchoShardTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.echo_shard_header")
                    .method_27692(class_124.field_1062));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.echo_shard_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Echo Shard armor ---
        if (isEchoShardArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.echo_shard_header")
                    .method_27692(class_124.field_1062));
            addArmorSlotTooltip(tips, stack, "echo_shard");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.echo_shard_full_set")
                    .method_27692(class_124.field_1077));
        }

        // --- Dragon's Breath tools ---
        if (isDragonBreathTool(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.dragon_breath_header")
                    .method_27692(class_124.field_1064));
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.dragon_breath_tool")
                    .method_27692(class_124.field_1080));
        }

        // --- Dragon's Breath armor ---
        if (isDragonBreathArmor(stack)) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.dragon_breath_header")
                    .method_27692(class_124.field_1064));
            addArmorSlotTooltip(tips, stack, "dragon_breath");
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod.dragon_breath_full_set")
                    .method_27692(class_124.field_1077));
        }
    }

    private static void addArmorSlotTooltip(List<class_2561> tips, class_1799 stack, String prefix) {
        if (!(stack.method_7909() instanceof class_1738 armor)) return;
        String slot = switch (armor.method_7685()) {
            case field_6166 -> "boots";
            case field_6172 -> "leggings";
            case field_6174 -> "chestplate";
            case field_6169 -> "helmet";
            default -> null;
        };
        if (slot != null) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod." + prefix + "_" + slot)
                    .method_27692(class_124.field_1080));
        }
    }

    private static void addFoodToolTooltip(List<class_2561> tips, class_1799 stack) {
        String key = null;
        if (isHoneyTool(stack)) key = "honey_tool";
        else if (isPufferfishTool(stack)) key = "pufferfish_tool";
        else if (isSweetBerryTool(stack)) key = "sweet_berry_tool";
        else if (isRottenFleshTool(stack)) key = "rotten_flesh_tool";
        else if (isMushroomTool(stack)) key = "mushroom_tool";
        else if (isChorusFruitTool(stack)) key = "chorus_fruit_tool";
        if (key != null) {
            tips.add(class_2561.method_43471("tooltip.usefultoolsmod." + key)
                    .method_27692(class_124.field_1080));
        }
    }

    private static void addFoodArmorTooltip(List<class_2561> tips, class_1799 stack) {
        String prefix = null;
        class_124 color = class_124.field_1054;
        if (isBreadArmor(stack)) prefix = "bread";
        else if (isDriedKelpArmor(stack)) { prefix = "dried_kelp"; color = class_124.field_1060; }
        else if (isRottenFleshArmor(stack)) { prefix = "rotten_flesh"; color = class_124.field_1079; }
        else if (isMelonArmor(stack)) { prefix = "melon"; color = class_124.field_1060; }
        else if (isSweetBerryArmor(stack)) { prefix = "sweet_berry"; color = class_124.field_1061; }
        else if (isPumpkinPieArmor(stack)) { prefix = "pumpkin_pie"; color = class_124.field_1065; }
        else if (isMushroomArmor(stack)) { prefix = "mushroom"; color = class_124.field_1061; }
        else if (isPufferfishArmor(stack)) { prefix = "pufferfish"; color = class_124.field_1054; }
        else if (isHoneyArmor(stack)) { prefix = "honey"; color = class_124.field_1065; }
        else if (isChorusFruitArmor(stack)) { prefix = "chorus_fruit"; color = class_124.field_1076; }
        else if (isGoldenAppleArmor(stack)) { prefix = "golden_apple"; color = class_124.field_1065; }
        if (prefix == null) return;

        addArmorSlotTooltip(tips, stack, prefix);
        tips.add(class_2561.method_43471("tooltip.usefultoolsmod." + prefix + "_full_set")
                .method_27692(class_124.field_1077));
    }

    private static void addTimeRemaining(List<class_2561> tips, class_1799 stack, double drainPerSecond) {
        if (!stack.method_7963()) return;
        int remaining = stack.method_7936() - stack.method_7919();
        int totalSeconds = (int) Math.ceil(remaining / drainPerSecond);
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;

        String time;
        if (minutes > 0) {
            time = minutes + "m " + seconds + "s";
        } else {
            time = seconds + "s";
        }

        tips.add(class_2561.method_43469("tooltip.usefultoolsmod.time_remaining", time)
                .method_27692(class_124.field_1080));
    }

    // -----------------------------------------------------------------------
    // Ectoplasm wall phasing
    // -----------------------------------------------------------------------

    /** Tracks which players are currently phasing through walls. */
    private static final Set<UUID> PHASING_PLAYERS = new HashSet<>();

    /** Cooldown to prevent spamming the phase teleport (ticks). */
    private static final Map<UUID, Integer> PHASE_COOLDOWNS = new HashMap<>();

    /**
     * Full ecto armor set allows the player to phase through walls <= 3 blocks thick.
     * Sneak while walking into a wall to teleport to the other side.
     */
    private static void handleEctoWallPhasing(class_1657 player) {
        boolean hasFullSet = hasFullEctoArmorSet(player);
        if (!hasFullSet || !player.method_5715()) return;

        UUID uuid = player.method_5667();
        int cooldown = PHASE_COOLDOWNS.getOrDefault(uuid, 0);
        if (cooldown > 0) {
            PHASE_COOLDOWNS.put(uuid, cooldown - 1);
            return;
        }

        class_1937 world = player.method_37908();
        class_2338 feetPos = player.method_24515();
        class_2350 dir = getHorizontalLookDirection(player);
        class_2338 ahead = feetPos.method_10093(dir);

        // Check if the player is pushing into a wall (block directly ahead is solid)
        if (!hasCollision(world, ahead) && !hasCollision(world, ahead.method_10084())) {
            return; // No wall ahead
        }

        // Measure wall thickness and find the exit position
        int thickness = 0;
        class_2338 exitPos = null;
        for (int i = 1; i <= 3; i++) {
            class_2338 check = feetPos.method_10079(dir, i);
            if (hasCollision(world, check) || hasCollision(world, check.method_10084())) {
                thickness++;
            } else {
                // Found open air — this is the exit
                // Also verify head clearance
                if (!hasCollision(world, check.method_10084())) {
                    exitPos = check;
                }
                break;
            }
        }

        if (exitPos == null || thickness == 0) return;

        // Teleport to the center of the exit block
        double tx = exitPos.method_10263() + 0.5;
        double ty = exitPos.method_10264();
        double tz = exitPos.method_10260() + 0.5;
        player.method_20620(tx, ty, tz);

        // Effects
        player.method_6092(new class_1293(class_1294.field_5909, 20, 0, false, false, true));

        if (world instanceof class_3218 serverWorld) {
            // Particles at entry
            serverWorld.method_14199(class_2398.field_22246,
                    player.field_6014, player.field_6036 + 1.0, player.field_5969,
                    8, 0.3, 0.5, 0.3, 0.02);
            // Particles at exit
            serverWorld.method_14199(class_2398.field_22246,
                    tx, ty + 1.0, tz,
                    8, 0.3, 0.5, 0.3, 0.02);
        }

        // Cooldown: 10 ticks (half second) before next phase
        PHASE_COOLDOWNS.put(uuid, 10);
    }

    /** Check if player is wearing full ecto armor set. */
    private static boolean hasFullEctoArmorSet(class_1657 player) {
        return isEctoArmor(player.method_6118(class_1304.field_6169))
            && isEctoArmor(player.method_6118(class_1304.field_6174))
            && isEctoArmor(player.method_6118(class_1304.field_6172))
            && isEctoArmor(player.method_6118(class_1304.field_6166));
    }

    private static class_2350 getHorizontalLookDirection(class_1657 player) {
        float yaw = player.method_36454();
        double dx = -Math.sin(Math.toRadians(yaw));
        double dz = Math.cos(Math.toRadians(yaw));
        if (Math.abs(dx) > Math.abs(dz)) {
            return dx > 0 ? class_2350.field_11034 : class_2350.field_11039;
        } else {
            return dz > 0 ? class_2350.field_11035 : class_2350.field_11043;
        }
    }

    private static boolean hasCollision(class_1937 world, class_2338 pos) {
        return !world.method_8320(pos).method_26220(world, pos).method_1110();
    }

    // -----------------------------------------------------------------------
    // Generalized food hunger drain (all food sets including cake)
    // -----------------------------------------------------------------------

    /** All food armor materials for hunger drain scanning. */
    private static List<class_1741> FOOD_ARMOR_MATERIALS;
    private static List<class_1741> getFoodArmorMaterials() {
        if (FOOD_ARMOR_MATERIALS == null) {
            FOOD_ARMOR_MATERIALS = List.of(
                    ModArmorMaterials.CAKE,
                    ModArmorMaterials.BREAD,
                    ModArmorMaterials.DRIED_KELP,
                    ModArmorMaterials.ROTTEN_FLESH,
                    ModArmorMaterials.MELON,
                    ModArmorMaterials.SWEET_BERRY,
                    ModArmorMaterials.PUMPKIN_PIE,
                    ModArmorMaterials.MUSHROOM,
                    ModArmorMaterials.PUFFERFISH,
                    ModArmorMaterials.HONEY,
                    ModArmorMaterials.CHORUS_FRUIT,
                    ModArmorMaterials.GOLDEN_APPLE
            );
        }
        return FOOD_ARMOR_MATERIALS;
    }

    private static boolean isFoodTool(class_1799 stack) {
        if (stack.method_7960()) return false;
        return isCakeTool(stack) || isBreadTool(stack) || isDriedKelpTool(stack)
            || isRottenFleshTool(stack) || isMelonTool(stack) || isSweetBerryTool(stack)
            || isPumpkinPieTool(stack) || isMushroomTool(stack) || isPufferfishTool(stack)
            || isHoneyTool(stack) || isChorusFruitTool(stack) || isGoldenAppleTool(stack);
    }

    private static boolean isFoodArmor(class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof class_1738 armor)) return false;
        for (class_1741 mat : getFoodArmorMaterials()) {
            if (armor.method_7686() == mat) return true;
        }
        return false;
    }

    private static boolean isFoodSetEnabled(class_1799 stack) {
        if (isCakeTool(stack) || isCakeArmor(stack)) return Config.cakeEnabled;
        if (isBreadTool(stack) || isBreadArmor(stack)) return Config.breadEnabled;
        if (isDriedKelpTool(stack) || isDriedKelpArmor(stack)) return Config.driedKelpEnabled;
        if (isRottenFleshTool(stack) || isRottenFleshArmor(stack)) return Config.rottenFleshEnabled;
        if (isMelonTool(stack) || isMelonArmor(stack)) return Config.melonEnabled;
        if (isSweetBerryTool(stack) || isSweetBerryArmor(stack)) return Config.sweetBerryEnabled;
        if (isPumpkinPieTool(stack) || isPumpkinPieArmor(stack)) return Config.pumpkinPieEnabled;
        if (isMushroomTool(stack) || isMushroomArmor(stack)) return Config.mushroomEnabled;
        if (isPufferfishTool(stack) || isPufferfishArmor(stack)) return Config.pufferfishEnabled;
        if (isHoneyTool(stack) || isHoneyArmor(stack)) return Config.honeyEnabled;
        if (isChorusFruitTool(stack) || isChorusFruitArmor(stack)) return Config.chorusFruitEnabled;
        if (isGoldenAppleTool(stack) || isGoldenAppleArmor(stack)) return Config.goldenAppleEnabled;
        return false;
    }

    private static void handleFoodHungerDrain(class_1657 player) {
        if (!(player.method_37908() instanceof class_3218 serverWorld)) return;
        if (player.method_7344().method_7586() > 6) return;
        if (player.field_6012 % 40 != 0) return;

        class_1799 main = player.method_6047();
        class_1799 off = player.method_6079();
        if (isFoodTool(main) && main.method_7963() && isFoodSetEnabled(main)) {
            main.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6173));
            player.method_7344().method_7585(1, 0.1f);
            spawnFoodParticles(player, serverWorld);
        }
        if (isFoodTool(off) && off.method_7963() && isFoodSetEnabled(off)) {
            off.method_7956(1, player, (p) -> p.method_20235(class_1304.field_6171));
            player.method_7344().method_7585(1, 0.1f);
            spawnFoodParticles(player, serverWorld);
        }

        for (class_1304 slot : ARMOR_SLOTS) {
            class_1799 piece = player.method_6118(slot);
            if (isFoodArmor(piece) && piece.method_7963() && isFoodSetEnabled(piece)) {
                piece.method_7956(1, player, (p) -> p.method_20235(slot));
                player.method_7344().method_7585(1, 0.1f);
                spawnFoodParticles(player, serverWorld);
            }
        }
    }

    private static void spawnFoodParticles(class_1657 player, class_3218 world) {
        world.method_14199(class_2398.field_11211,
                player.method_23317(), player.method_23318() + 1.0, player.method_23321(),
                5, 0.3, 0.3, 0.3, 0.01);
    }

    private static void handleCakeArmorEffects(class_1657 player) {
        // Boots -> Speed I (sugar rush)
        if (isCakeArmor(player.method_6118(class_1304.field_6166))) {
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        }
        // Leggings -> Jump Boost I (light and fluffy)
        if (isCakeArmor(player.method_6118(class_1304.field_6172))) {
            player.method_6092(new class_1293(class_1294.field_5913, 60, 0, false, false, true));
        }
        // Chestplate -> Regeneration I (comfort food healing)
        if (isCakeArmor(player.method_6118(class_1304.field_6174))) {
            player.method_6092(new class_1293(class_1294.field_5924, 60, 0, false, false, true));
        }
        // Helmet -> Saturation (keeps hunger satisfied)
        if (isCakeArmor(player.method_6118(class_1304.field_6169))) {
            player.method_6092(new class_1293(class_1294.field_5922, 60, 0, false, false, true));
        }

        // Full set -> Absorption I (frosting shield — 2 extra hearts)
        boolean fullSet = isCakeArmor(player.method_6118(class_1304.field_6169))
                && isCakeArmor(player.method_6118(class_1304.field_6174))
                && isCakeArmor(player.method_6118(class_1304.field_6172))
                && isCakeArmor(player.method_6118(class_1304.field_6166));
        if (fullSet) {
            player.method_6092(new class_1293(class_1294.field_5898, 60, 0, false, false, true));
        }
    }

    // -----------------------------------------------------------------------
    // Ectoplasm-infused non-weapon tool effects
    // -----------------------------------------------------------------------

    private static void handleInfusedToolEffects(class_1657 player) {
        class_1799 main = player.method_6047();
        class_1799 off = player.method_6079();

        applyInfusedEffect(player, main);
        applyInfusedEffect(player, off);
    }

    private static void applyInfusedEffect(class_1657 player, class_1799 stack) {
        if (stack.method_7960() || !EctoplasmInfusionHelper.isInfused(stack)) return;

        // Pickaxe -> Night Vision (spectral sight)
        if (stack.method_7909() instanceof class_1810) {
            player.method_6092(new class_1293(class_1294.field_5925, 260, 0, false, false, true));
        }
        // Shovel -> Haste I (spectral efficiency)
        else if (stack.method_7909() instanceof class_1821) {
            player.method_6092(new class_1293(class_1294.field_5917, 60, 0, false, false, true));
        }
        // Hoe -> Luck I (spectral fortune)
        else if (stack.method_7909() instanceof class_1794) {
            player.method_6092(new class_1293(class_1294.field_5926, 60, 0, false, false, true));
        }
    }

    /**
     * Teleports the player to the nearest safe (non-solid) position above them.
     */
    private static void teleportToSafety(class_1657 player, class_1937 world) {
        class_2338 pos = player.method_24515();

        // Try going up
        for (int y = 0; y < 256; y++) {
            class_2338 check = pos.method_10086(y);
            class_2338 checkHead = check.method_10084();

            boolean feetClear = world.method_8320(check).method_26220(world, check).method_1110();
            boolean headClear = world.method_8320(checkHead).method_26220(world, checkHead).method_1110();

            if (feetClear && headClear) {
                player.method_20620(check.method_10263() + 0.5, check.method_10264(), check.method_10260() + 0.5);
                return;
            }
        }
    }

    // =======================================================================
    // Food set helpers
    // =======================================================================

    private static boolean isBreadTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.BREAD_SWORD) || s.method_31574(ModItems.BREAD_PICKAXE)
            || s.method_31574(ModItems.BREAD_SHOVEL) || s.method_31574(ModItems.BREAD_AXE) || s.method_31574(ModItems.BREAD_HOE));
    }
    private static boolean isBreadArmor(class_1799 s) {
        return !s.method_7960() && s.method_7909() instanceof class_1738 a && a.method_7686() == ModArmorMaterials.BREAD;
    }
    private static boolean isDriedKelpTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.DRIED_KELP_SWORD) || s.method_31574(ModItems.DRIED_KELP_PICKAXE)
            || s.method_31574(ModItems.DRIED_KELP_SHOVEL) || s.method_31574(ModItems.DRIED_KELP_AXE) || s.method_31574(ModItems.DRIED_KELP_HOE));
    }
    private static boolean isDriedKelpArmor(class_1799 s) {
        return !s.method_7960() && s.method_7909() instanceof class_1738 a && a.method_7686() == ModArmorMaterials.DRIED_KELP;
    }
    private static boolean isRottenFleshTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.ROTTEN_FLESH_SWORD) || s.method_31574(ModItems.ROTTEN_FLESH_PICKAXE)
            || s.method_31574(ModItems.ROTTEN_FLESH_SHOVEL) || s.method_31574(ModItems.ROTTEN_FLESH_AXE) || s.method_31574(ModItems.ROTTEN_FLESH_HOE));
    }
    private static boolean isRottenFleshArmor(class_1799 s) {
        return !s.method_7960() && s.method_7909() instanceof class_1738 a && a.method_7686() == ModArmorMaterials.ROTTEN_FLESH;
    }
    private static boolean isMelonTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.MELON_SWORD) || s.method_31574(ModItems.MELON_PICKAXE)
            || s.method_31574(ModItems.MELON_SHOVEL) || s.method_31574(ModItems.MELON_AXE) || s.method_31574(ModItems.MELON_HOE));
    }
    private static boolean isMelonArmor(class_1799 s) {
        return !s.method_7960() && s.method_7909() instanceof class_1738 a && a.method_7686() == ModArmorMaterials.MELON;
    }
    private static boolean isSweetBerryTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.SWEET_BERRY_SWORD) || s.method_31574(ModItems.SWEET_BERRY_PICKAXE)
            || s.method_31574(ModItems.SWEET_BERRY_SHOVEL) || s.method_31574(ModItems.SWEET_BERRY_AXE) || s.method_31574(ModItems.SWEET_BERRY_HOE));
    }
    private static boolean isSweetBerryArmor(class_1799 s) {
        return !s.method_7960() && s.method_7909() instanceof class_1738 a && a.method_7686() == ModArmorMaterials.SWEET_BERRY;
    }
    private static boolean isPumpkinPieTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.PUMPKIN_PIE_SWORD) || s.method_31574(ModItems.PUMPKIN_PIE_PICKAXE)
            || s.method_31574(ModItems.PUMPKIN_PIE_SHOVEL) || s.method_31574(ModItems.PUMPKIN_PIE_AXE) || s.method_31574(ModItems.PUMPKIN_PIE_HOE));
    }
    private static boolean isPumpkinPieArmor(class_1799 s) {
        return !s.method_7960() && s.method_7909() instanceof class_1738 a && a.method_7686() == ModArmorMaterials.PUMPKIN_PIE;
    }
    private static boolean isMushroomTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.MUSHROOM_SWORD) || s.method_31574(ModItems.MUSHROOM_PICKAXE)
            || s.method_31574(ModItems.MUSHROOM_SHOVEL) || s.method_31574(ModItems.MUSHROOM_AXE) || s.method_31574(ModItems.MUSHROOM_HOE));
    }
    private static boolean isMushroomArmor(class_1799 s) {
        return !s.method_7960() && s.method_7909() instanceof class_1738 a && a.method_7686() == ModArmorMaterials.MUSHROOM;
    }
    private static boolean isPufferfishTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.PUFFERFISH_SWORD) || s.method_31574(ModItems.PUFFERFISH_PICKAXE)
            || s.method_31574(ModItems.PUFFERFISH_SHOVEL) || s.method_31574(ModItems.PUFFERFISH_AXE) || s.method_31574(ModItems.PUFFERFISH_HOE));
    }
    private static boolean isPufferfishArmor(class_1799 s) {
        return !s.method_7960() && s.method_7909() instanceof class_1738 a && a.method_7686() == ModArmorMaterials.PUFFERFISH;
    }
    private static boolean isHoneyTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.HONEY_SWORD) || s.method_31574(ModItems.HONEY_PICKAXE)
            || s.method_31574(ModItems.HONEY_SHOVEL) || s.method_31574(ModItems.HONEY_AXE) || s.method_31574(ModItems.HONEY_HOE));
    }
    private static boolean isHoneyArmor(class_1799 s) {
        return !s.method_7960() && s.method_7909() instanceof class_1738 a && a.method_7686() == ModArmorMaterials.HONEY;
    }
    private static boolean isChorusFruitTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.CHORUS_FRUIT_SWORD) || s.method_31574(ModItems.CHORUS_FRUIT_PICKAXE)
            || s.method_31574(ModItems.CHORUS_FRUIT_SHOVEL) || s.method_31574(ModItems.CHORUS_FRUIT_AXE) || s.method_31574(ModItems.CHORUS_FRUIT_HOE));
    }
    private static boolean isChorusFruitArmor(class_1799 s) {
        return !s.method_7960() && s.method_7909() instanceof class_1738 a && a.method_7686() == ModArmorMaterials.CHORUS_FRUIT;
    }
    private static boolean isGoldenAppleTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.GOLDEN_APPLE_SWORD) || s.method_31574(ModItems.GOLDEN_APPLE_PICKAXE)
            || s.method_31574(ModItems.GOLDEN_APPLE_SHOVEL) || s.method_31574(ModItems.GOLDEN_APPLE_AXE) || s.method_31574(ModItems.GOLDEN_APPLE_HOE));
    }
    private static boolean isGoldenAppleArmor(class_1799 s) {
        return !s.method_7960() && s.method_7909() instanceof class_1738 a && a.method_7686() == ModArmorMaterials.GOLDEN_APPLE;
    }

    private static boolean isWearingFullSet(class_1657 player, Predicate<class_1799> check) {
        return check.test(player.method_6118(class_1304.field_6169))
            && check.test(player.method_6118(class_1304.field_6174))
            && check.test(player.method_6118(class_1304.field_6172))
            && check.test(player.method_6118(class_1304.field_6166));
    }

    // =======================================================================
    // Food set armor effects
    // =======================================================================

    // --- Bread: Boots=Speed, Legs=Jump, Chest=Saturation, Helm=Luck, Full=Hunger immunity ---
    private static void handleBreadArmorEffects(class_1657 player) {
        if (isBreadArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isBreadArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5913, 60, 0, false, false, true));
        if (isBreadArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5922, 60, 0, false, false, true));
        if (isBreadArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5926, 60, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isBreadArmor)) {
            player.method_6016(class_1294.field_5903);
        }
    }

    // --- Dried Kelp: Boots=Dolphins Grace, Legs=Haste, Chest=Water Breathing, Helm=Night Vision, Full=Conduit Power ---
    private static void handleDriedKelpArmorEffects(class_1657 player) {
        if (isDriedKelpArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5900, 60, 0, false, false, true));
        if (isDriedKelpArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5917, 60, 0, false, false, true));
        if (isDriedKelpArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5923, 60, 0, false, false, true));
        if (isDriedKelpArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5925, 260, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isDriedKelpArmor))
            player.method_6092(new class_1293(class_1294.field_5927, 60, 0, false, false, true));
    }

    // --- Rotten Flesh: Boots=Slow Falling, Legs=Fire Resist, Chest=Resistance, Helm=Hunger, Full=Undead neutral (no direct Fabric API) ---
    private static void handleRottenFleshArmorEffects(class_1657 player) {
        if (isRottenFleshArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5906, 60, 0, false, false, true));
        if (isRottenFleshArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5918, 60, 0, false, false, true));
        if (isRottenFleshArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isRottenFleshArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5903, 60, 0, false, false, true));
        // Note: Full set undead neutral effect requires a mixin for LivingChangeTargetEvent in Fabric.
        // The proximity-based check below handles it via the server tick instead.
        if (Config.rottenFleshUndeadNeutral && isWearingFullSet(player, ModEvents::isRottenFleshArmor)
                && player.field_6012 % 20 == 0 && player.method_37908() instanceof class_3218 serverWorld) {
            class_238 area = player.method_5829().method_1014(16.0);
            for (class_1308 mob : serverWorld.method_8390(class_1308.class, area, m -> m.method_5968() == player)) {
                if (mob instanceof class_1642 || mob instanceof class_1547 || mob instanceof class_1593) {
                    mob.method_5980(null);
                }
            }
        }
    }

    // --- Melon: Boots=Speed, Legs=Jump, Chest=Regen, Helm=Water Breathing, Full=Passive hunger restore ---
    private static void handleMelonArmorEffects(class_1657 player) {
        if (isMelonArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isMelonArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5913, 60, 0, false, false, true));
        if (isMelonArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5924, 60, 0, false, false, true));
        if (isMelonArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5923, 60, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isMelonArmor) && player.field_6012 % 60 == 0) {
            player.method_7344().method_7585(1, 0.1f);
        }
    }

    // --- Sweet Berries: Boots=Speed, Legs=Jump Boost, Chest=Regen, Helm=Saturation, Full=Thorns (event) ---
    private static void handleSweetBerryArmorEffects(class_1657 player) {
        if (isSweetBerryArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isSweetBerryArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5913, 60, 0, false, false, true));
        if (isSweetBerryArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5924, 60, 0, false, false, true));
        if (isSweetBerryArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5922, 60, 0, false, false, true));
    }

    // --- Pumpkin Pie: Boots=Speed, Legs=Jump, Chest=Absorption, Helm=Enderman avoid (proximity check), Full=Luck ---
    private static void handlePumpkinPieArmorEffects(class_1657 player) {
        if (isPumpkinPieArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isPumpkinPieArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5913, 60, 0, false, false, true));
        if (isPumpkinPieArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5898, 60, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isPumpkinPieArmor))
            player.method_6092(new class_1293(class_1294.field_5926, 60, 0, false, false, true));
        // Pumpkin Pie helmet — endermen ignore player (proximity-based replacement for LivingChangeTargetEvent)
        if (Config.pumpkinPieEndermanAvoidance && isPumpkinPieArmor(player.method_6118(class_1304.field_6169))
                && player.field_6012 % 20 == 0 && player.method_37908() instanceof class_3218 serverWorld) {
            class_238 area = player.method_5829().method_1014(16.0);
            for (class_1560 enderman : serverWorld.method_8390(class_1560.class, area,
                    m -> m.method_5968() == player)) {
                enderman.method_5980(null);
            }
        }
    }

    // --- Mushroom: Boots=Haste, Legs=Jump, Chest=Resistance, Helm=Night Vision, Full=Nausea aura ---
    private static void handleMushroomArmorEffects(class_1657 player) {
        if (isMushroomArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5917, 60, 0, false, false, true));
        if (isMushroomArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5913, 60, 0, false, false, true));
        if (isMushroomArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isMushroomArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5925, 260, 0, false, false, true));
        if (Config.mushroomSporeCloud && isWearingFullSet(player, ModEvents::isMushroomArmor)
                && player.field_6012 % 40 == 0 && player.method_37908() instanceof class_3218 serverWorld) {
            class_238 area = player.method_5829().method_1014(4.0);
            for (class_1308 mob : serverWorld.method_8390(class_1308.class, area, m -> m.method_5968() != null)) {
                mob.method_6092(new class_1293(class_1294.field_5916, 100, 0, false, false, false));
            }
        }
    }

    // --- Pufferfish: Boots=Water Breathing, Legs=Resistance, Chest=Poison immunity, Helm=Conduit Power, Full=Poison aura ---
    private static void handlePufferfishArmorEffects(class_1657 player) {
        if (isPufferfishArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5923, 60, 0, false, false, true));
        if (isPufferfishArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isPufferfishArmor(player.method_6118(class_1304.field_6174)))
            player.method_6016(class_1294.field_5899);
        if (isPufferfishArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5927, 60, 0, false, false, true));
        if (Config.pufferfishPoisonAura && isWearingFullSet(player, ModEvents::isPufferfishArmor)
                && player.field_6012 % 40 == 0 && player.method_37908() instanceof class_3218 serverWorld) {
            class_238 area = player.method_5829().method_1014(3.0);
            for (class_1308 mob : serverWorld.method_8390(class_1308.class, area, m -> m.method_5968() != null)) {
                mob.method_6092(new class_1293(class_1294.field_5899, 100, 0, false, false, false));
            }
        }
    }

    // --- Honey: Boots=Slow Falling, Legs=Resistance, Chest=Fire Resist, Helm=Poison immunity, Full=Sticky (event) ---
    private static void handleHoneyArmorEffects(class_1657 player) {
        if (isHoneyArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5906, 60, 0, false, false, true));
        if (isHoneyArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isHoneyArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5918, 60, 0, false, false, true));
        if (isHoneyArmor(player.method_6118(class_1304.field_6169))) {
            player.method_6016(class_1294.field_5899);
        }
    }

    // --- Chorus Fruit: Boots=Slow Falling, Legs=Speed, Chest=Resistance, Helm=Night Vision, Full=Teleport dodge (event) ---
    private static void handleChorusFruitArmorEffects(class_1657 player) {
        if (isChorusFruitArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5906, 60, 0, false, false, true));
        if (isChorusFruitArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isChorusFruitArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isChorusFruitArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5925, 260, 0, false, false, true));
    }

    // --- Golden Apple: Boots=Speed, Legs=Resistance, Chest=Regen, Helm=Fire Resist, Full=Absorption II ---
    private static void handleGoldenAppleArmorEffects(class_1657 player) {
        if (isGoldenAppleArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isGoldenAppleArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isGoldenAppleArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5924, 60, 0, false, false, true));
        if (isGoldenAppleArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5918, 60, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isGoldenAppleArmor))
            player.method_6092(new class_1293(class_1294.field_5898, 60, 1, false, false, true));
    }

    // =======================================================================
    // Damage events — offensive tool hits + defensive armor effects
    // =======================================================================

    /**
     * ALLOW_DAMAGE: handles defensive armor effects (chorus fruit teleport dodge).
     * Returns false to cancel damage, true to allow.
     */
    private static boolean onAllowDamage(class_1309 entity, class_1282 source, float amount) {
        // --- Armor reactive effects (player is the target) ---
        if (entity instanceof class_1657 victim && source.method_5529() instanceof class_1309 attacker) {
            // Sweet Berry thorns
            if (Config.sweetBerryEnabled && Config.sweetBerryThorns
                    && isWearingFullSet(victim, ModEvents::isSweetBerryArmor)) {
                attacker.method_5643(victim.method_48923().method_48818(victim), 1.0f);
            }
            // Honey sticky — attacker gets Slowness II
            if (Config.honeyEnabled && Config.honeySticky
                    && isWearingFullSet(victim, ModEvents::isHoneyArmor)) {
                attacker.method_6092(new class_1293(class_1294.field_5909, 60, 1));
            }
            // Chorus Fruit teleport dodge — 15% chance
            if (Config.chorusFruitEnabled && Config.chorusFruitTeleport
                    && isWearingFullSet(victim, ModEvents::isChorusFruitArmor)) {
                if (victim.method_37908().field_9229.method_43057() < 0.15f) {
                    teleportRandomly(victim, 3, 8);
                    return false; // Cancel damage
                }
            }
            // Cactus armor — per-piece thorn damage
            if (Config.cactusEnabled && Config.cactusEffects) {
                int cactusPieces = 0;
                for (class_1304 slot : new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166})
                    if (isCactusArmor(victim.method_6118(slot))) cactusPieces++;
                if (cactusPieces > 0)
                    attacker.method_5643(victim.method_48923().method_48818(victim), cactusPieces * 0.5f);
            }
            // Nether Brick full set — attacker ignited
            if (Config.netherBrickEnabled && Config.netherBrickEffects
                    && isWearingFullSet(victim, ModEvents::isNetherBrickArmor)) {
                attacker.method_5639(2); // 40 ticks
            }
            // Magma Cream full set — attacker ignited + Slowness
            if (Config.magmaCreamEnabled && Config.magmaCreamEffects
                    && isWearingFullSet(victim, ModEvents::isMagmaCreamArmor)) {
                attacker.method_5639(3); // 60 ticks
                attacker.method_6092(new class_1293(class_1294.field_5909, 60, 0));
            }
            // Slime full set — massive knockback on attacker
            if (Config.slimeEnabled && Config.slimeEffects
                    && isWearingFullSet(victim, ModEvents::isSlimeArmor)) {
                var dir = attacker.method_19538().method_1020(victim.method_19538()).method_1029();
                attacker.method_18799(attacker.method_18798().method_1031(dir.field_1352 * 2.0, 0.5, dir.field_1350 * 2.0));
                attacker.field_6037 = true;
            }
            // Blaze full set — attacker ignited
            if (Config.blazeEnabled && Config.blazeEffects
                    && isWearingFullSet(victim, ModEvents::isBlazeArmor)) {
                attacker.method_5639(4); // 80 ticks
            }
            // Purpur full set — 20% teleport dodge
            if (Config.purpurEnabled && Config.purpurEffects
                    && isWearingFullSet(victim, ModEvents::isPurpurArmor)) {
                if (victim.method_37908().field_9229.method_43057() < 0.20f) {
                    teleportRandomly(victim, 3, 8);
                    return false; // Cancel damage
                }
            }
            // Shulker full set — attacker levitated/launched
            if (Config.shulkerEnabled && Config.shulkerEffects
                    && isWearingFullSet(victim, ModEvents::isShulkerArmor)) {
                if (attacker instanceof class_1657) {
                    attacker.method_6092(new class_1293(class_1294.field_5902, 40, 0));
                } else {
                    attacker.method_18799(attacker.method_18798().method_1031(0, 1.2, 0));
                    attacker.field_6037 = true;
                }
            }
            // Echo Shard full set — attacker gets Darkness
            if (Config.echoShardEnabled && Config.echoShardEffects
                    && isWearingFullSet(victim, ModEvents::isEchoShardArmor)) {
                attacker.method_6092(new class_1293(class_1294.field_38092, 60, 0));
            }
            // Dragon Breath full set — attacker gets Wither + ignited
            if (Config.dragonBreathEnabled && Config.dragonBreathEffects
                    && isWearingFullSet(victim, ModEvents::isDragonBreathArmor)) {
                attacker.method_6092(new class_1293(class_1294.field_5920, 60, 0));
                attacker.method_5639(3); // 60 ticks
            }
        }
        return true;
    }

    /**
     * AttackEntityCallback: handles offensive food tool on-hit effects.
     * Note: This fires when the player attacks, before damage is dealt.
     * For applying effects to the target, we use this callback.
     */
    private static class_1269 onAttackEntity(class_1657 player, class_1937 world, class_1268 hand,
                                                class_1297 entity, net.minecraft.class_3966 hitResult) {
        if (world.method_8608()) return class_1269.field_5811;
        if (!(entity instanceof class_1309 target)) return class_1269.field_5811;

        class_1799 held = player.method_6047();

        if (Config.honeyEnabled && isHoneyTool(held)) {
            target.method_6092(new class_1293(class_1294.field_5909, 60, 0));
        }
        if (Config.pufferfishEnabled && isPufferfishTool(held)) {
            target.method_6092(new class_1293(class_1294.field_5899, 100, 0));
        }
        if (Config.sweetBerryEnabled && isSweetBerryTool(held)) {
            // Note: AttackEntityCallback cannot modify damage amount directly.
            // The +1 damage bonus from sweet berry tools should be handled via
            // the tool's attack damage attribute instead, or via ALLOW_DAMAGE.
            // For now, we apply a brief weakness-counter effect as a workaround.
            // Actually, we handle this in onAllowDamage instead for accuracy.
        }
        if (Config.rottenFleshEnabled && isRottenFleshTool(held)) {
            target.method_6092(new class_1293(class_1294.field_5903, 100, 0));
        }
        if (Config.mushroomEnabled && isMushroomTool(held)) {
            target.method_6092(new class_1293(class_1294.field_5916, 60, 0));
        }
        if (Config.chorusFruitEnabled && Config.chorusFruitTeleport && isChorusFruitTool(held)) {
            if (world.field_9229.method_43057() < 0.1f) {
                teleportRandomly(target, 3, 8);
            }
        }

        // Vanilla material tool on-hit effects
        if (Config.paperEnabled && Config.paperEffects && isPaperTool(held)) {
            if (world.field_9229.method_43057() < 0.05f)
                target.method_6092(new class_1293(class_1294.field_5920, 20, 0));
            if (world.field_9229.method_43057() < 0.25f)
                held.method_7956(held.method_7936() - held.method_7919(), player, e -> e.method_20235(class_1304.field_6173));
        }
        if (Config.featherEnabled && Config.featherEffects && isFeatherTool(held)) {
            var dir = target.method_19538().method_1020(player.method_19538()).method_1029();
            target.method_18799(target.method_18798().method_1031(dir.field_1352 * 0.3, 0.8, dir.field_1350 * 0.3));
            target.field_6037 = true;
        }
        if (Config.glassEnabled && Config.glassEffects && isGlassTool(held)) {
            // +2 damage handled via extra hurt call
            target.method_5643(player.method_48923().method_48802(player), 2.0f);
            if (held.method_7919() >= held.method_7936() - 1 && world instanceof class_3218 sl) {
                for (class_1309 nearby : sl.method_8390(class_1309.class,
                        player.method_5829().method_1014(3.0), e -> e != player)) {
                    nearby.method_5643(player.method_48923().method_48802(player), 3.0f);
                }
                sl.method_14199(class_2398.field_11205, player.method_23317(), player.method_23318() + 1, player.method_23321(), 20, 1, 1, 1, 0.2);
            }
        }
        if (Config.spongeEnabled && Config.spongeEffects && isSpongeTool(held)) {
            if (target.method_5799()) target.method_5643(player.method_48923().method_48802(player), 3.0f);
        }
        if (Config.netherWartEnabled && Config.netherWartEffects && isNetherWartTool(held)) {
            target.method_6092(new class_1293(class_1294.field_5920, 60, 0));
        }
        if (Config.pointedDripstoneEnabled && Config.pointedDripstoneEffects && isDripstoneTool(held)) {
            // +30% damage, +50% if falling — applied as extra damage
            float bonus = 0.3f;
            if (player.field_6017 > 0 && !player.method_24828()) bonus += 0.5f;
            target.method_5643(player.method_48923().method_48802(player), target.method_6063() * 0.01f * bonus > 1 ? 1 : bonus);
        }
        if (Config.cactusEnabled && Config.cactusEffects && isCactusTool(held)) {
            target.method_5643(player.method_48923().method_48802(player), 1.0f);
            target.method_6092(new class_1293(class_1294.field_5899, 40, 0));
        }
        if (Config.boneEnabled && Config.boneEffects && isBoneTool(held)) {
            if (target instanceof class_1308 mob && mob.method_5999())
                target.method_5643(player.method_48923().method_48802(player), 2.0f);
        }
        if (Config.netherBrickEnabled && Config.netherBrickEffects && isNetherBrickTool(held)) {
            target.method_5639(4); // 80 ticks
        }
        if (Config.magmaCreamEnabled && Config.magmaCreamEffects && isMagmaCreamTool(held)) {
            target.method_5639(5); // 100 ticks
            target.method_6092(new class_1293(class_1294.field_5909, 60, 0));
        }
        if (Config.slimeEnabled && Config.slimeEffects && isSlimeTool(held)) {
            var dir = target.method_19538().method_1020(player.method_19538()).method_1029();
            target.method_18799(target.method_18798().method_1031(dir.field_1352 * 1.5, 0.4, dir.field_1350 * 1.5));
            target.field_6037 = true;
        }
        if (Config.blazeEnabled && Config.blazeEffects && isBlazeTool(held)) {
            target.method_5639(6); // 120 ticks
        }
        if (Config.purpurEnabled && Config.purpurEffects && isPurpurTool(held)) {
            if (world.field_9229.method_43057() < 0.1f)
                teleportRandomly(target, 5, 10);
        }
        if (Config.ghastTearEnabled && Config.ghastTearEffects && isGhastTearTool(held)) {
            player.method_6025(2.0f);
        }
        if (Config.eyeOfEnderEnabled && Config.eyeOfEnderEffects && isEyeOfEnderTool(held)) {
            if (world.field_9229.method_43057() < 0.15f)
                target.method_6092(new class_1293(class_1294.field_5919, 60, 0));
        }
        if (Config.shulkerEnabled && Config.shulkerEffects && isShulkerTool(held)) {
            target.method_18799(target.method_18798().method_1031(0, 1.2, 0));
            target.field_6037 = true;
        }
        if (Config.echoShardEnabled && Config.echoShardEffects && isEchoShardTool(held)) {
            target.method_6092(new class_1293(class_1294.field_38092, 100, 0));
        }
        if (Config.dragonBreathEnabled && Config.dragonBreathEffects && isDragonBreathTool(held)) {
            target.method_6092(new class_1293(class_1294.field_5920, 60, 1));
            target.method_6092(new class_1293(class_1294.field_5899, 60, 0));
            if (world instanceof class_3218 sl && world.field_9229.method_43057() < 0.3f) {
                class_1295 cloud = new class_1295(sl, target.method_23317(), target.method_23318(), target.method_23321());
                cloud.method_5603(1.5f);
                cloud.method_5604(40);
                cloud.method_5596(-1.5f / 40f);
                cloud.method_5610(new class_1293(class_1294.field_5921, 1, 0));
                cloud.method_5607(player);
                sl.method_8649(cloud);
            }
        }
        if (Config.phantomEnabled && Config.phantomEffects && isPhantomTool(held)) {
            if (!world.method_8530()) target.method_5643(player.method_48923().method_48802(player), 2.0f);
        }

        return class_1269.field_5811;
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    private static boolean isSnowTool(class_1799 stack) {
        if (stack.method_7960()) return false;
        return stack.method_31574(ModItems.SNOW_SWORD)
            || stack.method_31574(ModItems.SNOW_PICKAXE)
            || stack.method_31574(ModItems.SNOW_SHOVEL)
            || stack.method_31574(ModItems.SNOW_AXE)
            || stack.method_31574(ModItems.SNOW_HOE);
    }

    private static boolean isIceTool(class_1799 stack) {
        if (stack.method_7960()) return false;
        return stack.method_31574(ModItems.ICE_SWORD)
            || stack.method_31574(ModItems.ICE_PICKAXE)
            || stack.method_31574(ModItems.ICE_SHOVEL)
            || stack.method_31574(ModItems.ICE_AXE)
            || stack.method_31574(ModItems.ICE_HOE);
    }

    private static boolean isIceArmor(class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof class_1738 armor)) return false;
        return armor.method_7686() == ModArmorMaterials.ICE;
    }

    private static boolean isPprismTool(class_1799 stack) {
        if (stack.method_7960()) return false;
        return stack.method_31574(ModItems.PPRISM_SWORD)
            || stack.method_31574(ModItems.PPRISM_PICKAXE)
            || stack.method_31574(ModItems.PPRISM_SHOVEL)
            || stack.method_31574(ModItems.PPRISM_AXE)
            || stack.method_31574(ModItems.PPRISM_HOE);
    }

    private static boolean isPprismArmor(class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof class_1738 armor)) return false;
        return armor.method_7686() == ModArmorMaterials.PPRISM;
    }

    private static boolean isCoalTool(class_1799 stack) {
        if (stack.method_7960()) return false;
        return stack.method_31574(ModItems.COAL_SWORD)
            || stack.method_31574(ModItems.COAL_PICKAXE)
            || stack.method_31574(ModItems.COAL_SHOVEL)
            || stack.method_31574(ModItems.COAL_AXE)
            || stack.method_31574(ModItems.COAL_HOE);
    }

    private static boolean isCoalArmor(class_1799 stack) {
        return !stack.method_7960() && stack.method_7909() instanceof CoalArmorItem;
    }

    private static boolean isOpTool(class_1799 stack) {
        if (stack.method_7960()) return false;
        return stack.method_31574(ModItems.OVERPOWER_SWORD)
            || stack.method_31574(ModItems.OVERPOWER_PICKAXE)
            || stack.method_31574(ModItems.OVERPOWER_SHOVEL)
            || stack.method_31574(ModItems.OVERPOWER_AXE);
    }

    private static boolean isOpArmor(class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof class_1738 armor)) return false;
        return armor.method_7686() == ModArmorMaterials.OVERPOWER;
    }

    private static boolean isFniTool(class_1799 stack) {
        if (stack.method_7960()) return false;
        return stack.method_31574(ModItems.FNI_SWORD)
            || stack.method_31574(ModItems.FNI_PICKAXE)
            || stack.method_31574(ModItems.FNI_SHOVEL)
            || stack.method_31574(ModItems.FNI_AXE)
            || stack.method_31574(ModItems.FNI_HOE);
    }

    private static boolean isFniArmor(class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof class_1738 armor)) return false;
        return armor.method_7686() == ModArmorMaterials.FNI;
    }

    private static boolean isEctoArmor(class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof class_1738 armor)) return false;
        return armor.method_7686() == ModArmorMaterials.ECTO;
    }

    private static boolean isCakeTool(class_1799 stack) {
        if (stack.method_7960()) return false;
        return stack.method_31574(ModItems.CAKE_SWORD)
            || stack.method_31574(ModItems.CAKE_PICKAXE)
            || stack.method_31574(ModItems.CAKE_SHOVEL)
            || stack.method_31574(ModItems.CAKE_AXE)
            || stack.method_31574(ModItems.CAKE_HOE);
    }

    private static boolean isCakeArmor(class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof class_1738 armor)) return false;
        return armor.method_7686() == ModArmorMaterials.CAKE;
    }

    private static boolean isWearingAnyCoalArmor(class_1657 player) {
        for (class_1304 slot : ARMOR_SLOTS) {
            if (isCoalArmor(player.method_6118(slot))) return true;
        }
        return false;
    }

    private static boolean isWearingAnyBurningCoalArmor(class_1657 player) {
        for (class_1304 slot : ARMOR_SLOTS) {
            class_1799 piece = player.method_6118(slot);
            if (isCoalArmor(piece) && CoalBurningHelper.isBurning(piece)) return true;
        }
        return false;
    }

    private static void clearArmorBurning(class_1657 player) {
        for (class_1304 slot : ARMOR_SLOTS) {
            class_1799 piece = player.method_6118(slot);
            if (isCoalArmor(piece)) CoalBurningHelper.setBurning(piece, false);
        }
    }

    private static void clearBurningIfCoalTool(class_1799 stack) {
        if (isCoalTool(stack)) CoalBurningHelper.setBurning(stack, false);
    }

    private static void applyEffects(class_1657 player, class_1293... effects) {
        for (class_1293 effect : effects) {
            player.method_6092(effect);
        }
    }

    // =======================================================================
    // Utility — random teleport
    // =======================================================================

    private static void teleportRandomly(class_1309 entity, int minDist, int maxDist) {
        class_1937 world = entity.method_37908();
        if (world.method_8608()) return;

        for (int attempt = 0; attempt < 16; attempt++) {
            double angle = world.field_9229.method_43058() * Math.PI * 2;
            double dist = minDist + world.field_9229.method_43058() * (maxDist - minDist);
            double tx = entity.method_23317() + Math.cos(angle) * dist;
            double tz = entity.method_23321() + Math.sin(angle) * dist;
            double ty = entity.method_23318();

            class_2338 target = class_2338.method_49637(tx, ty, tz);
            // Try to find a safe y
            for (int dy = -2; dy <= 2; dy++) {
                class_2338 check = target.method_10086(dy);
                class_2338 checkHead = check.method_10084();
                if (world.method_8320(check).method_26220(world, check).method_1110()
                        && world.method_8320(checkHead).method_26220(world, checkHead).method_1110()
                        && !world.method_8320(check.method_10074()).method_26220(world, check.method_10074()).method_1110()) {
                    entity.method_20620(check.method_10263() + 0.5, check.method_10264(), check.method_10260() + 0.5);
                    if (world instanceof class_3218 serverWorld) {
                        serverWorld.method_14199(class_2398.field_11214,
                                entity.method_23317(), entity.method_23318() + 1.0, entity.method_23321(),
                                32, 0.5, 0.5, 0.5, 0.5);
                    }
                    return;
                }
            }
        }
    }

    // =======================================================================
    // Vanilla Material Set helpers
    // =======================================================================

    private static boolean isPaperTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.PAPER_SWORD) || s.method_31574(ModItems.PAPER_PICKAXE) || s.method_31574(ModItems.PAPER_SHOVEL) || s.method_31574(ModItems.PAPER_AXE) || s.method_31574(ModItems.PAPER_HOE));
    }
    private static boolean isFeatherTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.FEATHER_SWORD) || s.method_31574(ModItems.FEATHER_PICKAXE) || s.method_31574(ModItems.FEATHER_SHOVEL) || s.method_31574(ModItems.FEATHER_AXE) || s.method_31574(ModItems.FEATHER_HOE));
    }
    private static boolean isGlassTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.GLASS_SWORD) || s.method_31574(ModItems.GLASS_PICKAXE) || s.method_31574(ModItems.GLASS_SHOVEL) || s.method_31574(ModItems.GLASS_AXE) || s.method_31574(ModItems.GLASS_HOE));
    }
    private static boolean isSpongeTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.SPONGE_SWORD) || s.method_31574(ModItems.SPONGE_PICKAXE) || s.method_31574(ModItems.SPONGE_SHOVEL) || s.method_31574(ModItems.SPONGE_AXE) || s.method_31574(ModItems.SPONGE_HOE));
    }
    private static boolean isNetherWartTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.NETHER_WART_SWORD) || s.method_31574(ModItems.NETHER_WART_PICKAXE) || s.method_31574(ModItems.NETHER_WART_SHOVEL) || s.method_31574(ModItems.NETHER_WART_AXE) || s.method_31574(ModItems.NETHER_WART_HOE));
    }
    private static boolean isDripstoneTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.POINTED_DRIPSTONE_SWORD) || s.method_31574(ModItems.POINTED_DRIPSTONE_PICKAXE) || s.method_31574(ModItems.POINTED_DRIPSTONE_SHOVEL) || s.method_31574(ModItems.POINTED_DRIPSTONE_AXE) || s.method_31574(ModItems.POINTED_DRIPSTONE_HOE));
    }
    private static boolean isCactusTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.CACTUS_SWORD) || s.method_31574(ModItems.CACTUS_PICKAXE) || s.method_31574(ModItems.CACTUS_SHOVEL) || s.method_31574(ModItems.CACTUS_AXE) || s.method_31574(ModItems.CACTUS_HOE));
    }
    private static boolean isCactusArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.CACTUS;
    }
    private static boolean isBoneTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.BONE_SWORD) || s.method_31574(ModItems.BONE_PICKAXE) || s.method_31574(ModItems.BONE_SHOVEL) || s.method_31574(ModItems.BONE_AXE) || s.method_31574(ModItems.BONE_HOE));
    }
    private static boolean isBoneArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.BONE;
    }
    private static boolean isClayArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.CLAY;
    }
    private static boolean isNetherBrickTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.NETHER_BRICK_SWORD) || s.method_31574(ModItems.NETHER_BRICK_PICKAXE) || s.method_31574(ModItems.NETHER_BRICK_SHOVEL) || s.method_31574(ModItems.NETHER_BRICK_AXE) || s.method_31574(ModItems.NETHER_BRICK_HOE));
    }
    private static boolean isNetherBrickArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.NETHER_BRICK;
    }
    private static boolean isCopperArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.COPPER;
    }
    private static boolean isPhantomTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.PHANTOM_SWORD) || s.method_31574(ModItems.PHANTOM_PICKAXE) || s.method_31574(ModItems.PHANTOM_SHOVEL) || s.method_31574(ModItems.PHANTOM_AXE) || s.method_31574(ModItems.PHANTOM_HOE));
    }
    private static boolean isPhantomArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.PHANTOM;
    }
    private static boolean isMagmaCreamTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.MAGMA_CREAM_SWORD) || s.method_31574(ModItems.MAGMA_CREAM_PICKAXE) || s.method_31574(ModItems.MAGMA_CREAM_SHOVEL) || s.method_31574(ModItems.MAGMA_CREAM_AXE) || s.method_31574(ModItems.MAGMA_CREAM_HOE));
    }
    private static boolean isMagmaCreamArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.MAGMA_CREAM;
    }
    private static boolean isSlimeTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.SLIME_SWORD) || s.method_31574(ModItems.SLIME_PICKAXE) || s.method_31574(ModItems.SLIME_SHOVEL) || s.method_31574(ModItems.SLIME_AXE) || s.method_31574(ModItems.SLIME_HOE));
    }
    private static boolean isSlimeArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.SLIME;
    }
    private static boolean isBlazeTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.BLAZE_SWORD) || s.method_31574(ModItems.BLAZE_PICKAXE) || s.method_31574(ModItems.BLAZE_SHOVEL) || s.method_31574(ModItems.BLAZE_AXE) || s.method_31574(ModItems.BLAZE_HOE));
    }
    private static boolean isBlazeArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.BLAZE;
    }
    private static boolean isNautilusTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.NAUTILUS_SWORD) || s.method_31574(ModItems.NAUTILUS_PICKAXE) || s.method_31574(ModItems.NAUTILUS_SHOVEL) || s.method_31574(ModItems.NAUTILUS_AXE) || s.method_31574(ModItems.NAUTILUS_HOE));
    }
    private static boolean isNautilusArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.NAUTILUS;
    }
    private static boolean isPurpurTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.PURPUR_SWORD) || s.method_31574(ModItems.PURPUR_PICKAXE) || s.method_31574(ModItems.PURPUR_SHOVEL) || s.method_31574(ModItems.PURPUR_AXE) || s.method_31574(ModItems.PURPUR_HOE));
    }
    private static boolean isPurpurArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.PURPUR;
    }
    private static boolean isGhastTearTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.GHAST_TEAR_SWORD) || s.method_31574(ModItems.GHAST_TEAR_PICKAXE) || s.method_31574(ModItems.GHAST_TEAR_SHOVEL) || s.method_31574(ModItems.GHAST_TEAR_AXE) || s.method_31574(ModItems.GHAST_TEAR_HOE));
    }
    private static boolean isGhastTearArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.GHAST_TEAR;
    }
    private static boolean isEyeOfEnderTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.EYE_OF_ENDER_SWORD) || s.method_31574(ModItems.EYE_OF_ENDER_PICKAXE) || s.method_31574(ModItems.EYE_OF_ENDER_SHOVEL) || s.method_31574(ModItems.EYE_OF_ENDER_AXE) || s.method_31574(ModItems.EYE_OF_ENDER_HOE));
    }
    private static boolean isEyeOfEnderArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.EYE_OF_ENDER;
    }
    private static boolean isShulkerTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.SHULKER_SWORD) || s.method_31574(ModItems.SHULKER_PICKAXE) || s.method_31574(ModItems.SHULKER_SHOVEL) || s.method_31574(ModItems.SHULKER_AXE) || s.method_31574(ModItems.SHULKER_HOE));
    }
    private static boolean isShulkerArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.SHULKER;
    }
    private static boolean isTurtleScuteArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.TURTLE_SCUTE;
    }
    private static boolean isEchoShardTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.ECHO_SHARD_SWORD) || s.method_31574(ModItems.ECHO_SHARD_PICKAXE) || s.method_31574(ModItems.ECHO_SHARD_SHOVEL) || s.method_31574(ModItems.ECHO_SHARD_AXE) || s.method_31574(ModItems.ECHO_SHARD_HOE));
    }
    private static boolean isEchoShardArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.ECHO_SHARD;
    }
    private static boolean isDragonBreathTool(class_1799 s) {
        return !s.method_7960() && (s.method_31574(ModItems.DRAGON_BREATH_SWORD) || s.method_31574(ModItems.DRAGON_BREATH_PICKAXE) || s.method_31574(ModItems.DRAGON_BREATH_SHOVEL) || s.method_31574(ModItems.DRAGON_BREATH_AXE) || s.method_31574(ModItems.DRAGON_BREATH_HOE));
    }
    private static boolean isDragonBreathArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.DRAGON_BREATH;
    }
    private static boolean isRabbitHideArmor(class_1799 s) {
        if (s.method_7960() || !(s.method_7909() instanceof class_1738 a)) return false;
        return a.method_7686() == ModArmorMaterials.RABBIT_HIDE;
    }

    // =======================================================================
    // Vanilla Material Set tick handlers
    // =======================================================================

    private static void handlePaperPassive(class_1657 player) {
        if (isPaperTool(player.method_6047()) || isPaperTool(player.method_6079()))
            player.method_6092(new class_1293(class_1294.field_5911, 60, 0, false, false, true));
    }

    private static void handleFeatherPassive(class_1657 player) {
        if (isFeatherTool(player.method_6047()) || isFeatherTool(player.method_6079()))
            player.method_6092(new class_1293(class_1294.field_5906, 60, 0, false, false, true));
    }

    private static void handleSpongePassive(class_1657 player) {
        if (!isSpongeTool(player.method_6047())) return;
        if (player.field_6012 % 20 != 0) return;
        if (!player.method_5799() && !player.method_37908().method_8520(player.method_24515())) return;
        class_1799 held = player.method_6047();
        class_2338 center = player.method_24515();
        int repaired = 0;
        for (class_2338 pos : class_2338.method_10097(center.method_10069(-3, -1, -3), center.method_10069(3, 1, 3))) {
            if (repaired >= 5) break;
            if (player.method_37908().method_8320(pos).method_27852(class_2246.field_10382)) {
                player.method_37908().method_8652(pos, class_2246.field_10124.method_9564(), 3);
                repaired++;
            }
        }
        if (repaired > 0 && held.method_7986())
            held.method_7974(Math.max(0, held.method_7919() - repaired));
    }

    private static void handleNetherWartPassive(class_1657 player) {
        if (isNetherWartTool(player.method_6047()) || isNetherWartTool(player.method_6079()))
            player.method_6092(new class_1293(class_1294.field_5903, 60, 0, false, false, true));
    }

    private static void handleRabbitHideArmor(class_1657 player) {
        if (isRabbitHideArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5913, 60, 0, false, false, true));
        if (isRabbitHideArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isRabbitHideArmor)) {
            player.method_6092(new class_1293(class_1294.field_5913, 60, 2, false, false, true));
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
            player.field_6017 = 0;
        }
    }

    private static void handleCactusAura(class_1657 player) {
        if (!isWearingFullSet(player, ModEvents::isCactusArmor)) return;
        if (player.field_6012 % 40 != 0) return;
        if (!(player.method_37908() instanceof class_3218 sl)) return;
        for (class_1309 mob : sl.method_8390(class_1309.class,
                player.method_5829().method_1014(2.0), e -> e != player && e instanceof class_1308)) {
            mob.method_5643(player.method_48923().method_48818(player), 1.0f);
        }
    }

    private static void handleBoneArmor(class_1657 player) {
        if (isWearingFullSet(player, ModEvents::isBoneArmor) && player.field_6012 % 20 == 0) {
            if (!(player.method_37908() instanceof class_3218 sl)) return;
            for (class_1309 mob : sl.method_8390(class_1309.class,
                    player.method_5829().method_1014(8.0), e -> e instanceof class_1308 m && m.method_5999())) {
                mob.method_6092(new class_1293(class_1294.field_5911, 40, 0, false, false, false));
            }
        }
        // Bone helmet — undead reduced detection range (>16 blocks cancel target)
        if (isBoneArmor(player.method_6118(class_1304.field_6169))
                && player.field_6012 % 20 == 0 && player.method_37908() instanceof class_3218 sl) {
            class_238 area = player.method_5829().method_1014(48.0);
            for (class_1308 mob : sl.method_8390(class_1308.class, area,
                    m -> m.method_5999() && m.method_5968() == player && m.method_5739(player) > 16)) {
                mob.method_5980(null);
            }
        }
    }

    private static void handleClayArmor(class_1657 player) {
        if (isClayArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isClayArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5913, 60, 0, false, false, true));
        if (isClayArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isClayArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5926, 60, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isClayArmor))
            player.method_6092(new class_1293(class_1294.field_5898, 60, 0, false, false, true));
    }

    private static void handleNetherBrickArmor(class_1657 player) {
        for (class_1304 slot : ARMOR_SLOTS) {
            if (isNetherBrickArmor(player.method_6118(slot))) {
                player.method_6092(new class_1293(class_1294.field_5918, 60, 0, false, false, true));
                break;
            }
        }
    }

    private static void handleCopperArmor(class_1657 player) {
        boolean inRain = player.method_37908().method_8520(player.method_24515());
        if (!inRain) return;
        if (isCopperArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isCopperArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5923, 60, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isCopperArmor) && player.method_37908().method_8546())
            player.method_6092(new class_1293(class_1294.field_5910, 60, 0, false, false, true));
    }

    private static void handlePhantomEffects(class_1657 player) {
        class_1799 held = player.method_6047();
        if (isPhantomTool(held))
            player.method_6092(new class_1293(class_1294.field_5906, 60, 0, false, false, true));
        boolean night = !player.method_37908().method_8530();
        if (isPhantomArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5906, 60, 0, false, false, true));
        if (night && isPhantomArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (night && isPhantomArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isPhantomArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5925, 220, 0, false, false, true));
        // Phantom membrane full set — phantoms ignore player
        if (isWearingFullSet(player, ModEvents::isPhantomArmor)
                && player.field_6012 % 20 == 0 && player.method_37908() instanceof class_3218 sl) {
            for (class_1593 phantom : sl.method_8390(class_1593.class,
                    player.method_5829().method_1014(48.0), m -> m.method_5968() == player)) {
                phantom.method_5980(null);
            }
        }
    }

    private static void handleMagmaCreamArmor(class_1657 player) {
        if (isMagmaCreamArmor(player.method_6118(class_1304.field_6166)) || isMagmaCreamArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5918, 60, 0, false, false, true));
        if (isMagmaCreamArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
    }

    private static void handleSlimeEffects(class_1657 player) {
        if (isSlimeArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5913, 60, 1, false, false, true));
        if (isSlimeArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isSlimeArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isSlimeArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5906, 60, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isSlimeArmor))
            player.field_6017 = 0;
    }

    private static void handleBlazeArmor(class_1657 player) {
        for (class_1304 slot : ARMOR_SLOTS) {
            if (isBlazeArmor(player.method_6118(slot))) {
                player.method_6092(new class_1293(class_1294.field_5918, 60, 0, false, false, true));
                break;
            }
        }
        if (isWearingFullSet(player, ModEvents::isBlazeArmor))
            player.method_6092(new class_1293(class_1294.field_5910, 60, 0, false, false, true));
    }

    private static void handleNautilusEffects(class_1657 player) {
        if (isNautilusTool(player.method_6047()) && player.method_5799())
            player.method_6092(new class_1293(class_1294.field_5927, 60, 0, false, false, true));
        if (!player.method_5799()) return;
        if (isNautilusArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isNautilusArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5927, 60, 0, false, false, true));
        if (isNautilusArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isNautilusArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5923, 220, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isNautilusArmor))
            player.method_6092(new class_1293(class_1294.field_5900, 60, 0, false, false, true));
        // Nautilus full set — guardians and drowned ignore player
        if (isWearingFullSet(player, ModEvents::isNautilusArmor)
                && player.field_6012 % 20 == 0 && player.method_37908() instanceof class_3218 sl) {
            class_238 area = player.method_5829().method_1014(48.0);
            for (class_1308 mob : sl.method_8390(class_1308.class, area,
                    m -> (m instanceof class_1577 || m instanceof class_1551) && m.method_5968() == player)) {
                mob.method_5980(null);
            }
        }
    }

    private static void handlePurpurEffects(class_1657 player) {
        if (isPurpurTool(player.method_6047()))
            player.field_6017 = 0;
        if (isPurpurArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5906, 60, 0, false, false, true));
        if (isPurpurArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isPurpurArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isPurpurArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5925, 220, 0, false, false, true));
    }

    private static void handleGhastTearEffects(class_1657 player) {
        if (isGhastTearTool(player.method_6047()))
            player.method_6092(new class_1293(class_1294.field_5924, 60, 0, false, false, true));
        if (isGhastTearArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isGhastTearArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5924, 60, 0, false, false, true));
        if (isGhastTearArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isGhastTearArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5898, 60, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isGhastTearArmor)) {
            player.method_6092(new class_1293(class_1294.field_5924, 60, 1, false, false, true));
            player.method_6092(new class_1293(class_1294.field_5898, 60, 1, false, false, true));
        }
    }

    private static void handleEyeOfEnderEffects(class_1657 player) {
        if (isEyeOfEnderTool(player.method_6047()))
            player.method_6092(new class_1293(class_1294.field_5925, 220, 0, false, false, true));
        if (isEyeOfEnderArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isEyeOfEnderArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5913, 60, 0, false, false, true));
        if (isEyeOfEnderArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isEyeOfEnderArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5925, 220, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isEyeOfEnderArmor) && player.field_6012 % 20 == 0) {
            if (player.method_37908() instanceof class_3218 sl) {
                for (class_1309 mob : sl.method_8390(class_1309.class,
                        player.method_5829().method_1014(16.0), e -> e != player))
                    mob.method_6092(new class_1293(class_1294.field_5912, 40, 0, false, false, false));
                // Eye of Ender full set — endermen neutral
                for (class_1560 enderman : sl.method_8390(class_1560.class,
                        player.method_5829().method_1014(48.0), m -> m.method_5968() == player)) {
                    enderman.method_5980(null);
                }
            }
        }
    }

    private static void handleShulkerEffects(class_1657 player) {
        if (isShulkerTool(player.method_6047()) && !player.method_24828())
            player.method_6092(new class_1293(class_1294.field_5917, 60, 0, false, false, true));
        if (isShulkerArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5906, 60, 0, false, false, true));
        if (isShulkerArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5913, 60, 1, false, false, true));
        if (isShulkerArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isShulkerArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5925, 220, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isShulkerArmor)) {
            player.method_6092(new class_1293(class_1294.field_5913, 60, 2, false, false, true));
            player.method_6092(new class_1293(class_1294.field_5906, 60, 0, false, false, true));
            player.field_6017 = 0;
        }
    }

    private static void handleTurtleScuteArmor(class_1657 player) {
        if (isTurtleScuteArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5923, 220, 0, false, false, true));
        if (player.method_5799()) {
            if (isTurtleScuteArmor(player.method_6118(class_1304.field_6166)))
                player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
            if (isTurtleScuteArmor(player.method_6118(class_1304.field_6172)))
                player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
            if (isTurtleScuteArmor(player.method_6118(class_1304.field_6174)))
                player.method_6092(new class_1293(class_1294.field_5927, 60, 0, false, false, true));
            if (isWearingFullSet(player, ModEvents::isTurtleScuteArmor)) {
                player.method_6092(new class_1293(class_1294.field_5927, 60, 1, false, false, true));
                player.method_6092(new class_1293(class_1294.field_5900, 60, 0, false, false, true));
            }
        } else if (isWearingFullSet(player, ModEvents::isTurtleScuteArmor)) {
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
            player.method_6092(new class_1293(class_1294.field_5909, 60, 0, false, false, true));
        }
        // Turtle Scute full set — guardians ignore player
        if (isWearingFullSet(player, ModEvents::isTurtleScuteArmor)
                && player.field_6012 % 20 == 0 && player.method_37908() instanceof class_3218 sl) {
            for (class_1577 guardian : sl.method_8390(class_1577.class,
                    player.method_5829().method_1014(48.0), m -> m.method_5968() == player)) {
                guardian.method_5980(null);
            }
        }
    }

    private static void handleEchoShardEffects(class_1657 player) {
        if (isEchoShardArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isEchoShardArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 0, false, false, true));
        if (isEchoShardArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 1, false, false, true));
        if (isEchoShardArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5925, 220, 0, false, false, true));
        boolean toolHeld = isEchoShardTool(player.method_6047());
        boolean fullSet = isWearingFullSet(player, ModEvents::isEchoShardArmor);
        if ((toolHeld || fullSet) && player.field_6012 % 20 == 0) {
            if (player.method_37908() instanceof class_3218 sl) {
                for (class_1309 mob : sl.method_8390(class_1309.class,
                        player.method_5829().method_1014(16.0), e -> e != player))
                    mob.method_6092(new class_1293(class_1294.field_5912, 40, 0, false, false, false));
                // Echo Shard full set — warden neutral
                if (fullSet) {
                    for (class_7260 warden : sl.method_8390(class_7260.class,
                            player.method_5829().method_1014(48.0), m -> m.method_5968() == player)) {
                        warden.method_5980(null);
                    }
                }
            }
        }
    }

    private static void handleDragonBreathEffects(class_1657 player) {
        if (isDragonBreathTool(player.method_6047())) {
            player.method_6092(new class_1293(class_1294.field_5910, 60, 0, false, false, true));
            player.method_6092(new class_1293(class_1294.field_5918, 60, 0, false, false, true));
        }
        if (isDragonBreathArmor(player.method_6118(class_1304.field_6166)))
            player.method_6092(new class_1293(class_1294.field_5904, 60, 0, false, false, true));
        if (isDragonBreathArmor(player.method_6118(class_1304.field_6172)))
            player.method_6092(new class_1293(class_1294.field_5910, 60, 0, false, false, true));
        if (isDragonBreathArmor(player.method_6118(class_1304.field_6174)))
            player.method_6092(new class_1293(class_1294.field_5907, 60, 1, false, false, true));
        if (isDragonBreathArmor(player.method_6118(class_1304.field_6169)))
            player.method_6092(new class_1293(class_1294.field_5918, 60, 0, false, false, true));
        if (isWearingFullSet(player, ModEvents::isDragonBreathArmor)) {
            player.method_6092(new class_1293(class_1294.field_5910, 60, 1, false, false, true));
            player.method_6092(new class_1293(class_1294.field_5907, 60, 1, false, false, true));
        }
    }
}
