package com.stonytark.usefultoolsmod.worldgen;

import net.minecraft.class_5450;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.world.gen.placementmodifier.*;

import java.util.List;

public class ModOrePlacement {
    public static List<class_6797> orePlacement(class_6797 countPlacement, class_6797 heightRange) {
        return List.of(countPlacement, class_5450.method_39639(), heightRange, class_6792.method_39614());
    }

    public static List<class_6797> commonOrePlacement(int count, class_6797 heightRange) {
        return orePlacement(class_6793.method_39623(count), heightRange);
    }

    public static List<class_6797> rareOrePlacement(int chance, class_6797 heightRange) {
        return orePlacement(class_6799.method_39659(chance), heightRange);
    }
}
