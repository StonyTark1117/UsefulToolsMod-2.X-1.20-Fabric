package com.stonytark.usefultoolsmod.worldgen;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.block.ModBlocks;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class ModConfiguredFeatures {
    public static final class_5321<class_2975<?, ?>> OVERWORLD_RGOLD_ORE_KEY = registerKey("rgold_ore");
    public static final class_5321<class_2975<?, ?>> NETHER_RGOLD_ORE_KEY = registerKey("nether_rgold_ore");
    public static final class_5321<class_2975<?, ?>> END_RGOLD_ORE_KEY = registerKey("end_rgold_ore");

    public static void bootstrap() {
        // In Fabric 1.20.1, worldgen is handled via data files, not bootstrap
    }

    public static class_5321<class_2975<?, ?>> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, new class_2960(UsefultoolsMod.MOD_ID, name));
    }
}
