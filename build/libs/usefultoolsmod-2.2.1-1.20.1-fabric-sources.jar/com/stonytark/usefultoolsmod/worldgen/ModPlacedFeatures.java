package com.stonytark.usefultoolsmod.worldgen;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_7924;

public class ModPlacedFeatures {
    public static final class_5321<class_6796> RGOLD_ORE_PLACED_KEY = registerKey("rgold_ore_placed");
    public static final class_5321<class_6796> NETHER_RGOLD_ORE_PLACED_KEY = registerKey("nether_rgold_ore_placed");
    public static final class_5321<class_6796> END_RGOLD_ORE_PLACED_KEY = registerKey("end_rgold_ore_placed");

    public static void bootstrap() {
        // In Fabric 1.20.1, worldgen is handled via data files
    }

    private static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, new class_2960(UsefultoolsMod.MOD_ID, name));
    }
}
