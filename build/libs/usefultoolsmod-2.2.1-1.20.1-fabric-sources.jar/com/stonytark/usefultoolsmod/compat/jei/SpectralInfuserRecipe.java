package com.stonytark.usefultoolsmod.compat.jei;

import net.minecraft.class_1799;

/**
 * Simple data holder representing one Spectral Infuser recipe for JEI display.
 */
public record SpectralInfuserRecipe(class_1799 weaponInput, class_1799 ectoplasmFuel, class_1799 output) {
}
