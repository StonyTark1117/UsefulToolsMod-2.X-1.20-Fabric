package com.stonytark.usefultoolsmod.compat.jei;

import com.stonytark.usefultoolsmod.UsefultoolsMod;
import com.stonytark.usefultoolsmod.block.ModBlocks;
import com.stonytark.usefultoolsmod.item.ModItems;
import com.stonytark.usefultoolsmod.item.custom.EctoplasmInfusionHelper;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1831;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;

@JeiPlugin
public class UsefulToolsJeiPlugin implements IModPlugin {

    @Override
    public class_2960 getPluginUid() {
        return new class_2960(UsefultoolsMod.MOD_ID, "jei_plugin");
    }

    @Override
    public void registerCategories(IRecipeCategoryRegistration registration) {
        registration.addRecipeCategories(
                new SpectralInfuserRecipeCategory(registration.getJeiHelpers().getGuiHelper()));
    }

    @Override
    public void registerRecipes(IRecipeRegistration registration) {
        List<SpectralInfuserRecipe> recipes = new ArrayList<>();
        class_1799 ectoplasm = new class_1799(ModItems.ECTOPLASM);

        class_7923.field_41178.forEach(item -> {
            if (item instanceof class_1831 || item instanceof class_1738) {
                class_1799 input = new class_1799(item);
                class_1799 output = input.method_7972();
                EctoplasmInfusionHelper.setInfused(output, true);
                recipes.add(new SpectralInfuserRecipe(input, ectoplasm, output));
            }
        });

        // Egg + Ectoplasm → Ghost Spawn Egg
        recipes.add(new SpectralInfuserRecipe(
                new class_1799(class_1802.field_8803),
                ectoplasm,
                new class_1799(ModItems.GHOST_SPAWN_EGG)));

        registration.addRecipes(SpectralInfuserRecipeCategory.TYPE, recipes);
    }

    @Override
    public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
        registration.addRecipeCatalyst(new class_1799(ModBlocks.SPECTRAL_INFUSER),
                SpectralInfuserRecipeCategory.TYPE);
    }
}
