package com.stonytark.usefultoolsmod.compat.wthit;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import net.minecraft.class_124;
import net.minecraft.class_2487;
import net.minecraft.class_2561;

public class SpectralInfuserComponentProvider implements IBlockComponentProvider {

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        class_2487 data = accessor.getData().raw();
        if (data == null) return;

        int progress = data.method_10550("utm_progress");
        int maxProgress = data.method_10550("utm_maxProgress");

        if (data.method_10545("utm_outputName")) {
            String outputName = data.method_10558("utm_outputName");
            tooltip.addLine(class_2561.method_43470("Output: ")
                    .method_27692(class_124.field_1060)
                    .method_10852(class_2561.method_43470(outputName).method_27692(class_124.field_1068)));
        } else if (data.method_10545("utm_inputName")) {
            String inputName = data.method_10558("utm_inputName");

            if (progress > 0 && maxProgress > 0) {
                int percent = (progress * 100) / maxProgress;
                tooltip.addLine(class_2561.method_43470("Infusing: ")
                        .method_27692(class_124.field_1062)
                        .method_10852(class_2561.method_43470(inputName).method_27692(class_124.field_1068)));
                tooltip.addLine(class_2561.method_43470("Progress: " + percent + "%")
                        .method_27692(class_124.field_1080));
            } else {
                tooltip.addLine(class_2561.method_43470("Input: ")
                        .method_27692(class_124.field_1054)
                        .method_10852(class_2561.method_43470(inputName).method_27692(class_124.field_1068)));
                if (!data.method_10577("utm_hasFuel")) {
                    tooltip.addLine(class_2561.method_43470("Needs Ectoplasm")
                            .method_27692(class_124.field_1061));
                }
            }
        } else {
            tooltip.addLine(class_2561.method_43470("Empty")
                    .method_27692(class_124.field_1063));
        }
    }
}
