package com.stonytark.usefultoolsmod.compat.wthit;

import com.stonytark.usefultoolsmod.entity.custom.GhostEntity;
import com.stonytark.usefultoolsmod.item.custom.EctoplasmArmorHelper;
import com.stonytark.usefultoolsmod.item.custom.EctoplasmInfusionHelper;
import mcp.mobius.waila.api.IEntityAccessor;
import mcp.mobius.waila.api.IEntityComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;

public class GhostComponentProvider implements IEntityComponentProvider {

    @Override
    public void appendBody(ITooltip tooltip, IEntityAccessor accessor, IPluginConfig config) {
        if (!(accessor.getEntity() instanceof GhostEntity ghost)) return;
        class_1657 player = accessor.getPlayer();

        if (ghost.method_6109()) {
            tooltip.addLine(class_2561.method_43470("Baby Ghost")
                    .method_27692(class_124.field_1080));
        }

        boolean ghostInvisible = EctoplasmArmorHelper.isGhostInvisible(player);
        if (ghostInvisible) {
            tooltip.addLine(class_2561.method_43470("Cannot see you")
                    .method_27692(class_124.field_1060));
        } else {
            tooltip.addLine(class_2561.method_43470("Can see you")
                    .method_27692(class_124.field_1054));
        }

        class_1799 mainHand = player.method_6047();
        boolean canHurt = EctoplasmInfusionHelper.isInfused(mainHand);
        if (canHurt) {
            tooltip.addLine(class_2561.method_43470("Your weapon can damage this ghost")
                    .method_27692(class_124.field_1060));
        } else {
            tooltip.addLine(class_2561.method_43470("Your weapon cannot damage this ghost")
                    .method_27692(class_124.field_1061));
            tooltip.addLine(class_2561.method_43470("Requires ectoplasm-infused weapon")
                    .method_27692(class_124.field_1080));
        }
    }
}
