package com.stonytark.usefultoolsmod.compat.wthit;

import com.stonytark.usefultoolsmod.block.entity.SpectralInfuserBlockEntity;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;

public class SpectralInfuserDataProvider implements IDataProvider<SpectralInfuserBlockEntity> {

    @Override
    public void appendData(IDataWriter data, IServerAccessor<SpectralInfuserBlockEntity> accessor,
                           IPluginConfig config) {
        SpectralInfuserBlockEntity be = accessor.getTarget();
        class_2371<class_1799> inv = be.getInventory();
        var containerData = be.getPropertyDelegate();

        class_1799 input = inv.get(0);
        class_1799 fuel = inv.get(1);
        class_1799 output = inv.get(2);

        class_2487 tag = data.raw();
        tag.method_10569("utm_progress", containerData.method_17390(0));
        tag.method_10569("utm_maxProgress", containerData.method_17390(1));
        tag.method_10556("utm_hasFuel", !fuel.method_7960());

        if (!input.method_7960()) {
            tag.method_10582("utm_inputName", input.method_7964().getString());
        }
        if (!output.method_7960()) {
            tag.method_10582("utm_outputName", output.method_7964().getString());
        }
    }
}
