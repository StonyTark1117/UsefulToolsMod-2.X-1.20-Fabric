package lol.bai.badpackets.impl.mixin.client;

import com.mojang.authlib.GameProfile;
import lol.bai.badpackets.impl.handler.ClientPacketHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.util.telemetry.WorldSession;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.s2c.play.CustomPayloadS2CPacket;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class MixinClientPacketListener implements ClientPacketHandler.Holder {

    @Shadow
    @Final
    private MinecraftClient minecraft;

    @Unique
    private ClientPacketHandler badpacket_packetHandler;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void badpackets_createClientPacketHandler(MinecraftClient $$0, Screen $$1, ClientConnection $$2, ServerInfo $$3, GameProfile $$4, WorldSession $$5, CallbackInfo ci) {
        badpacket_packetHandler = new ClientPacketHandler(minecraft, (ClientPlayNetworkHandler) (Object) this);
    }

    @Inject(method = "onDisconnect", at = @At("HEAD"))
    private void badpackets_removeClientPacketHandler(Text reason, CallbackInfo ci) {
        badpacket_packetHandler.onDisconnect();
    }

    @Inject(method = "handleCustomPayload", at = @At("HEAD"), cancellable = true)
    private void badpackets_receiveS2CPacket(CustomPayloadS2CPacket packet, CallbackInfo ci) {
        if (!minecraft.isOnThread()) {
            PacketByteBuf buf = packet.getData();
            try {
                if (badpacket_packetHandler.receive(packet.getChannel(), buf)) {
                    ci.cancel();
                }
            } finally {
                buf.release();
            }
        }
    }

    @Override
    public ClientPacketHandler badpackets_getHandler() {
        return badpacket_packetHandler;
    }

}
