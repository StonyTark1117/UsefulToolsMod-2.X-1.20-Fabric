package mcp.mobius.waila.api;

import java.util.function.Predicate;

import mcp.mobius.waila.api.__internal__.IHarvestService;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.NonExtendable
@ApiStatus.Experimental
public interface IToolType {

    static Builder0 builder() {
        return IHarvestService.INSTANCE.createToolTypeBuilder();
    }

    interface Builder0 {

        /**
         * The wooden stack, or any stack of the type that has its {@linkplain ItemStack#getMiningSpeedMultiplier(BlockState) destroy speed}
         * the same as or higher than {@linkplain ToolMaterials#WOOD wood}.
         */
        Builder1 lowestTierStack(ItemStack stack);

        /**
         * The wooden item, or any item of the type that has its {@linkplain Item#getMiningSpeedMultiplier(ItemStack, BlockState) destroy speed}
         * the same as or higher than {@linkplain ToolMaterials#WOOD wood}
         */
        Builder1 lowestTierItem(ItemConvertible item);

    }

    interface Builder1 {

        /**
         * The block state predicate, used to check if the current block can be mined by the tool.
         */
        Builder2 blockPredicate(Predicate<BlockState> predicate);

        /**
         * The block tag, used to check if the current block can be mined by the tool.
         */
        Builder2 blockTag(TagKey<Block> tag);

        Builder2 blockTag(Identifier tag);

    }

    interface Builder2 {

        /**
         * The stack predicate, used to check if the current stack is valid for the tool type.
         */
        Builder3 itemPredicate(Predicate<ItemStack> predicate);

        /**
         * The item tag, used to check if the current stack is valid for the tool type.
         */
        Builder3 itemTag(TagKey<Item> tag);

        Builder3 itemTag(Identifier tag);

    }

    interface Builder3 {

        IToolType build();

    }

}
