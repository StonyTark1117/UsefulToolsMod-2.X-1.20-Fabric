package mcp.mobius.waila.api.component;

import java.text.DecimalFormat;

import mcp.mobius.waila.api.__internal__.ApiSide;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Position;
import net.minecraft.util.math.Vec3i;

/**
 * Component that renders 3D position coordinate.
 */
@ApiSide.ClientOnly
public class PositionComponent extends WrappedComponent {

    private static final DecimalFormat DECIMAL = new DecimalFormat("0.##");

    public PositionComponent(Vec3i pos) {
        this(pos.getX(), pos.getY(), pos.getZ());
    }

    public PositionComponent(Position pos) {
        this(pos.getX(), pos.getY(), pos.getZ());
    }

    public PositionComponent(double x, double y, double z) {
        super(Text.literal("(")
            .append(Text.literal(DECIMAL.format(x)).formatted(Formatting.RED))
            .append(", ")
            .append(Text.literal(DECIMAL.format(y)).formatted(Formatting.GREEN))
            .append(", ")
            .append(Text.literal(DECIMAL.format(z)).formatted(Formatting.BLUE))
            .append(")"));
    }

}
