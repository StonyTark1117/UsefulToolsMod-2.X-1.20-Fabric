package mcp.mobius.waila.api;

import mcp.mobius.waila.api.__internal__.ApiSide;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * Used to get some basic data out of the game without having to request direct access to the game engine.
 */
@ApiSide.ClientOnly
@ApiStatus.NonExtendable
public interface IEntityAccessor {

    World getWorld();

    PlayerEntity getPlayer();

    <T extends Entity> T getEntity();

    EntityHitResult getEntityHitResult();

    @Nullable
    Vec3d getRenderingPosition();

    long getServerDataTime();

    IDataReader getData();

    int getUpdateId();

    Vec3d getRayCastOrigin();

    Vec3d getRayCastDirection();

    double getRayCastMaxDistance();

    float getFrameTime();

    // -----------------------------------------------------------------------------------------------------------------------------------------------
    // TODO: Remove

    /**
     * @deprecated use {@link #getData()}, {@link IDataReader#raw()}
     */
    @Deprecated(forRemoval = true)
    @ApiStatus.ScheduledForRemoval(inVersion = "1.21")
    NbtCompound getServerData();

    /**
     * @deprecated use {@link #getEntityHitResult()}
     */
    @Deprecated
    @ApiStatus.ScheduledForRemoval(inVersion = "1.21")
    HitResult getHitResult();

    /**
     * @deprecated use {@link #getFrameTime()}
     */
    @Deprecated
    @ApiStatus.ScheduledForRemoval(inVersion = "1.21")
    double getPartialFrame();

}
