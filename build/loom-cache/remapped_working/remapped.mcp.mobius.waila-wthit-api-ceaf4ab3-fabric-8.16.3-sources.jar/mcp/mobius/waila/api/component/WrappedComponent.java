package mcp.mobius.waila.api.component;

import I;
import java.util.List;
import java.util.Objects;

import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.__internal__.ApiSide;
import mcp.mobius.waila.api.__internal__.IApiService;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Language;

/**
 * Component that renders a vanilla {@link Text}.
 */
@ApiSide.ClientOnly
public class WrappedComponent implements ITooltipComponent {

    public WrappedComponent(String literal) {
        this(Text.literal(literal));
    }

    public WrappedComponent(Text component) {
        this.component = component;
    }

    public final Text component;
    private List<OrderedText> lines;
    private int height;

    @Override
    public int getWidth() {
        var font = getFont();
        var split = font.getTextHandler().wrapLines(component, Integer.MAX_VALUE, Style.EMPTY);
        lines = Language.getInstance().reorder(split);

        var width = lines.stream().mapToInt(font::getWidth).max().orElse(0);
        height = font.fontHeight * split.size();

        return width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    @Override
    public void render(DrawContext ctx, int x, int y, float delta) {
        var font = getFont();

        for (var line : lines) {
            ctx.drawTextWithShadow(font, line, x, y, IApiService.INSTANCE.getFontColor());
            y += font.fontHeight;
        }
    }

    private TextRenderer getFont() {
        return MinecraftClient.getInstance().textRenderer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        var that = (WrappedComponent) o;
        return component.equals(that.component);
    }

    @Override
    public int hashCode() {
        return Objects.hash(component);
    }

}
