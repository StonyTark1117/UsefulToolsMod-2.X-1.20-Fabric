package mcp.mobius.waila.api.component;

import I;
import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.WailaHelper;
import mcp.mobius.waila.api.__internal__.ApiSide;
import mcp.mobius.waila.api.__internal__.IApiService;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;

/**
 * Component that renders an {@link ItemStack} with its name.
 */
@ApiSide.ClientOnly
public class NamedItemComponent implements ITooltipComponent {

    public static final NamedItemComponent EMPTY = new NamedItemComponent(ItemStack.EMPTY);

    public NamedItemComponent(ItemStack stack) {
        this.stack = stack;

        var count = stack.getCount();
        var name = stack.getName().getString();
        this.label = count > 1 ? WailaHelper.suffix(count) + " " + name : name;
    }

    public NamedItemComponent(ItemConvertible item) {
        this(new ItemStack(item));
    }

    public final ItemStack stack;
    public final String label;

    @Override
    public int getWidth() {
        return getFont().getWidth(label) + 10;
    }

    @Override
    public int getHeight() {
        return getFont().fontHeight;
    }

    @Override
    public void render(DrawContext ctx, int x, int y, float delta) {
        var pose = ctx.getMatrices();
        pose.push();
        pose.translate(x, y, 0);
        pose.scale(0.5f, 0.5f, 0.5f);
        ctx.drawItem(stack, 0, 0);
        pose.pop();

        ctx.drawTextWithShadow(getFont(), label, x + 10, y, IApiService.INSTANCE.getFontColor());
    }

    private TextRenderer getFont() {
        return MinecraftClient.getInstance().textRenderer;
    }

}
