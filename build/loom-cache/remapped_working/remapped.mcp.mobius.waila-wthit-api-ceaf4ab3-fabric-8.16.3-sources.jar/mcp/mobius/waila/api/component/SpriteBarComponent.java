package mcp.mobius.waila.api.component;

import I;
import com.mojang.blaze3d.systems.RenderSystem;
import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.WailaHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.texture.Sprite;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Component that renders a bar with a texture as the foreground.
 */
public class SpriteBarComponent implements ITooltipComponent {

    public SpriteBarComponent(float ratio, Identifier texture, float u0, float u1, float v0, float v1, int regionWidth, int regionHeight, int tint, Text text) {
        this.ratio = ratio;
        this.texture = texture;
        this.u0 = u0;
        this.u1 = u1;
        this.v0 = v0;
        this.v1 = v1;
        this.spriteTint = tint;
        this.regionWidth = regionWidth;
        this.regionHeight = regionHeight;
        this.text = text;
    }

    public SpriteBarComponent(float ratio, Sprite sprite, int regionWidth, int regionHeight, int tint, Text text) {
        this(ratio, sprite.getAtlasId(), sprite.getMinU(), sprite.getMaxU(), sprite.getMinV(), sprite.getMaxV(), regionWidth, regionHeight, tint, text);
    }

    private final float ratio;
    private final Identifier texture;
    private final float u0, u1, v0, v1;
    private final int spriteTint;
    private final int regionWidth;
    private final int regionHeight;
    private final Text text;

    @Override
    public int getWidth() {
        return Math.max(MinecraftClient.getInstance().textRenderer.getWidth(text), BarComponent.WIDTH);
    }

    @Override
    public int getHeight() {
        return BarComponent.HEIGHT;
    }

    @Override
    public void render(DrawContext ctx, int x, int y, float delta) {
        var matrices = ctx.getMatrices();

        BarComponent.renderBar(matrices, x, y, BarComponent.WIDTH, BarComponent.V0_BG, BarComponent.U1, BarComponent.V1_BG, 0xFFAAAAAA);

        matrices.push();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorTexProgram);
        RenderSystem.setShaderTexture(0, texture);

        var mx = (int) (x + BarComponent.WIDTH * ratio);
        var my = y + BarComponent.HEIGHT;

        ctx.enableScissor(x + 1, y + 1, mx - 1, my - 1);

        var a = WailaHelper.getAlpha(spriteTint);
        var r = WailaHelper.getRed(spriteTint);
        var g = WailaHelper.getGreen(spriteTint);
        var b = WailaHelper.getBlue(spriteTint);

        var tessellator = Tessellator.getInstance();
        var buffer = tessellator.getBuffer();

        buffer.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR_TEXTURE);

        for (var px1 = x; px1 < mx; px1 += regionWidth) {
            var px2 = px1 + regionWidth;

            for (var py1 = y; py1 < my; py1 += regionHeight) {
                var py2 = py1 + regionHeight;

                buffer.vertex(matrices.peek().getPositionMatrix(), px1, py2, 0).color(r, g, b, a).texture(u0, v1).next();
                buffer.vertex(matrices.peek().getPositionMatrix(), px2, py2, 0).color(r, g, b, a).texture(u1, v1).next();
                buffer.vertex(matrices.peek().getPositionMatrix(), px2, py1, 0).color(r, g, b, a).texture(u1, v0).next();
                buffer.vertex(matrices.peek().getPositionMatrix(), px1, py1, 0).color(r, g, b, a).texture(u0, v0).next();
            }
        }

        tessellator.draw();
        RenderSystem.disableBlend();
        matrices.pop();
        ctx.disableScissor();

        BarComponent.renderText(matrices, text, x, y);
    }

}
