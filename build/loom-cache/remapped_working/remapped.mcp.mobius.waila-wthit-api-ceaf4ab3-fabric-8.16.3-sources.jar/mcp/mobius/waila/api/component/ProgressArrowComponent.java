package mcp.mobius.waila.api.component;

import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.api.__internal__.ApiSide;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

/**
 * Component that renders a furnace-like progress arrow.
 */
@ApiSide.ClientOnly
public class ProgressArrowComponent implements ITooltipComponent {

    /**
     * @param progress the progress between 0.0f and 1.0f.
     */
    public ProgressArrowComponent(float progress) {
        this.progress = MathHelper.clamp(progress, 0.0f, 1.0f);
    }

    private final float progress;

    @Override
    public int getWidth() {
        return 22;
    }

    @Override
    public int getHeight() {
        return 16;
    }

    @Override
    public void render(DrawContext ctx, int x, int y, float delta) {
        // Draws the "empty" background arrow
        ctx.drawTexture(WailaConstants.COMPONENT_TEXTURE, x, y, 0, 16, 22, 16);

        if (progress > 0) {
            // Draws the "full" foreground arrow based on the progress
            ctx.drawTexture(WailaConstants.COMPONENT_TEXTURE, x, y, 0, 0, (int) (progress * 22) + 1, 16);
        }
    }

}
