package mcp.mobius.waila.api;

import mcp.mobius.waila.api.__internal__.ApiSide;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.ApiStatus;

/**
 * Decides where Waila will start ray casting for objects.
 *
 * @see IClientRegistrar#rayCastVector(IRayCastVectorProvider, int)
 */
@ApiSide.ClientOnly
@ApiStatus.Experimental
public interface IRayCastVectorProvider {

    /**
     * Returns whether this provider instance should be used.
     *
     * @param config current plugin configurations
     */
    default boolean isEnabled(IPluginConfig config) {
        return true;
    }

    /**
     * Returns the ray cast origin.
     *
     * @see Entity#getCameraPosVec(float)
     */
    Vec3d getOrigin(float delta);

    /**
     * Returns the ray cast direction.
     *
     * @see Entity#getRotationVec(float)
     */
    Vec3d getDirection(float delta);

}
