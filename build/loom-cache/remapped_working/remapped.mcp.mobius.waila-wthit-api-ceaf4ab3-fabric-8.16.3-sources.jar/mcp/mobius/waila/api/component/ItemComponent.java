package mcp.mobius.waila.api.component;

import F;
import I;
import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.WailaHelper;
import mcp.mobius.waila.api.__internal__.ApiSide;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;

/**
 * Component that renders an {@link ItemStack}.
 */
@ApiSide.ClientOnly
public class ItemComponent implements ITooltipComponent {

    public static final ItemComponent EMPTY = new ItemComponent(ItemStack.EMPTY);

    public ItemComponent(ItemStack stack) {
        this.stack = stack;
    }

    public ItemComponent(ItemConvertible item) {
        this(new ItemStack(item));
    }

    public final ItemStack stack;

    @Override
    public int getWidth() {
        return stack.isEmpty() ? 0 : 18;
    }

    @Override
    public int getHeight() {
        return stack.isEmpty() ? 0 : 18;
    }

    @Override
    public void render(DrawContext ctx, int x, int y, float delta) {
        ctx.drawItem(stack, x + 1, y + 1);
        renderItemDecorations(ctx, stack, x + 1, y + 1);
    }

    static void renderItemDecorations(DrawContext ctx, ItemStack stack, int x, int y) {
        var client = MinecraftClient.getInstance();
        var count = stack.getCount();

        ctx.drawItemInSlot(client.textRenderer, stack, x + 1, y + 1, "");
        if (count <= 1) return;

        var countText = WailaHelper.suffix(count);
        var actualW = client.textRenderer.getWidth(countText);
        var scale = (actualW <= 16) ? 1f : 16f / actualW;

        var pose = ctx.getMatrices();
        pose.push();
        pose.translate(0.0, 0.0, 250.0);
        pose.scale(scale, scale, 1f);

        client.textRenderer.draw(countText,
            ((x + 17 - (actualW * scale)) / scale),
            ((y + 17 - (client.textRenderer.fontHeight * scale)) / scale),
            0xFFFFFF, true,
            pose.peek().getPositionMatrix(), ctx.getVertexConsumers(), TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0, client.textRenderer.isRightToLeft());

        pose.pop();
    }

}
