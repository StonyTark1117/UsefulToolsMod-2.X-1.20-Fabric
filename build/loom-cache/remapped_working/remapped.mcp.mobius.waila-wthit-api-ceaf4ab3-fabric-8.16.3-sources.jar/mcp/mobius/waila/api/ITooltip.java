package mcp.mobius.waila.api;

import mcp.mobius.waila.api.__internal__.ApiSide;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * The tooltip object that Waila will show.
 */
@ApiSide.ClientOnly
@ApiStatus.NonExtendable
public interface ITooltip {

    int getLineCount();

    /**
     * Returns the line on this index.
     * <p>
     * <b>Note:</b> position dependant, you can't access
     * head tooltip in {@code appendBody}. To access all tooltip, use {@link IEventListener#onHandleTooltip}.
     */
    ITooltipLine getLine(int index);

    /**
     * Add a new line to the tooltip.
     */
    ITooltipLine addLine();

    /**
     * Replace the line that has the tag with a new line.
     *
     * @see WailaConstants
     */
    ITooltipLine setLine(Identifier tag);

    /**
     * Returns the line with specified tag, if any.
     *
     * @see WailaConstants
     */
    @Nullable
    ITooltipLine getLine(Identifier tag);

    /**
     * Add a new line to the tooltip.
     */
    default void addLine(Text component) {
        addLine().with(component);
    }

    /**
     * Add a new line to the tooltip.
     */
    default void addLine(ITooltipComponent component) {
        addLine().with(component);
    }

    /**
     * Replace the line that has the tag with a new line.
     *
     * @see WailaConstants
     */
    default void setLine(Identifier tag, Text component) {
        setLine(tag).with(component);
    }

    /**
     * Replace the line that has the tag with a new line.
     *
     * @see WailaConstants
     */
    default void setLine(Identifier tag, ITooltipComponent component) {
        setLine(tag).with(component);
    }

}
