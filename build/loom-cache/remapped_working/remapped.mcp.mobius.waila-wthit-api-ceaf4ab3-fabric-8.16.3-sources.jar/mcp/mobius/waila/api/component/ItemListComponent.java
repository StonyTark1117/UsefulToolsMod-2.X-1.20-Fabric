package mcp.mobius.waila.api.component;

import I;
import java.util.List;

import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.__internal__.ApiSide;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;

/**
 * Component that renders items that dynamically grow based on available space.
 */
@ApiSide.ClientOnly
public class ItemListComponent implements ITooltipComponent.HorizontalGrowing {

    public ItemListComponent(List<ItemStack> items) {
        this(items, 3);
    }

    public ItemListComponent(List<ItemStack> items, int maxHeight) {
        this(items, maxHeight, 1f);
    }

    public ItemListComponent(List<ItemStack> items, int maxHeight, float scale) {
        this.items = items;
        this.maxHeight = maxHeight;
        this.scale = scale;
    }

    private final List<ItemStack> items;
    private final int maxHeight;
    private final float scale;

    private int gridWidth;
    private int gridHeight;
    private int maxIndex;

    @Override
    public int getMinimalWidth() {
        return (int) (Math.min(items.size(), 9) * 18 * scale);
    }

    @Override
    public void setGrownWidth(int grownWidth) {
        gridWidth = MathHelper.ceil(grownWidth / (18 * scale));
        gridHeight = items.isEmpty() ? 0 : Math.min(MathHelper.ceilDiv(items.size(), gridWidth), maxHeight);
        maxIndex = gridWidth * gridHeight - 1;
    }

    @Override
    public int getHeight() {
        return MathHelper.ceil(gridHeight * 18 * scale);
    }

    @Override
    public void render(DrawContext ctx, int x, int y, float delta) {
        var pose = ctx.getMatrices();
        pose.push();
        pose.translate(x, y, 0);
        pose.scale(scale, scale, 1f);

        for (var i = 0; i < items.size(); i++) {
            var item = items.get(i);
            var ix = (18 * (i % gridWidth)) + 1;
            var iy = (18 * (i / gridWidth)) + 1;
            ctx.drawItem(item, ix, iy);
            ItemComponent.renderItemDecorations(ctx, item, ix, iy);

            if (i == maxIndex) break;
        }

        pose.pop();
    }

}
