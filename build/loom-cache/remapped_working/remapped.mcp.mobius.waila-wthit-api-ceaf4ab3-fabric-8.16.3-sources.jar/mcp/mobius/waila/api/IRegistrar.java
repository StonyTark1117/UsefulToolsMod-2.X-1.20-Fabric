package mcp.mobius.waila.api;

import java.nio.file.Path;

import mcp.mobius.waila.api.__internal__.ApiSide;
import mcp.mobius.waila.api.__internal__.IHarvestService;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.ApiStatus;

/**
 * @deprecated use {@link ICommonRegistrar} or {@link IClientRegistrar} instead.
 */
@Deprecated
@ApiStatus.NonExtendable
public interface IRegistrar extends ICommonRegistrar, IClientRegistrar {

    int DEFAULT_PRIORITY = WailaConstants.DEFAULT_PRIORITY;

    default void addConfig(Identifier key, boolean defaultValue) {
        localConfig(key, defaultValue);
    }

    default void addConfig(Identifier key, int defaultValue, IntFormat format) {
        localConfig(key, defaultValue, format);
    }

    default void addConfig(Identifier key, int defaultValue) {
        addConfig(key, defaultValue, IntFormat.DECIMAL);
    }

    default void addConfig(Identifier key, double defaultValue) {
        localConfig(key, defaultValue);
    }

    default void addConfig(Identifier key, String defaultValue) {
        localConfig(key, defaultValue);
    }

    default <T extends Enum<T>> void addConfig(Identifier key, T defaultValue) {
        localConfig(key, defaultValue);
    }

    default void addConfig(Identifier key, Path path) {
        externalConfig(key, path);
    }

    default void addFeatureConfig(Identifier key, boolean clientOnly) {
        featureConfig(key, clientOnly);
    }

    default void addSyncedConfig(Identifier key, boolean defaultValue, boolean clientOnlyValue) {
        syncedConfig(key, defaultValue, clientOnlyValue);
    }

    default void addSyncedConfig(Identifier key, int defaultValue, int clientOnlyValue, IntFormat format) {
        syncedConfig(key, defaultValue, clientOnlyValue, format);
    }

    default void addSyncedConfig(Identifier key, int defaultValue, int clientOnlyValue) {
        addSyncedConfig(key, defaultValue, clientOnlyValue, IntFormat.DECIMAL);
    }

    default void addSyncedConfig(Identifier key, double defaultValue, double clientOnlyValue) {
        syncedConfig(key, defaultValue, clientOnlyValue);
    }

    default void addSyncedConfig(Identifier key, String defaultValue, String clientOnlyValue) {
        syncedConfig(key, defaultValue, clientOnlyValue);
    }

    default <T extends Enum<T>> void addSyncedConfig(Identifier key, T defaultValue, T clientOnlyValue) {
        syncedConfig(key, defaultValue, clientOnlyValue);
    }

    default void addConfigAlias(Identifier actual, Identifier... aliases) {
        configAlias(actual, aliases);
    }

    default void addEventListener(IEventListener listener, int priority) {
        eventListener(listener, priority);
    }

    default void addEventListener(IEventListener listener) {
        addEventListener(listener, DEFAULT_PRIORITY);
    }

    default void addBlacklist(int priority, Block... blocks) {
        blacklist(priority, blocks);
    }

    default void addBlacklist(int priority, BlockEntityType<?>... blockEntityTypes) {
        blacklist(priority, blockEntityTypes);
    }

    default void addBlacklist(Block... blocks) {
        addBlacklist(DEFAULT_PRIORITY, blocks);
    }

    default void addBlacklist(BlockEntityType<?>... blockEntityTypes) {
        addBlacklist(DEFAULT_PRIORITY, blockEntityTypes);
    }

    void removeBlacklist(int priority, Block... blocks);

    void removeBlacklist(int priority, BlockEntityType<?>... blockEntityTypes);

    default void removeBlacklist(Block... blocks) {
        removeBlacklist(DEFAULT_PRIORITY, blocks);
    }

    default void removeBlacklist(BlockEntityType<?>... blockEntityTypes) {
        removeBlacklist(DEFAULT_PRIORITY, blockEntityTypes);
    }

    @ApiStatus.Experimental
    default <T> void addRedirect(IBlockComponentProvider provider, Class<T> clazz, int priority) {
        redirect(provider, clazz, priority);
    }

    @ApiStatus.Experimental
    default <T> void addRedirect(IBlockComponentProvider provider, Class<T> clazz) {
        addRedirect(provider, clazz, DEFAULT_PRIORITY);
    }

    @ApiSide.ClientOnly
    default <T> void addOverride(IBlockComponentProvider provider, Class<T> clazz, int priority) {
        override(provider, clazz, priority);
    }

    @ApiSide.ClientOnly
    default <T> void addOverride(IBlockComponentProvider provider, Class<T> clazz) {
        addOverride(provider, clazz, DEFAULT_PRIORITY);
    }

    @ApiSide.ClientOnly
    default <T> void addIcon(IBlockComponentProvider provider, Class<T> clazz, int priority) {
        icon(provider, clazz, priority);
    }

    @ApiSide.ClientOnly
    default <T> void addIcon(IBlockComponentProvider provider, Class<T> clazz) {
        addIcon(provider, clazz, DEFAULT_PRIORITY);
    }

    @ApiSide.ClientOnly
    default <T> void addComponent(IBlockComponentProvider provider, TooltipPosition position, Class<T> clazz, int priority) {
        switch (position) {
            case HEAD -> head(provider, clazz, priority);
            case BODY -> body(provider, clazz, priority);
            case TAIL -> tail(provider, clazz, priority);
        }
    }

    @ApiSide.ClientOnly
    default <T> void addComponent(IBlockComponentProvider provider, TooltipPosition position, Class<T> clazz) {
        addComponent(provider, position, clazz, DEFAULT_PRIORITY);
    }

    default <T> void addDataContext(IBlockComponentProvider provider, Class<T> clazz) {
        dataContext(provider, clazz);
    }

    default <T, BE extends BlockEntity> void addBlockData(IDataProvider<BE> provider, Class<T> clazz, int priority) {
        blockData(provider, clazz, priority);
    }

    default <T, BE extends BlockEntity> void addBlockData(IDataProvider<BE> provider, Class<T> clazz) {
        addBlockData(provider, clazz, DEFAULT_PRIORITY);
    }

    default void addBlacklist(int priority, EntityType<?>... entityTypes) {
        blacklist(priority, entityTypes);
    }

    default void addBlacklist(EntityType<?>... entityTypes) {
        addBlacklist(DEFAULT_PRIORITY, entityTypes);
    }

    void removeBlacklist(int priority, EntityType<?>... entityTypes);

    default void removeBlacklist(EntityType<?>... entityTypes) {
        removeBlacklist(DEFAULT_PRIORITY, entityTypes);
    }

    @ApiStatus.Experimental
    default <T> void addRedirect(IEntityComponentProvider provider, Class<T> clazz, int priority) {
        redirect(provider, clazz, priority);
    }

    @ApiStatus.Experimental
    default <T> void addRedirect(IEntityComponentProvider provider, Class<T> clazz) {
        addRedirect(provider, clazz, DEFAULT_PRIORITY);
    }

    @ApiSide.ClientOnly
    default <T> void addOverride(IEntityComponentProvider provider, Class<T> clazz, int priority) {
        override(provider, clazz, priority);
    }

    @ApiSide.ClientOnly
    default <T> void addOverride(IEntityComponentProvider provider, Class<T> clazz) {
        addOverride(provider, clazz, DEFAULT_PRIORITY);
    }

    @ApiSide.ClientOnly
    default <T> void addIcon(IEntityComponentProvider provider, Class<T> clazz, int priority) {
        icon(provider, clazz, priority);
    }

    @ApiSide.ClientOnly
    default <T> void addIcon(IEntityComponentProvider provider, Class<T> clazz) {
        addIcon(provider, clazz, DEFAULT_PRIORITY);
    }

    @ApiSide.ClientOnly
    default <T> void addComponent(IEntityComponentProvider provider, TooltipPosition position, Class<T> clazz, int priority) {
        switch (position) {
            case HEAD -> head(provider, clazz, priority);
            case BODY -> body(provider, clazz, priority);
            case TAIL -> tail(provider, clazz, priority);
        }
    }

    @ApiSide.ClientOnly
    default <T> void addComponent(IEntityComponentProvider provider, TooltipPosition position, Class<T> clazz) {
        addComponent(provider, position, clazz, DEFAULT_PRIORITY);
    }

    default <T> void addDataContext(IEntityComponentProvider provider, Class<T> clazz) {
        dataContext(provider, clazz);
    }

    default <T, E extends Entity> void addEntityData(IDataProvider<E> provider, Class<T> clazz, int priority) {
        entityData(provider, clazz, priority);
    }

    default <T, E extends Entity> void addEntityData(IDataProvider<E> provider, Class<T> clazz) {
        addEntityData(provider, clazz, DEFAULT_PRIORITY);
    }

    default <A extends IData, I extends A> void addDataType(Identifier id, Class<A> apiType, Class<I> implType, IData.Serializer<I> serializer) {
        dataType(id, apiType, implType, serializer);
    }

    default <T extends IData> void addDataType(Identifier id, Class<T> type, IData.Serializer<T> serializer) {
        addDataType(id, type, type, serializer);
    }

    @ApiSide.ClientOnly
    @ApiStatus.Experimental
    default <T extends ITheme> void addThemeType(Identifier id, IThemeType<T> type) {
        themeType(id, type);
    }

    @ApiSide.ClientOnly
    @ApiStatus.Experimental
    default void addRayCastVector(IRayCastVectorProvider provider, int priority) {
        rayCastVector(provider, priority);
    }

    @ApiSide.ClientOnly
    @ApiStatus.Experimental
    default void addRayCastVector(IRayCastVectorProvider provider) {
        addRayCastVector(provider, DEFAULT_PRIORITY);
    }

    @ApiSide.ClientOnly
    @ApiStatus.Experimental
    default void addToolType(Identifier id, IToolType toolType) {
        toolType(id, toolType);
    }

    // -----------------------------------------------------------------------------------------------------------------------------------------------
    // TODO: Remove

    /**
     * @deprecated use {@link #addBlockData(IDataProvider, Class)}
     */
    @SuppressWarnings("removal")
    @Deprecated(forRemoval = true)
    @ApiStatus.ScheduledForRemoval(inVersion = "1.21")
    default <T, BE extends BlockEntity> void addBlockData(IServerDataProvider<BE> provider, Class<T> clazz) {
        addBlockData((IDataProvider<? extends BlockEntity>) provider, clazz);
    }

    /**
     * @deprecated use {@link #addEntityData(IDataProvider, Class)}
     */
    @SuppressWarnings("removal")
    @Deprecated(forRemoval = true)
    @ApiStatus.ScheduledForRemoval(inVersion = "1.21")
    default <T, E extends Entity> void addEntityData(IServerDataProvider<E> provider, Class<T> clazz) {
        addEntityData((IDataProvider<? extends Entity>) provider, clazz);
    }

    /**
     * @deprecated use {@link #addFeatureConfig(Identifier, boolean)}
     */
    @Deprecated(forRemoval = true)
    @ApiStatus.ScheduledForRemoval(inVersion = "1.22")
    default void addMergedConfig(Identifier key, boolean defaultValue) {
        addFeatureConfig(key, true);
    }

    /**
     * @deprecated use {@link #addFeatureConfig(Identifier, boolean)}
     */
    @Deprecated(forRemoval = true)
    @ApiStatus.ScheduledForRemoval(inVersion = "1.22")
    default void addMergedSyncedConfig(Identifier key, boolean defaultValue, boolean clientOnlyValue) {
        addFeatureConfig(key, false);
    }

    /**
     * @deprecated use {@link #addRayCastVector(IRayCastVectorProvider, int)}
     */
    @Deprecated
    @ApiStatus.ScheduledForRemoval(inVersion = "1.21")
    @ApiSide.ClientOnly
    void replacePicker(IObjectPicker picker, int priority);

    /**
     * @deprecated use {@link #addRayCastVector(IRayCastVectorProvider, int)}
     */
    @Deprecated
    @ApiStatus.ScheduledForRemoval(inVersion = "1.21")
    @ApiSide.ClientOnly
    default void replacePicker(IObjectPicker picker) {
        replacePicker(picker, DEFAULT_PRIORITY);
    }

}
