package mcp.mobius.waila.api;

import mcp.mobius.waila.api.__internal__.IApiService;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.ApiStatus;

/**
 * Used to guess the mod origin of game objects.
 */
@ApiStatus.NonExtendable
public interface IModInfo {

    static IModInfo get(String namespace) {
        return IApiService.INSTANCE.getModInfo(namespace);
    }

    static IModInfo get(Identifier id) {
        return get(id.getNamespace());
    }

    static IModInfo get(Block block) {
        return get(Registries.BLOCK.getId(block));
    }

    static IModInfo get(ItemStack stack) {
        return IApiService.INSTANCE.getModInfo(stack);
    }

    static IModInfo get(Item item) {
        return get(Registries.ITEM.getId(item));
    }

    static IModInfo get(Entity entity) {
        return get(Registries.ENTITY_TYPE.getId(entity.getType()));
    }

    /**
     * Returns whether the mod is actually present in the classpath.
     */
    boolean isPresent();

    /**
     * Returns the id of the mod.
     */
    String getId();

    /**
     * Returns the name of the mod.
     */
    String getName();

    /**
     * Returns the string representation of the version of the mod.
     */
    String getVersion();

}
