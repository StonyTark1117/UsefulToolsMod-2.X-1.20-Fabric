package mezz.jei.common.platform;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.color.item.ItemColors;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.item.TooltipData;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.Sprite;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

public interface IPlatformRenderHelper {
    TextRenderer getFontRenderer(MinecraftClient minecraft, ItemStack itemStack);

    boolean shouldRender(StatusEffectInstance potionEffect);

    Sprite getParticleIcon(BakedModel bakedModel);

    ItemColors getItemColors();

    Optional<NativeImage> getMainImage(Sprite sprite);

    @SuppressWarnings("OptionalUsedAsFieldOrParameterType")
    void renderTooltip(Screen screen, DrawContext guiGraphics, List<Text> textComponents, Optional<TooltipData> tooltipComponent, int x, int y, @Nullable TextRenderer font, ItemStack stack);
}
