package mezz.jei.gui.ingredients;

import mezz.jei.api.ingredients.IIngredientHelper;
import mezz.jei.api.ingredients.IIngredientRenderer;
import mezz.jei.common.config.IIngredientFilterConfig;
import mezz.jei.common.util.Translator;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.StringHelper;
import org.jetbrains.annotations.Unmodifiable;

import java.util.List;
import java.util.Set;

public final class IngredientInformationUtil {
	private IngredientInformationUtil() {
	}

	public static <T> String getDisplayName(T ingredient, IIngredientHelper<T> ingredientHelper) {
		String displayName = ingredientHelper.getDisplayName(ingredient);
		return removeChatFormatting(displayName);
	}

	@Unmodifiable
	public static <T> List<String> getTooltipStrings(T ingredient, IIngredientRenderer<T> ingredientRenderer, Set<String> toRemove, IIngredientFilterConfig config) {
		TooltipContext.Default tooltipFlag = config.getSearchAdvancedTooltips() ? TooltipContext.Default.ADVANCED : TooltipContext.Default.BASIC;
		List<Text> tooltip = ingredientRenderer.getTooltip(ingredient, tooltipFlag);
		return tooltip.stream()
			.map(Text::getString)
			.map(IngredientInformationUtil::removeChatFormatting)
			.map(Translator::toLowercaseWithLocale)
			.map(line -> {
				for (String excludeWord : toRemove) {
					line = line.replace(excludeWord, "");
				}
				return line;
			})
			.filter(line -> !StringHelper.isEmpty(line))
			.toList();
	}

	private static String removeChatFormatting(String string) {
		String withoutFormattingCodes = Formatting.strip(string);
		return (withoutFormattingCodes == null) ? "" : withoutFormattingCodes;
	}

}
