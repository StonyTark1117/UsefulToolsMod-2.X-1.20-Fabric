package mezz.jei.fabric.ingredients.fluid;

import mezz.jei.api.fabric.ingredients.fluids.IJeiFluidIngredient;
import net.minecraft.fluid.Fluid;
import net.minecraft.nbt.NbtCompound;
import javax.annotation.Nullable;
import java.util.Optional;

public final class JeiFluidIngredient implements IJeiFluidIngredient {
    private final Fluid fluid;
    private final long amount;
    @Nullable
    private final NbtCompound tag;

    public JeiFluidIngredient(Fluid fluid, long amount) {
        this.fluid = fluid;
        this.amount = amount;
        this.tag = null;
    }

    public JeiFluidIngredient(Fluid fluid, long amount, @Nullable NbtCompound tag) {
        this.fluid = fluid;
        this.amount = amount;
        if (tag != null) {
            this.tag = tag.copy();
        } else {
            this.tag = null;
        }
    }

    @Override
    public Fluid getFluid() {
        return fluid;
    }

    @Override
    public long getAmount() {
        return amount;
    }

    @Override
    public Optional<NbtCompound> getTag() {
        return Optional.ofNullable(tag);
    }
}
