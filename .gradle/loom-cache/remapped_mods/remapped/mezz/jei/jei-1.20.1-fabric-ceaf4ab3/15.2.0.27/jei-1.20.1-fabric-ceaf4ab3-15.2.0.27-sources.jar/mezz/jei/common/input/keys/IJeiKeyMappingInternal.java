package mezz.jei.common.input.keys;

import java.util.function.Consumer;

import mezz.jei.api.runtime.IJeiKeyMapping;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

public interface IJeiKeyMappingInternal extends IJeiKeyMapping {
    @Override
    boolean isActiveAndMatches(InputUtil.Key key);

    @Override
    boolean isUnbound();

    @Override
    Text getTranslatedKeyMessage();

    IJeiKeyMapping register(Consumer<KeyBinding> registerMethod);
}
