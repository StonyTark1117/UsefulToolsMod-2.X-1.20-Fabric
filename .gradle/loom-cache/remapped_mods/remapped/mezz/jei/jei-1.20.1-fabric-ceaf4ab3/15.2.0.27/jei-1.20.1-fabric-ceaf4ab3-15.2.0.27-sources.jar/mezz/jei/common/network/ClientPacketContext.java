package mezz.jei.common.network;

import mezz.jei.common.config.IServerConfig;
import net.minecraft.client.network.ClientPlayerEntity;

public record ClientPacketContext(ClientPlayerEntity player,
                                  IConnectionToServer connection,
                                  IServerConfig serverConfig
) {
}
