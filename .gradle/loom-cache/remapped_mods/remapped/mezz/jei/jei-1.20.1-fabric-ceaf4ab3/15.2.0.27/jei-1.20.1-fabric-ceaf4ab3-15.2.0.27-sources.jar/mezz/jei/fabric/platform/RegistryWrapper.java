package mezz.jei.fabric.platform;

import mezz.jei.common.platform.IPlatformRegistry;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import java.util.Optional;
import java.util.stream.Stream;

public class RegistryWrapper<T> implements IPlatformRegistry<T> {
    public static <T> IPlatformRegistry<T> getRegistry(RegistryKey<? extends Registry<T>> key) {
        Registry<? extends Registry<?>> rootRegistry = Registries.REGISTRIES;
        Registry<?> registry = rootRegistry.get(key.getValue());
        if (registry == null) {
            throw new NullPointerException("Could not find registry for key: " + key);
        }
        IPlatformRegistry<?> registryWrapper = new RegistryWrapper<>(registry);
        @SuppressWarnings("unchecked")
        IPlatformRegistry<T> castPlatformRegistry = (IPlatformRegistry<T>) registryWrapper;
        return castPlatformRegistry;
    }

    private final Registry<T> registry;

    private RegistryWrapper(Registry<T> registry) {
        this.registry = registry;
    }

    @Override
    public Stream<T> getValues() {
        return this.registry.stream();
    }

    @Override
    public Optional<T> getValue(Identifier resourceLocation) {
        T t = this.registry.get(resourceLocation);
        return Optional.ofNullable(t);
    }

    @Override
    public int getId(T entry) {
        return this.registry.getRawId(entry);
    }

    @Override
    public Optional<T> getValue(int id) {
        return this.registry.getEntry(id)
            .map(RegistryEntry::value);
    }

    @Override
    public boolean contains(T entry) {
        return this.registry.getId(entry) != null;
    }

    @Override
    public Optional<Identifier> getRegistryName(T entry) {
        return this.registry.getKey(entry)
            .map(RegistryKey::getValue);
    }
}
