package mezz.jei.common.network.packets;

import mezz.jei.common.network.IPacketId;
import mezz.jei.common.network.PacketIdServer;
import mezz.jei.common.network.ServerPacketContext;
import mezz.jei.common.network.ServerPacketData;
import mezz.jei.common.transfer.BasicRecipeTransferHandlerServer;
import mezz.jei.common.transfer.TransferOperation;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class PacketRecipeTransfer extends PacketJei {
	public final Collection<TransferOperation> transferOperations;
	public final Collection<Slot> craftingSlots;
	public final Collection<Slot> inventorySlots;
	private final boolean maxTransfer;
	private final boolean requireCompleteSets;

	public PacketRecipeTransfer(
		Collection<TransferOperation> transferOperations,
		Collection<Slot> craftingSlots,
		Collection<Slot> inventorySlots,
		boolean maxTransfer,
		boolean requireCompleteSets
	) {
		this.transferOperations = transferOperations;
		this.craftingSlots = craftingSlots;
		this.inventorySlots = inventorySlots;
		this.maxTransfer = maxTransfer;
		this.requireCompleteSets = requireCompleteSets;
	}

	@Override
	public IPacketId getPacketId() {
		return PacketIdServer.RECIPE_TRANSFER;
	}

	@Override
	public void writePacketData(PacketByteBuf buf) {
		buf.writeVarInt(transferOperations.size());
		for (TransferOperation operation : transferOperations) {
			operation.writePacketData(buf);
		}

		buf.writeVarInt(craftingSlots.size());
		for (Slot craftingSlot : craftingSlots) {
			buf.writeVarInt(craftingSlot.id);
		}

		buf.writeVarInt(inventorySlots.size());
		for (Slot inventorySlot : inventorySlots) {
			buf.writeVarInt(inventorySlot.id);
		}

		buf.writeBoolean(maxTransfer);
		buf.writeBoolean(requireCompleteSets);
	}

	public static CompletableFuture<Void> readPacketData(ServerPacketData data) {
		ServerPacketContext context = data.context();
		ServerPlayerEntity player = context.player();
		PacketByteBuf buf = data.buf();
		ScreenHandler container = player.currentScreenHandler;

		int transferOperationsSize = buf.readVarInt();
		List<TransferOperation> transferOperations = new ArrayList<>();
		for (int i = 0; i < transferOperationsSize; i++) {
			TransferOperation transferOperation = TransferOperation.readPacketData(buf, container);
			transferOperations.add(transferOperation);
		}

		int craftingSlotsSize = buf.readVarInt();
		List<Slot> craftingSlots = new ArrayList<>();
		for (int i = 0; i < craftingSlotsSize; i++) {
			int slotIndex = buf.readVarInt();
			Slot slot = container.getSlot(slotIndex);
			craftingSlots.add(slot);
		}

		int inventorySlotsSize = buf.readVarInt();
		List<Slot> inventorySlots = new ArrayList<>();
		for (int i = 0; i < inventorySlotsSize; i++) {
			int slotIndex = buf.readVarInt();
			Slot slot = container.getSlot(slotIndex);
			inventorySlots.add(slot);
		}
		boolean maxTransfer = buf.readBoolean();
		boolean requireCompleteSets = buf.readBoolean();

		MinecraftServer server = player.server;
		return server.submit(() ->
			BasicRecipeTransferHandlerServer.setItems(
				player,
				transferOperations,
				craftingSlots,
				inventorySlots,
				maxTransfer,
				requireCompleteSets
			)
		);
	}

}
