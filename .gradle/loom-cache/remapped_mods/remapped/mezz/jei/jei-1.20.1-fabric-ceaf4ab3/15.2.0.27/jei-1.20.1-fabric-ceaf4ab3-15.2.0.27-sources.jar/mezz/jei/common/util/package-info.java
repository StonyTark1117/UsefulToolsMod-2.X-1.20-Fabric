@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.common.util;

import javax.annotation.ParametersAreNonnullByDefault;
