package mezz.jei.common.network.packets;

import io.netty.buffer.Unpooled;
import mezz.jei.common.network.IPacketId;
import net.minecraft.network.PacketByteBuf;
import org.apache.commons.lang3.tuple.Pair;

public abstract class PacketJei {
	public final Pair<PacketByteBuf, Integer> getPacketData() {
		IPacketId packetId = getPacketId();
		int packetIdOrdinal = packetId.ordinal();
		PacketByteBuf packetBuffer = new PacketByteBuf(Unpooled.buffer());
		packetBuffer.writeByte(packetIdOrdinal);
		writePacketData(packetBuffer);
		return Pair.of(packetBuffer, packetIdOrdinal);
	}

	protected abstract IPacketId getPacketId();

	protected abstract void writePacketData(PacketByteBuf buf);
}
