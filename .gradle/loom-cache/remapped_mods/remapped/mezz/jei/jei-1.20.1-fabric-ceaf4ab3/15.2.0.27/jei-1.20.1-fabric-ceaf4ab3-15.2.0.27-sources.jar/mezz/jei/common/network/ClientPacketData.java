package mezz.jei.common.network;

import net.minecraft.network.PacketByteBuf;

public record ClientPacketData(PacketByteBuf buf, ClientPacketContext context) {
}
