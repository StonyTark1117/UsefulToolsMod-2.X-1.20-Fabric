package mezz.jei.fabric.events;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;

public class JeiScreenEvents {
    public static final Event<AfterRenderBackground> AFTER_RENDER_BACKGROUND =
        EventFactory.createArrayBacked(AfterRenderBackground.class, callbacks -> (screen, guiGraphics) -> {
            for (AfterRenderBackground callback : callbacks) {
                callback.afterRenderBackground(screen, guiGraphics);
            }
        });

    public static final Event<DrawForeground> DRAW_FOREGROUND =
        EventFactory.createArrayBacked(DrawForeground.class, callbacks -> (screen, guiGraphics, mouseX, mouseY) -> {
            for (DrawForeground callback : callbacks) {
                callback.drawForeground(screen, guiGraphics, mouseX, mouseY);
            }
        });


    @Environment(EnvType.CLIENT)
    @FunctionalInterface
    public interface AfterRenderBackground {
        void afterRenderBackground(Screen screen, DrawContext guiGraphics);
    }

    @Environment(EnvType.CLIENT)
    @FunctionalInterface
    public interface DrawForeground {
        void drawForeground(HandledScreen<?> screen, DrawContext guiGraphics, int mouseX, int mouseY);
    }
}
