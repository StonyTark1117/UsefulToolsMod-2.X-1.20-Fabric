package mezz.jei.library.color;

import mezz.jei.common.platform.IPlatformRenderHelper;
import mezz.jei.common.platform.Services;
import mezz.jei.common.util.ErrorUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.color.item.ItemColors;
import net.minecraft.client.render.block.BlockModels;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.item.ItemModels;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.texture.MissingSprite;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteContents;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public final class ColorGetter {
	private static final Logger LOGGER = LogManager.getLogger();

	public ColorGetter() {

	}

	public List<Integer> getColors(ItemStack itemStack, int colorCount) {
		try {
			return unsafeGetColors(itemStack, colorCount);
		} catch (RuntimeException | LinkageError e) {
			String itemStackInfo = ErrorUtil.getItemStackInfo(itemStack);
			LOGGER.warn("Failed to get color name for {}", itemStackInfo, e);
			return Collections.emptyList();
		}
	}

	private List<Integer> unsafeGetColors(ItemStack itemStack, int colorCount) {
		final Item item = itemStack.getItem();
		if (itemStack.isEmpty()) {
			return Collections.emptyList();
		} else if (item instanceof final BlockItem itemBlock) {
			final Block block = itemBlock.getBlock();
			//noinspection ConstantConditions
			if (block == null) {
				return Collections.emptyList();
			}
			return getBlockColors(block, colorCount);
		} else {
			return getItemColors(itemStack, colorCount);
		}
	}

	private List<Integer> getItemColors(ItemStack itemStack, int colorCount) {
		IPlatformRenderHelper renderHelper = Services.PLATFORM.getRenderHelper();
		final ItemColors itemColors = renderHelper.getItemColors();
		final int renderColor = itemColors.getColor(itemStack, 0);
		final Sprite textureAtlasSprite = getTextureAtlasSprite(itemStack);
		if (textureAtlasSprite == null) {
			return Collections.emptyList();
		}
		return getColors(textureAtlasSprite, renderColor, colorCount);
	}

	private List<Integer> getBlockColors(Block block, int colorCount) {
		BlockState blockState = block.getDefaultState();
		final BlockColors blockColors = MinecraftClient.getInstance().getBlockColors();
		final int renderColor = blockColors.getColor(blockState, null, null, 0);
		final Sprite textureAtlasSprite = getTextureAtlasSprite(blockState);
		if (textureAtlasSprite == null) {
			return Collections.emptyList();
		}
		return getColors(textureAtlasSprite, renderColor, colorCount);
	}

	public List<Integer> getColors(Sprite textureAtlasSprite, int renderColor, int colorCount) {
		if (colorCount <= 0) {
			return Collections.emptyList();
		}
		return getNativeImage(textureAtlasSprite)
			.map(bufferedImage -> {
				final List<Integer> colors = new ArrayList<>(colorCount);
				final int[][] palette = ColorThief.getPalette(bufferedImage, colorCount, 2, false);
				for (int[] colorInt : palette) {
					int red = (int) ((colorInt[0] - 1) * (float) (renderColor >> 16 & 255) / 255.0F);
					int green = (int) ((colorInt[1] - 1) * (float) (renderColor >> 8 & 255) / 255.0F);
					int blue = (int) ((colorInt[2] - 1) * (float) (renderColor & 255) / 255.0F);
					red = MathHelper.clamp(red, 0, 255);
					green = MathHelper.clamp(green, 0, 255);
					blue = MathHelper.clamp(blue, 0, 255);
					int color = ((0xFF) << 24) |
						((red & 0xFF) << 16) |
						((green & 0xFF) << 8) |
						(blue & 0xFF);
					colors.add(color);
				}
				return colors;
			})
			.orElseGet(Collections::emptyList);
	}

	private static Optional<NativeImage> getNativeImage(Sprite textureAtlasSprite) {
		SpriteContents contents = textureAtlasSprite.getContents();
		int iconWidth = contents.getWidth();
		int iconHeight = contents.getHeight();
		if (iconWidth <= 0 || iconHeight <= 0) {
			return Optional.empty();
		}

		IPlatformRenderHelper renderHelper = Services.PLATFORM.getRenderHelper();
		return renderHelper.getMainImage(textureAtlasSprite);
	}

	@Nullable
	private static Sprite getTextureAtlasSprite(BlockState blockState) {
		MinecraftClient minecraft = MinecraftClient.getInstance();
		BlockRenderManager blockRendererDispatcher = minecraft.getBlockRenderManager();
		BlockModels blockModelShapes = blockRendererDispatcher.getModels();
		BakedModel blockModel = blockModelShapes.getModel(blockState);
		IPlatformRenderHelper renderHelper = Services.PLATFORM.getRenderHelper();
		Sprite textureAtlasSprite = renderHelper.getParticleIcon(blockModel);
		if (textureAtlasSprite.getAtlasId().equals(MissingSprite.getMissingSpriteId())) {
			return null;
		}
		return textureAtlasSprite;
	}

	@Nullable
	private static Sprite getTextureAtlasSprite(ItemStack itemStack) {
		ItemRenderer itemRenderer = MinecraftClient.getInstance().getItemRenderer();
		ItemModels itemModelMesher = itemRenderer.getModels();
		BakedModel itemModel = itemModelMesher.getModel(itemStack);
		IPlatformRenderHelper renderHelper = Services.PLATFORM.getRenderHelper();
		Sprite particleTexture = renderHelper.getParticleIcon(itemModel);
		if (particleTexture.getAtlasId().equals(MissingSprite.getMissingSpriteId())) {
			return null;
		}
		return particleTexture;
	}
}
