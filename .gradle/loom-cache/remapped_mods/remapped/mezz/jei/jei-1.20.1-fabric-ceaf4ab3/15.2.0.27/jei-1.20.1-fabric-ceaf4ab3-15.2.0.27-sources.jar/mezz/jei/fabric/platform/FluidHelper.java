package mezz.jei.fabric.platform;

import mezz.jei.api.fabric.constants.FabricTypes;
import mezz.jei.api.fabric.ingredients.fluids.IJeiFluidIngredient;
import mezz.jei.api.ingredients.IIngredientRenderer;
import mezz.jei.api.ingredients.IIngredientTypeWithSubtypes;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.ingredients.subtypes.IIngredientSubtypeInterpreter;
import mezz.jei.api.ingredients.subtypes.UidContext;
import mezz.jei.common.platform.IPlatformFluidHelperInternal;
import mezz.jei.fabric.ingredients.fluid.JeiFluidIngredient;
import mezz.jei.library.render.FluidTankRenderer;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.client.texture.Sprite;
import net.minecraft.fluid.Fluid;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;

@SuppressWarnings("UnstableApiUsage")
public class FluidHelper implements IPlatformFluidHelperInternal<IJeiFluidIngredient> {
    @Override
    public IIngredientTypeWithSubtypes<Fluid, IJeiFluidIngredient> getFluidIngredientType() {
        return FabricTypes.FLUID_STACK;
    }

    @Override
    public IIngredientSubtypeInterpreter<IJeiFluidIngredient> getAllNbtSubtypeInterpreter() {
        return AllFluidNbt.INSTANCE;
    }

    @Override
    public IIngredientRenderer<IJeiFluidIngredient> createRenderer(long capacity, boolean showCapacity, int width, int height) {
        return new FluidTankRenderer<>(this, capacity, showCapacity, width, height);
    }

    @Override
    public Optional<Sprite> getStillFluidSprite(IJeiFluidIngredient ingredient) {
        FluidVariant fluidVariant = getFluidVariant(ingredient);
        Sprite sprite = FluidVariantRendering.getSprite(fluidVariant);
        return Optional.ofNullable(sprite);
    }

    @Override
    public Text getDisplayName(IJeiFluidIngredient ingredient) {
        FluidVariant fluidVariant = getFluidVariant(ingredient);
        return FluidVariantAttributes.getName(fluidVariant);
    }

    @Override
    public int getColorTint(IJeiFluidIngredient ingredient) {
        FluidVariant fluidVariant = getFluidVariant(ingredient);
        int fluidColor = FluidVariantRendering.getColor(fluidVariant);
        return fluidColor | 0xFF000000;
    }

    @Override
    public List<Text> getTooltip(IJeiFluidIngredient ingredient, TooltipContext tooltipFlag) {
        FluidVariant fluidVariant = getFluidVariant(ingredient);
        return FluidVariantRendering.getTooltip(fluidVariant, tooltipFlag);
    }

    private FluidVariant getFluidVariant(IJeiFluidIngredient ingredient) {
        Fluid fluid = ingredient.getFluid();
        NbtCompound tag = ingredient.getTag().orElse(null);
        return FluidVariant.of(fluid, tag);
    }

    @Override
    public long getAmount(IJeiFluidIngredient ingredient) {
        return ingredient.getAmount();
    }

    @Override
    public Optional<NbtCompound> getTag(IJeiFluidIngredient ingredient) {
        return ingredient.getTag();
    }

    @SuppressWarnings("UnstableApiUsage")
    @Override
    public long bucketVolume() {
        return FluidConstants.BUCKET;
    }

    @Override
    public IJeiFluidIngredient create(Fluid fluid, long amount, @Nullable NbtCompound tag) {
        return new JeiFluidIngredient(fluid, amount, tag);
    }

    @Override
    public IJeiFluidIngredient create(Fluid fluid, long amount) {
        return new JeiFluidIngredient(fluid, amount);
    }

    @Override
    public IJeiFluidIngredient copy(IJeiFluidIngredient ingredient) {
        NbtCompound tag = ingredient.getTag().orElse(null);
        return new JeiFluidIngredient(ingredient.getFluid(), ingredient.getAmount(), tag);
    }

    @Override
    public IJeiFluidIngredient normalize(IJeiFluidIngredient ingredient) {
        NbtCompound tag = ingredient.getTag().orElse(null);
        return new JeiFluidIngredient(ingredient.getFluid(), bucketVolume(), tag);
    }

    @Override
    public Optional<IJeiFluidIngredient> getContainedFluid(ITypedIngredient<?> ingredient) {
        return ingredient.getItemStack()
            .map(ContainerItemContext::withConstant)
            .map(c -> c.find(FluidStorage.ITEM))
            .map(Storage::iterator)
            .filter(Iterator::hasNext)
            .map(Iterator::next)
            .map(view -> {
                FluidVariant resource = view.getResource();
                return new JeiFluidIngredient(resource.getFluid(), bucketVolume(), resource.copyNbt());
            });
    }

    private static class AllFluidNbt implements IIngredientSubtypeInterpreter<IJeiFluidIngredient> {
        public static final AllFluidNbt INSTANCE = new AllFluidNbt();

        private AllFluidNbt() {
        }

        @Override
        public String apply(IJeiFluidIngredient storage, UidContext context) {
            return storage.getTag()
                .filter(tag -> !tag.isEmpty())
                .map(NbtCompound::toString)
                .orElse(IIngredientSubtypeInterpreter.NONE);
        }
    }
}
