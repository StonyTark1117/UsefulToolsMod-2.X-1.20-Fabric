package mezz.jei.common.platform;

import mezz.jei.common.input.keys.IJeiKeyMappingCategoryBuilder;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

public interface IPlatformInputHelper {
    boolean isActiveAndMatches(KeyBinding keyMapping, InputUtil.Key key);

    IJeiKeyMappingCategoryBuilder createKeyMappingCategoryBuilder(String name);
}
