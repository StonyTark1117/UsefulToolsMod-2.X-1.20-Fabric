package mezz.jei.common.gui;

import mezz.jei.api.ingredients.IIngredientRenderer;
import mezz.jei.api.ingredients.IIngredientType;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.runtime.IIngredientManager;
import mezz.jei.common.platform.IPlatformRenderHelper;
import mezz.jei.common.platform.Services;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.item.TooltipData;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import java.util.List;
import java.util.Optional;

public final class TooltipRenderer {
	private TooltipRenderer() {
	}

	public static void drawHoveringText(DrawContext guiGraphics, List<Text> textLines, int x, int y) {
		MinecraftClient minecraft = MinecraftClient.getInstance();
		TextRenderer font = minecraft.textRenderer;
		drawHoveringText(guiGraphics, textLines, x, y, ItemStack.EMPTY, font);
	}

	public static <T> void drawHoveringText(DrawContext guiGraphics, List<Text> textLines, int x, int y, ITypedIngredient<T> typedIngredient, IIngredientManager ingredientManager) {
		IIngredientType<T> ingredientType = typedIngredient.getType();
		T ingredient = typedIngredient.getIngredient();
		IIngredientRenderer<T> ingredientRenderer = ingredientManager.getIngredientRenderer(ingredientType);
		drawHoveringText(guiGraphics, textLines, x, y, ingredient, ingredientRenderer);
	}

	public static <T> void drawHoveringText(DrawContext guiGraphics, List<Text> textLines, int x, int y, T ingredient, IIngredientRenderer<T> ingredientRenderer) {
		MinecraftClient minecraft = MinecraftClient.getInstance();
		TextRenderer font = ingredientRenderer.getFontRenderer(minecraft, ingredient);
		ItemStack itemStack = ingredient instanceof ItemStack ? (ItemStack) ingredient : ItemStack.EMPTY;
		drawHoveringText(guiGraphics, textLines, x, y, itemStack, font);
	}

	private static void drawHoveringText(DrawContext guiGraphics, List<Text> textLines, int x, int y, ItemStack itemStack, TextRenderer font) {
		MinecraftClient minecraft = MinecraftClient.getInstance();
		Screen screen = minecraft.currentScreen;
		if (screen == null) {
			return;
		}

		Optional<TooltipData> tooltipImage = itemStack.getTooltipData();
		IPlatformRenderHelper renderHelper = Services.PLATFORM.getRenderHelper();
		renderHelper.renderTooltip(screen, guiGraphics, textLines, tooltipImage, x, y, font, itemStack);
	}
}
