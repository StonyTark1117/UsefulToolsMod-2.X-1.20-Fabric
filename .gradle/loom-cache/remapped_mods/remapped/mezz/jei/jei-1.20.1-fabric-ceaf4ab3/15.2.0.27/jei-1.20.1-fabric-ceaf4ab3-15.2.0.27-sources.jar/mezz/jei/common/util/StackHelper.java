package mezz.jei.common.util;

import mezz.jei.api.helpers.IStackHelper;
import mezz.jei.api.ingredients.subtypes.ISubtypeManager;
import mezz.jei.api.ingredients.subtypes.UidContext;
import mezz.jei.common.platform.Services;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public class StackHelper implements IStackHelper {
	private final ISubtypeManager subtypeManager;

	public StackHelper(ISubtypeManager subtypeManager) {
		this.subtypeManager = subtypeManager;
	}

	@Override
	public boolean isEquivalent(@Nullable ItemStack lhs, @Nullable ItemStack rhs, UidContext context) {
		ErrorUtil.checkNotNull(context, "context");
		if (lhs == rhs) {
			return true;
		}

		if (lhs == null || rhs == null) {
			return false;
		}

		if (lhs.getItem() != rhs.getItem()) {
			return false;
		}

		String keyLhs = getUniqueIdentifierForStack(lhs, context);
		String keyRhs = getUniqueIdentifierForStack(rhs, context);
		return keyLhs.equals(keyRhs);
	}

	@Override
	public String getUniqueIdentifierForStack(ItemStack stack, UidContext context) {
		String result = getRegistryNameForStack(stack);
		String subtypeInfo = subtypeManager.getSubtypeInfo(stack, context);
		if (!subtypeInfo.isEmpty()) {
			result = result + ':' + subtypeInfo;
		}
		return result;
	}

	public static String getRegistryNameForStack(ItemStack stack) {
		ErrorUtil.checkNotEmpty(stack, "stack");

		Item item = stack.getItem();
		return Services.PLATFORM
			.getRegistry(RegistryKeys.ITEM)
			.getRegistryName(item)
			.map(Identifier::toString)
			.orElseThrow(() -> {
				String stackInfo = ErrorUtil.getItemStackInfo(stack);
				return new IllegalStateException("Item has no registry name: " + stackInfo);
			});
	}
}
