package mezz.jei.api.fabric.ingredients.fluids;

import java.util.Optional;
import net.minecraft.fluid.Fluid;
import net.minecraft.nbt.NbtCompound;

/**
 * Built-in ingredient for representing Fluids in Fabric Minecraft.
 *
 * @since 10.1.0
 */
public interface IJeiFluidIngredient {
    /**
     * @return the fluid represented by this ingredient.
     *
     * @since 10.1.0
     */
    Fluid getFluid();

    /**
     * @return the amount of fluid.
     *
     * @since 10.1.0
     */
    long getAmount();

    /**
     * @return optionally any {@link NbtCompound} extra data for this fluid ingredient.
     *
     * @since 10.1.0
     */
    Optional<NbtCompound> getTag();
}
