package mezz.jei.fabric.platform;

import mezz.jei.api.helpers.IStackHelper;
import mezz.jei.common.platform.IPlatformIngredientHelper;
import net.minecraft.item.DyeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.BrewingRecipeRegistry;
import net.minecraft.recipe.Ingredient;
import net.minecraft.util.DyeColor;
import java.util.List;

public class IngredientHelper implements IPlatformIngredientHelper {
    @Override
    public Ingredient createShulkerDyeIngredient(DyeColor color) {
        DyeItem dye = DyeItem.byColor(color);
        return Ingredient.ofItems(dye);
    }

    @Override
    public Ingredient createNbtIngredient(ItemStack stack, IStackHelper stackHelper) {
        // TODO: Implement Fabric NBT-aware ingredients
        return Ingredient.ofStacks(stack);
    }

    @Override
    public List<Ingredient> getPotionContainers() {
        return BrewingRecipeRegistry.POTION_TYPES;
    }
}
