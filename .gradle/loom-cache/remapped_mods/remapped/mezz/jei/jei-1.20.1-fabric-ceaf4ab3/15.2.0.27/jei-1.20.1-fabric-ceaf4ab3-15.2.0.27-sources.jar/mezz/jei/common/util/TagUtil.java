package mezz.jei.common.util;

import com.mojang.datafixers.util.Pair;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

public class TagUtil {
	public static <VALUE, STACK> Optional<Identifier> getTagEquivalent(
		Collection<STACK> stacks,
		Function<STACK, VALUE> stackToValue,
		Supplier<Stream<Pair<TagKey<VALUE>, RegistryEntryList.Named<VALUE>>>> tagSupplier
	) {
		if (stacks.size() < 2) {
			return Optional.empty();
		}

		List<VALUE> values = stacks.stream()
			.map(stackToValue)
			.toList();

		return tagSupplier.get()
			.filter(e -> {
				RegistryEntryList.Named<VALUE> tag = e.getSecond();
				int count = tag.size();
				if (count == values.size()) {
					return IntStream.range(0, count).allMatch(i -> {
						VALUE tagValue = tag.get(i).value();
						VALUE value = values.get(i);
						return value.equals(tagValue);
					});
				}
				return false;
			})
			.map(e -> e.getFirst().id())
			.findFirst();
	}
}
