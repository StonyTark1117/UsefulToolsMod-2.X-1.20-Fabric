package mezz.jei.gui.elements;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.common.gui.elements.DrawableNineSliceTexture;
import mezz.jei.common.gui.textures.Textures;
import mezz.jei.common.input.IInternalKeyMappings;
import mezz.jei.gui.input.IUserInputHandler;
import mezz.jei.gui.input.UserInput;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.screen.ScreenTexts;
import mezz.jei.common.util.ImmutableRect2i;
import java.util.Optional;

/**
 * A gui button that has an {@link IDrawable} instead of a string label.
 */
public class GuiIconButton extends ButtonWidget {
	private final IDrawable icon;
	private final Textures textures;

	public GuiIconButton(IDrawable icon, PressAction pressable, Textures textures) {
		super(0, 0, 0, 0, ScreenTexts.EMPTY, pressable, ButtonWidget.DEFAULT_NARRATION_SUPPLIER);
		this.icon = icon;
		this.textures = textures;
	}

	public void updateBounds(ImmutableRect2i area) {
		setX(area.getX());
		setY(area.getY());
		this.width = area.getWidth();
		this.height = area.getHeight();
	}

	public void setHeight(int value) {
		this.height = value;
	}

	@Override
	public void render(DrawContext guiGraphics, int mouseX, int mouseY, float partialTicks) {
		if (this.visible) {
			RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
			boolean hovered =
				mouseX >= this.getX() &&
				mouseY >= this.getY() &&
				mouseX < this.getX() + this.width &&
				mouseY < this.getY() + this.height;
			RenderSystem.enableBlend();
			RenderSystem.blendFuncSeparate(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SrcFactor.ONE, GlStateManager.DstFactor.ZERO);
			RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
			DrawableNineSliceTexture texture = textures.getButtonForState(this.active, hovered);
			texture.draw(guiGraphics, this.getX(), this.getY(), this.width, this.height);

			int color = 0xFFE0E0E0;
			if (!this.active) {
				color = 0xFFA0A0A0;
			} else if (hovered) {
				color = 0xFFFFFFFF;
			}

			float red = (color >> 16 & 255) / 255.0F;
			float blue = (color >> 8 & 255) / 255.0F;
			float green = (color & 255) / 255.0F;
			float alpha = (color >> 24 & 255) / 255.0F;
			RenderSystem.setShaderColor(red, blue, green, alpha);

			double xOffset = getX() + (width - icon.getWidth()) / 2.0;
			double yOffset = getY() + (height - icon.getHeight()) / 2.0;
			var poseStack = guiGraphics.getMatrices();
			poseStack.push();
			{
				poseStack.translate(xOffset, yOffset, 0);
				icon.draw(guiGraphics);
			}
			poseStack.pop();
			RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
		}
	}

	public IUserInputHandler createInputHandler() {
		return new UserInputHandler(this);
	}

	private class UserInputHandler implements IUserInputHandler {
		private final GuiIconButton button;

		public UserInputHandler(GuiIconButton button) {
			this.button = button;
		}

		@Override
		public Optional<IUserInputHandler> handleUserInput(Screen screen, UserInput input, IInternalKeyMappings keyBindings) {
			if (!input.isMouse()) {
				return Optional.empty();
			}
			double mouseX = input.getMouseX();
			double mouseY = input.getMouseY();
			if (!this.button.active || !this.button.visible || !isMouseOver(mouseX, mouseY)) {
				return Optional.empty();
			}
			if (!this.button.isValidClickButton(input.getKey().getCode())) {
				return Optional.empty();
			}
			boolean flag = this.button.clicked(mouseX, mouseY);
			if (!flag) {
				return Optional.empty();
			}
			if (!input.isSimulate()) {
				this.button.playDownSound(MinecraftClient.getInstance().getSoundManager());
				this.button.onClick(mouseX, mouseY);
			}
			return Optional.of(this);
		}
	}
}
