package mezz.jei.library.gui.recipes;

import mezz.jei.api.gui.ingredient.IRecipeSlotTooltipCallback;
import mezz.jei.api.gui.ingredient.IRecipeSlotView;
import mezz.jei.api.helpers.IModIdHelper;
import mezz.jei.api.ingredients.IIngredientHelper;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.runtime.IIngredientManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import java.util.List;
import java.util.Optional;

public class OutputSlotTooltipCallback implements IRecipeSlotTooltipCallback {
	private final Identifier recipeName;
	private final IModIdHelper modIdHelper;
	private final IIngredientManager ingredientManager;

	public OutputSlotTooltipCallback(
		Identifier recipeName,
		IModIdHelper modIdHelper,
		IIngredientManager ingredientManager
	) {
		this.recipeName = recipeName;
		this.modIdHelper = modIdHelper;
		this.ingredientManager = ingredientManager;
	}

	@Override
	public void onTooltip(IRecipeSlotView recipeSlotView, List<Text> tooltip) {
		if (recipeSlotView.getRole() != RecipeIngredientRole.OUTPUT) {
			return;
		}
		Optional<ITypedIngredient<?>> displayedIngredient = recipeSlotView.getDisplayedIngredient();
		if (displayedIngredient.isEmpty()) {
			return;
		}

		if (modIdHelper.isDisplayingModNameEnabled()) {
			Identifier ingredientName = getResourceLocation(displayedIngredient.get());

			String recipeModId = recipeName.getNamespace();
			String ingredientModId = ingredientName.getNamespace();
			if (!recipeModId.equals(ingredientModId)) {
				String modName = modIdHelper.getFormattedModNameForModId(recipeModId);
				MutableText recipeBy = Text.translatable("jei.tooltip.recipe.by", modName);
				tooltip.add(recipeBy.formatted(Formatting.GRAY));
			}
		}

		MinecraftClient minecraft = MinecraftClient.getInstance();
		boolean showAdvanced = minecraft.options.advancedItemTooltips || Screen.hasShiftDown();
		if (showAdvanced) {
			MutableText recipeId = Text.translatable("jei.tooltip.recipe.id", recipeName.toString());
			tooltip.add(recipeId.formatted(Formatting.DARK_GRAY));
		}
	}

	private <T> Identifier getResourceLocation(ITypedIngredient<T> ingredient) {
		IIngredientHelper<T> ingredientHelper = ingredientManager.getIngredientHelper(ingredient.getType());
		return ingredientHelper.getResourceLocation(ingredient.getIngredient());
	}
}
