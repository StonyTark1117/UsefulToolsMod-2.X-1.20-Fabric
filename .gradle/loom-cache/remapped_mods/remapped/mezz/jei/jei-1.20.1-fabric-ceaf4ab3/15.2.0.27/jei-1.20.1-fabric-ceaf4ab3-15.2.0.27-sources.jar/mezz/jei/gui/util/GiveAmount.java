package mezz.jei.gui.util;

import net.minecraft.item.ItemStack;

public enum GiveAmount {
	ONE, MAX;

	public int getAmountForStack(ItemStack itemStack) {
		return switch (this) {
			case MAX -> itemStack.getMaxCount();
			case ONE -> 1;
		};
	}
}
