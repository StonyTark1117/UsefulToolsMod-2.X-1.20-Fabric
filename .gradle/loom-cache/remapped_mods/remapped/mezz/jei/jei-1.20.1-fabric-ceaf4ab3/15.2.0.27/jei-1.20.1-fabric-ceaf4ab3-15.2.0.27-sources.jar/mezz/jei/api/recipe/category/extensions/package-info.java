@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.recipe.category.extensions;

import javax.annotation.ParametersAreNonnullByDefault;
