package mezz.jei.common.network;

import net.minecraft.network.PacketByteBuf;

public record ServerPacketData(PacketByteBuf buf, ServerPacketContext context) {
}
