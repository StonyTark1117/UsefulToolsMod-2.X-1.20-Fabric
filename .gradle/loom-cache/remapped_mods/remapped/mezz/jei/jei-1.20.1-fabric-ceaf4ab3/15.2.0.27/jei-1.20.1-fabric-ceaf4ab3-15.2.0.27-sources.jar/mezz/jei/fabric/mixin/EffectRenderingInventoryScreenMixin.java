package mezz.jei.fabric.mixin;

import mezz.jei.api.runtime.IIngredientListOverlay;
import mezz.jei.api.runtime.IJeiRuntime;
import mezz.jei.fabric.plugins.fabric.FabricGuiPlugin;
import net.minecraft.client.gui.screen.ingame.AbstractInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(AbstractInventoryScreen.class)
public abstract class EffectRenderingInventoryScreenMixin extends HandledScreen<ScreenHandler> {
    public EffectRenderingInventoryScreenMixin(ScreenHandler menu, PlayerInventory inventory, Text component) {
        super(menu, inventory, component);
    }

    @ModifyVariable(
        method = "renderEffects(Lnet/minecraft/client/gui/GuiGraphics;II)V",
        index = 7,
        name = "bl",
        at = @At("STORE")
    )
    public boolean modifyHasRoom(boolean bl) {
        boolean ingredientListDisplayed = FabricGuiPlugin.getRuntime()
            .map(IJeiRuntime::getIngredientListOverlay)
            .map(IIngredientListOverlay::isListDisplayed)
            .orElse(false);

        if (ingredientListDisplayed) {
            // make the potion effects think that there is not enough room,
            // so they render in compact mode.
            return false;
        }
        return bl;
    }
}
