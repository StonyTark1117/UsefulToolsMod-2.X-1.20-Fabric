package mezz.jei.common.network;

import mezz.jei.common.network.packets.PacketJei;
import net.minecraft.server.network.ServerPlayerEntity;

public interface IConnectionToClient {
    void sendPacketToClient(PacketJei packet, ServerPlayerEntity player);
}
