package mezz.jei.fabric.platform;

import mezz.jei.common.platform.IPlatformScreenHelper;
import mezz.jei.common.util.ImmutableRect2i;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.recipebook.RecipeBookProvider;
import net.minecraft.client.gui.screen.recipebook.RecipeBookWidget;
import net.minecraft.client.gui.screen.recipebook.RecipeGroupButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.screen.slot.Slot;
import java.util.List;
import java.util.Optional;

public class ScreenHelper implements IPlatformScreenHelper {
    @Override
    public Optional<Slot> getSlotUnderMouse(HandledScreen<?> containerScreen) {
        Slot slot = containerScreen.focusedSlot;
        return Optional.ofNullable(slot);
    }

    @Override
    public int getGuiLeft(HandledScreen<?> containerScreen) {
        return containerScreen.x;
    }

    @Override
    public int getGuiTop(HandledScreen<?> containerScreen) {
        return containerScreen.y;
    }

    @Override
    public int getXSize(HandledScreen<?> containerScreen) {
        return containerScreen.backgroundWidth;
    }

    @Override
    public int getYSize(HandledScreen<?> containerScreen) {
        return containerScreen.backgroundHeight;
    }

    @Override
    public ImmutableRect2i getBookArea(RecipeBookProvider containerScreen) {
        RecipeBookWidget guiRecipeBook = containerScreen.getRecipeBookWidget();
        if (guiRecipeBook.isOpen()) {
            int i = (guiRecipeBook.parentWidth - 147) / 2 - guiRecipeBook.leftOffset;
            int j = (guiRecipeBook.parentHeight - 166) / 2;
            return new ImmutableRect2i(i, j, 147, 166);
        }
        return ImmutableRect2i.EMPTY;
    }

    @Override
    public List<RecipeGroupButtonWidget> getTabButtons(RecipeBookWidget recipeBookComponent) {
        return recipeBookComponent.tabButtons;
    }

    @Override
    public void setFocused(ClickableWidget widget, boolean value) {
        widget.setFocused(value);
    }
}
