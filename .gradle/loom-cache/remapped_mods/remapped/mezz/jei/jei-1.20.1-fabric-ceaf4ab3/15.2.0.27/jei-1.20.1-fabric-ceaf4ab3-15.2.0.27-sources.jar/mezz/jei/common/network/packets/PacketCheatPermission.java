package mezz.jei.common.network.packets;

import mezz.jei.common.network.ClientPacketContext;
import mezz.jei.common.network.ClientPacketData;
import mezz.jei.common.network.IPacketId;
import mezz.jei.common.network.PacketIdClient;
import mezz.jei.common.network.packets.handlers.ClientCheatPermissionHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.PacketByteBuf;
import java.util.concurrent.CompletableFuture;

public class PacketCheatPermission extends PacketJei {
	private final boolean hasPermission;

	public PacketCheatPermission(boolean hasPermission) {
		this.hasPermission = hasPermission;
	}

	@Override
	public IPacketId getPacketId() {
		return PacketIdClient.CHEAT_PERMISSION;
	}

	@Override
	public void writePacketData(PacketByteBuf buf) {
		buf.writeBoolean(hasPermission);
	}

	public static CompletableFuture<Void> readPacketData(ClientPacketData data) {
		PacketByteBuf buf = data.buf();
		boolean hasPermission = buf.readBoolean();
		MinecraftClient minecraft = MinecraftClient.getInstance();
		ClientPacketContext context = data.context();
		return minecraft.submit(() -> ClientCheatPermissionHandler.handleHasCheatPermission(context, hasPermission));
	}
}
