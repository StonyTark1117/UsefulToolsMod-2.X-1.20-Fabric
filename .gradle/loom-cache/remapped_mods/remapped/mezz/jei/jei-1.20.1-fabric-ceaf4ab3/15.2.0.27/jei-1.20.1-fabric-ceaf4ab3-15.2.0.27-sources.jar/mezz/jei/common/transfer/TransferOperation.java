package mezz.jei.common.transfer;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;

/**
 * Represents transferring an ItemStack from inventorySlot to craftingSlot.
 */
public record TransferOperation(Slot inventorySlot, Slot craftingSlot) {
	public static TransferOperation readPacketData(PacketByteBuf buf, ScreenHandler container) {
		int inventorySlotIndex = buf.readVarInt();
		int craftingSlotIndex = buf.readVarInt();

		Slot inventorySlot = container.getSlot(inventorySlotIndex);
		Slot craftingSlot = container.getSlot(craftingSlotIndex);
		return new TransferOperation(inventorySlot, craftingSlot);
	}

	public void writePacketData(PacketByteBuf buf) {
		buf.writeVarInt(inventorySlot.id);
		buf.writeVarInt(craftingSlot.id);
	}
}
