package mezz.jei.common.platform;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

public interface IPlatformItemStackHelper {
    int getBurnTime(ItemStack itemStack);

    boolean isBookEnchantable(ItemStack stack, ItemStack book);

    Optional<String> getCreatorModId(ItemStack stack);

    List<Text> getTestTooltip(@Nullable PlayerEntity player, ItemStack itemStack);
}
