package mezz.jei.common.gui.textures;

import mezz.jei.api.constants.ModIds;
import mezz.jei.common.Constants;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteAtlasHolder;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.util.Identifier;

public class JeiSpriteUploader extends SpriteAtlasHolder {
	public JeiSpriteUploader(TextureManager textureManager) {
		super(textureManager, Constants.LOCATION_JEI_GUI_TEXTURE_ATLAS, new Identifier(ModIds.JEI_ID, "gui"));
	}

	/**
	 * Overridden to make it public
	 */
	@Override
	public Sprite getSprite(Identifier location) {
		return super.getSprite(location);
	}

}
