package mezz.jei.common.input.keys;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

public enum JeiKeyModifier {
    CONTROL_OR_COMMAND {
        @Override
        public boolean isActive(JeiKeyConflictContext context) {
            return Screen.hasControlDown();
        }

        @Override
        public Text getCombinedName(InputUtil.Key key) {
            if (MinecraftClient.IS_SYSTEM_MAC) {
                return Text.translatable("jei.key.combo.command", key.getLocalizedText());
            } else {
                return Text.translatable("jei.key.combo.control", key.getLocalizedText());
            }
        }
    },
    SHIFT {
        @Override
        public boolean isActive(JeiKeyConflictContext context) {
            return Screen.hasShiftDown();
        }

        @Override
        public Text getCombinedName(InputUtil.Key key) {
            return Text.translatable("jei.key.combo.shift", key.getLocalizedText());
        }
    },
    ALT {
        @Override
        public boolean isActive(JeiKeyConflictContext context) {
            return Screen.hasAltDown();
        }

        @Override
        public Text getCombinedName(InputUtil.Key key) {
            return Text.translatable("jei.key.combo.alt", key.getLocalizedText());
        }
    },
    NONE {
        @Override
        public boolean isActive(JeiKeyConflictContext context) {
            if (context.conflicts(JeiKeyConflictContext.IN_GAME)) {
                return true;
            }
            return !CONTROL_OR_COMMAND.isActive(context) &&
                !SHIFT.isActive(context) &&
                !ALT.isActive(context);
        }

        @Override
        public Text getCombinedName(InputUtil.Key key) {
            return key.getLocalizedText();
        }
    };

    public abstract boolean isActive(JeiKeyConflictContext context);

    public abstract Text getCombinedName(InputUtil.Key key);
}
