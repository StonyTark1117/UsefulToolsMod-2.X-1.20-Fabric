package mezz.jei.common.util;

import java.util.ArrayList;
import java.util.List;
import mezz.jei.api.ingredients.IIngredientRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class IngredientTooltipHelper {
	private static final Logger LOGGER = LogManager.getLogger();

	public static <V> List<Text> getMutableIngredientTooltipSafe(V ingredient, IIngredientRenderer<V> ingredientRenderer) {
		try {
			MinecraftClient minecraft = MinecraftClient.getInstance();
			TooltipContext.Default tooltipFlag = minecraft.options.advancedItemTooltips ? TooltipContext.Default.ADVANCED : TooltipContext.Default.BASIC;
			List<Text> tooltip = ingredientRenderer.getTooltip(ingredient, tooltipFlag);
			return new ArrayList<>(tooltip);
		} catch (RuntimeException | LinkageError e) {
			LOGGER.error("Tooltip crashed.", e);
		}

		List<Text> tooltip = new ArrayList<>();
		MutableText translated = Text.translatable("jei.tooltip.error.crash");
		tooltip.add(translated.formatted(Formatting.RED));
		return tooltip;
	}
}
