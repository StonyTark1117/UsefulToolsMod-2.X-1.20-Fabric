package mezz.jei.fabric.events;

import mezz.jei.api.constants.ModIds;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceReloader;
import net.minecraft.util.Identifier;
import net.minecraft.util.profiler.Profiler;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public class JeiIdentifiableResourceReloadListener implements IdentifiableResourceReloadListener {
    private final Identifier fabricId;
    private final ResourceReloader listener;

    public JeiIdentifiableResourceReloadListener(String id, ResourceReloader listener) {
        this.fabricId = new Identifier(ModIds.JEI_ID, id);
        this.listener = listener;
    }

    @Override
    public Identifier getFabricId() {
        return this.fabricId;
    }

    @Override
    public CompletableFuture<Void> reload(Synchronizer preparationBarrier, ResourceManager resourceManager, Profiler profilerFiller, Profiler profilerFiller2, Executor executor, Executor executor2) {
        return listener.reload(preparationBarrier, resourceManager, profilerFiller, profilerFiller2, executor, executor2);
    }
}
