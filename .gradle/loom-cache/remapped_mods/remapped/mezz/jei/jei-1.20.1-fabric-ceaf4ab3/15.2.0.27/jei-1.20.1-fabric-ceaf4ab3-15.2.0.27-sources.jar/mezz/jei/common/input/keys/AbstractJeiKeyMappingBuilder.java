package mezz.jei.common.input.keys;

import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public abstract class AbstractJeiKeyMappingBuilder implements IJeiKeyMappingBuilder {
    protected abstract IJeiKeyMappingInternal buildMouse(int mouseButton);

    @Override
    public final IJeiKeyMappingInternal buildMouseLeft() {
        return buildMouse(InputUtil.field_32000);
    }

    @Override
    public final IJeiKeyMappingInternal buildMouseRight() {
        return buildMouse(InputUtil.field_32002);
    }

    @Override
    public final IJeiKeyMappingInternal buildMouseMiddle() {
        return buildMouse(InputUtil.field_32001);
    }

    @Override
    public final IJeiKeyMappingInternal buildUnbound() {
        return buildKeyboardKey(GLFW.GLFW_KEY_UNKNOWN);
    }
}
