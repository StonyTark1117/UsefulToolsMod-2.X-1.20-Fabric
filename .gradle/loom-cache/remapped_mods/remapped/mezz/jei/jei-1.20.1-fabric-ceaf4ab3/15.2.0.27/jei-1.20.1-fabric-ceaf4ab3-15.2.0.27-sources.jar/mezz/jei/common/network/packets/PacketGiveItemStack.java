package mezz.jei.common.network.packets;

import mezz.jei.common.network.IPacketId;
import mezz.jei.common.network.PacketIdServer;
import mezz.jei.common.network.ServerPacketContext;
import mezz.jei.common.network.ServerPacketData;
import mezz.jei.common.config.GiveMode;
import mezz.jei.common.util.ServerCommandUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import java.util.concurrent.CompletableFuture;

public class PacketGiveItemStack extends PacketJei {
	private final ItemStack itemStack;
	private final GiveMode giveMode;

	public PacketGiveItemStack(ItemStack itemStack, GiveMode giveMode) {
		this.itemStack = itemStack;
		this.giveMode = giveMode;
	}

	@Override
	public IPacketId getPacketId() {
		return PacketIdServer.GIVE_ITEM;
	}

	@Override
	public void writePacketData(PacketByteBuf buf) {
		buf.writeItemStack(itemStack);
		buf.writeEnumConstant(giveMode);
	}

	public static CompletableFuture<Void> readPacketData(ServerPacketData data) {
		PacketByteBuf buf = data.buf();
		ItemStack itemStack = buf.readItemStack();
		GiveMode giveMode = buf.readEnumConstant(GiveMode.class);
		ServerPacketContext context = data.context();
		ServerPlayerEntity player = context.player();
		MinecraftServer server = player.server;
		return server.submit(() -> ServerCommandUtil.executeGive(context, itemStack, giveMode));
	}
}
