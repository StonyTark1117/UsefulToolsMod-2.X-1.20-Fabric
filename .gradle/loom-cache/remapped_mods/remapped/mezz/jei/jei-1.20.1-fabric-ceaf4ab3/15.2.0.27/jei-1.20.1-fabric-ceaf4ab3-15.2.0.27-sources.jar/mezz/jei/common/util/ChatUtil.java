package mezz.jei.common.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Utilities for chat messages.
 */
public final class ChatUtil {
	private ChatUtil() {
	}

	public static void writeChatMessage(ClientPlayerEntity player, String translationKey, Formatting color) {
		Text component = Text.translatable(translationKey);
		component.getStyle().withFormatting(color);
		player.sendMessage(component);
	}
}
