package mezz.jei.common;

import mezz.jei.api.recipe.RecipeType;
import net.minecraft.util.Identifier;
import mezz.jei.api.constants.ModIds;

public final class Constants {
	public static final String TEXTURE_GUI_PATH = "textures/jei/gui/";
	public static final String TEXTURE_GUI_VANILLA = Constants.TEXTURE_GUI_PATH + "gui_vanilla.png";

	public static final Identifier RECIPE_GUI_VANILLA = new Identifier(ModIds.JEI_ID, TEXTURE_GUI_VANILLA);

	public static final RecipeType<?> UNIVERSAL_RECIPE_TRANSFER_TYPE = RecipeType.create(ModIds.JEI_ID, "universal_recipe_transfer_handler", Object.class);
	public static final Identifier LOCATION_JEI_GUI_TEXTURE_ATLAS = new Identifier(ModIds.JEI_ID, "textures/atlas/gui.png");
	public static final Identifier NETWORK_CHANNEL_ID = new Identifier(ModIds.JEI_ID, "channel");

	/**
	 * Ingredients with this tag will be hidden from JEI.
	 */
	public static final Identifier HIDDEN_INGREDIENT_TAG = new Identifier("c", "hidden_from_recipe_viewers");

	private Constants() {

	}
}
