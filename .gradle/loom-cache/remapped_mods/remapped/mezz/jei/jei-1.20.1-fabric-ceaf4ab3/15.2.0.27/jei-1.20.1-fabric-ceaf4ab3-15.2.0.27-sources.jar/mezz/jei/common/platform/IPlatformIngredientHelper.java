package mezz.jei.common.platform;

import mezz.jei.api.helpers.IStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.Ingredient;
import net.minecraft.util.DyeColor;
import java.util.List;

public interface IPlatformIngredientHelper {
    Ingredient createShulkerDyeIngredient(DyeColor color);

    Ingredient createNbtIngredient(ItemStack stack, IStackHelper stackHelper);

    List<Ingredient> getPotionContainers();
}
