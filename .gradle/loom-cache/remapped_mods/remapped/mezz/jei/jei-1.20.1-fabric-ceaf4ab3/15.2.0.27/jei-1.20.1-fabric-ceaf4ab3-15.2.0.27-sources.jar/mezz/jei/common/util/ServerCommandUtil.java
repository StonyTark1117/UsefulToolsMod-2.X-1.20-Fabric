package mezz.jei.common.util;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.RootCommandNode;
import mezz.jei.common.network.IConnectionToClient;
import mezz.jei.common.network.ServerPacketContext;
import mezz.jei.common.network.packets.PacketCheatPermission;
import mezz.jei.common.config.GiveMode;
import mezz.jei.common.config.IServerConfig;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Collection;
import java.util.Optional;

/**
 * Server-side-safe utilities for commands.
 */
public final class ServerCommandUtil {
	private static final Logger LOGGER = LogManager.getLogger();

	private ServerCommandUtil() {
	}

	public static boolean hasPermissionForCheatMode(ServerPlayerEntity sender, IServerConfig serverConfig) {
		if (serverConfig.isCheatModeEnabledForCreative() &&
			sender.isCreative()) {
			return true;
		}

		ServerCommandSource commandSource = sender.getCommandSource();
		if (serverConfig.isCheatModeEnabledForOp()) {
			MinecraftServer minecraftServer = sender.getServer();
			if (minecraftServer != null) {
				int opPermissionLevel = minecraftServer.getOpPermissionLevel();
				return commandSource.hasPermissionLevel(opPermissionLevel);
			}
		}

		if (serverConfig.isCheatModeEnabledForGive()) {
			return getGiveCommand(sender)
				.map(giveCommand -> giveCommand.canUse(commandSource))
				.orElse(false);
		}

		return false;
	}

	/**
	 * Gives a player an item.
	 */
	public static void executeGive(
		ServerPacketContext context,
		ItemStack itemStack,
		GiveMode giveMode
	) {
		ServerPlayerEntity sender = context.player();
		IServerConfig serverConfig = context.serverConfig();
		if (hasPermissionForCheatMode(sender, serverConfig)) {
			if (itemStack.isEmpty()) {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Player '{} ({})' tried to give an empty ItemStack.", sender.getName(), sender.getUuid());
				}
				return;
			}
			if (giveMode == GiveMode.INVENTORY) {
				giveToInventory(sender, itemStack);
			} else if (giveMode == GiveMode.MOUSE_PICKUP) {
				mousePickupItemStack(sender, itemStack);
			}
		} else {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Player '{} ({})' tried to cheat an ItemStack '{}' but does not have permission.", sender.getName(), sender.getUuid(), itemStack.toHoverableText());
			}
			IConnectionToClient connection = context.connection();
			connection.sendPacketToClient(new PacketCheatPermission(false), sender);
		}
	}

	public static void setHotbarSlot(
		ServerPacketContext context,
		ItemStack itemStack,
		int hotbarSlot
	) {
		ServerPlayerEntity sender = context.player();
		IServerConfig serverConfig = context.serverConfig();
		if (hasPermissionForCheatMode(sender, serverConfig)) {
			if (itemStack.isEmpty()) {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Player '{} ({})' tried to set an empty ItemStack to the hotbar slot: {}", sender.getName(), sender.getUuid(), hotbarSlot);
				}
				return;
			}
			if (!PlayerInventory.isValidHotbarIndex(hotbarSlot)) {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Player '{} ({})' tried to set slot that is not in the hotbar: {}", sender.getName(), sender.getUuid(), hotbarSlot);
				}
				return;
			}
			ItemStack stackInSlot = sender.getInventory().getStack(hotbarSlot);
			if (ItemStack.areEqual(stackInSlot, itemStack)) {
				return;
			}
			ItemStack itemStackCopy = itemStack.copy();
			sender.getInventory().setStack(hotbarSlot, itemStack);
			sender.getWorld().playSound(null, sender.getX(), sender.getY(), sender.getZ(), SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.PLAYERS, 0.2F, ((sender.getRandom().nextFloat() - sender.getRandom().nextFloat()) * 0.7F + 1.0F) * 2.0F);
			sender.playerScreenHandler.sendContentUpdates();
			notifyGive(sender, itemStackCopy);
		} else {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Player '{} ({})' tried to cheat an item '{}' to their hotbar but does not have permission.", sender.getName(), sender.getUuid(), itemStack.toHoverableText());
			}
			IConnectionToClient connection = context.connection();
			connection.sendPacketToClient(new PacketCheatPermission(false), sender);
		}
	}

	public static void mousePickupItemStack(PlayerEntity sender, ItemStack itemStack) {
		ScreenHandler containerMenu = sender.currentScreenHandler;

		ItemStack itemStackCopy = itemStack.copy();
		ItemStack existingStack = containerMenu.getCursorStack();

		final int giveCount;
		if (canStack(existingStack, itemStack)) {
			int newCount = Math.min(existingStack.getMaxCount(), existingStack.getCount() + itemStack.getCount());
			giveCount = newCount - existingStack.getCount();
			if (giveCount > 0) {
				existingStack.setCount(newCount);
			}
		} else {
			containerMenu.setCursorStack(itemStack);
			giveCount = itemStack.getCount();
		}

		if (giveCount > 0) {
			itemStackCopy.setCount(giveCount);
			notifyGive(sender, itemStackCopy);
			containerMenu.sendContentUpdates();
		}
	}

	public static boolean canStack(ItemStack a, ItemStack b) {
		ItemStack singleA = a.copyWithCount(1);
		ItemStack singleB = b.copyWithCount(1);
		return ItemEntity.canMerge(singleA, singleB);
	}

	/**
	 * Gives a player an item.
	 *
	 * @see GiveCommand#giveItem(CommandSource, ItemInput, Collection, int)
	 */
	@SuppressWarnings("JavadocReference")
	private static void giveToInventory(PlayerEntity entityplayermp, ItemStack itemStack) {
		ItemStack itemStackCopy = itemStack.copy();
		boolean flag = entityplayermp.getInventory().insertStack(itemStack);
		if (flag && itemStack.isEmpty()) {
			itemStack.setCount(1);
			ItemEntity entityitem = entityplayermp.dropItem(itemStack, false);
			if (entityitem != null) {
				entityitem.setDespawnImmediately();
			}

			entityplayermp.getWorld().playSound(null, entityplayermp.getX(), entityplayermp.getY(), entityplayermp.getZ(), SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.PLAYERS, 0.2F, ((entityplayermp.getRandom().nextFloat() - entityplayermp.getRandom().nextFloat()) * 0.7F + 1.0F) * 2.0F);
			entityplayermp.playerScreenHandler.sendContentUpdates();
		} else {
			ItemEntity entityitem = entityplayermp.dropItem(itemStack, false);
			if (entityitem != null) {
				entityitem.resetPickupDelay();
				entityitem.setOwner(entityplayermp.getUuid());
			}
		}

		notifyGive(entityplayermp, itemStackCopy);
	}

	private static void notifyGive(PlayerEntity player, ItemStack stack) {
		if (player.getServer() == null) {
			return;
		}
		ServerCommandSource commandSource = player.getCommandSource();
		int count = stack.getCount();
		Text stackTextComponent = stack.toHoverableText();
		Text displayName = player.getDisplayName();
		Text message = Text.translatable("commands.give.success.single", count, stackTextComponent, displayName);
		commandSource.sendFeedback(() -> message, true);
	}

	private static Optional<CommandNode<ServerCommandSource>> getGiveCommand(PlayerEntity sender) {
		return Optional.ofNullable(sender.getServer())
			.map(minecraftServer -> {
				CommandManager commandManager = minecraftServer.getCommandManager();
				CommandDispatcher<ServerCommandSource> dispatcher = commandManager.getDispatcher();
				RootCommandNode<ServerCommandSource> root = dispatcher.getRoot();
				return root.getChild("give");
			});
	}
}
