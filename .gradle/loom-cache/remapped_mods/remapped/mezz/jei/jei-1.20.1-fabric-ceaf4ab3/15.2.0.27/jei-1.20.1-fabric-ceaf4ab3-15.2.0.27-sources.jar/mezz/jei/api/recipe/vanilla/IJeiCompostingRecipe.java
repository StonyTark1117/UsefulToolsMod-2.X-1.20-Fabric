package mezz.jei.api.recipe.vanilla;

import org.jetbrains.annotations.Unmodifiable;

import javax.annotation.Nonnegative;
import net.minecraft.block.ComposterBlock;
import net.minecraft.item.ItemStack;
import java.util.List;

/**
 * Recipes representing ingredients that can be composted in the composter.
 *
 * JEI automatically creates these recipes from {@link ComposterBlock#ITEM_TO_LEVEL_INCREASE_CHANCE}.
 *
 * @since 9.5.0
 */
public interface IJeiCompostingRecipe {
	/**
	 * Get the inputs to this recipe.
	 * @since 9.5.0
	 */
	@Unmodifiable
	List<ItemStack> getInputs();

	/**
	 * Get the chance of this input adding a level of compost to the composter.
	 *
	 * @since 9.5.0
	 */
	@Nonnegative
	float getChance();
}
