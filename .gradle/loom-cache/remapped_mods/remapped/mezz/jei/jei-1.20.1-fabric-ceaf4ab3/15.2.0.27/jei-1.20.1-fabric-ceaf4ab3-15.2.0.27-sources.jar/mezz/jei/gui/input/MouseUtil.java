package mezz.jei.gui.input;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;

public final class MouseUtil {
	public static double getX() {
		MinecraftClient minecraft = MinecraftClient.getInstance();
		Mouse mouseHelper = minecraft.mouse;
		double scale = (double) minecraft.getWindow().getScaledWidth() / (double) minecraft.getWindow().getWidth();
		return mouseHelper.getX() * scale;
	}

	public static double getY() {
		MinecraftClient minecraft = MinecraftClient.getInstance();
		Mouse mouseHelper = minecraft.mouse;
		double scale = (double) minecraft.getWindow().getScaledHeight() / (double) minecraft.getWindow().getHeight();
		return mouseHelper.getY() * scale;
	}
}
