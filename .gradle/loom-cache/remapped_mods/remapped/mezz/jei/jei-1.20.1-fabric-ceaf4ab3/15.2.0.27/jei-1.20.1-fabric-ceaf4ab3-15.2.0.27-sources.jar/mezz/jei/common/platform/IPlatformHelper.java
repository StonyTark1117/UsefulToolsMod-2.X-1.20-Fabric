package mezz.jei.common.platform;

import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;

public interface IPlatformHelper {
    <T> IPlatformRegistry<T> getRegistry(RegistryKey<? extends Registry<T>> key);

    IPlatformItemStackHelper getItemStackHelper();

    IPlatformFluidHelperInternal<?> getFluidHelper();

    IPlatformRenderHelper getRenderHelper();

    IPlatformRecipeHelper getRecipeHelper();

    IPlatformConfigHelper getConfigHelper();

    IPlatformInputHelper getInputHelper();

    IPlatformScreenHelper getScreenHelper();

    IPlatformIngredientHelper getIngredientHelper();

    IPlatformModHelper getModHelper();
}
