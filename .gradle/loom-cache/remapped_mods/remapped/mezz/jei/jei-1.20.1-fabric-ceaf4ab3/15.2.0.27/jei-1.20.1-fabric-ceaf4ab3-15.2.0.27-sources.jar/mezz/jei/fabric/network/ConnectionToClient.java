package mezz.jei.fabric.network;

import mezz.jei.common.Constants;
import mezz.jei.common.network.IConnectionToClient;
import mezz.jei.common.network.packets.PacketJei;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import org.apache.commons.lang3.tuple.Pair;

public class ConnectionToClient implements IConnectionToClient {
	@Override
	public void sendPacketToClient(PacketJei packet, ServerPlayerEntity player) {
		Pair<PacketByteBuf, Integer> packetData = packet.getPacketData();
		PacketByteBuf buf = packetData.getLeft();
		ServerPlayNetworking.send(player, Constants.NETWORK_CHANNEL_ID, buf);
	}
}
