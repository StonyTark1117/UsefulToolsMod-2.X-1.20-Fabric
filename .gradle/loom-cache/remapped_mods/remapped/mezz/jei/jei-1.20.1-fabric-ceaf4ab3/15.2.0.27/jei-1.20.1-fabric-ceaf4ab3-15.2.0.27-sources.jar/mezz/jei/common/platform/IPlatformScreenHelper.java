package mezz.jei.common.platform;

import mezz.jei.common.util.ImmutableRect2i;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.recipebook.RecipeBookProvider;
import net.minecraft.client.gui.screen.recipebook.RecipeBookWidget;
import net.minecraft.client.gui.screen.recipebook.RecipeGroupButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.screen.slot.Slot;
import java.util.List;
import java.util.Optional;

public interface IPlatformScreenHelper {
    Optional<Slot> getSlotUnderMouse(HandledScreen<?> containerScreen);

    int getGuiLeft(HandledScreen<?> containerScreen);

    int getGuiTop(HandledScreen<?> containerScreen);

    int getXSize(HandledScreen<?> containerScreen);

    int getYSize(HandledScreen<?> containerScreen);

    ImmutableRect2i getBookArea(RecipeBookProvider containerScreen);

    List<RecipeGroupButtonWidget> getTabButtons(RecipeBookWidget recipeBookComponent);

    void setFocused(ClickableWidget widget, boolean value);
}
