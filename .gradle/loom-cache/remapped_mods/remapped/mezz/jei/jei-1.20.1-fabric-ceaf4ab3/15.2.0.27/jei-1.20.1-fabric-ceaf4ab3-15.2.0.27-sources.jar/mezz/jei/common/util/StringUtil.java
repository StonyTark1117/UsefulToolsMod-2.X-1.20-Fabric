package mezz.jei.common.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextHandler;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.text.MutableText;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

public final class StringUtil {
	private StringUtil() {

	}

	public static Text stripStyling(Text textComponent) {
		MutableText text = textComponent.copyContentOnly();
		for (Text sibling : textComponent.getSiblings()) {
			text.append(stripStyling(sibling));
		}
		return text;
	}

	public static Text truncateStringToWidth(Text text, int width, TextRenderer fontRenderer) {
		int ellipsisWidth = fontRenderer.getWidth("...");
		StringVisitable truncatedText = fontRenderer.trimToWidth(text, width - ellipsisWidth);
		String truncatedTextString = truncatedText.getString();
		return Text.literal(truncatedTextString + "...");
	}

	public static List<StringVisitable> splitLines(List<StringVisitable> lines, int width) {
		if (width <= 0) {
			return List.copyOf(lines);
		}

		MinecraftClient minecraft = MinecraftClient.getInstance();
		TextRenderer font = minecraft.textRenderer;
		TextHandler splitter = font.getTextHandler();
		return lines.stream()
			.flatMap(text -> splitter.wrapLines(text, width, Style.EMPTY).stream())
			.toList();
	}

	public static List<StringVisitable> expandNewlines(Text... descriptionComponents) {
		List<StringVisitable> descriptionLinesExpanded = new ArrayList<>();
		for (Text descriptionLine : descriptionComponents) {
			ExpandNewLineTextAcceptor newLineTextAcceptor = new ExpandNewLineTextAcceptor();
			descriptionLine.visit(newLineTextAcceptor, Style.EMPTY);
			newLineTextAcceptor.addLinesTo(descriptionLinesExpanded);
		}
		return descriptionLinesExpanded;
	}

	public static String intsToString(Collection<Integer> indexes) {
		return indexes.stream()
			.sorted()
			.map(i -> Integer.toString(i))
			.collect(Collectors.joining(", "));
	}
}
