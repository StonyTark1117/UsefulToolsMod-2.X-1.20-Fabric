@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.library.config.serializers;

import javax.annotation.ParametersAreNonnullByDefault;
