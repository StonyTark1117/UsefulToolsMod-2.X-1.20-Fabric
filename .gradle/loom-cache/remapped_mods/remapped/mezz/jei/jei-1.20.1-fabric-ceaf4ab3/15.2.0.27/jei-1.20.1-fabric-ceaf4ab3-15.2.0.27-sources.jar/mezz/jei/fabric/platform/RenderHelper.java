package mezz.jei.fabric.platform;

import mezz.jei.common.platform.IPlatformRenderHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.color.item.ItemColors;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.item.TooltipData;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteContents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;

public class RenderHelper implements IPlatformRenderHelper {
    @Override
    public TextRenderer getFontRenderer(MinecraftClient minecraft, ItemStack itemStack) {
        return minecraft.textRenderer;
    }

    @Override
    public boolean shouldRender(StatusEffectInstance potionEffect) {
        return true;
    }

    @Override
    public Sprite getParticleIcon(BakedModel bakedModel) {
        return bakedModel.getParticleSprite();
    }

    @Override
    public ItemColors getItemColors() {
        MinecraftClient minecraft = MinecraftClient.getInstance();
        return minecraft.itemColors;
    }

    @Override
    public Optional<NativeImage> getMainImage(Sprite sprite) {
        SpriteContents contents = sprite.getContents();
        NativeImage[] frames = contents.mipmapLevelsImages;
        if (frames.length == 0) {
            return Optional.empty();
        }
        NativeImage frame = frames[0];
        return Optional.ofNullable(frame);
    }

    @Override
    public void renderTooltip(
        Screen screen,
        DrawContext guiGraphics,
        List<Text> textComponents,
        Optional<TooltipData> tooltipComponent,
        int x,
        int y,
        @Nullable TextRenderer font,
        ItemStack stack
    ) {
        guiGraphics.drawTooltip(
            font,
            textComponents,
            tooltipComponent,
            x,
            y
        );
    }
}
