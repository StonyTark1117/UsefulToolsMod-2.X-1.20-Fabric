package mezz.jei.common.platform;

import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.util.Identifier;

public interface IPlatformRegistry<T> {
    Stream<T> getValues();

    Optional<T> getValue(Identifier resourceLocation);

    int getId(T entry);

    Optional<T> getValue(int id);

    boolean contains(T entry);

    Optional<Identifier> getRegistryName(T entry);
}
