package mezz.jei.common.network.packets;

import com.google.common.base.Preconditions;
import mezz.jei.common.network.IPacketId;
import mezz.jei.common.network.PacketIdServer;
import mezz.jei.common.network.ServerPacketContext;
import mezz.jei.common.network.ServerPacketData;
import mezz.jei.common.util.ServerCommandUtil;
import mezz.jei.common.util.ErrorUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import java.util.concurrent.CompletableFuture;

public class PacketSetHotbarItemStack extends PacketJei {
	private final ItemStack itemStack;
	private final int hotbarSlot;

	public PacketSetHotbarItemStack(ItemStack itemStack, int hotbarSlot) {
		ErrorUtil.checkNotNull(itemStack, "itemStack");
		Preconditions.checkArgument(PlayerInventory.isValidHotbarIndex(hotbarSlot), "hotbar slot must be in the hotbar. got: " + hotbarSlot);
		this.itemStack = itemStack;
		this.hotbarSlot = hotbarSlot;
	}

	@Override
	public IPacketId getPacketId() {
		return PacketIdServer.SET_HOTBAR_ITEM;
	}

	@Override
	public void writePacketData(PacketByteBuf buf) {
		buf.writeItemStack(itemStack);
		buf.writeVarInt(hotbarSlot);
	}

	public static CompletableFuture<Void> readPacketData(ServerPacketData data) {
		PacketByteBuf buf = data.buf();
		ItemStack itemStack = buf.readItemStack();
		int hotbarSlot = buf.readVarInt();
		ServerPacketContext context = data.context();
		ServerPlayerEntity player = context.player();
		MinecraftServer server = player.server;
		return server.submit(() -> ServerCommandUtil.setHotbarSlot(context, itemStack, hotbarSlot));
	}
}
