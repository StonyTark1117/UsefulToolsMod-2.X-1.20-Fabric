package mezz.jei.common.platform;

import mezz.jei.api.helpers.IPlatformFluidHelper;
import mezz.jei.api.ingredients.IIngredientRenderer;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.ingredients.subtypes.IIngredientSubtypeInterpreter;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.client.texture.Sprite;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import java.util.List;
import java.util.Optional;

public interface IPlatformFluidHelperInternal<T> extends IPlatformFluidHelper<T> {

    IIngredientSubtypeInterpreter<T> getAllNbtSubtypeInterpreter();

    IIngredientRenderer<T> createRenderer(long capacity, boolean showCapacity, int width, int height);

    Optional<Sprite> getStillFluidSprite(T ingredient);

    Text getDisplayName(T ingredient);

    int getColorTint(T ingredient);

    long getAmount(T ingredient);

    Optional<NbtCompound> getTag(T ingredient);

    List<Text> getTooltip(T ingredient, TooltipContext tooltipFlag);

    T copy(T ingredient);

    T normalize(T ingredient);

    Optional<T> getContainedFluid(ITypedIngredient<?> ingredient);
}
