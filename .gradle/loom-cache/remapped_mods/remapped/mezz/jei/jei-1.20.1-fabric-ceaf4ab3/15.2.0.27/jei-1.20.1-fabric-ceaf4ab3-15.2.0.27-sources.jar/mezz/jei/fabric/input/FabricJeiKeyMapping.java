package mezz.jei.fabric.input;

import java.util.function.Consumer;
import mezz.jei.common.input.keys.IJeiKeyMappingInternal;
import mezz.jei.common.input.keys.JeiKeyConflictContext;
import mezz.jei.common.input.keys.JeiKeyModifier;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

public class FabricJeiKeyMapping implements IJeiKeyMappingInternal {
    private final String category;
    private final String description;
    private final JeiKeyConflictContext context;
    private final JeiKeyModifier modifier;
    private final InputUtil.Type type;
    private final InputUtil.Key key;

    public FabricJeiKeyMapping(
        String category,
        String description,
        JeiKeyConflictContext context,
        JeiKeyModifier modifier,
        InputUtil.Type type,
        int keyCode
    ) {
        this.category = category;
        this.description = description;
        this.context = context;
        this.modifier = modifier;
        this.type = type;
        this.key = type.createFromCode(keyCode);
    }

    @Override
    public boolean isActiveAndMatches(InputUtil.Key key) {
        if (isUnbound()) {
            return false;
        }
        if (!this.key.equals(key)) {
            return false;
        }
        return context.isActive() && modifier.isActive(context);
    }

    @Override
    public boolean isUnbound() {
        return this.key.equals(InputUtil.UNKNOWN_KEY);
    }

    @Override
    public Text getTranslatedKeyMessage() {
        return modifier.getCombinedName(key);
    }

    @Override
    public IJeiKeyMappingInternal register(Consumer<KeyBinding> registerMethod) {
        return this;
    }
}
