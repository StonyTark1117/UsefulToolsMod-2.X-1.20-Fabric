package mezz.jei.library.config;

import mezz.jei.api.constants.ModIds;
import mezz.jei.common.config.file.IConfigCategoryBuilder;
import mezz.jei.common.config.file.IConfigSchemaBuilder;
import mezz.jei.common.platform.IPlatformItemStackHelper;
import mezz.jei.common.platform.Services;
import mezz.jei.core.util.function.CachedSupplierTransformer;
import mezz.jei.library.config.serializers.ChatFormattingSerializer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class ModIdFormatConfig implements IModIdFormatConfig {
    protected static final List<Formatting> defaultModNameFormat = List.of(Formatting.BLUE, Formatting.ITALIC);
    public static final String MOD_NAME_FORMAT_CODE = "%MODNAME%";

    private final Supplier<String> modNameFormat;
    @Nullable
    private String cachedOverride; // when we detect another mod is adding mod names to tooltips, use its formatting

    public ModIdFormatConfig(IConfigSchemaBuilder builder) {
        IConfigCategoryBuilder modName = builder.addCategory("modname");
        Supplier<List<Formatting>> configValue = modName.addList(
            "ModNameFormat",
            defaultModNameFormat,
            ChatFormattingSerializer.INSTANCE,
            "Formatting for mod name tooltip"
        );
        this.modNameFormat = new CachedSupplierTransformer<>(configValue, ModIdFormatConfig::toFormatString);
    }

    private static String toFormatString(List<Formatting> values) {
        return values.stream()
            .map(Formatting::toString)
            .collect(Collectors.joining());
    }

    private String getOverride() {
        if (cachedOverride == null) {
            cachedOverride = detectModNameTooltipFormatting();
        }
        return cachedOverride;
    }

    @Override
    public final String getModNameFormat() {
        String override = getOverride();
        if (!override.isEmpty()) {
            return override;
        }
        return modNameFormat.get();
    }

    @Override
    public final boolean isModNameFormatOverrideActive() {
        return !getOverride().isEmpty();
    }

    private String detectModNameTooltipFormatting() {
        IPlatformItemStackHelper itemStackHelper = Services.PLATFORM.getItemStackHelper();
        MinecraftClient minecraft = MinecraftClient.getInstance();
        ClientPlayerEntity player = minecraft.player;
        List<Text> tooltip = itemStackHelper.getTestTooltip(player, new ItemStack(Items.APPLE));
        if (tooltip.size() <= 1) {
            return "";
        }

        for (int lineNum = 1; lineNum < tooltip.size(); lineNum++) {
            Text line = tooltip.get(lineNum);
            String lineString = line.getString();
            if (lineString.contains(ModIds.MINECRAFT_NAME)) {
                String withoutFormatting = Formatting.strip(lineString);
                if (withoutFormatting != null && withoutFormatting.contains(ModIds.MINECRAFT_NAME)) {
                    return StringUtils.replaceOnce(lineString, ModIds.MINECRAFT_NAME, MOD_NAME_FORMAT_CODE);
                }
            }
        }
        return "";
    }
}
