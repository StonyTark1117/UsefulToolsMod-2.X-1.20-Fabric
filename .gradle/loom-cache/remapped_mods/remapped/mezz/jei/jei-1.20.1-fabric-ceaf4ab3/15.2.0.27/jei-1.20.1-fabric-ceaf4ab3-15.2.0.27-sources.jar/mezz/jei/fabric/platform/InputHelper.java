package mezz.jei.fabric.platform;

import mezz.jei.common.input.keys.IJeiKeyMappingCategoryBuilder;
import mezz.jei.common.platform.IPlatformInputHelper;
import mezz.jei.fabric.input.FabricJeiKeyMappingCategoryBuilder;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

public class InputHelper implements IPlatformInputHelper {
    @Override
    public boolean isActiveAndMatches(KeyBinding keyMapping, InputUtil.Key key) {
        if (keyMapping.isUnbound()) {
            return false;
        }
        if (key.getCategory().equals(InputUtil.Type.MOUSE)) {
            return keyMapping.matchesMouse(key.getCode());
        }
        return keyMapping.matchesKey(key.getCode(), 0);
    }

    @Override
    public IJeiKeyMappingCategoryBuilder createKeyMappingCategoryBuilder(String name) {
        return new FabricJeiKeyMappingCategoryBuilder(name);
    }
}
