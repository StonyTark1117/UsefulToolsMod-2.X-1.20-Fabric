package mcp.mobius.waila.api.component;

import com.mojang.blaze3d.systems.RenderSystem;
import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.__internal__.ApiSide;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;

/**
 * A component that renders a health bar.
 */
@ApiSide.ClientOnly
public class HealthComponent extends DrawContext implements ITooltipComponent {

    /**
     * @param health     the health point, 1 full icon represent 2 hp
     * @param maxHealth  the max health point
     * @param maxPerLine the max icon per line until it get wrapped into multiple
     * @param absorption indicates if the bar is absorption health bar
     */
    public HealthComponent(float health, float maxHealth, int maxPerLine, boolean absorption) {
        this.health = MathHelper.ceil(health);
        this.iconCount = MathHelper.ceilDiv(MathHelper.ceil(Math.max(health, maxHealth)), 2);
        this.lineWidth = Math.min(iconCount, maxPerLine);
        this.absorption = absorption;
    }

    private final int health;
    private final int iconCount;
    private final int lineWidth;
    private final boolean absorption;

    @Override
    public int getWidth() {
        return (lineWidth * 8) + 1;
    }

    @Override
    public int getHeight() {
        return (MathHelper.ceilDiv(iconCount, lineWidth) * 3) + 6;
    }

    @Override
    public void render(MatrixStack matrices, int x, int y, float delta) {
        RenderSystem.setShader(GameRenderer::getPositionTexProgram);
        RenderSystem.setShaderTexture(0, class_332.field_22737);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        int filled = health / 2 - 1;
        int half = filled + health % 2;

        for (int i = iconCount - 1; i >= 0; i--) {
            int ix = x + ((i % lineWidth) * 8);
            int iy = y + ((i / lineWidth) * 3);

            drawTexture(matrices, ix, iy, 16, 0, 9, 9);
            if (i <= filled) {
                drawTexture(matrices, ix, iy, absorption ? 160 : 52, 0, 9, 9);
            } else if (i == half) {
                drawTexture(matrices, ix, iy, absorption ? 169 : 61, 0, 9, 9);
            }
        }

        RenderSystem.disableBlend();
    }

}
