package mcp.mobius.waila.api.component;

import com.mojang.blaze3d.systems.RenderSystem;
import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.api.__internal__.ApiSide;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;

/**
 * A component that renders a furnace-like progress arrow.
 */
@ApiSide.ClientOnly
public class ProgressArrowComponent extends DrawContext implements ITooltipComponent {

    /**
     * @param progress the progress between 0.0f and 1.0f.
     */
    public ProgressArrowComponent(float progress) {
        this.progress = MathHelper.clamp(progress, 0.0f, 1.0f);
    }

    private final float progress;

    @Override
    public int getWidth() {
        return 22;
    }

    @Override
    public int getHeight() {
        return 16;
    }

    @Override
    public void render(MatrixStack matrices, int x, int y, float delta) {
        RenderSystem.setShader(GameRenderer::getPositionTexProgram);
        RenderSystem.setShaderTexture(0, WailaConstants.COMPONENT_TEXTURE);

        // Draws the "empty" background arrow
        drawTexture(matrices, x, y, 0, 16, 22, 16);

        if (progress > 0) {
            // Draws the "full" foreground arrow based on the progress
            drawTexture(matrices, x, y, 0, 0, (int) (progress * 22) + 1, 16);
        }
    }

}
