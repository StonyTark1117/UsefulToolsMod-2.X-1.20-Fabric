package mcp.mobius.waila.api.component;

import java.util.Objects;
import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.__internal__.ApiSide;
import mcp.mobius.waila.api.__internal__.IApiService;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

/**
 * A tooltip component that renders a vanilla {@link Text}.
 */
@ApiSide.ClientOnly
public class WrappedComponent implements ITooltipComponent {

    public WrappedComponent(String literal) {
        this(Text.literal(literal));
    }

    public WrappedComponent(Text component) {
        this.component = component;
    }

    public final Text component;

    @Override
    public int getWidth() {
        return getFont().getWidth(component);
    }

    @Override
    public int getHeight() {
        return getFont().fontHeight;
    }

    @Override
    public void render(MatrixStack matrices, int x, int y, float delta) {
        getFont().method_30881(matrices, component, x, y, IApiService.INSTANCE.getFontColor());
    }

    private TextRenderer getFont() {
        return MinecraftClient.getInstance().textRenderer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        WrappedComponent that = (WrappedComponent) o;
        return component.equals(that.component);
    }

    @Override
    public int hashCode() {
        return Objects.hash(component);
    }

}
