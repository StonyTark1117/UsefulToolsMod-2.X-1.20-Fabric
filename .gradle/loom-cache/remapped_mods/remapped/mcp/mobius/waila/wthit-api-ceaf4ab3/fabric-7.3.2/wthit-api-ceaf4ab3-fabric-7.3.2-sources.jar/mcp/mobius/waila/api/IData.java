package mcp.mobius.waila.api;

import net.minecraft.network.PacketByteBuf;
import org.jetbrains.annotations.ApiStatus;

/**
 * A typed data for syncing complex data from server to client.
 * <p>
 * Register data types with {@link IRegistrar#addDataType}
 * <p>
 * For simple data, consider using {@linkplain IDataWriter#raw() raw NBT data} instead,
 * as it is easier to do and enough for most purpose.
 */
public interface IData {

    /**
     * Write current data to the buffer.
     *
     * @param buf the buffer
     */
    @ApiStatus.OverrideOnly
    void write(PacketByteBuf buf);

    /**
     * A byte buffer to data serializer, should be implemented as a reference to data constructor.
     */
    @FunctionalInterface
    @ApiStatus.OverrideOnly
    interface Serializer<T extends IData> {

        /**
         * Read data from the buffer.
         *
         * @param buf the buffer
         */
        T read(PacketByteBuf buf);

    }

}
