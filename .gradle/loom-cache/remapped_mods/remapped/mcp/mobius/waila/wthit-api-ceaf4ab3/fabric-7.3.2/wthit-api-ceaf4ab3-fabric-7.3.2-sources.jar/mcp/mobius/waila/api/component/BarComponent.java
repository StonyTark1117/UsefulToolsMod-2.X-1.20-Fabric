package mcp.mobius.waila.api.component;

import com.mojang.blaze3d.systems.RenderSystem;
import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.api.WailaHelper;
import mcp.mobius.waila.api.__internal__.ApiSide;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;

/**
 * A component that renders a colored bar.
 */
@ApiSide.ClientOnly
public class BarComponent extends DrawContext implements ITooltipComponent {

    /**
     * @param ratio the ratio of the filled bar between 0.0f and 1.0f
     * @param color the bar color, <b>0xAARRGGBB</b>
     */
    public BarComponent(float ratio, int color) {
        this(ratio, color, ScreenTexts.EMPTY);
    }

    /**
     * @param ratio the ratio of the filled bar between 0.0f and 1.0f
     * @param color the bar color, <b>0xAARRGGBB</b>
     * @param text  the text that will be shown in the middle of the bar
     */
    public BarComponent(float ratio, int color, String text) {
        this(ratio, color, Text.literal(text));
    }

    /**
     * @param ratio the ratio of the filled bar between 0.0f and 1.0f
     * @param color the bar color, <b>0xAARRGGBB</b>
     * @param text  the text that will be shown in the middle of the bar
     */
    public BarComponent(float ratio, int color, Text text) {
        this.ratio = ratio;
        this.color = color;
        this.text = text;
    }

    private static final int WIDTH = 100;
    private static final int HEIGHT = 11;
    private static final float U0 = 22f / 256f;
    private static final float U1 = 122f / 256f;
    private static final float V0_BG = 0f / 256f;
    private static final float V1_BG = HEIGHT/ 256f;
    private static final float V0_FG = HEIGHT / 256f;
    private static final float V1_FG = 22f / 256f;
    private static final float UV_W = WIDTH / 256f;

    private final float ratio;
    private final int color;
    private final Text text;

    @Override
    public int getWidth() {
        return Math.max(MinecraftClient.getInstance().textRenderer.getWidth(text), WIDTH);
    }

    @Override
    public int getHeight() {
        return HEIGHT;
    }

    @Override
    public void render(MatrixStack matrices, int x, int y, float delta) {
        renderBar(matrices, x, y, WIDTH, V0_BG, U1, V1_BG, color);
        renderBar(matrices, x, y, WIDTH * ratio, V0_FG, U0 + (UV_W * ratio), V1_FG, color);

        double luminance = WailaHelper.getLuminance(color);
        int overlay = 0;

        if (luminance < 0.25)
            overlay = 0x08FFFFFF;
        else if (luminance > 0.90)
            overlay = 0x80000000;
        else if (luminance > 0.80)
            overlay = 0x70000000;
        else if (luminance > 0.70)
            overlay = 0x60000000;
        else if (luminance > 0.60)
            overlay = 0x50000000;
        else if (luminance > 0.50)
            overlay = 0x40000000;

        if (overlay != 0) {
            fill(matrices, x, y, x + WIDTH, y + HEIGHT, overlay);
        }

        int textWidth = MinecraftClient.getInstance().textRenderer.getWidth(text);
        float textX = x + Math.max((WIDTH - textWidth) / 2F, 0F);
        float textY = y + 2;
        MinecraftClient.getInstance().textRenderer.method_30883(matrices, text, textX, textY, 0xFFAAAAAA);
    }

    private static void renderBar(
        MatrixStack matrices,
        int x, int y, float w,
        float v0, float u1, float v1, int tint
    ) {
        matrices.push();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorTexProgram);
        RenderSystem.setShaderTexture(0, WailaConstants.COMPONENT_TEXTURE);

        int a = WailaHelper.getAlpha(tint);
        int r = WailaHelper.getRed(tint);
        int g = WailaHelper.getGreen(tint);
        int b = WailaHelper.getBlue(tint);

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();

        buffer.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR_TEXTURE);

        buffer.vertex(matrices.peek().getPositionMatrix(), x, y + HEIGHT, 0).color(r, g, b, a).texture(U0, v1).next();
        buffer.vertex(matrices.peek().getPositionMatrix(), x + w, y + HEIGHT, 0).color(r, g, b, a).texture(u1, v1).next();
        buffer.vertex(matrices.peek().getPositionMatrix(), x + w, y, 0).color(r, g, b, a).texture(u1, v0).next();
        buffer.vertex(matrices.peek().getPositionMatrix(), x, y, 0).color(r, g, b, a).texture(U0, v0).next();

        tessellator.draw();
        RenderSystem.disableBlend();
        matrices.pop();
    }

}
