package mcp.mobius.waila.api;

import mcp.mobius.waila.api.__internal__.IApiService;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;

public interface IBlacklistConfig {

    static IBlacklistConfig get() {
        return IApiService.INSTANCE.getBlacklistConfig();
    }

    boolean contains(Block block);

    boolean contains(BlockEntity blockEntity);

    boolean contains(Entity entity);

}
