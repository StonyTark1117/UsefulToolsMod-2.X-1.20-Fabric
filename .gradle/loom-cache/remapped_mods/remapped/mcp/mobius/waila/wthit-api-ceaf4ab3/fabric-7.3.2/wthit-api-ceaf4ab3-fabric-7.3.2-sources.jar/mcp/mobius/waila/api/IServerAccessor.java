package mcp.mobius.waila.api;

import mcp.mobius.waila.api.__internal__.ApiSide;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;
import org.jetbrains.annotations.ApiStatus;

@ApiSide.ServerOnly
@ApiStatus.NonExtendable
public interface IServerAccessor<T> {

    World getWorld();

    ServerPlayerEntity getPlayer();

    <H extends HitResult> H getHitResult();

    T getTarget();

}
