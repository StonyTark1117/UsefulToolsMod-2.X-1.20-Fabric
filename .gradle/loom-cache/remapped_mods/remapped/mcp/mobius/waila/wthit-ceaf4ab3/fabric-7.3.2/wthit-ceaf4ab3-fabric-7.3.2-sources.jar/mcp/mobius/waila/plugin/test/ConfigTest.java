package mcp.mobius.waila.plugin.test;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public enum ConfigTest implements IBlockComponentProvider {

    INSTANCE;

    static final Identifier ENABLED = new Identifier("test:enabled");

    static final Identifier BOOL = new Identifier("test:bool");
    static final Identifier INT = new Identifier("test:int");
    static final Identifier DOUBLE = new Identifier("test:double");
    static final Identifier STRING = new Identifier("test:string");
    static final Identifier ENUM = new Identifier("test:enum");

    static final Identifier SYNC_BOOL = new Identifier("test:sync_bool");
    static final Identifier SYNC_INT = new Identifier("test:sync_int");
    static final Identifier SYNC_DOUBLE = new Identifier("test:sync_double");
    static final Identifier SYNC_STRING = new Identifier("test:sync_string");
    static final Identifier SYNC_ENUM = new Identifier("test:sync_enum");

    @Override
    public void appendHead(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        if (!config.getBoolean(ENABLED)) {
            return;
        }

        tooltip.addLine(Text.literal(BOOL + "=" + config.getBoolean(BOOL)));
        tooltip.addLine(Text.literal(INT + "=" + config.getInt(INT)));
        tooltip.addLine(Text.literal(DOUBLE + "=" + config.getDouble(DOUBLE)));
        tooltip.addLine(Text.literal(STRING + "=" + config.getString(STRING)));
        tooltip.addLine(Text.literal(ENUM + "=" + config.getEnum(ENUM).name()));

        tooltip.addLine(Text.empty());

        tooltip.addLine(Text.literal(SYNC_BOOL + "=" + config.getBoolean(SYNC_BOOL)));
        tooltip.addLine(Text.literal(SYNC_INT + "=" + config.getInt(SYNC_INT)));
        tooltip.addLine(Text.literal(SYNC_DOUBLE + "=" + config.getDouble(SYNC_DOUBLE)));
        tooltip.addLine(Text.literal(SYNC_STRING + "=" + config.getString(SYNC_STRING)));
        tooltip.addLine(Text.literal(SYNC_ENUM + "=" + config.getEnum(SYNC_ENUM).name()));
    }

}
