package mcp.mobius.waila.service;

import java.lang.reflect.Type;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;

import com.google.common.collect.Streams;
import mcp.mobius.waila.Waila;
import mcp.mobius.waila.api.IBlacklistConfig;
import mcp.mobius.waila.api.IInstanceRegistry;
import mcp.mobius.waila.api.IJsonConfig;
import mcp.mobius.waila.api.IModInfo;
import mcp.mobius.waila.api.IPluginInfo;
import mcp.mobius.waila.api.IRegistryFilter;
import mcp.mobius.waila.api.ITheme;
import mcp.mobius.waila.api.IThemeType;
import mcp.mobius.waila.api.IWailaConfig;
import mcp.mobius.waila.api.__internal__.IApiService;
import mcp.mobius.waila.config.JsonConfig;
import mcp.mobius.waila.gui.hud.TooltipRenderer;
import mcp.mobius.waila.gui.hud.theme.ThemeType;
import mcp.mobius.waila.mixin.GuiAccess;
import mcp.mobius.waila.plugin.PluginInfo;
import mcp.mobius.waila.registry.InstanceRegistry;
import mcp.mobius.waila.registry.RegistryFilter;
import mcp.mobius.waila.util.ModInfo;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.item.TippedArrowItem;
import net.minecraft.item.ToolItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.ToolMaterials;
import net.minecraft.potion.PotionUtil;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.Identifier;

public abstract class ApiService implements IApiService {

    @Override
    public IModInfo getModInfo(ItemStack stack) {
        var item = stack.getItem();

        if (Identifier.DEFAULT_NAMESPACE.equals(Registries.ITEM.getId(item).getNamespace())) {
            if (item instanceof EnchantedBookItem) {
                var enchantmentsNbt = EnchantedBookItem.getEnchantmentNbt(stack);
                if (enchantmentsNbt.size() == 1) {
                    var enchantmentNbt = enchantmentsNbt.getCompound(0);
                    var id = Identifier.tryParse(enchantmentNbt.getString("id"));
                    if (id != null && Registries.ENCHANTMENT.containsId(id)) {
                        return IModInfo.get(id.getNamespace());
                    }
                }
            } else if (item instanceof PotionItem || item instanceof TippedArrowItem) {
                var potionType = PotionUtil.getPotion(stack);
                var id = Registries.POTION.getId(potionType);
                return IModInfo.get(id.getNamespace());
            } else if (item instanceof SpawnEggItem spawnEggItem) {
                var id = Registries.ENTITY_TYPE.getId(spawnEggItem.getEntityType(null));
                return IModInfo.get(id.getNamespace());
            }
        }

        return IModInfo.get(item);
    }

    @Override
    public IBlacklistConfig getBlacklistConfig() {
        return Waila.BLACKLIST_CONFIG.get().getView();
    }

    @Override
    public <T> IJsonConfig.Builder0<T> createConfigBuilder(Type type) {
        return new JsonConfig.Builder<>(type);
    }

    @Override
    public IModInfo getModInfo(String namespace) {
        return ModInfo.get(namespace);
    }

    @Override
    public IPluginInfo getPluginInfo(Identifier pluginId) {
        return PluginInfo.get(pluginId);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Override
    public Collection<IPluginInfo> getAllPluginInfoFromMod(String modId) {
        return (Collection) PluginInfo.getAllFromMod(modId);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Override
    public Collection<IPluginInfo> getAllPluginInfo() {
        return (Collection) PluginInfo.getAll();
    }

    @Override
    public IWailaConfig getConfig() {
        return Waila.CONFIG.get();
    }

    @Override
    public int getPairComponentColonOffset() {
        return TooltipRenderer.colonOffset;
    }

    @Override
    public int getColonFontWidth() {
        return TooltipRenderer.colonWidth;
    }

    @Override
    public int getFontColor() {
        return TooltipRenderer.state.getTheme().getDefaultTextColor();
    }

    @Override
    public <T extends ITheme> IThemeType.Builder<T> createThemeTypeBuilder(Class<T> clazz) {
        return new ThemeType<>(clazz);
    }

    @Override
    public String getDefaultEnergyUnit() {
        return "E";
    }

    @Override
    public Path getConfigDir() {
        return Waila.CONFIG_DIR;
    }

    @Override
    public Identifier getGuiIconsTexture() {
        return GuiAccess.wthit_guiIconsLocation();
    }

    @Override
    public <T> IRegistryFilter.Builder<T> createRegistryFilterBuilder(RegistryKey<? extends Registry<T>> registryKey) {
        return new RegistryFilter.Builder<>(registryKey);
    }

    @Override
    public <T> IInstanceRegistry<T> createInstanceRegistry(boolean reversed) {
        var registry = new InstanceRegistry<T>();
        if (reversed) registry.reversed();
        return registry;
    }

    @Override
    public List<ToolMaterial> getTiers() {
        var vanilla = List.of(ToolMaterials.values());
        var custom = new LinkedHashSet<ToolMaterial>();

        for (var item : Registries.ITEM) {
            if (item instanceof ToolItem tiered && !(tiered.getMaterial() instanceof ToolMaterials)) {
                custom.add(tiered.getMaterial());
            }
        }

        return Streams.concat(vanilla.stream(), custom.stream()).sorted(Comparator.comparingInt(ToolMaterial::getMiningLevel)).toList();
    }

}
