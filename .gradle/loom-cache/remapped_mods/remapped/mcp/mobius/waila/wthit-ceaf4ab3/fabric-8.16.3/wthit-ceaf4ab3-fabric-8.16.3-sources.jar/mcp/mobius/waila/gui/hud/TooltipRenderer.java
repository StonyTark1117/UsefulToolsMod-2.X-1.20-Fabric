package mcp.mobius.waila.gui.hud;

import java.awt.*;
import java.util.Iterator;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import D;
import F;
import I;
import J;
import com.google.common.base.Preconditions;
import com.google.common.base.Suppliers;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.text2speech.Narrator;
import mcp.mobius.waila.WailaClient;
import mcp.mobius.waila.access.ClientAccessor;
import mcp.mobius.waila.api.IEventListener;
import mcp.mobius.waila.api.IInstanceRegistry.Entry;
import mcp.mobius.waila.api.ITheme;
import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.IWailaConfig.Overlay.Position.Align;
import mcp.mobius.waila.api.IWailaConfig.Overlay.Position.Align.X;
import mcp.mobius.waila.api.IWailaConfig.Overlay.Position.Align.Y;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.api.component.EmptyComponent;
import mcp.mobius.waila.api.component.PairComponent;
import mcp.mobius.waila.api.component.WrappedComponent;
import mcp.mobius.waila.config.PluginConfig;
import mcp.mobius.waila.event.EventCanceller;
import mcp.mobius.waila.mixin.BossHealthOverlayAccess;
import mcp.mobius.waila.mixin.GameNarratorAccess;
import mcp.mobius.waila.registry.PluginAware;
import mcp.mobius.waila.registry.Registrar;
import mcp.mobius.waila.util.ProfilerUtil;
import mcp.mobius.waila.util.ProfilerUtil.Impl;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.WindowFramebuffer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

public class TooltipRenderer {

    private static final Tooltip TOOLTIP = new Tooltip();

    private static final Supplier<Rectangle> RENDER_RECT = Suppliers.memoize(Rectangle::new);
    private static final Supplier<Rectangle> RECT = Suppliers.memoize(Rectangle::new);

    private static boolean started;
    private static String lastNarration = "";
    private static ITooltipComponent icon = EmptyComponent.INSTANCE;
    private static int topOffset;

    public static int colonOffset;
    public static int colonWidth;

    public static State state;

    private static long lastFrame = System.nanoTime();
    private static @Nullable WindowFramebuffer framebuffer = null;
    private static int fbWidth, fbHeight;

    public static void beginBuild(State state) {
        started = true;
        TooltipRenderer.state = state;
        TOOLTIP.clear();
        icon = EmptyComponent.INSTANCE;
        topOffset = 0;
        colonOffset = 0;
        colonWidth = MinecraftClient.getInstance().textRenderer.getWidth(": ");
    }

    public static void add(Tooltip tooltip) {
        Preconditions.checkState(started);
        for (var line : tooltip) {
            add(line);
        }
    }

    public static void add(Line line) {
        Preconditions.checkState(started);

        if (line.tag != null) {
            TOOLTIP.setLine(line.tag, line);
        } else {
            TOOLTIP.add(line);
        }

        for (var component : line.components) {
            if (component instanceof InspectComponent wrapper) {
                component = wrapper.actual;
            }

            if (component instanceof PairComponent pair) {
                colonOffset = Math.max(pair.key.getWidth(), colonOffset);
                break;
            }
        }
    }

    public static void setIcon(ITooltipComponent icon) {
        Preconditions.checkState(started);
        TooltipRenderer.icon = PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_ICON) ? icon : EmptyComponent.INSTANCE;
    }

    public static Rectangle endBuild() {
        Preconditions.checkState(started);
        var accessor = ClientAccessor.INSTANCE;

        if (state.fireEvent()) {
            for (var entry : Registrar.get().eventListeners.get(Object.class)) {
                var pa = entry.instance();
                var listener = pa.instance();
                TOOLTIP.origin = pa;
                listener.onHandleTooltip(TOOLTIP, accessor, PluginConfig.CLIENT);
                TOOLTIP.origin = null;
            }
        }

        var client = MinecraftClient.getInstance();
        var window = client.getWindow();

        narrateObjectName(client);

        var scale = state.getScale();

        var fw = 0;
        for (var line : TOOLTIP) {
            line.calculateFixedWidth();
            fw = Math.max(fw, line.getFixedWidth());
        }

        var w = 0;
        var h = 0;
        Iterator<Line> iterator = TOOLTIP.iterator();
        while (iterator.hasNext()) {
            var line = iterator.next();
            line.calculateDynamicWidth(fw);
            line.calculateHeight();
            var lineW = line.getWidth();
            var lineH = line.getHeight();
            if (lineH <= 0) {
                iterator.remove();
                continue;
            }
            w = Math.max(w, lineW);
            h += lineH + 1;
        }

        if (h > 0) {
            h--;
        }

        topOffset = 0;
        if (icon.getHeight() > h) {
            topOffset = MathHelper.ceilDiv(icon.getHeight() - h, 2);
        }

        if (icon.getWidth() > 0) {
            w += icon.getWidth() + 3;
        }

        var padding = Padding.INSTANCE;
        padding.set(0);
        state.getTheme().setPadding(padding);

        w += padding.left + padding.right;
        h = Math.max(h, icon.getHeight()) + padding.top + padding.bottom;

        var windowW = (int) (window.getScaledWidth() / scale);
        var windowH = (int) (window.getScaledHeight() / scale);

        var anchorX = state.getXAnchor();
        var anchorY = state.getYAnchor();

        var alignX = state.getXAlign();
        var alignY = state.getYAlign();

        var x = windowW * anchorX.multiplier - w * alignX.multiplier + state.getX();
        var y = windowH * anchorY.multiplier - h * alignY.multiplier + state.getY();

        if (!state.bossBarsOverlap() && anchorX == Align.X.CENTER && anchorY == Align.Y.TOP) {
            y += Math.min(((BossHealthOverlayAccess) client.inGameHud.getBossBarHud()).wthit_events().size() * 19, window.getScaledHeight() / 3 + 2);
        }

        RECT.get().setRect(MathHelper.floor(x + 0.5), MathHelper.floor(y + 0.5), w, h);
        started = false;

        return RECT.get();
    }

    public static void resetState() {
        state = null;
    }

    public static void render(DrawContext ctx, float delta) {
        var client = MinecraftClient.getInstance();

        if (WailaClient.showFps) {
            var fpsString = client.getCurrentFps() + " FPS";
            var x1 = client.textRenderer.getWidth(fpsString) + 2;
            var y0 = client.getWindow().getScaledHeight() - client.textRenderer.fontHeight - 1;
            var y1 = y0 + client.textRenderer.fontHeight + 2;
            ctx.fill(0, y0, x1, y1, 0x90505050);
            ctx.drawText(client.textRenderer, fpsString, 1, y0 + 1, 0xE0E0E0, false);
        }

        if (state == null || !state.render()) return;

        var fps = state.getFps();

        // TODO: Figure out why opacity not working properly
        //noinspection ConstantValue
        if (true) {
            renderUncached(ctx, delta);
            return;
        }

        var nspf = 1_000_000_000f / fps;
        var now = System.nanoTime();

        if (framebuffer == null || (now - lastFrame) >= nspf) {
            var window = client.getWindow();

            if (framebuffer == null) {
                framebuffer = new WindowFramebuffer(window.getFramebufferWidth(), window.getFramebufferHeight());
                framebuffer.setClearColor(0f, 0f, 0f, 0f);
            }

            if (window.getFramebufferWidth() != fbWidth || window.getFramebufferHeight() != fbHeight) {
                fbWidth = window.getFramebufferWidth();
                fbHeight = window.getFramebufferHeight();
                framebuffer.resize(fbWidth, fbHeight, MinecraftClient.IS_SYSTEM_MAC);
            }

            framebuffer.clear(MinecraftClient.IS_SYSTEM_MAC);
            framebuffer.beginWrite(true);
            renderUncached(ctx, delta);
            framebuffer.endWrite();
            client.getFramebuffer().beginWrite(true);
            lastFrame = now;
        }

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionTexProgram);
        RenderSystem.setShaderTexture(0, framebuffer.getColorAttachment());

        var w = client.getWindow().getScaledWidth();
        var h = client.getWindow().getScaledHeight();

        var tesselator = Tessellator.getInstance();
        var buffer = tesselator.getBuffer();

        buffer.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE);

        var pose = ctx.getMatrices().peek().getPositionMatrix();
        buffer.vertex(pose, 0, h, 0).texture(0f, 0f).next();
        buffer.vertex(pose, w, h, 0).texture(1f, 0f).next();
        buffer.vertex(pose, w, 0, 0).texture(1f, 1f).next();
        buffer.vertex(pose, 0, 0, 0).texture(0f, 1f).next();

        tesselator.draw();

        RenderSystem.disableBlend();
    }

    private static void renderUncached(DrawContext ctx, float delta) {
        try (var ignored = ProfilerUtil.profile("wthit:render_uncached")) {
            _renderUncached(ctx, delta);
        }
    }

    private static void _renderUncached(DrawContext ctx, float delta) {
        var renderer = ComponentRenderer.get();
        var scale = state.getScale();

        ctx.getMatrices().push();
        ctx.getMatrices().scale(scale, scale, 1.0f);

        var rect = RENDER_RECT.get();
        rect.setRect(TooltipRenderer.RECT.get());

        if (state.fireEvent()) {
            var canceller = EventCanceller.INSTANCE;
            canceller.setCanceled(false);
            for (var listener : Registrar.get().eventListeners.get(Object.class)) {
                listener.instance().instance().onBeforeTooltipRender(ctx, rect, ClientAccessor.INSTANCE, PluginConfig.CLIENT, canceller);
                if (canceller.isCanceled()) {
                    ctx.getMatrices().pop();
                    RenderSystem.enableDepthTest();
                    RenderSystem.applyModelViewMatrix();
                    return;
                }
            }
        }

        var x = rect.x;
        var y = rect.y;
        var width = rect.width;
        var height = rect.height;
        var padding = Padding.INSTANCE;

        if (state.getBackgroundAlpha() > 0) {
            state.getTheme().renderTooltipBackground(ctx, x, y, width, height, state.getBackgroundAlpha(), delta);
        }

        var textX = x + padding.left;
        var textY = y + padding.top + topOffset;

        if (icon.getWidth() > 0) {
            textX += icon.getWidth() + 3;
        }

        for (var line : TOOLTIP) {
            line.render(renderer, ctx, textX, textY, delta);
            textY += line.getHeight() + 1;
        }

        RenderSystem.disableBlend();

        if (state.fireEvent()) {
            for (var listener : Registrar.get().eventListeners.get(Object.class)) {
                listener.instance().instance().onAfterTooltipRender(ctx, rect, ClientAccessor.INSTANCE, PluginConfig.CLIENT);
            }
        }

        Align.Y iconPos = PluginConfig.CLIENT.getEnum(WailaConstants.CONFIG_ICON_POSITION);
        var iconY = y + padding.top + MathHelper.ceil((height - (padding.top + padding.bottom) - icon.getHeight()) * iconPos.multiplier);
        if (iconPos == Align.Y.BOTTOM) {
            iconY++;
        }
        renderer.render(ctx, icon, x + padding.left, iconY, icon.getWidth(), icon.getHeight(), delta);

        RenderSystem.enableDepthTest();
        ctx.getMatrices().pop();
    }

    private static void narrateObjectName(MinecraftClient client) {
        if (!state.render()) {
            return;
        }

        var narrator = ((GameNarratorAccess) client.getNarratorManager()).wthit_narrator();
        if (!narrator.active() || !state.enableTextToSpeech() || MinecraftClient.getInstance().currentScreen instanceof ChatScreen) {
            return;
        }

        var objectName = TOOLTIP.getLine(WailaConstants.OBJECT_NAME_TAG);
        if (objectName != null && objectName.components.get(0) instanceof WrappedComponent component) {
            var narrate = component.component.getString().replaceAll("§[a-z0-9]", "");
            if (!lastNarration.equalsIgnoreCase(narrate)) {
                CompletableFuture.runAsync(() -> narrator.say(narrate, true));
                lastNarration = narrate;
            }
        }
    }

    private enum Padding implements ITheme.Padding {

        INSTANCE;

        int top, right, bottom, left;

        @Override
        public void set(int all) {
            set(all, all, all, all);
        }

        @Override
        public void set(int topBottom, int leftRight) {
            set(topBottom, leftRight, topBottom, leftRight);
        }

        @Override
        public void set(int top, int leftRight, int bottom) {
            set(top, leftRight, bottom, leftRight);
        }

        @Override
        public void set(int top, int right, int bottom, int left) {
            this.top = top;
            this.right = right;
            this.bottom = bottom;
            this.left = left;
        }

    }

    public interface State {

        boolean render();

        boolean fireEvent();

        int getFps();

        float getScale();

        Align.X getXAnchor();

        Align.Y getYAnchor();

        Align.X getXAlign();

        Align.Y getYAlign();

        int getX();

        int getY();

        boolean bossBarsOverlap();

        int getBackgroundAlpha();

        ITheme getTheme();

        boolean enableTextToSpeech();

    }

}
