package mcp.mobius.waila.plugin.vanilla.provider;

import mcp.mobius.waila.api.IEntityAccessor;
import mcp.mobius.waila.api.IEntityComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.component.PairComponent;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.entity.passive.PandaEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

public enum PandaProvider implements IEntityComponentProvider {

    INSTANCE;

    private static final Identifier PERSONALITY = Options.PANDA_GENES.withSuffixedPath(".personality");
    private static final Identifier TRAITS = Options.PANDA_GENES.withSuffixedPath(".traits");

    @Override
    public void appendBody(ITooltip tooltip, IEntityAccessor accessor, IPluginConfig config) {
        if (!config.getBoolean(Options.PANDA_GENES)) return;

        PandaEntity panda = accessor.getEntity();
        var personality = panda.getProductGene();
        var mainGene = panda.getMainGene();
        var hiddenGene = panda.getHiddenGene();

        tooltip.setLine(PERSONALITY, new PairComponent(
            Text.translatable(Tl.Tooltip.Panda.PERSONALITY),
            geneText(personality)));
        tooltip.setLine(TRAITS, new PairComponent(
            Text.translatable(Tl.Tooltip.Panda.TRAITS),
            Text.empty().append(geneText(mainGene)).append(", ").append(geneText(hiddenGene))));
    }

    private static MutableText geneText(PandaEntity.Gene gene) {
        var text = Text.translatable(Tl.Tooltip.Panda.GENE + "." + gene.asString());
        if (gene.isRecessive()) text.formatted(Formatting.RED);
        return text;
    }

}
