package mcp.mobius.waila.service;

import mcp.mobius.waila.api.__internal__.Internals;
import net.minecraft.client.option.KeyBinding;

public interface IClientService {

    IClientService INSTANCE = Internals.loadService(IClientService.class);

    KeyBinding createKeyBind(String id, int key);

}
