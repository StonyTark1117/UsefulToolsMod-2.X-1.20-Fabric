package mcp.mobius.waila.plugin.core.pick;

import java.util.List;
import java.util.Objects;

import mcp.mobius.waila.api.IObjectPicker;
import mcp.mobius.waila.api.IPickerAccessor;
import mcp.mobius.waila.api.IPickerResults;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.WailaConstants;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.fluid.FluidState;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.util.Unit;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

public enum ObjectPicker implements IObjectPicker {

    INSTANCE;

    @Override
    public void pick(IPickerAccessor accessor, IPickerResults results, IPluginConfig config) {
        Entity camera = accessor.getCameraEntity();

        if (camera == null) {
            return;
        }

        boolean showBlock = config.getBoolean(WailaConstants.CONFIG_SHOW_BLOCK);
        boolean showFluid = config.getBoolean(WailaConstants.CONFIG_SHOW_FLUID);
        boolean showEntity = config.getBoolean(WailaConstants.CONFIG_SHOW_ENTITY);

        if (!(showBlock || showFluid || showEntity)) {
            return;
        }

        float frameDelta = accessor.getFrameDelta();
        double maxDistance = accessor.getMaxDistance();

        Vec3d viewVec = camera.getRotationVec(frameDelta);
        Vec3d start = camera.getCameraPosVec(frameDelta);
        Vec3d end = start.add(viewVec.x * maxDistance, viewVec.y * maxDistance, viewVec.z * maxDistance);

        World world = camera.getWorld();

        if (showBlock || showFluid) {
            BlockView.raycast(start, end, Unit.INSTANCE, (unit, pos) -> {
                if (showBlock) {
                    BlockState blockState = world.getBlockState(pos);

                    if (!blockState.isAir()) {
                        VoxelShape blockShape = blockState.getOutlineShape(world, pos);
                        BlockHitResult blockHit = world.raycastBlock(start, end, pos.toImmutable(), blockShape, blockState);

                        if (blockHit != null) {
                            results.add(blockHit, start.squaredDistanceTo(blockHit.getPos()));
                        }
                    }
                }

                if (showFluid) {
                    FluidState fluidState = world.getFluidState(pos);

                    if (fluidState.isStill()) {
                        VoxelShape fluidShape = fluidState.getShape(world, pos);
                        BlockHitResult fluidHit = fluidShape.raycast(start, end, pos);

                        if (fluidHit != null) {
                            results.add(fluidHit, start.squaredDistanceTo(fluidHit.getPos()));
                        }
                    }
                }

                return null;
            }, unit -> unit);
        }

        if (showEntity) {
            List<Entity> entities = camera.world.method_8333(camera, new Box(start, end), EntityPredicates.VALID_ENTITY);

            for (Entity entity : entities) {
                Box bounds = entity.getBoundingBox();
                Vec3d clip = bounds.raycast(start, end).orElse(null);

                if (bounds.contains(start)) {
                    clip = Objects.requireNonNullElse(clip, start);
                }

                if (clip != null) {
                    results.add(new EntityHitResult(entity, clip), start.squaredDistanceTo(clip));
                }
            }
        }
    }

}
