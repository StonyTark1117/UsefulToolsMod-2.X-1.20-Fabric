package mcp.mobius.waila.mixin;

import java.util.List;
import mcp.mobius.waila.mixin.BeehiveBlockEntity.BeeDataAccess;
import net.minecraft.block.entity.BeehiveBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(BeehiveBlockEntity.class)
public interface BeehiveBlockEntityAccess {

    @Accessor("stored")
    List<BeeDataAccess> wthit_stored();

}
