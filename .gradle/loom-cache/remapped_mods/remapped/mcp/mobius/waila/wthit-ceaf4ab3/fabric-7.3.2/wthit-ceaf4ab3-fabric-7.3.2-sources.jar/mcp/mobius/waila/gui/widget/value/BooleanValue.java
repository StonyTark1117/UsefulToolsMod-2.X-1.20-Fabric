package mcp.mobius.waila.gui.widget.value;

import java.util.function.Consumer;
import mcp.mobius.waila.buildconst.Tl;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.Nullable;

import static mcp.mobius.waila.util.DisplayUtil.createButton;

public class BooleanValue extends ConfigValue<Boolean> {

    private final ButtonWidget button;

    public BooleanValue(String optionName, boolean value, @Nullable Boolean defaultValue, Consumer<Boolean> save) {
        super(optionName, value, defaultValue, save);

        this.button = createButton(0, 0, 100, 20, Text.empty(), w -> setValue(!getValue()));
        setMessage();
    }

    @Override
    protected void drawValue(MatrixStack matrices, int width, int height, int x, int y, int mouseX, int mouseY, boolean selected, float partialTicks) {
        setMessage();
        button.active = !isDisabled();
        button.setX(x + width - button.getWidth());
        button.setY(y + (height - button.getHeight()) / 2);
        button.render(matrices, mouseX, mouseY, partialTicks);
    }

    private void setMessage() {
        button.setMessage(Text.translatable(getValue() ? Tl.Config.TRUE : Tl.Config.FALSE)
            .formatted(isDisabled() ?
                Formatting.GRAY :
                getValue() ? Formatting.GREEN : Formatting.RED));
    }

    @Override
    public Element getListener() {
        return button;
    }

}
