package mcp.mobius.waila.plugin.vanilla.provider;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.block.entity.JukeboxBlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MusicDiscItem;
import net.minecraft.text.Text;

public enum JukeboxProvider implements IBlockComponentProvider, IDataProvider<JukeboxBlockEntity> {

    INSTANCE;

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(Options.JUKEBOX_RECORD) && accessor.getData().raw().contains("record")) {
            tooltip.addLine(Text.Serializer.fromJson(accessor.getData().raw().getString("record")));
        }
    }

    @Override
    public void appendData(IDataWriter data, IServerAccessor<JukeboxBlockEntity> accessor, IPluginConfig config) {
        if (config.getBoolean(Options.JUKEBOX_RECORD)) {
            ItemStack stack = accessor.getTarget().getStack();
            if (!stack.isEmpty()) {
                Text text = stack.getItem() instanceof MusicDiscItem
                    ? Text.translatable(stack.getTranslationKey() + ".desc")
                    : stack.toHoverableText();
                data.raw().putString("record", Text.Serializer.toJson(text));
            }
        }
    }

}
