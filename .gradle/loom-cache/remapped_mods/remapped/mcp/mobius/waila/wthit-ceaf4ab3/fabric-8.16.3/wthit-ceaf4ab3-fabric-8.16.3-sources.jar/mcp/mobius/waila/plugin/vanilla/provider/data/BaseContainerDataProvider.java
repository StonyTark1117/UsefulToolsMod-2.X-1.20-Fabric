package mcp.mobius.waila.plugin.vanilla.provider.data;

import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.data.ItemData;
import mcp.mobius.waila.mixin.BaseContainerBlockEntityAccess;
import net.minecraft.block.entity.LockableContainerBlockEntity;

public enum BaseContainerDataProvider implements IDataProvider<LockableContainerBlockEntity> {

    INSTANCE;

    @Override
    public void appendData(IDataWriter data, IServerAccessor<LockableContainerBlockEntity> accessor, IPluginConfig config) {
        var target = (BaseContainerBlockEntityAccess) accessor.getTarget();
        if (!target.wthit_lockKey().canOpen(accessor.getPlayer().getMainHandStack())) {
            data.blockAll(ItemData.class);
        }
    }

}
