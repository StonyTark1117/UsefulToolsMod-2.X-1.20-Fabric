package mcp.mobius.waila.plugin.test;

import I;
import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.component.ColorComponent;
import net.minecraft.util.Identifier;

public enum LongTest implements IBlockComponentProvider {

    INSTANCE;

    static final Identifier ENABLED = new Identifier("test:long.enabled");
    static final Identifier WIDTH = new Identifier("test:long.width");

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(ENABLED)) {
            var width = config.getInt(WIDTH);
            tooltip.addLine(new ColorComponent(width, 10, 0xFFFF00FF));
        }
    }

}
