package mcp.mobius.waila.plugin.vanilla.provider;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.block.BlockState;
import net.minecraft.block.InfestedBlock;

public enum InfestedBlockProvider implements IBlockComponentProvider {

    INSTANCE;

    @Override
    public BlockState getOverride(IBlockAccessor accessor, IPluginConfig config) {
        return config.getBoolean(Options.OVERRIDE_INFESTED)
            ? ((InfestedBlock) accessor.getBlock()).getRegularBlock().getDefaultState()
            : null;
    }

}
