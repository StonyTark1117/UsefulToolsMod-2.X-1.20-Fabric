package mcp.mobius.waila.gui.screen;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.jetbrains.annotations.NotNull;

@SuppressWarnings({"NotNullFieldNotInitialized", "DataFlowIssue"})
public abstract class YesIAmSureTheClientInstanceIsPresentByTheTimeIUseItScreen extends Screen {

    @NotNull
    MinecraftClient client;

    public YesIAmSureTheClientInstanceIsPresentByTheTimeIUseItScreen(Text title) {
        super(title);
    }

    @Override
    protected void init() {
        super.init();
        this.client = super.client;
    }

}
