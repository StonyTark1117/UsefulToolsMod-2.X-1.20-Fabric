package mcp.mobius.waila.plugin.test;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IData;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.component.PairComponent;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public enum ComplexDataTest implements IBlockComponentProvider, IDataProvider<ChestBlockEntity> {

    INSTANCE;

    public static final Identifier ENABLED = new Identifier("test:data.complex");
    public static final Identifier BLOCK = new Identifier("test:data.complex.block");
    public static final Identifier MULTIPLE_ADDITION = new Identifier("test:data.complex.multiple_addition");

    public static class Data implements IData {

        private final String value;

        public Data(String value) {
            this.value = value;
        }

        public Data(PacketByteBuf buf) {
            this(buf.readString());
        }

        @Override
        public void write(PacketByteBuf buf) {
            buf.writeString(value);
        }

    }

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        Data data = accessor.getData().get(Data.class);
        if (data != null) tooltip.addLine(new PairComponent(Text.literal("data"), Text.literal(data.value)));
    }

    @Override
    public void appendData(IDataWriter data, IServerAccessor<ChestBlockEntity> accessor, IPluginConfig config) {
        if (!config.getBoolean(ENABLED)) return;

        if (config.getBoolean(MULTIPLE_ADDITION)) data.add(Data.class, result -> {
            result.add(new Data("one"));
            try {
                result.add(new Data("two"));
            } catch (IllegalStateException e) {
                // no-op
            }
        });

        if (config.getBoolean(BLOCK)) data.add(Data.class, IDataWriter.Result::block);
        data.add(Data.class, ctx -> ctx.add(new Data("moe moe kyun")));
    }

}
