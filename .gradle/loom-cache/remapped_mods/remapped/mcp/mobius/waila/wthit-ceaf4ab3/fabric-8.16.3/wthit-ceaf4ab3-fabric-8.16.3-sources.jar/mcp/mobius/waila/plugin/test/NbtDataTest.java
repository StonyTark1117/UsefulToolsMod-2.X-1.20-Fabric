package mcp.mobius.waila.plugin.test;

import I;
import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.component.PairComponent;
import net.minecraft.block.entity.FurnaceBlockEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public enum NbtDataTest implements IBlockComponentProvider, IDataProvider<FurnaceBlockEntity> {

    INSTANCE;

    public static final Identifier ENABLED = new Identifier("test:data.nbt");

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        var data = accessor.getData().raw();
        if (data.contains("testnbt")) {
            var value = data.getInt("testnbt");
            tooltip.addLine(new PairComponent(Text.literal("testnbt"), Text.literal(String.valueOf(value))));
        }
    }

    @Override
    public void appendData(IDataWriter data, IServerAccessor<FurnaceBlockEntity> accessor, IPluginConfig config) {
        if (config.getBoolean(ENABLED)) {
            data.raw().putInt("testnbt", 2421);
        }
    }

}
