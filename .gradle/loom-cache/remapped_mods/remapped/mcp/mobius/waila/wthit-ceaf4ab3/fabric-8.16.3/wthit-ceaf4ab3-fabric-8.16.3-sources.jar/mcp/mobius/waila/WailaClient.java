package mcp.mobius.waila;

import java.util.List;
import mcp.mobius.waila.access.ClientAccessor;
import mcp.mobius.waila.api.IInstanceRegistry.Entry;
import mcp.mobius.waila.api.IWailaConfig;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.config.PluginConfig;
import mcp.mobius.waila.config.WailaConfig;
import mcp.mobius.waila.gui.hud.TooltipHandler;
import mcp.mobius.waila.gui.screen.HomeScreen;
import mcp.mobius.waila.integration.IRecipeAction;
import mcp.mobius.waila.registry.Registrar;
import mcp.mobius.waila.registry.RegistryFilter;
import mcp.mobius.waila.service.IClientService;
import mcp.mobius.waila.util.Log;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.network.ClientConnection;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;

public abstract class WailaClient {

    private static final Log LOG = Log.create();

    public static KeyBinding keyOpenConfig;
    public static KeyBinding keyShowOverlay;
    public static KeyBinding keyToggleLiquid;
    public static KeyBinding keyShowRecipeInput;
    public static KeyBinding keyShowRecipeOutput;

    public static boolean showComponentBounds = false;
    public static boolean showFps = false;

    @Nullable
    private static IRecipeAction recipeAction;

    public static void setRecipeAction(IRecipeAction action) {
        if (recipeAction == null) {
            LOG.info("Show recipe action set for " + action.getModName());
        } else if (!recipeAction.getModName().equals(action.getModName())) {
            LOG.warn("Show recipe action is already set for " + recipeAction.getModName());
            LOG.warn("Replaced it with one for " + action.getModName());
        }

        recipeAction = action;
    }

    protected static List<KeyBinding> registerKeyBinds() {
        return List.of(
            keyOpenConfig = createKeyBind(Tl.Key.CONFIG),
            keyShowOverlay = createKeyBind(Tl.Key.SHOW_OVERLAY),
            keyToggleLiquid = createKeyBind(Tl.Key.TOGGLE_LIQUID),
            keyShowRecipeInput = createKeyBind(Tl.Key.SHOW_RECIPE_INPUT),
            keyShowRecipeOutput = createKeyBind(Tl.Key.SHOW_RECIPE_OUTPUT)
        );
    }

    protected static void onClientTick() {
        Waila.onAnyTick();

        var client = MinecraftClient.getInstance();
        var config = Waila.CONFIG.get();

        TooltipHandler.tick();

        while (keyOpenConfig.wasPressed()) {
            client.setScreen(new HomeScreen(null));
        }

        while (keyShowOverlay.wasPressed()) {
            if (config.getGeneral().getDisplayMode() == IWailaConfig.General.DisplayMode.TOGGLE) {
                config.getGeneral().setDisplayTooltip(!config.getGeneral().isDisplayTooltip());
            }
        }

        while (keyToggleLiquid.wasPressed()) {
            PluginConfig.set(WailaConstants.CONFIG_SHOW_FLUID, !PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_FLUID));
        }

        if (recipeAction != null) {
            while (keyShowRecipeInput.wasPressed()) {
                recipeAction.showInput(ClientAccessor.INSTANCE.getStack());
            }

            while (keyShowRecipeOutput.wasPressed()) {
                recipeAction.showOutput(ClientAccessor.INSTANCE.getStack());
            }
        }
    }

    protected static void onItemTooltip(ItemStack stack, List<Text> tooltip) {
        if (PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_ITEM_MOD_NAME)) {
            for (var listener : Registrar.get().eventListeners.get(Object.class)) {
                var name = listener.instance().instance().getHoveredItemModName(stack, PluginConfig.CLIENT);
                if (name != null) {
                    tooltip.add(IWailaConfig.get().getFormatter().modName(name));
                    return;
                }
            }
        }
    }

    protected static void onServerLogIn(ClientConnection connection) {
        Waila.BLACKLIST_CONFIG.invalidate();
        PluginConfig.getSyncableConfigs().forEach(config ->
            config.setServerValue(null));
    }

    protected static void onServerLogout(ClientConnection connection) {
        RegistryFilter.attach(null);
        Waila.BLACKLIST_CONFIG.invalidate();
        PluginConfig.getSyncableConfigs().forEach(config ->
            config.setServerValue(null));
    }

    private static KeyBinding createKeyBind(String id) {
        return IClientService.INSTANCE.createKeyBind(id, InputUtil.UNKNOWN_KEY.getCode());
    }

}
