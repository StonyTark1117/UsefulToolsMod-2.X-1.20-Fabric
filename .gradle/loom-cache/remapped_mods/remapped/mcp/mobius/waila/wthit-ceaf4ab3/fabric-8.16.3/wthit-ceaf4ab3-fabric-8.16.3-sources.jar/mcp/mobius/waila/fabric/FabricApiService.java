package mcp.mobius.waila.fabric;

import mcp.mobius.waila.service.ApiService;
import net.fabricmc.fabric.api.mininglevel.v1.MiningLevelManager;
import net.minecraft.block.Block;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.tag.TagKey;
import org.jetbrains.annotations.Nullable;

public class FabricApiService extends ApiService {

    @Override
    public @Nullable TagKey<Block> getTierTag(ToolMaterial tier) {
        return tier.getMiningLevel() <= 0 ? null : MiningLevelManager.getBlockTag(tier.getMiningLevel());
    }

}
