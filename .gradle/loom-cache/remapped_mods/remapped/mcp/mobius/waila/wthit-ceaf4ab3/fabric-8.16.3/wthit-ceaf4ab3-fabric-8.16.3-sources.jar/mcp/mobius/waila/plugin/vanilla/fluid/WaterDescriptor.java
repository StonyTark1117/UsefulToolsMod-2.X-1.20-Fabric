package mcp.mobius.waila.plugin.vanilla.fluid;

import mcp.mobius.waila.api.data.FluidData;
import mcp.mobius.waila.api.data.FluidData.CauldronDescriptor;
import mcp.mobius.waila.api.data.FluidData.FluidDescription;
import mcp.mobius.waila.api.data.FluidData.FluidDescriptionContext;
import mcp.mobius.waila.api.data.FluidData.FluidDescriptor;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeveledCauldronBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.text.Text;

public enum WaterDescriptor implements FluidDescriptor<FlowableFluid>, CauldronDescriptor {

    INSTANCE;

    private static final Text NAME = Text.translatable("block.minecraft.water");

    @Override
    public void describeFluid(FluidDescriptionContext<FlowableFluid> ctx, FluidDescription desc) {
        desc.name(NAME)
            .sprite(MinecraftClient.getInstance().getBakedModelManager().getBlockModels().getModel(Blocks.WATER.getDefaultState()).getParticleSprite())
            .tint(0xFF3F76E4);
    }

    @Override
    public FluidData getCauldronFluidData(BlockState state) {
        return FluidData.of(FluidData.Unit.MILLIBUCKETS, 1)
            .add(Fluids.WATER, null, state.get(LeveledCauldronBlock.LEVEL) * 1000 / 3.0, 1000);
    }

}
