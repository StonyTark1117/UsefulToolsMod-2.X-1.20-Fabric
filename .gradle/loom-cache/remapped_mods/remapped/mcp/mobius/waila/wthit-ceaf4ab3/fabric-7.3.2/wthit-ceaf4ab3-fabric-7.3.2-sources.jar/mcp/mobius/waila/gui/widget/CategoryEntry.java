package mcp.mobius.waila.gui.widget;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.util.math.MatrixStack;
import org.jetbrains.annotations.NotNull;

public class CategoryEntry extends ConfigListWidget.Entry {

    public CategoryEntry(String title) {
        this.category = I18n.translate(title);
    }

    @Override
    public void method_25343(@NotNull MatrixStack matrices, int index, int rowTop, int rowLeft, int width, int height, int mouseX, int mouseY, boolean hovered, float deltaTime) {
        DrawContext.drawCenteredTextWithShadow(matrices, client.textRenderer, category, rowLeft + width / 2, rowTop + height - client.textRenderer.fontHeight, 0xFFFFFF);
    }

    @Override
    protected boolean match(String filter) {
        return false;
    }

}
