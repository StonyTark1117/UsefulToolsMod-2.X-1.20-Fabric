package mcp.mobius.waila.access;

import java.util.HashMap;
import java.util.Map;

import mcp.mobius.waila.api.IData;
import mcp.mobius.waila.api.IDataReader;
import mcp.mobius.waila.registry.Registrar;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public enum DataReader implements IDataReader {

    INSTANCE;

    private NbtCompound raw;
    private final Map<Class<? extends IData>, IData> typed = new HashMap<>();
    private boolean clean;

    public void reset(@Nullable NbtCompound raw) {
        if (clean && raw == null) return;

        this.raw = raw == null ? new NbtCompound() : raw;
        this.clean = raw == null;

        this.typed.clear();
    }

    @SuppressWarnings("unchecked")
    public static IData readTypedPacket(PacketByteBuf buf) {
        Identifier id = buf.readIdentifier();
        IData.Serializer<IData> serializer = (IData.Serializer<IData>) Registrar.INSTANCE.dataId2Serializer.get(id);

        return serializer.read(buf);
    }

    @Override
    public NbtCompound raw() {
        return raw;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends IData> @Nullable T get(Class<T> type) {
        return (T) typed.get(type);
    }

    public void add(IData data) {
        clean = false;
        typed.put(data.getClass(), data);
    }

}
