package mcp.mobius.waila.gui.screen;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;

import com.google.gson.Gson;
import mcp.mobius.waila.Waila;
import mcp.mobius.waila.buildconst.Tl;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ElementListWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;

import static mcp.mobius.waila.util.DisplayUtil.createButton;

public class CreditsScreen extends Screen {

    private final Screen parent;

    protected CreditsScreen(Screen parent) {
        super(Text.translatable(Tl.Gui.CREDITS));

        this.parent = parent;
    }

    @Override
    @SuppressWarnings("ConstantConditions")
    protected void init() {
        super.init();

        try {
            CreditMap credits = new Gson().fromJson(client.getResourceManager().getResource(Waila.id("credits.json")).get().getReader(), CreditMap.class);

            ListWidget listWidget = new ListWidget(client, width, height, 32, height - 32, client.textRenderer.fontHeight + 6);
            credits.forEach((key, list) -> {
                List<Entry> children = listWidget.children();
                children.add(new Entry(Text.translatable(Tl.Gui.CREDITS + "." + key).formatted(Formatting.GRAY)));
                for (String person : list) {
                    children.add(new Entry(Text.literal("        " + person)));
                }
                children.add(new Entry(Text.empty()));
            });

            addDrawableChild(listWidget);
        } catch (IOException e) {
            e.printStackTrace();
        }

        addDrawableChild(createButton(width / 2 - 50, height - 25, 100, 20, ScreenTexts.DONE, w -> close()));
    }

    @Override
    public void method_25394(@NotNull MatrixStack matrices, int mouseX, int mouseY, float partialTicks) {
        renderBackground(matrices);
        super.render(matrices, mouseX, mouseY, partialTicks);
        method_25300(matrices, textRenderer, title.getString(), width / 2, 12, 0xFFFFFF);
    }

    @Override
    @SuppressWarnings("ConstantConditions")
    public void close() {
        client.setScreen(parent);
    }

    private static class CreditMap extends LinkedHashMap<String, List<String>> {

    }

    private static class ListWidget extends ElementListWidget<mcp.mobius.waila.gui.screen.CreditsScreen.Entry> {

        private ListWidget(MinecraftClient client, int width, int height, int top, int bottom, int itemHeight) {
            super(client, width, height, top, bottom, itemHeight);

            setRenderBackground(false);
        }

        @Override
        protected int getScrollbarPositionX() {
            return client.getWindow().getScaledWidth() - 5;
        }

    }

    private static class Entry extends ElementListWidget.Entry<Entry> {

        private final Text component;

        private Entry(Text component) {
            this.component = component;
        }

        @Override
        public @NotNull List<? extends Selectable> selectableChildren() {
            return Collections.emptyList();
        }

        @Override
        public @NotNull List<? extends Element> children() {
            return Collections.emptyList();
        }

        @Override
        public void method_25343(@NotNull MatrixStack matrices, int index, int rowTop, int rowLeft, int width, int height, int mouseX, int mouseY, boolean hovered, float deltaTime) {
            MinecraftClient.getInstance().textRenderer.method_30881(matrices, component, rowLeft, rowTop + 3, 0xFFFFFF);
        }

    }

}
