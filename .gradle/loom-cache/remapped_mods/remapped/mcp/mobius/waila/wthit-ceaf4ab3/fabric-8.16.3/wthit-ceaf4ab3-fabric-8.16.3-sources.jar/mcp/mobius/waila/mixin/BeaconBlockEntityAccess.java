package mcp.mobius.waila.mixin;

import net.minecraft.block.entity.BeaconBlockEntity;
import net.minecraft.entity.effect.StatusEffect;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(BeaconBlockEntity.class)
public interface BeaconBlockEntityAccess {

    @Nullable
    @Accessor("primaryPower")
    StatusEffect wthit_primaryPower();

    @Nullable
    @Accessor("secondaryPower")
    StatusEffect wthit_secondaryPower();

    @Accessor("levels")
    int wthit_levels();

}
