package mcp.mobius.waila.gui.hud.theme;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import mcp.mobius.waila.Waila;
import mcp.mobius.waila.util.Log;
import net.minecraft.resource.JsonDataLoader;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import net.minecraft.util.profiler.Profiler;
import org.jetbrains.annotations.NotNull;

public class BuiltinThemeLoader extends JsonDataLoader {

    private static final Log LOG = Log.create();

    public static final Map<Identifier, ThemeDefinition<?>> THEMES = new HashMap<>();

    protected static final Identifier ID = Waila.id("builtin_themes");

    public BuiltinThemeLoader() {
        super(new Gson(), "waila_themes");
    }

    @Override
    protected void apply(@NotNull Map<Identifier, JsonElement> map, @NotNull ResourceManager manager, @NotNull Profiler profiler) {
        THEMES.clear();

        map.forEach((id, json) -> {
            try {
                Waila.CONFIG.get().getOverlay().getColor().getCustomThemes().remove(id);
                THEMES.put(id, ThemeDefinition.Adapter.deserialize(id, json, true));
            } catch (Exception e) {
                LOG.error("Couldn't parse builtin theme definition {}", id, e);
            }
        });

        Waila.CONFIG.save();
    }

}
