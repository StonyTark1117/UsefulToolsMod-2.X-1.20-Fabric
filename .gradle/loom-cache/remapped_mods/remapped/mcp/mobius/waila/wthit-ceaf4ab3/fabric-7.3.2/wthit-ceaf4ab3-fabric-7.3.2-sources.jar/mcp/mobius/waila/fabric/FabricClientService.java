package mcp.mobius.waila.fabric;

import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.service.IClientService;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

public class FabricClientService implements IClientService {

    @Override
    public KeyBinding createKeyBind(String id, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(id, InputUtil.Type.KEYSYM, key, WailaConstants.MOD_NAME));
    }

}
