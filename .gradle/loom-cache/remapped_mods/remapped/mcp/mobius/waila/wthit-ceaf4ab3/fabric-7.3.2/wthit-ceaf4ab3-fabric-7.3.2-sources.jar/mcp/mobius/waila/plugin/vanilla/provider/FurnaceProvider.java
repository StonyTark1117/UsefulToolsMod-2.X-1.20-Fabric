package mcp.mobius.waila.plugin.vanilla.provider;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.component.ItemComponent;
import mcp.mobius.waila.api.component.ProgressArrowComponent;
import mcp.mobius.waila.mixin.AbstractFurnaceBlockEntityAccess;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.block.FurnaceBlock;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;

public enum FurnaceProvider implements IBlockComponentProvider, IDataProvider<AbstractFurnaceBlockEntity> {

    INSTANCE;

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(Options.FURNACE_CONTENTS) && accessor.getData().raw().contains("progress")) {
            NbtCompound tag = accessor.getData().raw();
            NbtList furnaceItems = tag.getList("furnace", NbtElement.COMPOUND_TYPE);

            float progress = tag.getInt("progress");
            float total = tag.getInt("total");

            tooltip.addLine()
                .with(new ItemComponent(ItemStack.fromNbt(furnaceItems.getCompound(0))))
                .with(new ItemComponent(ItemStack.fromNbt(furnaceItems.getCompound(1))))
                .with(new ProgressArrowComponent(progress / total))
                .with(new ItemComponent(ItemStack.fromNbt(furnaceItems.getCompound(2))));
        }
    }

    @Override
    public void appendData(IDataWriter data, IServerAccessor<AbstractFurnaceBlockEntity> accessor, IPluginConfig config) {
        if (config.getBoolean(Options.FURNACE_CONTENTS)) {
            AbstractFurnaceBlockEntity furnace = accessor.getTarget();
            AbstractFurnaceBlockEntityAccess access = (AbstractFurnaceBlockEntityAccess) furnace;
            if (furnace.getCachedState().get(FurnaceBlock.LIT)) {
                NbtList items = new NbtList();
                items.add(furnace.getStack(0).writeNbt(new NbtCompound()));
                items.add(furnace.getStack(1).writeNbt(new NbtCompound()));
                items.add(furnace.getStack(2).writeNbt(new NbtCompound()));

                NbtCompound raw = data.raw();
                raw.put("furnace", items);
                raw.putInt("progress", access.wthit_cookingProgress());
                raw.putInt("total", access.wthit_cookingTotalTime());
            }
        }
    }

}
