package mcp.mobius.waila.access;

import mcp.mobius.waila.api.IServerAccessor;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;

public enum ServerAccessor implements IServerAccessor<Object> {

    INSTANCE;

    private World world;
    private ServerPlayerEntity player;
    private HitResult hitResult;
    private Object target;

    @SuppressWarnings("unchecked")
    public <T> IServerAccessor<T> set(World world, ServerPlayerEntity player, HitResult hitResult, Object target) {
        this.world = world;
        this.player = player;
        this.hitResult = hitResult;
        this.target = target;

        return (IServerAccessor<T>) this;
    }

    @Override
    public World getWorld() {
        return world;
    }

    @Override
    public ServerPlayerEntity getPlayer() {
        return player;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <H extends HitResult> H getHitResult() {
        return (H) hitResult;
    }

    @Override
    public Object getTarget() {
        return target;
    }

}
