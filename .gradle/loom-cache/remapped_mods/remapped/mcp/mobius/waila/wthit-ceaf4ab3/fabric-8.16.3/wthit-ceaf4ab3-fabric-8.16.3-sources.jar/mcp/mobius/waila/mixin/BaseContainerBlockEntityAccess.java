package mcp.mobius.waila.mixin;

import net.minecraft.block.entity.LockableContainerBlockEntity;
import net.minecraft.inventory.ContainerLock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(LockableContainerBlockEntity.class)
public interface BaseContainerBlockEntityAccess {

    @Accessor("lockKey")
    ContainerLock wthit_lockKey();

    @Accessor("lockKey")
    void wthit_lockKey(ContainerLock lockKey);

}
