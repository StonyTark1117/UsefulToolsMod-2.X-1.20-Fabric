package mcp.mobius.waila.service;

import mcp.mobius.waila.config.JsonConfig;
import mcp.mobius.waila.config.PluginConfig;
import mcp.mobius.waila.mixed.IMixedService;
import mcp.mobius.waila.registry.RegistryFilter;
import net.minecraft.client.network.ClientDynamicRegistryType;
import net.minecraft.registry.CombinedDynamicRegistries;
import net.minecraft.registry.DynamicRegistryManager;

public class MixedService implements IMixedService {

    @Override
    public void ReloadableServerResources_updateRegistryTags(DynamicRegistryManager registryAccess) {
        RegistryFilter.attach(registryAccess);
    }

    @Override
    public void ClientPacketListener_handleUpdateTags(CombinedDynamicRegistries<ClientDynamicRegistryType> registryAccess) {
        RegistryFilter.attach(registryAccess.getCombinedRegistryManager());
    }

    @Override
    public void onLanguageReloaded() {
        JsonConfig.reloadAllInstances();
        PluginConfig.write();
    }

}
