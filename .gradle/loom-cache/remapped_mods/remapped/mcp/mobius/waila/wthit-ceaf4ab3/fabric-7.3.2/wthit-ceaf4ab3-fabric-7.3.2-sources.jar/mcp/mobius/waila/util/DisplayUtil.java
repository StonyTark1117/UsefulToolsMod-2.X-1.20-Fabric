package mcp.mobius.waila.util;

import java.util.IllegalFormatException;
import java.util.Random;
import com.mojang.blaze3d.systems.RenderSystem;
import mcp.mobius.waila.WailaClient;
import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.WailaHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;

public final class DisplayUtil extends DrawContext {

    private static final Random RANDOM = new Random();

    private static final MinecraftClient CLIENT = MinecraftClient.getInstance();

    public static void renderStack(MatrixStack matrices, int x, int y, ItemStack stack) {
        renderStack(matrices, x, y, stack, stack.getCount() > 1 ? WailaHelper.suffix(stack.getCount()) : "");
    }

    public static void renderStack(MatrixStack matrices, int x, int y, ItemStack stack, String countText) {
        enable3DRender();
        try {
            CLIENT.getItemRenderer().method_4010(matrices, stack, x, y);
            CLIENT.getItemRenderer().method_4022(matrices, CLIENT.textRenderer, stack, x, y, countText);
        } catch (Exception e) {
            String stackStr = stack != null ? stack.toString() : "NullStack";
            ExceptionUtil.dump(e, "renderStack | " + stackStr, null);
        }
        enable2DRender();
    }

    public static void enable3DRender() {
        DiffuseLighting.enableGuiDepthLighting();
        RenderSystem.enableDepthTest();
    }

    public static void enable2DRender() {
        DiffuseLighting.disableGuiDepthLighting();
        RenderSystem.disableDepthTest();
    }

    public static void renderRectBorder(Matrix4f matrix, BufferBuilder buf, int x, int y, int w, int h, int s, int gradStart, int gradEnd) {
        if (s <= 0) {
            return;
        }

        // @formatter:off
        fillGradient(matrix, buf, x        , y        , w, s          , gradStart, gradStart);
        fillGradient(matrix, buf, x        , y + h - s, w, s          , gradEnd  , gradEnd);
        fillGradient(matrix, buf, x        , y + s    , s, h - (s * 2), gradStart, gradEnd);
        fillGradient(matrix, buf, x + w - s, y + s    , s, h - (s * 2), gradStart, gradEnd);
        // @formatter:on
    }

    public static void renderComponent(MatrixStack matrices, ITooltipComponent component, int x, int y, float delta) {
        component.render(matrices, x, y, delta);

        if (WailaClient.showComponentBounds) {
            matrices.push();
            float scale = (float) MinecraftClient.getInstance().getWindow().getScaleFactor();
            matrices.scale(1 / scale, 1 / scale, 1);

            RenderSystem.setShader(GameRenderer::getPositionColorProgram);

            Tessellator tesselator = Tessellator.getInstance();
            BufferBuilder buf = tesselator.getBuffer();
            buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            int bx = MathHelper.floor(x * scale + 0.5);
            int by = MathHelper.floor(y * scale + 0.5);
            int bw = MathHelper.floor(component.getWidth() * scale + 0.5);
            int bh = MathHelper.floor(component.getHeight() * scale + 0.5);
            int color = (0xFF << 24) + MathHelper.hsvToRgb(RANDOM.nextFloat(), RANDOM.nextFloat(), 1f);
            renderRectBorder(matrices.peek().getPositionMatrix(), buf, bx, by, bw, bh, 1, color, color);
            tesselator.draw();

            matrices.pop();
        }
    }

    public static void fillGradient(Matrix4f matrix, BufferBuilder buf, int x, int y, int w, int h, int start, int end) {
        fillGradient(matrix, buf, x, y, x + w, y + h, 0, start, end);
    }

    public static int getAlphaFromPercentage(int percentage) {
        return percentage == 100 ? 255 << 24 : percentage == 0 ? (int) (0.4F / 100.0F * 256) << 24 : (int) (percentage / 100.0F * 256) << 24;
    }

    public static String tryFormat(String format, Object... args) {
        try {
            return format.formatted(args);
        } catch (IllegalFormatException e) {
            return "FORMATTING ERROR";
        }
    }

    public static ButtonWidget createButton(int x, int y, int width, int height, Text label, ButtonWidget.PressAction pressAction) {
        return ButtonWidget.builder(label, pressAction).dimensions(x, y, width, height).build();
    }

}
