package mcp.mobius.waila.plugin.vanilla.provider;

import I;
import it.unimi.dsi.fastutil.objects.Object2IntLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.component.PairComponent;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import mcp.mobius.waila.plugin.vanilla.provider.data.BeehiveDataProvider;
import mcp.mobius.waila.plugin.vanilla.provider.data.BeehiveDataProvider.OccupantsData;
import mcp.mobius.waila.plugin.vanilla.provider.data.BeehiveDataProvider.OccupantsData.Occupant;
import net.minecraft.block.BeehiveBlock;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;

public enum BeehiveProvider implements IBlockComponentProvider {

    INSTANCE;

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        var occupants = accessor.getData().get(BeehiveDataProvider.OccupantsData.class);
        if (occupants != null && config.getBoolean(Options.BEE_HIVE_OCCUPANTS)) {
            var names = new Object2IntLinkedOpenHashMap<String>(occupants.occupants().size());

            for (var occupant : occupants.occupants()) {
                Text component = null;
                if (occupant.customName() != null) component = Text.Serializer.fromJson(occupant.customName());
                if (component == null) component = occupant.entityType().getName();

                var name = component.getString();
                names.put(name, names.getOrDefault(name, 0) + 1);
            }

            if (!names.isEmpty()) {
                var component = Text.empty();

                for (var entry : names.object2IntEntrySet()) {
                    if (!component.getSiblings().isEmpty()) component.append(ScreenTexts.LINE_BREAK);
                    var name = entry.getKey();
                    var count = entry.getIntValue();
                    if (count > 1) component.append(Text.literal(count + " " + name));
                    else component.append(Text.literal(name));
                }

                tooltip.setLine(Options.BEE_HIVE_OCCUPANTS, component);
            }
        }

        if (config.getBoolean(Options.BEE_HIVE_HONEY_LEVEL)) {
            var state = accessor.getBlockState();
            tooltip.setLine(Options.BEE_HIVE_HONEY_LEVEL, new PairComponent(
                Text.translatable(Tl.Tooltip.HONEY_LEVEL),
                Text.literal(state.get(BeehiveBlock.HONEY_LEVEL).toString())));
        }
    }

}
