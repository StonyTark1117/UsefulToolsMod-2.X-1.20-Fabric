package mcp.mobius.waila.plugin.test;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.component.PairComponent;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;

public enum HitResultServerDependantTest implements IBlockComponentProvider, IDataProvider<BlockEntity> {

    INSTANCE;

    static final Identifier ENABLED = new Identifier("test:hit_result.enabled");

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(ENABLED)) {
            tooltip.addLine(new PairComponent(Text.literal("hitX"), Text.literal("" + accessor.getData().raw().getDouble("hitX"))));
        }
    }

    @Override
    public void appendData(IDataWriter data, IServerAccessor<BlockEntity> accessor, IPluginConfig config) {
        if (config.getBoolean(ENABLED)) {
            BlockHitResult hitResult = accessor.getHitResult();
            data.raw().putDouble("hitX", hitResult.getPos().x);
        }
    }

}
