package mcp.mobius.waila.plugin.extra.data;

import I;
import java.util.ArrayList;

import mcp.mobius.waila.api.data.ProgressData;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;

public class ProgressDataImpl extends ProgressData {

    private final float ratio;

    public ProgressDataImpl(float ratio) {
        this.ratio = ratio;
    }

    public ProgressDataImpl(PacketByteBuf buf) {
        this.ratio = buf.readFloat();

        var inputSize = buf.readVarInt();
        input.ensureCapacity(inputSize);
        for (var i = 0; i < inputSize; i++) {
            input.add(buf.readItemStack());
        }

        var outputSize = buf.readVarInt();
        output.ensureCapacity(outputSize);
        for (var i = 0; i < outputSize; i++) {
            output.add(buf.readItemStack());
        }
    }

    @Override
    public void write(PacketByteBuf buf) {
        buf.writeFloat(ratio);

        buf.writeVarInt(input.size());
        for (var stack : input) {
            buf.writeItemStack(stack);
        }

        buf.writeVarInt(output.size());
        for (var stack : output) {
            buf.writeItemStack(stack);
        }
    }

    public float ratio() {
        return ratio;
    }

    public ArrayList<ItemStack> input() {
        return input;
    }

    public ArrayList<ItemStack> output() {
        return output;
    }

}
