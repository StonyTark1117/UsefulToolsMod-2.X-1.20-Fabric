package mcp.mobius.waila.plugin.vanilla.provider;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.component.PairComponent;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.block.BlockState;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

public enum BlockAttributesProvider implements IBlockComponentProvider {

    INSTANCE;

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(Options.ATTRIBUTE_BLOCK_POSITION)) {
            BlockPos pos = accessor.getPosition();
            tooltip.addLine(Text.literal("(" + pos.getX() + ", " + pos.getY() + ", " + pos.getZ() + ")"));
        }

        if (config.getBoolean(Options.ATTRIBUTE_BLOCK_STATE)) {
            BlockState state = accessor.getBlockState();
            state.getProperties().forEach(property -> {
                Comparable<?> value = state.get(property);
                MutableText valueText = Text.literal(value.toString());
                if (property instanceof BooleanProperty) {
                    valueText.formatted(value == Boolean.TRUE ? Formatting.GREEN : Formatting.RED);
                }
                tooltip.addLine(new PairComponent(Text.literal(property.getName()), valueText));
            });
        }
    }

}
