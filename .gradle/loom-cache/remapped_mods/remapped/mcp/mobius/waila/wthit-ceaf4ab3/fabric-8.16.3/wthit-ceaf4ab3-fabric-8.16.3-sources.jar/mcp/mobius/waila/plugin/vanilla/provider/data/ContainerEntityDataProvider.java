package mcp.mobius.waila.plugin.vanilla.provider.data;

import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.data.ItemData;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.VehicleInventory;
import net.minecraft.inventory.Inventory;

public enum ContainerEntityDataProvider implements IDataProvider<Entity> {

    INSTANCE;

    @Override
    public void appendData(IDataWriter data, IServerAccessor<Entity> accessor, IPluginConfig config) {
        data.add(ItemData.class, res -> {
            var entity = accessor.getTarget();

            if (entity instanceof VehicleInventory container && container.getLootTableId() != null) {
                res.block();
                return;
            }

            res.add(ItemData.of(config).vanilla((Inventory) entity));
        });
    }

}
