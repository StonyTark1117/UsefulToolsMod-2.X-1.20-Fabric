package mcp.mobius.waila.plugin.test;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITargetRedirector;
import net.minecraft.block.Blocks;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public enum RedirectTest implements IBlockComponentProvider {

    INSTANCE;

    public static final Identifier TARGET = new Identifier("test:redirect.target");

    public enum Target {
        NONE, SELF, BEHIND, HIT, NOWHERE
    }

    @Override
    public @Nullable ITargetRedirector.Result redirect(ITargetRedirector redirect, IBlockAccessor accessor, IPluginConfig config) {
        if (accessor.getBlock() != Blocks.BLACK_WOOL) return null;

        Target target = config.getEnum(TARGET);
        return switch (target) {
            case NONE -> null;
            case SELF -> redirect.toSelf();
            case BEHIND -> redirect.toBehind();
            case HIT -> redirect.to(accessor.getBlockHitResult().withBlockPos(accessor.getPosition().up()));
            case NOWHERE -> redirect.toNowhere();
        };
    }

}
