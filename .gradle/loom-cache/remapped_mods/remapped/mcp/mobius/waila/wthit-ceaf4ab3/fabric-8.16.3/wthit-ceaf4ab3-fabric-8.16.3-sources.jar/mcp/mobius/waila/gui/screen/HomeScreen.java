package mcp.mobius.waila.gui.screen;

import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.buildconst.Tl;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static mcp.mobius.waila.util.DisplayUtil.createButton;

public class HomeScreen extends YesIAmSureTheClientInstanceIsPresentByTheTimeIUseItScreen {

    private final @Nullable Screen parent;

    public HomeScreen(@Nullable Screen parent) {
        super(Text.literal(WailaConstants.MOD_NAME));

        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();

        addDrawableChild(createButton(width / 2 - 100, height / 2 - 60, 200, 20, Text.translatable(Tl.Gui.WAILA_SETTINGS, WailaConstants.MOD_NAME), w ->
            client.setScreen(new WailaConfigScreen(this))));
        addDrawableChild(createButton(width / 2 - 100, height / 2 - 36, 200, 20, Text.translatable(Tl.Gui.Plugin.TOGGLE), w ->
            client.setScreen(new PluginToggleScreen(this))));
        addDrawableChild(createButton(width / 2 - 100, height / 2 - 12, 200, 20, Text.translatable(Tl.Gui.Plugin.SETTINGS), w ->
            client.setScreen(new PluginConfigScreen(this))));
        addDrawableChild(createButton(width / 2 - 100, height / 2 + 12, 200, 20, Text.translatable(Tl.Gui.CREDITS), w ->
            client.setScreen(new CreditsScreen(this))));
        addDrawableChild(createButton(width / 2 - 50, height / 2 + 36, 100, 20, ScreenTexts.DONE, w ->
            client.setScreen(parent)));
    }

    @Override
    public void render(@NotNull DrawContext ctx, int x, int y, float partialTicks) {
        renderBackground(ctx);
        ctx.drawCenteredTextWithShadow(textRenderer, title.getString(), width / 2, height / 2 - 62 - textRenderer.fontHeight, 0xFFFFFF);
        super.render(ctx, x, y, partialTicks);
    }

}
