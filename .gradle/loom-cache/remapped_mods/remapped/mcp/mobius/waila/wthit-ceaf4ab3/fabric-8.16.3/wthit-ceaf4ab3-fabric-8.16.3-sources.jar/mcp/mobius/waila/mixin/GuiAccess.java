package mcp.mobius.waila.mixin;

import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(InGameHud.class)
public interface GuiAccess {

    @Accessor("GUI_ICONS_LOCATION")
    static Identifier wthit_guiIconsLocation() {
        throw new AssertionError("mixin");
    }

}
