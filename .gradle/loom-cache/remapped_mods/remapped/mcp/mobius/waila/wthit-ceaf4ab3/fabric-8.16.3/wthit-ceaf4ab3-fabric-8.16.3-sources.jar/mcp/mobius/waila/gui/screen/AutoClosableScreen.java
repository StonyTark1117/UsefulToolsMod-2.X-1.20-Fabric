package mcp.mobius.waila.gui.screen;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.text.Text;

@SuppressWarnings("DataFlowIssue")
public class AutoClosableScreen extends HandledScreen<AutoClosableScreen.Menu> {

    private AutoClosableScreen() {
        super(new Menu(), MinecraftClient.getInstance().player.getInventory(), Text.empty());
    }

    public static void inject() {
        var client = MinecraftClient.getInstance();
        var screen = client.currentScreen;
        if (!(screen instanceof AutoClosableScreen)) {
            client.setScreen(new AutoClosableScreen());
        }
    }

    @Override
    protected void drawBackground(DrawContext guiGraphics, float v, int i, int i1) {
        if (client.currentScreen == this) {
            client.setScreen(null);
        }
    }

    public static class Menu extends ScreenHandler {

        protected Menu() {
            super(null, 0);
        }

        @Override
        public ItemStack quickMove(PlayerEntity player, int i) {
            return ItemStack.EMPTY;
        }

        @Override
        public boolean canUse(PlayerEntity player) {
            return false;
        }

    }

}
