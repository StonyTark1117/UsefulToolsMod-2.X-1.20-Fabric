package mcp.mobius.waila.command;

import java.util.Arrays;
import java.util.stream.Stream;

import com.google.gson.JsonPrimitive;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import mcp.mobius.waila.Waila;
import mcp.mobius.waila.WailaClient;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.config.ConfigEntry;
import mcp.mobius.waila.config.PluginConfig;
import mcp.mobius.waila.gui.screen.HomeScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.command.argument.IdentifierArgumentType;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import static net.minecraft.command.CommandSource.suggestMatching;
import static net.minecraft.command.CommandSource.suggestFromIdentifier;

public abstract class ClientCommand<S> {

    private final ArgumentBuilderFactory<S> argument;

    protected ClientCommand(ArgumentBuilderFactory<S> argument) {
        this.argument = argument;
    }

    protected abstract FeedbackSender feedback(S source);

    public final void register(CommandDispatcher<S> dispatcher) {
        ArgumentBuilderBuilder<S> command = new ArgumentBuilderBuilder<>(argument.literal(WailaConstants.NAMESPACE + "c"))

            .then(argument.literal("config"))

            .then(argument.literal("open"))
            .executes(context -> {
                MinecraftClient client = MinecraftClient.getInstance();
                client.send(() -> client.setScreen(new HomeScreen(client.currentScreen)));
                return 1;
            })

            .pop("open")

            .then(argument.literal("plugin"))

            .then(argument.required("id", IdentifierArgumentType.identifier()))
            .suggests((context, builder) -> method_9270(PluginConfig.getAllKeys(), builder))
            .executes(context -> {
                FeedbackSender feedback = feedback(context.getSource());
                Identifier id = context.getArgument("id", Identifier.class);
                ConfigEntry<?> entry = PluginConfig.getEntry(id);
                if (entry == null) {
                    feedback.fail(Text.translatable(Tl.Command.Config.UNKNOWN_ID, id));
                    return 0;
                }

                feedback.success(Text.translatable(Tl.Command.Config.Get.ID, id));
                feedback.success(Text.translatable(Tl.Command.Config.Get.SYNCED, entry.isSynced()));
                feedback.success(Text.translatable(Tl.Command.Config.Get.CURRENT_VALUE, entry.getValue(false).toString()));
                feedback.success(Text.translatable(Tl.Command.Config.Get.DEFAULT_VALUE, entry.getDefaultValue().toString()));
                if (entry.isServerRequired()) {
                    feedback.success(Text.translatable(Tl.Command.Config.Get.CLIENT_ONLY_VALUE, entry.getClientOnlyValue().toString()));
                }
                return 1;
            })

            .then(argument.required("value", StringArgumentType.word()))
            .suggests((context, builder) -> {
                Identifier id = context.getArgument("id", Identifier.class);
                ConfigEntry<Object> entry = PluginConfig.getEntry(id);
                if (entry != null) {
                    if (entry.getType().equals(ConfigEntry.BOOLEAN)) {
                        return method_9253(new String[]{String.valueOf(!((boolean) entry.getValue(false)))}, builder);
                    } else if (entry.getType().equals(ConfigEntry.ENUM)) {
                        Stream<String> suggestions = Arrays.stream(entry.getLocalValue().getClass().getEnumConstants())
                            .filter(e -> e != entry.getLocalValue())
                            .map(e -> ((Enum<?>) e).name());
                        return method_9264(suggestions, builder);
                    }
                }
                return method_9253(new String[0], builder);
            })
            .executes(context -> {
                FeedbackSender feedback = feedback(context.getSource());
                Identifier id = context.getArgument("id", Identifier.class);
                ConfigEntry<Object> entry = PluginConfig.getEntry(id);
                if (entry == null) {
                    feedback.fail(Text.translatable(Tl.Command.Config.UNKNOWN_ID, id));
                    return 0;
                }

                if (entry.blocksClientEdit() && MinecraftClient.getInstance().getCurrentServerEntry() != null) {
                    feedback.fail(Text.translatable(Tl.Command.Config.Set.SYNCED, id));
                }

                JsonPrimitive jsonValue = new JsonPrimitive(context.getArgument("value", String.class));
                try {
                    entry.setLocalValue(entry.getType().parser.apply(jsonValue, entry.getDefaultValue()));
                    feedback.success(Text.translatable(Tl.Command.Config.Set.SUCCESS, id, entry.getLocalValue()));
                    return 1;
                } catch (Throwable throwable) {
                    feedback.fail(Text.translatable(Tl.Command.Config.Set.PARSE_FAIL, throwable.getMessage()));
                    throwable.printStackTrace();
                    return 0;
                }
            })

            .pop("value", "id", "plugin", "config")

            .then(argument.literal("overlay"))
            .then(argument.required("enabled", BoolArgumentType.bool()))
            .suggests((context, builder) -> method_9253(new String[]{String.valueOf(!Waila.CONFIG.get().getGeneral().isDisplayTooltip())}, builder))
            .executes(context -> {
                FeedbackSender feedback = feedback(context.getSource());
                boolean enabled = BoolArgumentType.getBool(context, "enabled");
                Waila.CONFIG.get().getGeneral().setDisplayTooltip(enabled);
                feedback.success(Text.translatable(enabled ? Tl.Command.Overlay.TRUE : Tl.Command.Overlay.FALSE));
                return enabled ? 1 : 0;
            })

            .pop("enabled", "overlay");

        if (Waila.ENABLE_DEBUG_COMMAND) {
            command
                .then(argument.literal("debug"))

                .then(argument.literal("showComponentBounds"))
                .then(argument.required("enabled", BoolArgumentType.bool()))
                .suggests((context, builder) -> method_9253(new String[]{String.valueOf(!WailaClient.showComponentBounds)}, builder))
                .executes(context -> {
                    FeedbackSender feedback = feedback(context.getSource());
                    boolean enabled = BoolArgumentType.getBool(context, "enabled");
                    MinecraftClient.getInstance().execute(() -> WailaClient.showComponentBounds = enabled);
                    feedback.success(Text.literal((enabled ? "En" : "Dis") + "abled component bounds"));
                    return enabled ? 1 : 0;
                })

                .pop("enabled", "showComponentBounds", "debug");
        }

        command.register(dispatcher);
    }

    protected interface ArgumentBuilderFactory<S> {

        LiteralArgumentBuilder<S> literal(String name);

        <T> RequiredArgumentBuilder<S, T> required(String name, ArgumentType<T> type);

    }

    protected interface FeedbackSender {

        void success(Text message);

        void fail(Text message);

    }


}
