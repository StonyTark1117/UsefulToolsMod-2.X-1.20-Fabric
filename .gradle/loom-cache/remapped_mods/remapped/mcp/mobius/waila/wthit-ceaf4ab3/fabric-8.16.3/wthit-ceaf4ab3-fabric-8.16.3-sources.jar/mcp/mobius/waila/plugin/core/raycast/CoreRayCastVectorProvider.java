package mcp.mobius.waila.plugin.core.raycast;

import mcp.mobius.waila.api.IRayCastVectorProvider;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

@SuppressWarnings("DataFlowIssue")
public enum CoreRayCastVectorProvider implements IRayCastVectorProvider {

    INSTANCE;

    @Override
    public Vec3d getOrigin(float delta) {
        return MinecraftClient.getInstance().getCameraEntity().getCameraPosVec(delta);
    }

    @Override
    public Vec3d getDirection(float delta) {
        return MinecraftClient.getInstance().getCameraEntity().getRotationVec(delta);
    }

}
