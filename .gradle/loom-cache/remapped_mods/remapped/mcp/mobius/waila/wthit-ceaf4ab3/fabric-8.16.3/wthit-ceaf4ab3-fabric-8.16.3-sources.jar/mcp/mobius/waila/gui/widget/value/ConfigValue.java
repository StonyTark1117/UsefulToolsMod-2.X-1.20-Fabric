package mcp.mobius.waila.gui.widget.value;

import java.util.List;
import java.util.function.Consumer;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import mcp.mobius.waila.gui.widget.ConfigListWidget;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.text.MutableText;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static mcp.mobius.waila.util.DisplayUtil.createButton;

import I;

public abstract class ConfigValue<T> extends ConfigListWidget.Entry {

    protected final Consumer<T> save;
    protected final String translationKey;

    @Nullable
    protected final T defaultValue;
    protected final T initialValue;

    private final MutableText title;
    private final String description;
    private final ButtonWidget resetButton;

    @Nullable
    private String disabledReason = null;
    private boolean disabled = false;

    @Nullable
    private String id;

    private T value;
    private int x;

    public ConfigValue(String translationKey, T value, @Nullable T defaultValue, Consumer<T> save) {
        this.translationKey = translationKey;
        this.title = Text.translatable(translationKey);
        this.description = translationKey + "_desc";
        this.initialValue = value;
        this.value = value;
        this.save = save;
        this.defaultValue = defaultValue;
        this.resetButton = defaultValue == null ? null
            : createButton(0, 0, 40, 20, Text.translatable("controls.reset"), button -> resetValue());
    }

    @Override
    protected void drawEntry(DrawContext ctx, int index, int rowTop, int rowLeft, int width, int height, int mouseX, int mouseY, boolean hovered, float deltaTime) {
        var title = getTitle();

        if (isDisabled()) title.formatted(Formatting.STRIKETHROUGH, Formatting.GRAY);
        else if (!isValueValid()) title.formatted(Formatting.ITALIC, Formatting.RED);
        else if (!value.equals(initialValue)) title.formatted(Formatting.ITALIC, Formatting.YELLOW);
        else title.formatted(Formatting.RESET);

        ctx.drawTextWithShadow(client.textRenderer, title.copy(), rowLeft, rowTop + (height - client.textRenderer.fontHeight) / 2, 0xFFFFFF);

        var w = width;
        if (resetButton != null) {
            w -= resetButton.getWidth() + 2;
            resetButton.setX(rowLeft + width - resetButton.getWidth());
            resetButton.setY(rowTop + (height - resetButton.getHeight()) / 2);
            resetButton.active = !isValueValid() || (!isDisabled() && !getValue().equals(defaultValue));
            resetButton.render(ctx, mouseX, mouseY, deltaTime);
        }

        drawValue(ctx, w, height, rowLeft, rowTop, mouseX, mouseY, hovered, deltaTime);
        this.x = rowLeft;
    }

    public void renderTooltip(DrawContext ctx, int mouseX, int mouseY) {
        for (Element child : children()) {
            if (child instanceof ClickableWidget widget) {
                var x1 = widget.getX() - 2;
                var y1 = widget.getY();
                var x2 = widget.getX() + widget.getWidth() + 4;
                var y2 = widget.getY() + widget.getHeight() + 4;
                if (x1 <= mouseX && mouseX <= x2 && y1 <= mouseY && mouseY <= y2) return;
            }
        }

        var desc = getDescription();
        if (id != null || desc != null || (isDisabled() && disabledReason != null)) {
            var title = getTitle().getString();
            List<OrderedText> tooltip = Lists.newArrayList(Text.literal(title).asOrderedText());
            if (desc != null) {
                tooltip.addAll(client.textRenderer.wrapLines(desc, 250));
            }
            if (isDisabled() && disabledReason != null) {
                tooltip.addAll(client.textRenderer.wrapLines(Text.translatable(disabledReason).formatted(Formatting.RED), 250));
            }
            if (id != null) {
                tooltip.add(Text.literal(id).formatted(Formatting.DARK_GRAY).asOrderedText());
            }
            ctx.drawOrderedTooltip(client.textRenderer, tooltip, mouseX, mouseY);
        }
    }

    public boolean isValueValid() {
        return true;
    }

    @Override
    protected void buildSearchKey(StringBuilder sb) {
        sb.append(getTitle().getString());
        var desc = getDescription();
        if (desc != null) sb.append(" ").append(desc.getString());
    }

    @Override
    protected void gatherChildren(ImmutableList.Builder<Element> children) {
        var element = getListener();
        if (element != null) {
            children.add(element);
        }

        var resetButton = getResetButton();
        if (resetButton != null) {
            children.add(resetButton);
        }
    }

    public void save() {
        if (!isDisabled()) {
            save.accept(getValue());
        }
    }

    @Nullable
    public Element getListener() {
        return null;
    }

    @Nullable
    public ButtonWidget getResetButton() {
        return resetButton;
    }

    public MutableText getTitle() {
        return title;
    }

    @Nullable
    public Text getDescription() {
        return I18n.hasTranslation(description) ? Text.translatable(description).formatted(Formatting.GRAY) : null;
    }

    public int getX() {
        return x;
    }

    public final @NotNull T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    @SuppressWarnings("DataFlowIssue")
    protected void resetValue() {
        setValue(defaultValue);
    }

    public void enable() {
        this.disabledReason = null;
        this.disabled = false;
    }

    public void disable(@Nullable String reason) {
        this.disabledReason = reason;
        this.disabled = true;
    }

    public final boolean isDisabled() {
        return disabled;
    }

    public void setId(@Nullable String id) {
        this.id = id;
    }

    protected abstract void drawValue(DrawContext ctx, int width, int height, int x, int y, int mouseX, int mouseY, boolean selected, float partialTicks);

}
