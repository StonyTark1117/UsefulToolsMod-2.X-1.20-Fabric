package mcp.mobius.waila.gui.screen;

import Z;
import it.unimi.dsi.fastutil.objects.Object2BooleanOpenHashMap;
import java.util.List;
import mcp.mobius.waila.api.IWailaConfig;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.gui.widget.ConfigListWidget;
import mcp.mobius.waila.gui.widget.value.BooleanValue;
import mcp.mobius.waila.plugin.PluginInfo;
import mcp.mobius.waila.plugin.PluginLoader;
import net.minecraft.client.gui.screen.ConfirmScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class PluginToggleScreen extends ConfigScreen {

    public PluginToggleScreen(Screen parent) {
        super(parent, Text.translatable(Tl.Gui.Plugin.TOGGLE));
    }

    @Override
    public ConfigListWidget getOptions() {
        var initialValues = new Object2BooleanOpenHashMap<Identifier>();
        var updatedValues = new Object2BooleanOpenHashMap<Identifier>();

        var options = new ConfigListWidget(this, client, width, height, 32, height - 32, 26, () -> {
            if (initialValues.equals(updatedValues)) {
                super.close();
                return;
            }

            client.setScreen(new ConfirmScreen(accepted -> {
                if (!accepted) {
                    super.close();
                    return;
                }

                updatedValues.forEach((k, v) -> ((PluginInfo) PluginInfo.get(k)).setEnabled(v));
                var integratedServer = client.getServer();

                if (integratedServer != null) {
                    PluginLoader.reloadServerPlugins(integratedServer);
                } else {
                    PluginLoader.reloadClientPlugins();
                }

                super.close();
            }, Text.translatable(Tl.Gui.Plugin.TOGGLE), Text.translatable(Tl.Gui.Plugin.Toggle.CONFIRM)));

        });

        var sorted = PluginInfo.getAll().stream().sorted((a, b) -> {
            var aId = a.getPluginId();
            var bId = b.getPluginId();

            var aIsWaila = aId.getNamespace().equals(WailaConstants.NAMESPACE);
            var bIsWaila = bId.getNamespace().equals(WailaConstants.NAMESPACE);
            if (aIsWaila == bIsWaila) return aId.toString().compareTo(bId.toString());
            return aIsWaila ? -1 : +1;
        }).toList();

        for (var plugin : sorted) {
            var impl = (PluginInfo) plugin;
            var id = plugin.getPluginId();
            var enabled = plugin.isEnabled();

            initialValues.put(id, enabled);
            updatedValues.put(id, enabled);

            var toggle = new BooleanValue("", enabled, null, val -> updatedValues.put(id, val.booleanValue())) {
                @Override
                public MutableText getTitle() {
                    return Text.literal(plugin.getPluginId().toString());
                }

                @Override
                public Text getDescription() {
                    return IWailaConfig.get().getFormatter().modName(plugin.getModInfo().getName());
                }
            };

            if (impl.isLocked()) {
                toggle.disable(Tl.Gui.Plugin.Toggle.LOCKED);
            }

            options.add(toggle);
        }

        return options;
    }

    @Override
    public void close() {
    }

}
