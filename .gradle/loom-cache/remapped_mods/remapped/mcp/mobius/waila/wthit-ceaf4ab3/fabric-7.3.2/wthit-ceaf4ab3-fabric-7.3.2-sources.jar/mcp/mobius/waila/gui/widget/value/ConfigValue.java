package mcp.mobius.waila.gui.widget.value;

import java.util.List;
import java.util.function.Consumer;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import mcp.mobius.waila.gui.widget.ConfigListWidget;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static mcp.mobius.waila.util.DisplayUtil.createButton;

public abstract class ConfigValue<T> extends ConfigListWidget.Entry {

    protected final Consumer<T> save;
    protected final String translationKey;

    @Nullable
    protected final T defaultValue;
    protected final T initialValue;

    private final MutableText title;
    private final String description;
    private final ButtonWidget resetButton;

    @Nullable
    private String disabledReason = null;
    private boolean disabled = false;

    @Nullable
    private String id;

    private T value;
    private int x;

    public ConfigValue(String translationKey, T value, @Nullable T defaultValue, Consumer<T> save) {
        this.translationKey = translationKey;
        this.title = Text.translatable(translationKey);
        this.description = translationKey + "_desc";
        this.initialValue = value;
        this.value = value;
        this.save = save;
        this.defaultValue = defaultValue;
        this.resetButton = defaultValue == null ? null
            : createButton(0, 0, 40, 20, Text.translatable("controls.reset"), button -> resetValue());
    }

    @Override
    public final void method_25343(@NotNull MatrixStack matrices, int index, int rowTop, int rowLeft, int width, int height, int mouseX, int mouseY, boolean hovered, float deltaTime) {
        super.method_25343(matrices, index, rowTop, rowLeft, width, height, mouseX, mouseY, hovered, deltaTime);

        if (isDisabled()) title.formatted(Formatting.STRIKETHROUGH, Formatting.GRAY);
        else if (!isValueValid()) title.formatted(Formatting.ITALIC, Formatting.RED);
        else if (!value.equals(initialValue)) title.formatted(Formatting.ITALIC, Formatting.YELLOW);
        else title.formatted(Formatting.RESET);

        client.textRenderer.method_30881(matrices, title.copy(), rowLeft, rowTop + (height - client.textRenderer.fontHeight) / 2f, 0xFFFFFF);

        int w = width;
        if (resetButton != null) {
            w -= resetButton.getWidth() + 2;
            resetButton.setX(rowLeft + width - resetButton.getWidth());
            resetButton.setY(rowTop + (height - resetButton.getHeight()) / 2);
            resetButton.active = !isValueValid() || (!isDisabled() && !getValue().equals(defaultValue));
            resetButton.render(matrices, mouseX, mouseY, deltaTime);
        }

        drawValue(matrices, w, height, rowLeft, rowTop, mouseX, mouseY, hovered, deltaTime);
        this.x = rowLeft;
    }

    public void renderTooltip(Screen screen, MatrixStack matrices, int mouseX, int mouseY, float delta) {
        for (Element child : children()) {
            if (child instanceof ClickableWidget widget) {
                int x1 = widget.getX() - 2;
                int y1 = widget.getY();
                int x2 = widget.getX() + widget.getWidth() + 4;
                int y2 = widget.getY() + widget.getHeight() + 4;
                if (x1 <= mouseX && mouseX <= x2 && y1 <= mouseY && mouseY <= y2) return;
            }
        }

        boolean hasDescTl = I18n.hasTranslation(getDescription());
        if (id != null || hasDescTl || (isDisabled() && disabledReason != null)) {
            String title = getTitle().getString();
            List<OrderedText> tooltip = Lists.newArrayList(Text.literal(title).asOrderedText());
            if (hasDescTl) {
                tooltip.addAll(client.textRenderer.wrapLines(Text.translatable(getDescription()).formatted(Formatting.GRAY), 250));
            }
            if (isDisabled() && disabledReason != null) {
                tooltip.addAll(client.textRenderer.wrapLines(Text.translatable(disabledReason).formatted(Formatting.RED), 250));
            }
            if (id != null) {
                tooltip.add(Text.literal(id).formatted(Formatting.DARK_GRAY).asOrderedText());
            }
            screen.method_25417(matrices, tooltip, mouseX, mouseY);
        }
    }

    public boolean isValueValid() {
        return true;
    }

    @Override
    public boolean match(String filter) {
        boolean match = super.match(filter) || StringUtils.containsIgnoreCase(title.getString(), filter);
        if (id != null) match = match || StringUtils.containsIgnoreCase(id, filter);
        if (I18n.hasTranslation(getDescription())) match = match || StringUtils.containsIgnoreCase(I18n.translate(getDescription()), filter);
        return match;
    }

    @Override
    protected void gatherChildren(ImmutableList.Builder<Element> children) {
        Element element = getListener();
        if (element != null) {
            children.add(element);
        }

        ButtonWidget resetButton = getResetButton();
        if (resetButton != null) {
            children.add(resetButton);
        }
    }

    public void save() {
        if (!isDisabled()) {
            save.accept(getValue());
        }
    }

    @Nullable
    public Element getListener() {
        return null;
    }

    @Nullable
    public ButtonWidget getResetButton() {
        return resetButton;
    }

    public Text getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public int getX() {
        return x;
    }

    public final T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    protected void resetValue() {
        setValue(defaultValue);
    }

    public void disable(@Nullable String reason) {
        this.disabledReason = reason;
        this.disabled = true;
    }

    public final boolean isDisabled() {
        return disabled;
    }

    public void setId(@Nullable String id) {
        this.id = id;
    }

    protected abstract void drawValue(MatrixStack matrices, int width, int height, int x, int y, int mouseX, int mouseY, boolean selected, float partialTicks);

}
