package mcp.mobius.waila.plugin.vanilla.provider;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Future;
import java.util.function.Supplier;

import com.google.common.base.Suppliers;
import com.google.common.util.concurrent.Futures;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IEntityAccessor;
import mcp.mobius.waila.api.IEntityComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.component.PairComponent;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.entity.Entity;
import net.minecraft.entity.Tameable;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public enum PetOwnerProvider implements IEntityComponentProvider, IDataProvider<Entity> {

    INSTANCE;

    static final Supplier<HttpClient> HTTP = Suppliers.memoize(HttpClient::newHttpClient);

    static final Map<UUID, Future<Text>> NAMES = new HashMap<>();
    static final Text UNKNOWN = Text.literal("???");
    static final Text LOADING = Text.translatable(Tl.Tooltip.Owner.LOADING).formatted(Formatting.ITALIC);
    static final Text KEY = Text.translatable(Tl.Tooltip.OWNER);

    @Override
    public void appendBody(ITooltip tooltip, IEntityAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(Options.PET_OWNER)) {
            NbtCompound data = accessor.getData().raw();
            if (!data.containsUuid("owner")) return;
            UUID uuid = data.getUuid("owner");

            Text name = LOADING;
            if (NAMES.containsKey(uuid)) {
                Future<Text> future = NAMES.get(uuid);
                if (future.isDone()) {
                    name = Futures.getUnchecked(future);
                }
            } else {
                NAMES.put(uuid, requestOwner(uuid));
            }

            if (!(name == UNKNOWN || name == LOADING) || !config.getBoolean(Options.PET_HIDE_UNKNOWN_OWNER)) {
                tooltip.addLine(new PairComponent(KEY, name));
            }
        }
    }

    @Override
    public void appendData(IDataWriter data, IServerAccessor<Entity> accessor, IPluginConfig config) {
        if (config.getBoolean(Options.PET_OWNER)) {
            UUID uuid = ((Tameable) accessor.getTarget()).getOwnerUuid();
            if (uuid != null) data.raw().putUuid("owner", uuid);
        }
    }

    private Future<Text> requestOwner(UUID uuid) {
        return HTTP.get().sendAsync(HttpRequest.newBuilder()
                    .uri(URI.create("https://sessionserver.mojang.com/session/minecraft/profile/" + uuid))
                    .GET()
                    .build(),
                HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
            .thenApplyAsync(res -> {
                JsonElement element = JsonParser.parseString(res.body());
                if (element.isJsonObject()) {
                    JsonObject object = element.getAsJsonObject();
                    if (object.has("name")) {
                        element = object.get("name");
                        if (element.isJsonPrimitive()) {
                            String nameStr = element.getAsString();
                            if (!nameStr.isBlank()) {
                                return Text.literal(nameStr);
                            }
                        }
                    }
                }
                return UNKNOWN;
            })
            .handle((component, throwable) -> {
                if (component != null) {
                    return component;
                } else if (throwable != null) {
                    throwable.printStackTrace();
                }

                return UNKNOWN;
            });
    }

}
