package mcp.mobius.waila.gui.hud;

import mcp.mobius.waila.Waila;
import mcp.mobius.waila.WailaClient;
import mcp.mobius.waila.access.ClientAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IEntityComponentProvider;
import mcp.mobius.waila.api.IInstanceRegistry.Entry;
import mcp.mobius.waila.api.IObjectPicker;
import mcp.mobius.waila.api.IRayCastVectorProvider;
import mcp.mobius.waila.api.ITargetRedirector;
import mcp.mobius.waila.api.ITheme;
import mcp.mobius.waila.api.IWailaConfig;
import mcp.mobius.waila.api.IWailaConfig.Overlay.Position.Align;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.config.PluginConfig;
import mcp.mobius.waila.config.WailaConfig;
import mcp.mobius.waila.config.WailaConfig.General;
import mcp.mobius.waila.mixin.PlayerTabOverlayAccess;
import mcp.mobius.waila.pick.PickerAccessor;
import mcp.mobius.waila.pick.PickerResults;
import mcp.mobius.waila.registry.Registrar;
import mcp.mobius.waila.util.ProfilerUtil;
import mcp.mobius.waila.util.ProfilerUtil.Impl;
import net.minecraft.block.FluidBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

import static mcp.mobius.waila.gui.hud.ComponentHandler.gatherBlock;
import static mcp.mobius.waila.gui.hud.ComponentHandler.gatherEntity;
import static mcp.mobius.waila.gui.hud.ComponentHandler.requestBlockData;
import static mcp.mobius.waila.gui.hud.ComponentHandler.requestEntityData;
import static mcp.mobius.waila.gui.hud.TooltipPosition.BODY;
import static mcp.mobius.waila.gui.hud.TooltipPosition.HEAD;
import static mcp.mobius.waila.gui.hud.TooltipPosition.TAIL;

import F;
import I;
import Z;

public class TooltipHandler {

    private static final ConfigTooltipRendererState STATE = new ConfigTooltipRendererState();
    private static final Tooltip TOOLTIP = new Tooltip();
    private static final Text SNEAK_DETAIL = Text.translatable(Tl.Tooltip.SNEAK_FOR_DETAILS).formatted(Formatting.ITALIC);

    private enum ProcessResult {
        CONTINUE, BREAK
    }

    public static void tick() {
        tick(STATE, false);
    }

    public static boolean tick(TooltipRenderer.State state, boolean inspect) {
        try (var ignored = ProfilerUtil.profile("wthit:tick")) {
            return _tick(state, inspect);
        }
    }

    private static boolean _tick(TooltipRenderer.State state, boolean inspect) {
        STATE.render = false;

        var client = MinecraftClient.getInstance();
        var config = Waila.CONFIG.get().getGeneral();

        if (client.world == null) return false;
        if (client.interactionManager == null) return false;

        if (!inspect) {
            if (client.options.hudHidden) return false;
            if (client.currentScreen != null && !(client.currentScreen instanceof ChatScreen)) return false;
            if (!config.isDisplayTooltip()) return false;
            if (config.getDisplayMode() == IWailaConfig.General.DisplayMode.HOLD_KEY && !WailaClient.keyShowOverlay.isPressed()) return false;
            if (config.isHideFromPlayerList() && ((PlayerTabOverlayAccess) client.inGameHud.getPlayerListHud()).wthit_isVisible()) return false;
            if (config.isHideFromDebug() && client.options.debugEnabled) return false;
        }

        PlayerEntity player = client.player;
        if (player == null) return false;

        var camera = client.cameraEntity;
        if (camera == null) return false;

        var frameTime = client.getTickDelta();
        var pickRange = client.interactionManager.getReachDistance();
        var results = PickerResults.get();
        Vec3d castOrigin = null;
        Vec3d castDirection = null;

        var picker = Registrar.get().picker;
        if (picker != null) {
            // TODO: remove
            castOrigin = camera.getCameraPosVec(frameTime);
            castDirection = camera.getRotationVec(frameTime);
            picker.pick(PickerAccessor.of(client, camera, pickRange, frameTime), results, PluginConfig.CLIENT);
        } else {
            for (var entry : Registrar.get().raycastVectorProviders.get(Object.class)) {
                var provider = entry.instance();
                if (!provider.isEnabled(PluginConfig.CLIENT)) continue;

                castOrigin = provider.getOrigin(frameTime);
                castDirection = provider.getDirection(frameTime);
                RayCaster.cast(client.world, camera, castOrigin, castDirection, pickRange, results);
                break;
            }
        }

        if (castOrigin == null) return false;

        for (var target : results) {
            if (processTarget(state, target, client, player, castOrigin, castDirection, pickRange, config) == ProcessResult.BREAK) break;
        }

        return true;
    }

    private static ProcessResult redirectTarget(TooltipRenderer.State state, HitResult target, TargetRedirector redirector, MinecraftClient client, PlayerEntity player, Vec3d castOrigin, Vec3d castDirection, double pickRange, WailaConfig.General config) {
        if (redirector.nowhere) return ProcessResult.BREAK;
        if (redirector.behind) return ProcessResult.CONTINUE;

        var redirect = redirector.to;
        if (redirect == null) return ProcessResult.CONTINUE;
        if (redirect.getType() == HitResult.Type.MISS) return ProcessResult.CONTINUE;

        return processTarget(
            state, redirect, client, player,
            castOrigin.subtract(target.getPos().subtract(redirect.getPos())),
            castDirection, pickRange, config);
    }

    private static ProcessResult processTarget(TooltipRenderer.State state, HitResult target, MinecraftClient client, PlayerEntity player, Vec3d castOrigin, Vec3d castDirection, double pickRange, WailaConfig.General config) {
        var accessor = ClientAccessor.INSTANCE;

        //noinspection DataFlowIssue
        accessor.set(client.world, player, target, client.cameraEntity, castOrigin, castDirection, pickRange, client.getTickDelta());

        TooltipRenderer.beginBuild(state);

        if (target.getType() == HitResult.Type.BLOCK) {
            var block = accessor.getBlock();
            var blockEntity = accessor.getBlockEntity();

            var redirector = TargetRedirector.get();
            var redirectPriority = Integer.MAX_VALUE;
            @Nullable ITargetRedirector.Result redirectResult = null;

            for (var entry : Registrar.get().blockRedirect.get(block)) {
                redirectResult = entry.instance().redirect(redirector, accessor, PluginConfig.CLIENT);
                redirectPriority = entry.priority();
                if (redirectResult != null) break;
            }

            var hasBeRedirector = false;
            for (var entry : Registrar.get().blockRedirect.get(blockEntity)) {
                if (entry.priority() >= redirectPriority) break;
                if (!hasBeRedirector) {
                    hasBeRedirector = true;
                    redirector = TargetRedirector.get();
                }
                redirectResult = entry.instance().redirect(redirector, accessor, PluginConfig.CLIENT);
                if (redirectResult != null) break;
            }

            if (redirectResult != null && !redirector.self) {
                return redirectTarget(state, target, redirector, client, player, castOrigin, castDirection, pickRange, config);
            }

            if (block instanceof FluidBlock) {
                if (!PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_FLUID)) return ProcessResult.CONTINUE;
            } else if (!PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_BLOCK)) {
                return ProcessResult.CONTINUE;
            }

            var blockState = ComponentHandler.getOverrideBlock(target);
            if (blockState == IBlockComponentProvider.EMPTY_BLOCK_STATE) return ProcessResult.CONTINUE;

            accessor.setState(blockState);

            requestBlockData(accessor);

            TOOLTIP.clear();
            gatherBlock(accessor, TOOLTIP, HEAD);
            TooltipRenderer.add(TOOLTIP);

            TOOLTIP.clear();
            gatherBlock(accessor, TOOLTIP, BODY);

            if (config.isShiftForDetails() && !TOOLTIP.isEmpty() && !player.isSneaking()) {
                if (!config.isHideShiftText()) {
                    TooltipRenderer.add(new Line(null).with(SNEAK_DETAIL));
                }
            } else {
                TooltipRenderer.add(TOOLTIP);
            }

            TOOLTIP.clear();
            gatherBlock(accessor, TOOLTIP, TAIL);
        } else if (target.getType() == HitResult.Type.ENTITY) {
            var actualEntity = accessor.getEntity();

            var redirector = TargetRedirector.get();
            @Nullable ITargetRedirector.Result redirectResult = null;

            for (var entry : Registrar.get().entityRedirect.get(actualEntity)) {
                redirectResult = entry.instance().redirect(redirector, accessor, PluginConfig.CLIENT);
                if (redirectResult != null) break;
            }

            if (redirectResult != null && !redirector.self) {
                return redirectTarget(state, target, redirector, client, player, castOrigin, castDirection, pickRange, config);
            }

            if (!PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_ENTITY)) return ProcessResult.CONTINUE;

            if (actualEntity == null) return ProcessResult.CONTINUE;

            var targetEnt = ComponentHandler.getOverrideEntity(target);
            if (targetEnt == IEntityComponentProvider.EMPTY_ENTITY) return ProcessResult.CONTINUE;

            accessor.setEntity(targetEnt);
            if (targetEnt == null) return ProcessResult.CONTINUE;

            requestEntityData(targetEnt, accessor);

            TOOLTIP.clear();
            gatherEntity(targetEnt, accessor, TOOLTIP, HEAD);
            TooltipRenderer.add(TOOLTIP);

            TOOLTIP.clear();
            gatherEntity(targetEnt, accessor, TOOLTIP, BODY);

            if (config.isShiftForDetails() && !TOOLTIP.isEmpty() && !player.isSneaking()) {
                if (!config.isHideShiftText()) {
                    TooltipRenderer.add(new Line(null).with(SNEAK_DETAIL));
                }
            } else {
                TooltipRenderer.add(TOOLTIP);
            }

            TOOLTIP.clear();
            gatherEntity(targetEnt, accessor, TOOLTIP, TAIL);
        }

        TooltipRenderer.add(TOOLTIP);

        if (PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_ICON)) {
            TooltipRenderer.setIcon(ComponentHandler.getIcon(target));
        }

        STATE.render = true;
        TooltipRenderer.endBuild();
        return ProcessResult.BREAK;
    }

    private static class ConfigTooltipRendererState implements TooltipRenderer.State {

        private boolean render;

        @Override
        public boolean render() {
            return render;
        }

        @Override
        public boolean fireEvent() {
            return true;
        }

        private WailaConfig.Overlay getOverlay() {
            return Waila.CONFIG.get().getOverlay();
        }

        @Override
        public int getFps() {
            return getOverlay().getFps();
        }

        @Override
        public float getScale() {
            return getOverlay().getScale();
        }

        @Override
        public Align.X getXAnchor() {
            return getOverlay().getPosition().getAnchor().getX();
        }

        @Override
        public Align.Y getYAnchor() {
            return getOverlay().getPosition().getAnchor().getY();
        }

        @Override
        public Align.X getXAlign() {
            return getOverlay().getPosition().getAlign().getX();
        }

        @Override
        public Align.Y getYAlign() {
            return getOverlay().getPosition().getAlign().getY();
        }

        @Override
        public int getX() {
            return getOverlay().getPosition().getX();
        }

        @Override
        public int getY() {
            return getOverlay().getPosition().getY();
        }

        @Override
        public boolean bossBarsOverlap() {
            return getOverlay().getPosition().isBossBarsOverlap();
        }

        @Override
        public ITheme getTheme() {
            return getOverlay().getColor().getTheme();
        }

        @Override
        public int getBackgroundAlpha() {
            return getOverlay().getColor().getBackgroundAlpha();
        }

        @Override
        public boolean enableTextToSpeech() {
            return Waila.CONFIG.get().getGeneral().isEnableTextToSpeech();
        }

    }

}
