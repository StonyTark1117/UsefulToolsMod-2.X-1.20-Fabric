package mcp.mobius.waila.gui.widget;

import java.util.List;
import java.util.Objects;
import I;
import Z;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.gui.screen.ConfigScreen;
import mcp.mobius.waila.gui.widget.value.ConfigValue;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.widget.ElementListWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.toast.SystemToast;
import net.minecraft.text.Text;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ConfigListWidget extends ElementListWidget<ConfigListWidget.Entry> {

    private final ConfigScreen owner;
    private final @Nullable Runnable diskWriter;

    private int topOffset;
    private int bottomOffset;

    public boolean enableSearchBox = true;
    private @Nullable TextFieldWidget searchBox;

    public @Nullable String filter = null;

    // the fuck? apparently @Nullable String[] means a non-null array containing nullable string
    public String @Nullable [] splitFilter = null;

    public ConfigListWidget(ConfigScreen owner, MinecraftClient client, int width, int height, int top, int bottom, int itemHeight, @Nullable Runnable diskWriter) {
        super(client, width, height, top, bottom, itemHeight - 4);

        this.owner = owner;
        this.diskWriter = diskWriter;

        resize(top, bottom);
        setRenderBackground(false);
    }

    public ConfigListWidget(ConfigScreen owner, MinecraftClient client, int width, int height, int top, int bottom, int itemHeight) {
        this(owner, client, width, height, top, bottom, itemHeight, null);
    }

    @Override
    public int getRowWidth() {
        return Math.min(width - 20, 450);
    }

    @Override
    protected int getScrollbarPositionX() {
        return client.getWindow().getScaledWidth() - 5;
    }

    public void tick() {
        if (searchBox != null) searchBox.tick();
        children().forEach(mcp.mobius.waila.gui.widget.ConfigListWidget.Entry::tick);
    }

    public boolean save(boolean ignoreErrors) {
        List<? extends ConfigValue<?>> values = children()
            .stream()
            .filter(e -> e instanceof ConfigValue)
            .map(e -> (ConfigValue<?>) e)
            .toList();

        if (values.stream().allMatch(ConfigValue::isValueValid)) {
            values.forEach(ConfigValue::save);
            if (diskWriter != null) diskWriter.run();
            return true;
        }

        if (!ignoreErrors) client.getToastManager().add(new SystemToast(
            SystemToast.Type.TUTORIAL_HINT,
            Text.translatable(Tl.Config.InvalidInput.TITLE),
            Text.translatable(Tl.Config.InvalidInput.DESC)));

        return ignoreErrors;
    }

    public TextFieldWidget getSearchBox() {
        Preconditions.checkState(enableSearchBox);
        return Objects.requireNonNull(searchBox);
    }

    public void init() {
        var dirtyChildren = List.copyOf(children());
        for (var child : dirtyChildren) {
            child.clear(this);
        }

        var rootChildren = List.copyOf(children());
        var index = 0;
        for (var child : rootChildren) {
            index += child.init(this, index);
        }

        for (var child : children()) {
            child.setFocused(null);
        }

        if (enableSearchBox && searchBox == null) {
            searchBox = new TextFieldWidget(client.textRenderer, 0, 0, 160, 18, Text.empty());
            searchBox.setPlaceholder(Text.translatable(Tl.Config.SEARCH_PROMPT));
            searchBox.setChangedListener(filter -> {
                var isBlank = filter.isBlank();
                if ((isBlank && this.filter == null) || (filter.equals(this.filter))) return;

                children().clear();
                if (isBlank) {
                    this.filter = null;
                    this.splitFilter = null;
                    children().addAll(rootChildren);
                } else {
                    this.filter = filter;
                    this.splitFilter = filter.split("\\s");
                    children().addAll(rootChildren.stream().filter(it -> it.match(this.splitFilter)).toList());
                }
                init();
            });
        }

        resize(topOffset, owner.height + bottomOffset);
        setScrollAmount(getScrollAmount());
    }

    public void add(mcp.mobius.waila.gui.widget.ConfigListWidget.Entry entry) {
        add(children().size(), entry);
    }

    public void add(int index, mcp.mobius.waila.gui.widget.ConfigListWidget.Entry entry) {
        children().add(index, entry);
    }

    public ConfigListWidget with(mcp.mobius.waila.gui.widget.ConfigListWidget.Entry entry) {
        return with(children().size(), entry);
    }

    public ConfigListWidget with(int index, mcp.mobius.waila.gui.widget.ConfigListWidget.Entry entry) {
        add(index, entry);
        return this;
    }

    public void resize(int top, int bottom) {
        this.topOffset = top;
        this.bottomOffset = bottom - owner.height;
        updateSize(owner.width, owner.height, topOffset, owner.height + bottomOffset);
        if (searchBox != null) searchBox.setPosition(getRowLeft() + getRowWidth() - 160, (top - 18) / 2);
    }

    public abstract static class Entry extends ElementListWidget.Entry<mcp.mobius.waila.gui.widget.ConfigListWidget.Entry> {

        protected final MinecraftClient client;
        protected @Nullable List<? extends Element> children;
        protected @Nullable List<? extends Selectable> narratables;

        protected ConfigListWidget list;
        protected int index;

        public @Nullable CategoryEntry category;
        public int categoryDepth;

        public Entry() {
            this.client = MinecraftClient.getInstance();
        }

        public void tick() {
        }

        public final int init(ConfigListWidget list, int index) {
            Preconditions.checkState(list.children().get(index) == this);

            this.list = list;
            this.index = index;
            return init();
        }

        public int init() {
            return 1;
        }

        public void clear(ConfigListWidget list) {
        }

        protected void gatherChildren(ImmutableList.Builder<Element> children) {
        }

        protected void gatherNarratables(ImmutableList.Builder<Selectable> narratables) {
        }

        protected abstract void buildSearchKey(StringBuilder sb);

        public final boolean match(String[] filter) {
            var sb = new StringBuilder();
            buildSearchKey(sb);

            for (var s : filter) {
                if (StringUtils.containsIgnoreCase(sb.toString(), s)) {
                    return true;
                }
            }

            return false;
        }

        @Override
        public @NotNull List<? extends Element> children() {
            if (children == null) {
                ImmutableList.Builder<Element> builder = ImmutableList.builder();
                gatherChildren(builder);
                children = builder.build();
            }

            return children;
        }

        @Override
        public @NotNull List<? extends Selectable> selectableChildren() {
            if (narratables == null) {
                ImmutableList.Builder<Selectable> builder = ImmutableList.builder();
                gatherNarratables(builder);
                narratables = builder.build();
            }

            return narratables;
        }

        @Override
        public final void render(@NotNull DrawContext ctx, int index, int rowTop, int rowLeft, int width, int height, int mouseX, int mouseY, boolean hovered, float deltaTime) {
            if (category != null) {
                for (var i = 0; i < categoryDepth; i++) {
                    var lineX1 = rowLeft + 5 + i * 16;
                    var lineX2 = lineX1 + 2;
                    var lineY1 = rowTop - height / 2 - 4;
                    var lineY2 = lineY1 + height + 4;

                    if (i == (categoryDepth - 1) && (index - category.index) == 1) {
                        lineY1 += 8;
                    }

                    ctx.fill(lineX1, lineY1, lineX2, lineY2, 0x22FAFAFA);
                }

                var offset = categoryDepth * 16;
                rowLeft += offset;
                width -= offset;
            }

            drawEntry(ctx, index, rowTop, rowLeft, width, height, mouseX, mouseY, hovered, deltaTime);
        }

        protected abstract void drawEntry(DrawContext ctx, int index, int rowTop, int rowLeft, int width, int height, int mouseX, int mouseY, boolean hovered, float deltaTime);

    }

}
