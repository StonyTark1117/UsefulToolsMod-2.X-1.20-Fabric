package mcp.mobius.waila.plugin.vanilla.provider;

import I;
import Z;
import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IModInfo;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.ITooltipLine;
import mcp.mobius.waila.api.component.ItemComponent;
import mcp.mobius.waila.api.component.PairComponent;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.block.PropaguleBlock;
import net.minecraft.block.SaplingBlock;
import net.minecraft.block.StemBlock;
import net.minecraft.item.Items;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public enum PlantProvider implements IBlockComponentProvider {

    INSTANCE;

    private static void addMaturityTooltip(ITooltip tooltip, float growthValue) {
        var line = tooltip.setLine(Options.PLANT_CROP_PROGRESS);
        growthValue *= 100.0F;
        if (growthValue < 100.0F) {
            line.with(new PairComponent(
                Text.translatable(Tl.Tooltip.CROP_GROWTH), Text.literal(String.format("%.0f%%", growthValue))));
        } else {
            line.with(new PairComponent(
                Text.translatable(Tl.Tooltip.CROP_GROWTH), Text.translatable(Tl.Tooltip.CROP_MATURE)));
        }
    }

    private static void addGrowableTooltip(ITooltip tooltip, Identifier tag, String translationKey, boolean growable) {
        tooltip.setLine(tag, new PairComponent(Text.translatable(translationKey),
            growable ? Text.translatable(Tl.Tooltip.TRUE) : Text.translatable(Tl.Tooltip.FALSE)));
    }

    private static void addCropGrowableTooltip(ITooltip tooltip, IBlockAccessor accessor) {
        var lightLevel = accessor.getWorld().getBaseLightLevel(accessor.getPosition(), 0);
        addGrowableTooltip(tooltip, Options.PLANT_CROP_GROWABLE, Tl.Tooltip.CROP_GROWABLE, lightLevel >= 9);
    }

    private static void addTreeGrowableTooltip(ITooltip tooltip, IBlockAccessor accessor) {
        var lightLevel = accessor.getWorld().getBaseLightLevel(accessor.getPosition(), 0);
        var growable = lightLevel >= 9;
        if (accessor.getBlock() instanceof PropaguleBlock
            && accessor.getBlockState().get(PropaguleBlock.HANGING)) {
            growable = false;
        }

        addGrowableTooltip(tooltip, Options.PLANT_TREE_GROWABLE, Tl.Tooltip.TREE_GROWABLE, growable);
    }

    @Nullable
    @Override
    public ITooltipComponent getIcon(IBlockAccessor accessor, IPluginConfig config) {
        if (accessor.getBlock() == Blocks.WHEAT)
            return new ItemComponent(Items.WHEAT);

        if (accessor.getBlock() == Blocks.BEETROOTS)
            return new ItemComponent(Items.BEETROOT);

        return null;
    }

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(Options.PLANT_CROP_PROGRESS)) {
            if (accessor.getBlock() instanceof CropBlock crop) {
                addMaturityTooltip(tooltip, crop.getAge(accessor.getBlockState()) / (float) crop.getMaxAge());
            } else if (accessor.getBlock() == Blocks.MELON_STEM || accessor.getBlock() == Blocks.PUMPKIN_STEM) {
                addMaturityTooltip(tooltip, accessor.getBlockState().get(Properties.AGE_7) / 7F);
            } else if (accessor.getBlock() == Blocks.COCOA) {
                addMaturityTooltip(tooltip, accessor.getBlockState().get(Properties.AGE_2) / 2.0F);
            } else if (accessor.getBlock() == Blocks.SWEET_BERRY_BUSH) {
                addMaturityTooltip(tooltip, accessor.getBlockState().get(Properties.AGE_3) / 3.0F);
            } else if (accessor.getBlock() == Blocks.NETHER_WART) {
                addMaturityTooltip(tooltip, accessor.getBlockState().get(Properties.AGE_3) / 3.0F);
            }
        }

        if (config.getBoolean(Options.PLANT_CROP_GROWABLE)) {
            if ((accessor.getBlock() instanceof CropBlock || accessor.getBlock() instanceof StemBlock)
                && IModInfo.get(accessor.getBlock()).getId().equals("minecraft")) {
                addCropGrowableTooltip(tooltip, accessor);
            }
        }

        if (config.getBoolean(Options.PLANT_TREE_GROWABLE)) {
            if (accessor.getBlock() instanceof SaplingBlock && IModInfo.get(accessor.getBlock()).getId().equals("minecraft")) {
                addTreeGrowableTooltip(tooltip, accessor);
            }
        }
    }

}
