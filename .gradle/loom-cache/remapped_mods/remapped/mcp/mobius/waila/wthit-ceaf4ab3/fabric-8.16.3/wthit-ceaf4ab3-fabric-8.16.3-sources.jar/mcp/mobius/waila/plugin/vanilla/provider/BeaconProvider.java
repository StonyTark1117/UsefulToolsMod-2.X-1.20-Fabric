package mcp.mobius.waila.plugin.vanilla.provider;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import mcp.mobius.waila.plugin.vanilla.provider.data.BeaconDataProvider;
import mcp.mobius.waila.plugin.vanilla.provider.data.BeaconDataProvider.Data;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.MutableText;

public enum BeaconProvider implements IBlockComponentProvider {

    INSTANCE;


    private MutableText getText(StatusEffect effect) {
        return effect.getName().copy();
    }

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        if (!config.getBoolean(Options.EFFECT_BEACON)) return;

        var data = accessor.getData().get(BeaconDataProvider.Data.class);
        if (data == null || data.primary() == null) return;

        var text = getText(data.primary());
        if (data.primary() == data.secondary()) text.append(" II");

        if (data.secondary() != null && data.primary() != data.secondary()) {
            text.append(ScreenTexts.LINE_BREAK).append(getText(data.secondary()));
        }

        tooltip.setLine(Options.EFFECT_BEACON, text);
    }

}
