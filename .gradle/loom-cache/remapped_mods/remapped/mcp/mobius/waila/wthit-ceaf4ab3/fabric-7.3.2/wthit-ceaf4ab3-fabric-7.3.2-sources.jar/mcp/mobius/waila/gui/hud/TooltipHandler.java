package mcp.mobius.waila.gui.hud;

import mcp.mobius.waila.Waila;
import mcp.mobius.waila.WailaClient;
import mcp.mobius.waila.access.DataAccessor;
import mcp.mobius.waila.api.IBlacklistConfig;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IEntityComponentProvider;
import mcp.mobius.waila.api.ITheme;
import mcp.mobius.waila.api.IWailaConfig;
import mcp.mobius.waila.api.IWailaConfig.Overlay.Position.Align;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.config.PluginConfig;
import mcp.mobius.waila.config.WailaConfig;
import mcp.mobius.waila.mixin.PlayerTabOverlayAccess;
import mcp.mobius.waila.pick.PickerAccessor;
import mcp.mobius.waila.pick.PickerResults;
import mcp.mobius.waila.registry.Registrar;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.HitResult;

import static mcp.mobius.waila.api.TooltipPosition.BODY;
import static mcp.mobius.waila.api.TooltipPosition.HEAD;
import static mcp.mobius.waila.api.TooltipPosition.TAIL;
import static mcp.mobius.waila.gui.hud.ComponentHandler.gatherBlock;
import static mcp.mobius.waila.gui.hud.ComponentHandler.gatherEntity;

public class TooltipHandler {

    private static final ConfigTooltipRendererState STATE = new ConfigTooltipRendererState();
    private static final Tooltip TOOLTIP = new Tooltip();
    private static final Text SNEAK_DETAIL = Text.translatable(Tl.Tooltip.SNEAK_FOR_DETAILS).formatted(Formatting.ITALIC);

    public static void tick() {
        STATE.render = false;

        MinecraftClient client = MinecraftClient.getInstance();
        WailaConfig.General config = Waila.CONFIG.get().getGeneral();

        if (client.options.hudHidden) {
            return;
        }

        if (client.currentScreen != null && !(client.currentScreen instanceof ChatScreen)) {
            return;
        }

        if (client.world == null || !config.isDisplayTooltip()) {
            return;
        }

        if (config.getDisplayMode() == IWailaConfig.General.DisplayMode.HOLD_KEY && !WailaClient.keyShowOverlay.isPressed()) {
            return;
        }

        if (config.isHideFromPlayerList() && ((PlayerTabOverlayAccess) client.inGameHud.getPlayerListHud()).wthit_isVisible()) {
            return;
        }

        if (config.isHideFromDebug() && client.options.debugEnabled) {
            return;
        }

        if (client.interactionManager == null) {
            return;
        }

        PlayerEntity player = client.player;

        if (player == null) {
            return;
        }

        PickerResults results = PickerResults.get();
        Registrar.INSTANCE.picker.pick(PickerAccessor.of(client, client.cameraEntity, client.interactionManager.getReachDistance(), client.getTickDelta()), results, PluginConfig.CLIENT);

        for (HitResult target : results) {
            DataAccessor accessor = DataAccessor.INSTANCE;
            accessor.set(client.world, player, target, client.cameraEntity, client.getTickDelta());

            TooltipRenderer.beginBuild(STATE);

            if (target.getType() == HitResult.Type.BLOCK) {
                Block block = accessor.getBlock();

                if (block instanceof FluidBlock) {
                    if (!PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_FLUID)) {
                        continue;
                    }
                } else if (!PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_BLOCK)) {
                    continue;
                }

                if (accessor.getBlockState().isIn(Waila.BLOCK_BLACKLIST_TAG) || IBlacklistConfig.get().contains(block)) {
                    continue;
                }

                BlockEntity blockEntity = accessor.getBlockEntity();
                if (blockEntity != null && IBlacklistConfig.get().contains(blockEntity)) {
                    continue;
                }

                BlockState state = ComponentHandler.getOverrideBlock(target);
                if (state == IBlockComponentProvider.EMPTY_BLOCK_STATE) {
                    continue;
                }

                accessor.setState(state);

                TOOLTIP.clear();
                gatherBlock(accessor, TOOLTIP, HEAD);
                TooltipRenderer.add(TOOLTIP);

                TOOLTIP.clear();
                gatherBlock(accessor, TOOLTIP, BODY);

                if (config.isShiftForDetails() && !TOOLTIP.isEmpty() && !player.isSneaking()) {
                    if (!config.isHideShiftText()) {
                        TooltipRenderer.add(new Line(null).with(SNEAK_DETAIL));
                    }
                } else {
                    TooltipRenderer.add(TOOLTIP);
                }

                TOOLTIP.clear();
                gatherBlock(accessor, TOOLTIP, TAIL);
            } else if (target.getType() == HitResult.Type.ENTITY) {
                if (!PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_ENTITY)) {
                    continue;
                }

                Entity actualEntity = accessor.getEntity();

                if (actualEntity == null) {
                    continue;
                }

                if (actualEntity.getType().isIn(Waila.ENTITY_BLACKLIST_TAG) || IBlacklistConfig.get().contains(accessor.getEntity())) {
                    continue;
                }

                Entity targetEnt = ComponentHandler.getOverrideEntity(target);

                if (targetEnt == IEntityComponentProvider.EMPTY_ENTITY) {
                    continue;
                }

                accessor.setEntity(targetEnt);

                if (targetEnt == null) {
                    continue;
                }

                TOOLTIP.clear();
                gatherEntity(targetEnt, accessor, TOOLTIP, HEAD);
                TooltipRenderer.add(TOOLTIP);

                TOOLTIP.clear();
                gatherEntity(targetEnt, accessor, TOOLTIP, BODY);

                if (config.isShiftForDetails() && !TOOLTIP.isEmpty() && !player.isSneaking()) {
                    if (!config.isHideShiftText()) {
                        TooltipRenderer.add(new Line(null).with(SNEAK_DETAIL));
                    }
                } else {
                    TooltipRenderer.add(TOOLTIP);
                }

                TOOLTIP.clear();
                gatherEntity(targetEnt, accessor, TOOLTIP, TAIL);
            }

            TooltipRenderer.add(TOOLTIP);

            if (PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_ICON)) {
                TooltipRenderer.setIcon(ComponentHandler.getIcon(target));
            }

            STATE.render = true;
            TooltipRenderer.endBuild();

            break;
        }
    }

    private static class ConfigTooltipRendererState implements TooltipRenderer.State {

        private boolean render;

        @Override
        public boolean render() {
            return render;
        }

        @Override
        public boolean fireEvent() {
            return true;
        }

        private WailaConfig.Overlay getOverlay() {
            return Waila.CONFIG.get().getOverlay();
        }

        @Override
        public float getScale() {
            return getOverlay().getScale();
        }

        @Override
        public Align.X getXAnchor() {
            return getOverlay().getPosition().getAnchor().getX();
        }

        @Override
        public Align.Y getYAnchor() {
            return getOverlay().getPosition().getAnchor().getY();
        }

        @Override
        public Align.X getXAlign() {
            return getOverlay().getPosition().getAlign().getX();
        }

        @Override
        public Align.Y getYAlign() {
            return getOverlay().getPosition().getAlign().getY();
        }

        @Override
        public int getX() {
            return getOverlay().getPosition().getX();
        }

        @Override
        public int getY() {
            return getOverlay().getPosition().getY();
        }

        @Override
        public boolean bossBarsOverlap() {
            return getOverlay().getPosition().isBossBarsOverlap();
        }

        @Override
        public ITheme getTheme() {
            return getOverlay().getColor().getTheme();
        }

        @Override
        public int getBackgroundAlpha() {
            return getOverlay().getColor().getBackgroundAlpha();
        }

        @Override
        public boolean enableTextToSpeech() {
            return Waila.CONFIG.get().getGeneral().isEnableTextToSpeech();
        }

    }

}
