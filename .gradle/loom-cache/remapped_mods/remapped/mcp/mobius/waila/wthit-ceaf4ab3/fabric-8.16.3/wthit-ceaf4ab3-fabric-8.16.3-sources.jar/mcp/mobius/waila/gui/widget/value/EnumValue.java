package mcp.mobius.waila.gui.widget.value;

import java.util.Locale;
import java.util.function.Consumer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;

import static mcp.mobius.waila.util.DisplayUtil.createButton;

public class EnumValue<T extends Enum<T>> extends ConfigValue<T> {

    private final ButtonWidget button;

    public EnumValue(String optionName, T[] values, T selected, @Nullable T defaultValue, Consumer<T> save) {
        super(optionName, selected, defaultValue, save);

        this.button = createButton(0, 0, 100, 20, Text.translatable(optionName + "_" + selected.name().toLowerCase(Locale.ROOT)), w ->
            setValue(values[(getValue().ordinal() + 1) % values.length]));
    }

    @Override
    protected void drawValue(DrawContext ctx, int width, int height, int x, int y, int mouseX, int mouseY, boolean selected, float partialTicks) {
        button.active = !isDisabled();
        button.setX(x + width - button.getWidth());
        button.setY(y + (height - button.getHeight()) / 2);
        button.setMessage(Text.translatable(getValueTlKey()));
        button.render(ctx, mouseX, mouseY, partialTicks);
    }

    @Override
    public Element getListener() {
        return button;
    }

    @Override
    protected void buildSearchKey(StringBuilder sb) {
        super.buildSearchKey(sb);
        sb.append(" ").append(I18n.translate(getValueTlKey()));
    }

    private String getValueTlKey() {
        return translationKey + "_" + getValue().name().toLowerCase(Locale.ROOT);
    }

}
