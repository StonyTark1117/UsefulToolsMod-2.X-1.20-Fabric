package mcp.mobius.waila.mixin;

import java.util.Optional;
import net.minecraft.block.ChiseledBookshelfBlock;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(ChiseledBookshelfBlock.class)
public interface ChiseledBookShelfBlockAccess {

    @Invoker("getRelativeHitCoordinatesForBlockFace")
    static Optional<Vec2f> wthit_getRelativeHitCoordinatesForBlockFace(BlockHitResult $$0, Direction $$1) {
        throw new AssertionError("mixin");
    }

    @Invoker("getHitSlot")
    static int wthit_getHitSlot(Vec2f $$0) {
        throw new AssertionError("mixin");
    }

}
