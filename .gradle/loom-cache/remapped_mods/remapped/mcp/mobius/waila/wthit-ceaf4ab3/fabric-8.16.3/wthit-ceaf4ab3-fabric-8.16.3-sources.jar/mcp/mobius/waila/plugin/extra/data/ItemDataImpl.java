package mcp.mobius.waila.plugin.extra.data;

import I;
import Z;
import java.util.ArrayList;
import java.util.Objects;

import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.data.ItemData;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.Registries;

public class ItemDataImpl extends ItemData {

    private final IPluginConfig config;
    private boolean syncNbt;

    public ItemDataImpl(IPluginConfig config) {
        this.config = config;
    }

    public ItemDataImpl(PacketByteBuf buf) {
        this.config = null;

        syncNbt = buf.readBoolean();
        var size = buf.readVarInt();
        ensureSpace(size);

        for (var i = 0; i < size; i++) {
            if (buf.readBoolean()) continue;

            var item = buf.readRegistryValue(Registries.ITEM);
            var count = buf.readVarInt();
            var stack = new ItemStack(Objects.requireNonNull(item), count);
            if (syncNbt) stack.setNbt(buf.readNbt());
            add(stack);
        }
    }

    @Override
    public void write(PacketByteBuf buf) {
        var syncNbt = config.getBoolean(CONFIG_SYNC_NBT);
        buf.writeBoolean(syncNbt);
        buf.writeVarInt(items.size());

        for (var stack : items) {
            if (stack.isEmpty()) {
                buf.writeBoolean(true);
            } else {
                buf.writeBoolean(false);
                buf.writeRegistryValue(Registries.ITEM, stack.getItem());
                buf.writeVarInt(stack.getCount());
                if (syncNbt) buf.writeNbt(stack.getNbt());
            }
        }
    }

    public ArrayList<ItemStack> items() {
        return items;
    }

    public boolean syncNbt() {
        return syncNbt;
    }

}
