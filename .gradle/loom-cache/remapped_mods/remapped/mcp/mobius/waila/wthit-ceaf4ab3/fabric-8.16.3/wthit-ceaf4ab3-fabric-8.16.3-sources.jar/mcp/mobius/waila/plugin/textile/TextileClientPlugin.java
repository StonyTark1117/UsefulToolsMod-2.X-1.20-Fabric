package mcp.mobius.waila.plugin.textile;

import mcp.mobius.waila.api.IClientRegistrar;
import mcp.mobius.waila.api.IToolType;
import mcp.mobius.waila.api.IWailaClientPlugin;
import mcp.mobius.waila.api.data.FluidData;
import mcp.mobius.waila.mixed.IShearable;
import mcp.mobius.waila.plugin.textile.fluid.TextileFluidDescriptor;
import net.fabricmc.fabric.api.mininglevel.v1.FabricMineableTags;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalItemTags;
import net.minecraft.block.Block;
import net.minecraft.block.TallPlantBlock;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Identifier;

public abstract class TextileClientPlugin implements IWailaClientPlugin {

    @Override
    public void register(IClientRegistrar registrar) {
        FluidData.describeFluid(Fluid.class, TextileFluidDescriptor.INSTANCE);
        FluidData.describeCauldron(Block.class, TextileFluidDescriptor.INSTANCE);

        registrar.toolType(new Identifier("pickaxe"), IToolType.builder()
            .lowestTierItem(Items.WOODEN_PICKAXE)
            .blockTag(BlockTags.PICKAXE_MINEABLE)
            .itemTag(ItemTags.PICKAXES)
            .build());

        registrar.toolType(new Identifier("shovel"), IToolType.builder()
            .lowestTierItem(Items.WOODEN_SHOVEL)
            .blockTag(BlockTags.SHOVEL_MINEABLE)
            .itemTag(ItemTags.SHOVELS)
            .build());

        registrar.toolType(new Identifier("axe"), IToolType.builder()
            .lowestTierItem(Items.WOODEN_AXE)
            .blockTag(BlockTags.AXE_MINEABLE)
            .itemTag(ItemTags.AXES)
            .build());

        registrar.toolType(new Identifier("hoe"), IToolType.builder()
            .lowestTierItem(Items.WOODEN_HOE)
            .blockTag(BlockTags.HOE_MINEABLE)
            .itemTag(ItemTags.HOES)
            .build());

        registrar.toolType(new Identifier("sword"), IToolType.builder()
            .lowestTierItem(Items.WOODEN_SWORD)
            .blockTag(FabricMineableTags.SWORD_MINEABLE)
            .itemTag(ItemTags.SWORDS)
            .build());

        registrar.toolType(new Identifier("shears"), IToolType.builder()
            .lowestTierItem(Items.SHEARS)
            .blockPredicate(it -> it.isIn(FabricMineableTags.SHEARS_MINEABLE) || it.getBlock() instanceof IShearable || it.getBlock() instanceof TallPlantBlock)
            .itemTag(ConventionalItemTags.SHEARS)
            .build());
    }

}
