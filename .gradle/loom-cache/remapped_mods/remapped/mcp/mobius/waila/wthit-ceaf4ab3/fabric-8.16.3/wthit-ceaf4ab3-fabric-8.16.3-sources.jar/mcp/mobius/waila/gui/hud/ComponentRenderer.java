package mcp.mobius.waila.gui.hud;

import java.util.Random;

import com.mojang.blaze3d.systems.RenderSystem;
import mcp.mobius.waila.WailaClient;
import mcp.mobius.waila.api.ITooltipComponent;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.Nullable;

import static mcp.mobius.waila.util.DisplayUtil.renderRectBorder;

import F;
import I;

public abstract class ComponentRenderer {

    private static final Random RANDOM = new Random();

    public abstract void render(DrawContext ctx, ITooltipComponent component, int x, int y, int cw, int ch, float delta);

    private static @Nullable ComponentRenderer current = null;

    public static ComponentRenderer get() {
        if (current == null) current = Default.INSTANCE;
        return current;
    }

    public static void set(@Nullable ComponentRenderer value) {
        if (value == null) value = Default.INSTANCE;
        current = value;
    }

    public static class Default extends ComponentRenderer {

        public static final Default INSTANCE = new Default();

        @Override
        public void render(DrawContext ctx, ITooltipComponent component, int x, int y, int cw, int ch, float delta) {
            component.render(ctx, x, y, delta);

            if (WailaClient.showComponentBounds) {
                renderBounds(ctx, x, y, cw, ch, 1f);
            }
        }

        public static void renderBounds(DrawContext ctx, int x, int y, int cw, int ch, float v) {
            ctx.getMatrices().push();
            var scale = (float) MinecraftClient.getInstance().getWindow().getScaleFactor();
            ctx.getMatrices().scale(1 / scale, 1 / scale, 1);

            RenderSystem.setShader(GameRenderer::getPositionColorProgram);

            var tesselator = Tessellator.getInstance();
            var buf = tesselator.getBuffer();
            buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            var bx = MathHelper.floor(x * scale + 0.5);
            var by = MathHelper.floor(y * scale + 0.5);
            var bw = MathHelper.floor(cw * scale + 0.5);
            var bh = MathHelper.floor(ch * scale + 0.5);
            var color = (0xFF << 24) + MathHelper.hsvToRgb(RANDOM.nextFloat(), RANDOM.nextFloat(), v);
            renderRectBorder(ctx.getMatrices().peek().getPositionMatrix(), buf, bx, by, bw, bh, 1, color, color);
            tesselator.draw();

            ctx.getMatrices().pop();
        }

    }

}
