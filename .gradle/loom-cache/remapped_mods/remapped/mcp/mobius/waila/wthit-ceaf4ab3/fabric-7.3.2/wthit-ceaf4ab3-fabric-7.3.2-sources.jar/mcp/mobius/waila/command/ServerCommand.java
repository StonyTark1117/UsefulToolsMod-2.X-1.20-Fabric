package mcp.mobius.waila.command;

import java.nio.file.Path;

import com.mojang.brigadier.CommandDispatcher;
import io.netty.buffer.Unpooled;
import lol.bai.badpackets.api.PacketSender;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.debug.DumpGenerator;
import mcp.mobius.waila.network.Packets;
import net.minecraft.entity.Entity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Text;

public class ServerCommand {

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        new ArgumentBuilderBuilder<>(CommandManager.literal(WailaConstants.NAMESPACE))
            .then(CommandManager.literal("dump"))
            .requires(source -> source.hasPermissionLevel(CommandManager.field_31840))
            .executes(context -> {
                ServerCommandSource source = context.getSource();
                MinecraftServer server = source.getServer();
                boolean dedicated = server.isDedicated();
                Path path = DumpGenerator.generate(dedicated ? DumpGenerator.SERVER : DumpGenerator.LOCAL);
                if (path != null) {
                    Text pathComponent = Text.literal(path.toString()).styled(style -> style
                        .withUnderline(true)
                        .withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_FILE, path.toString())));
                    source.sendFeedback(Text.translatable(dedicated ? Tl.Command.SERVER_DUMP_SUCCESS : Tl.Command.LOCAL_DUMP_SUCCESS, pathComponent), false);
                    Entity entity = source.getEntity();
                    if (entity instanceof ServerPlayerEntity player && !server.isHost(player.getGameProfile())) {
                        PacketSender.s2c(player).send(Packets.GENERATE_CLIENT_DUMP, new PacketByteBuf(Unpooled.EMPTY_BUFFER));
                    }
                    return 1;
                } else {
                    return 0;
                }
            })

            .pop("dump")

            .register(dispatcher);
    }

}
