package mcp.mobius.waila.plugin.vanilla.provider.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import mcp.mobius.waila.api.IData;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.mixin.BeehiveBlockEntity.BeeDataAccess;
import mcp.mobius.waila.mixin.BeehiveBlockEntityAccess;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.block.entity.BeehiveBlockEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.nbt.NbtElement;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public enum BeehiveDataProvider implements IDataProvider<BeehiveBlockEntity> {

    INSTANCE;

    public static final Identifier OCCUPANTS = new Identifier("bee.occupants");


    @Override
    public void appendData(IDataWriter data, IServerAccessor<BeehiveBlockEntity> accessor, IPluginConfig config) {
        if (config.getBoolean(Options.BEE_HIVE_OCCUPANTS)) {
            var stored = ((BeehiveBlockEntityAccess) accessor.getTarget()).wthit_stored();
            if (!stored.isEmpty()) {
                var occupants = new ArrayList<OccupantsData.Occupant>(stored.size());

                for (var beeData : stored) {
                    var beeNbt = beeData.wthit_entityData();

                    var entityType = EntityType.fromNbt(beeNbt);
                    if (entityType.isEmpty()) continue;

                    var customName = beeNbt.method_10573("CustomName", NbtElement.STRING_TYPE)
                        ? beeNbt.method_10558("CustomName")
                        : null;

                    occupants.add(new OccupantsData.Occupant(entityType.get(), customName));
                }

                if (!occupants.isEmpty()) data.addImmediate(new OccupantsData(occupants));
            }
        }
    }

    public record OccupantsData(List<Occupant> occupants) implements IData {

        public OccupantsData(PacketByteBuf buf) {
            this(buf.readList(b -> new Occupant(
                b.readRegistryValue(Registries.ENTITY_TYPE),
                b.readNullable(PacketByteBuf::readString))));
        }

        @Override
        public void write(PacketByteBuf buf) {
            buf.writeCollection(occupants, (b, occupant) -> {
                b.writeRegistryValue(Registries.ENTITY_TYPE, occupant.entityType);
                b.writeNullable(occupant.customName, PacketByteBuf::writeString);
            });
        }

        public record Occupant(EntityType<?> entityType, @Nullable String customName) {

        }

    }

}
