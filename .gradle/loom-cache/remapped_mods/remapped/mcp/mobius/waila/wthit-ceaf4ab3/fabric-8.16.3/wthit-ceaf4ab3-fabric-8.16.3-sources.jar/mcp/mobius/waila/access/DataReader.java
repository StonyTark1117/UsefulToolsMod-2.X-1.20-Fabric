package mcp.mobius.waila.access;

import java.util.HashMap;
import java.util.Map;

import mcp.mobius.waila.api.IData;
import mcp.mobius.waila.api.IData.Serializer;
import mcp.mobius.waila.api.IDataReader;
import mcp.mobius.waila.registry.Registrar;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.PacketByteBuf;
import org.jetbrains.annotations.Nullable;

public enum DataReader implements IDataReader {

    SERVER, CLIENT;

    public static final IDataReader NOOP = new IDataReader() {
        private static final NbtCompound TAG = new NbtCompound();

        @Override
        public NbtCompound raw() {
            return TAG;
        }

        @Override
        public <T extends IData> @Nullable T get(Class<T> type) {
            return null;
        }

        @Override
        public <T extends IData> void invalidate(Class<T> type) {
        }
    };

    private NbtCompound raw;
    private final Map<Class<? extends IData>, IData> typed = new HashMap<>();
    private boolean clean;

    DataReader() {
        reset(null);
    }

    public void reset(@Nullable NbtCompound raw) {
        if (clean && raw == null) return;

        this.raw = raw == null ? new NbtCompound() : raw;
        this.clean = raw == null;

        this.typed.clear();
    }

    @SuppressWarnings("unchecked")
    public static IData readTypedPacket(PacketByteBuf buf) {
        var id = buf.readIdentifier();
        var serializer = (IData.Serializer<IData>) Registrar.get().dataId2Serializer.get(id);

        return serializer.read(buf);
    }

    @Override
    public NbtCompound raw() {
        return raw;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends IData> @Nullable T get(Class<T> type) {
        return (T) typed.get(type);
    }

    @Override
    public <T extends IData> void invalidate(Class<T> type) {
        typed.remove(type);
    }

    public void add(IData data) {
        clean = false;

        typed.put(Registrar.get().impl2ApiDataType.get(data.getClass()), data);
    }

}
