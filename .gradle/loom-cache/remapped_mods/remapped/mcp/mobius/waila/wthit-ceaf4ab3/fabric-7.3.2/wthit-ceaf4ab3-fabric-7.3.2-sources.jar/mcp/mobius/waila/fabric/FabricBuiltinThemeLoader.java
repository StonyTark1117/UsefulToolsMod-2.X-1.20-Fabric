package mcp.mobius.waila.fabric;

import mcp.mobius.waila.gui.hud.theme.BuiltinThemeLoader;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.util.Identifier;

public class FabricBuiltinThemeLoader extends BuiltinThemeLoader implements IdentifiableResourceReloadListener {

    @Override
    public Identifier getFabricId() {
        return ID;
    }

}
