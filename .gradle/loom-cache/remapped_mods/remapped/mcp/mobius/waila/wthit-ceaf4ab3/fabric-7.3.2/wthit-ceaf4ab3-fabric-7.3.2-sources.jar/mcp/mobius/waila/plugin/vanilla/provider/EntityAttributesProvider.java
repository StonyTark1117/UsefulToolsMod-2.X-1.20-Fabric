package mcp.mobius.waila.plugin.vanilla.provider;

import java.text.DecimalFormat;

import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IEntityAccessor;
import mcp.mobius.waila.api.IEntityComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.ITooltipLine;
import mcp.mobius.waila.api.component.ArmorComponent;
import mcp.mobius.waila.api.component.HealthComponent;
import mcp.mobius.waila.api.component.SpacingComponent;
import mcp.mobius.waila.api.component.TextureComponent;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

public enum EntityAttributesProvider implements IEntityComponentProvider, IDataProvider<Entity> {

    INSTANCE;

    private static final DecimalFormat DECIMAL = new DecimalFormat("0.##");

    private int addSpacing(ITooltipLine line, int i) {
        if (i > 0) {
            line.with(new SpacingComponent(3, 0));
            return i - 1;
        }
        return 0;
    }

    private void addHealth(ITooltipLine line, LivingEntity entity, NbtCompound data, boolean showAbsorption) {
        MutableText component = Text.literal(DECIMAL.format(entity.getHealth()));
        if (showAbsorption && data.contains("abs")) {
            component.append(Text.literal("+" + DECIMAL.format(data.getFloat("abs"))).formatted(Formatting.GOLD));
        }
        line.with(new TextureComponent(class_332.field_22737, 8, 8, 52, 0, 9, 9, 256, 256))
            .with(component.append("/" + DECIMAL.format(entity.getMaxHealth())).formatted(Formatting.RED));
    }

    private void addArmor(ITooltipLine line, LivingEntity entity) {
        line.with(new TextureComponent(class_332.field_22737, 8, 8, 34, 9, 9, 9, 256, 256))
            .with(Text.literal(String.valueOf(entity.getArmor())));
    }

    @Override
    @SuppressWarnings("UnusedAssignment")
    public void appendHead(ITooltip tooltip, IEntityAccessor accessor, IPluginConfig config) {
        if (!(accessor.getEntity() instanceof LivingEntity entity)) {
            return;
        }

        boolean compact = config.getBoolean(Options.ATTRIBUTE_COMPACT);
        boolean showHealth = config.getBoolean(Options.ATTRIBUTE_HEALTH);
        boolean showAbsorption = config.getBoolean(Options.ATTRIBUTE_ABSORPTION);
        boolean showArmor = config.getBoolean(Options.ATTRIBUTE_ARMOR) && entity.getArmor() > 0;

        NbtCompound data = accessor.getData().raw();

        if (compact) {
            ITooltipLine line = tooltip.addLine();
            int i = 0;

            if (showHealth) {
                i = addSpacing(line, i);
                addHealth(line, entity, data, showAbsorption);
                i++;
            }

            if (showArmor) {
                i = addSpacing(line, i);
                addArmor(line, entity);
                i++;
            }
        } else {
            int maxPerLine = config.getInt(Options.ATTRIBUTE_ICON_PER_LINE);

            if (showHealth) {
                float absorption = data.contains("abs") ? data.getFloat("abs") : 0f;
                if (entity.getMaxHealth() + absorption > config.getInt(Options.ATTRIBUTE_LONG_HEALTH_MAX)) {
                    addHealth(tooltip.addLine(), entity, data, showAbsorption);
                } else {
                    tooltip.addLine(new HealthComponent(entity.getHealth(), entity.getMaxHealth(), maxPerLine, false));
                    if (showAbsorption && absorption > 0) {
                        tooltip.addLine(new HealthComponent(absorption, 0, maxPerLine, true));
                    }
                }
            }

            if (showArmor) {
                if (entity.getArmor() > config.getInt(Options.ATTRIBUTE_LONG_ARMOR_MAX)) {
                    addArmor(tooltip.addLine(), entity);
                } else {
                    tooltip.addLine(new ArmorComponent(entity.getArmor(), maxPerLine));
                }
            }
        }
    }

    @Override
    public void appendBody(ITooltip tooltip, IEntityAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(Options.ATTRIBUTE_ENTITY_POSITION)) {
            Vec3d pos = accessor.getEntity().getPos();
            tooltip.addLine(Text.literal("(" + DECIMAL.format(pos.x) + ", " + DECIMAL.format(pos.y) + ", " + DECIMAL.format(pos.z) + ")"));
        }
    }

    @Override
    public void appendData(IDataWriter data, IServerAccessor<Entity> accessor, IPluginConfig config) {
        if (accessor.getTarget() instanceof LivingEntity living) {
            if (config.getBoolean(Options.ATTRIBUTE_ABSORPTION) && living.getAbsorptionAmount() > 0) {
                data.raw().putFloat("abs", living.getAbsorptionAmount());
            }
        }
    }

}
