package mcp.mobius.waila.plugin.test;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import net.minecraft.util.Identifier;

public enum ErrorTest implements IBlockComponentProvider {

    INSTANCE;

    public static final Identifier ENABLED = new Identifier("test:error.enabled");

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(ENABLED)) {
            throw new RuntimeException("ErrorTest");
        }
    }

}
