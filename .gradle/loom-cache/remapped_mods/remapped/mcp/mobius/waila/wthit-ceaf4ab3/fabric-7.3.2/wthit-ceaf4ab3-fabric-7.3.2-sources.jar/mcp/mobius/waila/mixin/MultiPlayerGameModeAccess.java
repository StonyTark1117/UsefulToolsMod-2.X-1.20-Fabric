package mcp.mobius.waila.mixin;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(ClientPlayerInteractionManager.class)
public interface MultiPlayerGameModeAccess {

    @Accessor("destroyProgress")
    float wthit_destroyProgress();

}
