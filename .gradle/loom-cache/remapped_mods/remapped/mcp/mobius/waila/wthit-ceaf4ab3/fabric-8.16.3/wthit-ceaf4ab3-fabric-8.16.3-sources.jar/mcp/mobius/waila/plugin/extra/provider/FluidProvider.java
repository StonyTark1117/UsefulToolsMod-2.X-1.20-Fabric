package mcp.mobius.waila.plugin.extra.provider;

import D;
import F;
import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IClientRegistrar;
import mcp.mobius.waila.api.ICommonRegistrar;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.WailaHelper;
import mcp.mobius.waila.api.component.PairComponent;
import mcp.mobius.waila.api.component.SpriteBarComponent;
import mcp.mobius.waila.api.component.WrappedComponent;
import mcp.mobius.waila.api.data.FluidData;
import mcp.mobius.waila.api.data.FluidData.Unit;
import mcp.mobius.waila.plugin.extra.data.FluidDataImpl;
import mcp.mobius.waila.plugin.extra.data.FluidDataImpl.Entry;
import mcp.mobius.waila.plugin.extra.data.FluidDataImpl.FluidDescription;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class FluidProvider extends DataProvider<FluidData, FluidDataImpl> {

    public static final FluidProvider INSTANCE = new FluidProvider();

    private static final String INFINITE = "∞";

    private FluidProvider() {
        super(FluidData.ID, FluidData.class, FluidDataImpl.class, FluidDataImpl::new);
    }

    @Override
    protected void registerAdditions(ICommonRegistrar registrar, int priority) {
        registrar.localConfig(FluidData.CONFIG_DISPLAY_UNIT, FluidData.Unit.MILLIBUCKETS);
    }

    @Override
    protected void registerAdditions(IClientRegistrar registrar, int priority) {
        registrar.body(new CauldronProvider(), Block.class, priority);
    }

    @Override
    protected void appendBody(ITooltip tooltip, FluidDataImpl data, IPluginConfig config, Identifier objectId) {
        addFluidTooltip(tooltip, data, config);
    }

    private void addFluidTooltip(ITooltip tooltip, FluidDataImpl data, IPluginConfig config) {
        FluidData.Unit displayUnit = config.getEnum(FluidData.CONFIG_DISPLAY_UNIT);
        var storedUnit = data.unit();

        for (var entry : data.entries()) {
            if (entry.isEmpty()) continue;

            var desc = FluidDataImpl.FluidDescription.getFluidDesc(entry);

            var stored = entry.stored();
            var capacity = entry.capacity();
            var ratio = Double.isInfinite(capacity) ? 1f : (float) (stored / capacity);

            String text;
            if (Double.isInfinite(stored)) text = INFINITE;
            else {
                text = WailaHelper.suffix((long) FluidData.Unit.convert(storedUnit, displayUnit, stored));
                if (Double.isFinite(capacity)) text += "/" + WailaHelper.suffix((long) FluidData.Unit.convert(storedUnit, displayUnit, capacity));
            }

            text += " " + displayUnit.symbol;

            var sprite = desc.sprite();
            tooltip.setLine(FluidData.ID.withSuffixedPath("." + Registries.FLUID.getId(entry.fluid()).toTranslationKey()), new PairComponent(
                new WrappedComponent(desc.name().getString()),
                new SpriteBarComponent(ratio, sprite, 16, 16, desc.tint(), Text.literal(text))));
        }
    }

    private class CauldronProvider implements IBlockComponentProvider {

        @Override
        public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
            if (accessor.getData().get(FluidData.class) != null) return;
            if (!config.getBoolean(enabledBlockOption)) return;
            if (blacklistConfig.get().getView().blockFilter.matches(accessor.getBlock())) return;

            var fluidData = FluidDataImpl.FluidDescription.getCauldronFluidData(accessor.getBlockState());
            if (fluidData != null) addFluidTooltip(tooltip, (FluidDataImpl) fluidData, config);
        }

    }

}
