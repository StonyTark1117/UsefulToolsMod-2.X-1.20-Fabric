package mcp.mobius.waila.access;

import D;
import I;
import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.ICommonAccessor;
import mcp.mobius.waila.api.IDataReader;
import mcp.mobius.waila.api.IEntityAccessor;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public enum ClientAccessor implements ICommonAccessor, IBlockAccessor, IEntityAccessor {

    INSTANCE;

    private World world;
    private PlayerEntity player;
    private HitResult hitResult;
    private Vec3d renderingVec = null;
    private Block block = Blocks.AIR;
    private BlockState state = Blocks.AIR.getDefaultState();
    private BlockPos pos = BlockPos.ORIGIN;
    private Identifier blockRegistryName = Registries.ITEM.getDefaultId();
    private @Nullable BlockEntity blockEntity;
    private @Nullable Entity entity;
    private long timeLastUpdate = System.currentTimeMillis();
    private ItemStack stack = ItemStack.EMPTY;
    private int updateId;
    private boolean dataAccess = true;
    private Vec3d rayCastOrigin;
    private Vec3d rayCastDirection;
    private double rayCastMaxDistance;
    private float frameTime;

    @Override
    public World getWorld() {
        return this.world;
    }

    @Override
    public PlayerEntity getPlayer() {
        return this.player;
    }

    @Override
    public Block getBlock() {
        return this.block;
    }

    @Override
    public BlockState getBlockState() {
        return this.state;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends BlockEntity> T getBlockEntity() {
        return (T) this.blockEntity;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends Entity> T getEntity() {
        return (T) this.entity;
    }

    public void setEntity(@Nullable Entity entity) {
        this.entity = entity;
    }

    @Override
    public BlockPos getPosition() {
        return this.pos;
    }

    @Override
    @Deprecated
    public HitResult getHitResult() {
        return getRawHitResult();
    }

    public HitResult getRawHitResult() {
        return this.hitResult;
    }

    @Override
    public BlockHitResult getBlockHitResult() {
        return (BlockHitResult) hitResult;
    }

    @Override
    public EntityHitResult getEntityHitResult() {
        return (EntityHitResult) hitResult;
    }

    @Override
    public Vec3d getRenderingPosition() {
        return this.renderingVec;
    }

    @Override
    @SuppressWarnings("removal")
    public NbtCompound getServerData() {
        return getData().raw();
    }

    @Override
    public IDataReader getData() {
        if (!dataAccess) return DataReader.NOOP;

        var data = DataReader.CLIENT;
        if (!isTagCorrectBlockEntity() && !isTagCorrectEntity()) data.reset(null);
        return data;
    }

    @Override
    public long getServerDataTime() {
        var data = getData().raw();
        return data.contains("WailaTime") ? data.getLong("WailaTime") : System.currentTimeMillis();
    }

    @Override
    public double getPartialFrame() {
        return this.frameTime;
    }

    @Override
    public @Nullable Direction getSide() {
        return hitResult == null ? null : hitResult.getType() == HitResult.Type.ENTITY ? null : ((BlockHitResult) hitResult).getSide();
    }

    @Override
    public ItemStack getStack() {
        return this.stack;
    }

    @Override
    public Identifier getBlockId() {
        return blockRegistryName;
    }

    @Override
    public int getUpdateId() {
        return updateId;
    }

    @Override
    public Vec3d getRayCastOrigin() {
        return rayCastOrigin;
    }

    @Override
    public Vec3d getRayCastDirection() {
        return rayCastDirection;
    }

    @Override
    public double getRayCastMaxDistance() {
        return rayCastMaxDistance;
    }

    @Override
    public float getFrameTime() {
        return frameTime;
    }

    public void set(World world, PlayerEntity player, HitResult hit, Entity viewEntity, Vec3d rayCastOrigin, Vec3d rayCastDirection, double rayCastMaxDistance, float frameTime) {
        this.updateId++;
        if (updateId == 0) updateId++;

        this.world = world;
        this.player = player;
        this.hitResult = hit;
        this.rayCastMaxDistance = rayCastMaxDistance;
        this.rayCastOrigin = rayCastOrigin;
        this.rayCastDirection = rayCastDirection;
        this.frameTime = frameTime;

        if (this.hitResult.getType() == HitResult.Type.BLOCK) {
            this.pos = ((BlockHitResult) hit).getBlockPos();
            this.blockEntity = this.world.getBlockEntity(this.pos);
            this.entity = null;
            setState(world.getBlockState(pos));
        } else if (this.hitResult.getType() == HitResult.Type.ENTITY) {
            this.entity = ((EntityHitResult) hit).getEntity();
            this.pos = entity.getBlockPos();
            this.blockEntity = null;
            setState(Blocks.AIR.getDefaultState());
        }

        if (viewEntity != null) {
            var px = viewEntity.prevX + (viewEntity.getX() - viewEntity.prevX) * frameTime;
            var py = viewEntity.prevY + (viewEntity.getY() - viewEntity.prevY) * frameTime;
            var pz = viewEntity.prevZ + (viewEntity.getZ() - viewEntity.prevZ) * frameTime;
            this.renderingVec = new Vec3d(this.pos.getX() - px, this.pos.getY() - py, this.pos.getZ() - pz);
        }
    }

    public void setState(BlockState state) {
        this.state = state;
        this.block = state.getBlock();
        this.stack = block.getPickStack(world, pos, state);
        this.blockRegistryName = Registries.BLOCK.getId(block);
    }

    public void setDataAccess(boolean dataAccess) {
        this.dataAccess = dataAccess;
    }

    private boolean isTagCorrectBlockEntity() {
        if (blockEntity == null) return false;

        var tag = DataReader.CLIENT.raw();

        if (tag == null) {
            this.timeLastUpdate = System.currentTimeMillis() - 250;
            return false;
        }

        var x = tag.getInt("x");
        var y = tag.getInt("y");
        var z = tag.getInt("z");

        var hitPos = ((BlockHitResult) hitResult).getBlockPos();
        if (x == hitPos.getX() && y == hitPos.getY() && z == hitPos.getZ())
            return true;
        else {
            this.timeLastUpdate = System.currentTimeMillis() - 250;
            return false;
        }
    }

    private boolean isTagCorrectEntity() {
        if (entity == null) return false;

        var tag = DataReader.CLIENT.raw();

        if (tag == null || !tag.contains("WailaEntityID")) {
            this.timeLastUpdate = System.currentTimeMillis() - 250;
            return false;
        }

        var id = tag.getInt("WailaEntityID");

        if (id == this.entity.getId())
            return true;
        else {
            this.timeLastUpdate = System.currentTimeMillis() - 250;
            return false;
        }
    }

    public boolean isTimeElapsed(long time) {
        return System.currentTimeMillis() - this.timeLastUpdate >= time;
    }

    public void resetTimer() {
        this.timeLastUpdate = System.currentTimeMillis();
    }

}
