package mcp.mobius.waila.command;

import java.nio.file.Path;
import java.util.function.Supplier;
import Z;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import io.netty.buffer.Unpooled;
import lol.bai.badpackets.api.PacketSender;
import mcp.mobius.waila.Waila;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.debug.DumpGenerator;
import mcp.mobius.waila.mixin.BaseContainerBlockEntityAccess;
import mcp.mobius.waila.network.Packets;
import mcp.mobius.waila.plugin.PluginLoader;
import net.minecraft.command.argument.BlockPosArgumentType;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.inventory.ContainerLock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;

public abstract class ServerCommand extends CommonCommand<ServerCommandSource, MinecraftServer> {

    public ServerCommand() {
        super(WailaConstants.NAMESPACE);
    }

    protected abstract @Nullable String fillContainer(ServerWorld world, BlockPos pos, ServerPlayerEntity player);

    @Override
    protected boolean pluginCommandRequirement(ServerCommandSource source) {
        return source.hasPermissionLevel(CommandManager.field_31840);
    }

    @Override
    protected void register(ArgumentBuilderBuilder<ServerCommandSource> command) {
        command
            .then(CommandManager.literal("dump"))
            .requires(source -> source.hasPermissionLevel(CommandManager.field_31840))
            .executes(context -> {
                var source = context.getSource();
                var server = source.getServer();
                var dedicated = server.isDedicated();
                var path = DumpGenerator.generate(dedicated ? DumpGenerator.SERVER : DumpGenerator.LOCAL);
                if (path != null) {
                    Text pathComponent = Text.literal(path.toString()).styled(style -> style
                        .withUnderline(true)
                        .withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_FILE, path.toString())));
                    source.sendFeedback(() -> Text.translatable(dedicated ? Tl.Command.SERVER_DUMP_SUCCESS : Tl.Command.LOCAL_DUMP_SUCCESS, pathComponent), false);
                    var entity = source.getEntity();
                    if (entity instanceof ServerPlayerEntity player && !server.isHost(player.getGameProfile())) {
                        PacketSender.s2c(player).send(Packets.GENERATE_CLIENT_DUMP, new PacketByteBuf(Unpooled.EMPTY_BUFFER));
                    }
                    return 1;
                } else {
                    return 0;
                }
            })
            .pop("dump");

        if (Waila.ENABLE_DEBUG_COMMAND) command
            .then(CommandManager.literal("debug"))
            .requires(source -> source.hasPermissionLevel(CommandManager.field_31840))

            .then(CommandManager.literal("getBlockInfo"))
            .then(CommandManager.argument("pos", BlockPosArgumentType.blockPos()))
            .executes(context -> {
                var source = context.getSource();
                var world = source.getWorld();
                var pos = BlockPosArgumentType.getLoadedBlockPos(context, "pos");
                var block = world.getBlockState(pos).getBlock();

                //noinspection deprecation
                source.sendFeedback(() -> Text.literal("Block ID: " + block.getRegistryEntry().registryKey().getValue()), false);
                source.sendFeedback(() -> Text.literal("Block class: " + block.getClass().getName()), false);

                var blockEntity = world.getBlockEntity(pos);
                if (blockEntity != null) {
                    //noinspection DataFlowIssue
                    source.sendFeedback(() -> Text.literal("Block entity type ID: " + Registries.BLOCK_ENTITY_TYPE.getId(blockEntity.getType())), false);
                    source.sendFeedback(() -> Text.literal("Block entity class: " + blockEntity.getClass().getName()), false);
                }

                return 1;
            })
            .pop("pos", "getBlockInfo")

            .then(CommandManager.literal("getEntityInfo"))
            .then(CommandManager.argument("target", EntityArgumentType.entity()))
            .executes(context -> {
                var source = context.getSource();
                var entity = EntityArgumentType.getEntity(context, "target");

                //noinspection deprecation
                source.sendFeedback(() -> Text.literal("Entity type ID: " + entity.getType().getRegistryEntry().registryKey().getValue()), false);
                source.sendFeedback(() -> Text.literal("Entity class: " + entity.getClass().getName()), false);
                return 1;
            })
            .pop("target", "getEntityInfo")

            .then(CommandManager.literal("lockContainer"))
            .then(CommandManager.argument("pos", BlockPosArgumentType.blockPos()))
            .then(CommandManager.argument("lock", StringArgumentType.string()))
            .executes(context -> {
                var source = context.getSource();
                var world = source.getWorld();
                var player = source.getPlayer();
                var pos = BlockPosArgumentType.getLoadedBlockPos(context, "pos");
                var lock = StringArgumentType.getString(context, "lock");

                if (player == null) {
                    source.sendError(Text.literal("Needs a player"));
                } else if (world.getBlockEntity(pos) instanceof BaseContainerBlockEntityAccess container) {
                    container.wthit_lockKey(new ContainerLock(lock));
                    var key = new ItemStack(Items.NAME_TAG);
                    key.setCustomName(Text.literal(lock));
                    player.setStackInHand(Hand.MAIN_HAND, key);
                    source.sendFeedback(() -> Text.literal("Locked container " + pos.toShortString() + " with lock \"" + lock + "\""), false);
                    return 1;
                } else {
                    source.sendError(Text.literal("Couldn't lock container " + pos.toShortString()));
                }

                return 0;
            })
            .pop("lock", "pos", "lockContainer")

            .then(CommandManager.literal("fillContainer"))
            .then(CommandManager.argument("pos", BlockPosArgumentType.blockPos()))
            .executes(context -> {
                var source = context.getSource();
                var world = source.getWorld();
                var player = source.getPlayer();
                var pos = BlockPosArgumentType.getLoadedBlockPos(context, "pos");

                var err = fillContainer(world, pos, player);
                if (err != null) {
                    source.sendError(Text.literal(err));
                    return 0;
                } else {
                    source.sendFeedback(() -> Text.literal("Filled " + pos.toShortString()), false);
                    return 1;
                }
            })
            .pop("pos", "fillContainer")

            .pop("debug");
    }

    @Override
    protected LiteralArgumentBuilder<ServerCommandSource> literal(String name) {
        return CommandManager.literal(name);
    }

    @Override
    protected <T> RequiredArgumentBuilder<ServerCommandSource, T> argument(String name, ArgumentType<T> type) {
        return CommandManager.argument(name, type);
    }

    @Override
    protected void success(ServerCommandSource source, Supplier<Text> msg) {
        source.sendFeedback(msg, false);
    }

    @Override
    protected void fail(ServerCommandSource source, Text msg) {
        source.sendError(msg);
    }

    @Override
    protected MinecraftServer getExecutor(ServerCommandSource source) {
        return source.getServer();
    }

    @Override
    protected void reloadPlugins(MinecraftServer executor) {
        PluginLoader.reloadServerPlugins(executor);
    }

}
