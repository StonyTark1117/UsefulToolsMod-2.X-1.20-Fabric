package mcp.mobius.waila.gui.hud;

import mcp.mobius.waila.api.ITargetRedirector;
import net.minecraft.util.hit.HitResult;
import org.jetbrains.annotations.Nullable;

public class TargetRedirector implements ITargetRedirector {

    private static final TargetRedirector INSTANCE = new TargetRedirector();
    private static final mcp.mobius.waila.gui.hud.TargetRedirector.Result RESULT = new mcp.mobius.waila.gui.hud.TargetRedirector.Result();

    public boolean self, nowhere, behind;
    public @Nullable HitResult to;

    public static TargetRedirector get() {
        INSTANCE.self = false;
        INSTANCE.nowhere = false;
        INSTANCE.behind = false;
        INSTANCE.to = null;
        return INSTANCE;
    }

    @Override
    public mcp.mobius.waila.gui.hud.TargetRedirector.Result toSelf() {
        self = true;
        return RESULT;
    }

    @Override
    public mcp.mobius.waila.gui.hud.TargetRedirector.Result toNowhere() {
        nowhere = true;
        return RESULT;
    }

    @Override
    public mcp.mobius.waila.gui.hud.TargetRedirector.Result toBehind() {
        behind = true;
        return RESULT;
    }

    @Override
    public mcp.mobius.waila.gui.hud.TargetRedirector.Result to(HitResult hitResult) {
        to = hitResult;
        return RESULT;
    }

    public static class Result implements ITargetRedirector.Result {

    }

}
