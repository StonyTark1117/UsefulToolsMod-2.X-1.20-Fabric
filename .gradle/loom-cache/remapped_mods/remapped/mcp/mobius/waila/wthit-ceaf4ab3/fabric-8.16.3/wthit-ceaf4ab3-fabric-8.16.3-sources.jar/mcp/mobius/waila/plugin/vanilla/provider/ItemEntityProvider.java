package mcp.mobius.waila.plugin.vanilla.provider;

import I;
import J;
import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;

import mcp.mobius.waila.api.IEntityAccessor;
import mcp.mobius.waila.api.IEntityComponentProvider;
import mcp.mobius.waila.api.IModInfo;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.IWailaConfig;
import mcp.mobius.waila.api.IWailaConfig.Formatter;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.api.component.ItemComponent;
import mcp.mobius.waila.plugin.vanilla.config.EnchantmentDisplayMode;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.WrittenBookItem;
import net.minecraft.registry.Registries;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.StringHelper;
import org.jetbrains.annotations.Nullable;

public enum ItemEntityProvider implements IEntityComponentProvider {

    INSTANCE;

    private static final Identifier AUTHOR = Options.BOOK_WRITTEN.withSuffixedPath(".author");
    private static final Identifier GENERATION = Options.BOOK_WRITTEN.withSuffixedPath(".generation");

    private static long lastEnchantmentTime = 0;
    private static int enchantmentIndex = 0;
    private static int curseIndex = 0;

    @Nullable
    @Override
    public Entity getOverride(IEntityAccessor accessor, IPluginConfig config) {
        return !config.getBoolean(Options.ENTITY_ITEM_ENTITY) ? EMPTY_ENTITY : null;
    }

    @Override
    public ITooltipComponent getIcon(IEntityAccessor accessor, IPluginConfig config) {
        return new ItemComponent(accessor.<ItemEntity>getEntity().getStack());
    }

    @Override
    public void appendHead(ITooltip tooltip, IEntityAccessor accessor, IPluginConfig config) {
        var formatter = IWailaConfig.get().getFormatter();

        var stack = accessor.<ItemEntity>getEntity().getStack();
        tooltip.setLine(WailaConstants.OBJECT_NAME_TAG, formatter.entityName(stack.getName().getString()));

        if (config.getBoolean(WailaConstants.CONFIG_SHOW_REGISTRY)) {
            tooltip.setLine(WailaConstants.REGISTRY_NAME_TAG, formatter.registryName(Registries.ITEM.getId(stack.getItem())));
        }
    }

    @Override
    public void appendBody(ITooltip tooltip, IEntityAccessor accessor, IPluginConfig config) {
        var stack = accessor.<ItemEntity>getEntity().getStack();
        appendBookProperties(tooltip, stack, config);
    }

    @Override
    public void appendTail(ITooltip tooltip, IEntityAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(WailaConstants.CONFIG_SHOW_MOD_NAME)) {
            var mod = IModInfo.get(accessor.<ItemEntity>getEntity().getStack()).getName();
            tooltip.setLine(WailaConstants.MOD_NAME_TAG, IWailaConfig.get().getFormatter().modName(mod));
        }
    }

    public static void appendBookProperties(ITooltip tooltip, ItemStack stack, IPluginConfig config) {
        if (stack.isOf(Items.ENCHANTED_BOOK)) {
            EnchantmentDisplayMode mode = config.getEnum(Options.BOOK_ENCHANTMENT_DISPLAY_MODE);
            if (mode == EnchantmentDisplayMode.DISABLED) return;

            if (mode == EnchantmentDisplayMode.CYCLE) {
                var enchantmentTiming = config.getInt(Options.BOOK_ENCHANTMENT_CYCLE_TIMING);
                var enchantmentsTag = EnchantedBookItem.getEnchantmentNbt(stack);
                var now = System.currentTimeMillis();

                var enchantments = new ArrayList<EnchantmentLevelEntry>();
                var curses = new ArrayList<EnchantmentLevelEntry>();

                for (var i = 0; i < enchantmentsTag.size(); i++) {
                    var enchantmentTag = enchantmentsTag.getCompound(i);
                    var enchantment = Registries.ENCHANTMENT.get(EnchantmentHelper.getIdFromNbt(enchantmentTag));
                    if (enchantment == null) continue;

                    var level = EnchantmentHelper.getLevelFromNbt(enchantmentTag);
                    var instance = new EnchantmentLevelEntry(enchantment, level);

                    if (enchantment.isCursed()) curses.add(instance);
                    else enchantments.add(instance);
                }

                if ((now - lastEnchantmentTime) >= enchantmentTiming) {
                    lastEnchantmentTime = now;
                    enchantmentIndex++;
                    curseIndex++;

                    if (enchantmentIndex > (enchantments.size() - 1)) enchantmentIndex = 0;
                    if (curseIndex > (curses.size() - 1)) curseIndex = 0;
                }

                Text text = null;

                if (!enchantments.isEmpty()) {
                    var instance = enchantments.get(enchantmentIndex);
                    text = instance.enchantment.getName(instance.level);
                }

                if (!curses.isEmpty()) {
                    var instance = curses.get(curseIndex);
                    var curse = instance.enchantment.getName(instance.level);
                    if (text == null) text = curse;
                    else text = text.copy().append(ScreenTexts.LINE_BREAK).append(curse);
                }

                if (text != null) tooltip.setLine(Options.BOOK_ENCHANTMENT_DISPLAY_MODE, text);
            } else {
                var enchantments = EnchantmentHelper.get(stack);
                MutableText text = null;

                if (mode == EnchantmentDisplayMode.COMBINED) {
                    MutableText enchantmentLine = null;
                    MutableText curseLine = null;

                    for (var entry : enchantments.entrySet()) {
                        var enchantment = entry.getKey();
                        int level = entry.getValue();
                        var name = enchantment.getName(level);

                        if (enchantment.isCursed()) {
                            if (curseLine == null) {
                                curseLine = Text.empty().append(name);
                            } else {
                                curseLine.append(Text.literal(", ")).append(name);
                            }
                        } else {
                            if (enchantmentLine == null) {
                                enchantmentLine = Text.empty().append(name);
                            } else {
                                enchantmentLine.append(Text.literal(", ")).append(name);
                            }
                        }
                    }

                    if (enchantmentLine != null) text = enchantmentLine;
                    if (curseLine != null) {
                        if (text == null) text = curseLine;
                        else text.append(ScreenTexts.LINE_BREAK).append(curseLine);
                    }
                } else {
                    for (var entry : enchantments.entrySet()) {
                        var name = entry.getKey().getName(entry.getValue());
                        if (text == null) text = Text.empty().append(name);
                        else text.append(ScreenTexts.LINE_BREAK).append(name);
                    }
                }

                if (text != null) tooltip.setLine(Options.BOOK_ENCHANTMENT_DISPLAY_MODE, text);
            }
        } else if (stack.isOf(Items.WRITTEN_BOOK)) {
            if (!config.getBoolean(Options.BOOK_WRITTEN) || !stack.hasNbt()) return;

            var tag = Objects.requireNonNull(stack.getNbt());
            var author = tag.getString(WrittenBookItem.AUTHOR_KEY);
            var generation = WrittenBookItem.getGeneration(stack);

            if (!StringHelper.isEmpty(author)) {
                tooltip.setLine(AUTHOR, Text.translatable("book.byAuthor", author));
            }

            tooltip.setLine(GENERATION, Text.translatable("book.generation." + generation));
        }
    }

}
