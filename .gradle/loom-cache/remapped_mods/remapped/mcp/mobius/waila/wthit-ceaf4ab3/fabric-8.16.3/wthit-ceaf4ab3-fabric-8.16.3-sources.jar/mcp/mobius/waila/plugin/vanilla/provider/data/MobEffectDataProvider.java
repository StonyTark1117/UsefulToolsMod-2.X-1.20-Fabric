package mcp.mobius.waila.plugin.vanilla.provider.data;

import I;
import java.util.List;
import java.util.Objects;

import mcp.mobius.waila.api.IData;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public enum MobEffectDataProvider implements IDataProvider<LivingEntity> {

    INSTANCE;

    public static final Identifier DATA = new Identifier("mob_effects");

    @Override
    public void appendData(IDataWriter data, IServerAccessor<LivingEntity> accessor, IPluginConfig config) {
        if (config.getBoolean(Options.EFFECT_MOB)) data.add(Data.class, res -> res.add(new Data(accessor
            .getTarget()
            .getStatusEffects()
            .stream()
            .filter(it -> it.shouldShowParticles() || config.getBoolean(Options.EFFECT_HIDDEN_MOB))
            .toList())));
    }

    public record Data(
        List<StatusEffectInstance> list
    ) implements IData {

        public Data(PacketByteBuf buf) {
            this(buf.readList(b -> {
                var effect = b.readRegistryValue(Registries.STATUS_EFFECT);
                var amplifier = b.readVarInt();
                return new StatusEffectInstance(Objects.requireNonNull(effect), -1, amplifier);
            }));
        }

        @Override
        public void write(PacketByteBuf buf) {
            buf.writeCollection(list, (b, m) -> {
                b.writeRegistryValue(Registries.STATUS_EFFECT, m.getEffectType());
                b.writeVarInt(m.getAmplifier());
            });
        }

    }

}
