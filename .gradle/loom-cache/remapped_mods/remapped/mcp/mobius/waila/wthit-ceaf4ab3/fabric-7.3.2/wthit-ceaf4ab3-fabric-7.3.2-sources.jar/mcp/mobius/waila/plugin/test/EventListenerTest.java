package mcp.mobius.waila.plugin.test;

import java.awt.Rectangle;
import mcp.mobius.waila.api.ICommonAccessor;
import mcp.mobius.waila.api.IEventListener;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.WailaConstants;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public enum EventListenerTest implements IEventListener {

    INSTANCE;

    static final Identifier HANDLE_TOOLTIP = new Identifier("test:event.handle_tooltip");
    static final Identifier BEFORE_RENDER = new Identifier("test:event.before_render");
    static final Identifier AFTER_RENDER = new Identifier("test:event.after_render");
    static final Identifier ITEM_MOD_NAME = new Identifier("test:event.item_mod_name");

    @Override
    public void onHandleTooltip(ITooltip tooltip, ICommonAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(HANDLE_TOOLTIP)) {
            tooltip.addLine(Text.literal("EventListenerTest"));
            tooltip.setLine(WailaConstants.MOD_NAME_TAG, Text.literal("EventListenerTest"));
        }
    }

    @Override
    public void onBeforeTooltipRender(MatrixStack matrices, Rectangle rect, ICommonAccessor accessor, IPluginConfig config, Canceller canceller) {
        if (config.getBoolean(BEFORE_RENDER)) {
            DrawContext.fill(matrices, rect.x, rect.y, rect.x + 20, rect.y + 20, 0xFF0000FF);
            rect.setLocation(rect.x + 25, rect.y + 25);
        }
    }

    @Override
    public void onAfterTooltipRender(MatrixStack matrices, Rectangle rect, ICommonAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(AFTER_RENDER)) {
            DrawContext.fill(matrices, rect.x, rect.y, rect.x + 20, rect.y + 20, 0xFF00FFFF);
        }
    }

    @Nullable
    @Override
    public String getHoveredItemModName(ItemStack stack, IPluginConfig config) {
        if (config.getBoolean(ITEM_MOD_NAME)) {
            return "EventListenerTest";
        }
        return null;
    }

}
