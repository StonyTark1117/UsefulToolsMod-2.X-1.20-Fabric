package mcp.mobius.waila.plugin.vanilla.provider;

import java.text.DecimalFormat;

import mcp.mobius.waila.api.IEntityAccessor;
import mcp.mobius.waila.api.IEntityComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.component.PairComponent;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public enum HorseProvider implements IEntityComponentProvider {

    INSTANCE;

    private static final DecimalFormat FORMAT = new DecimalFormat("#.##");
    private static final Text JUMP_KEY = Text.translatable(Tl.Tooltip.Horse.Jump.KEY);
    private static final Text SPEED_KEY = Text.translatable(Tl.Tooltip.Horse.Speed.KEY);

    @Override
    public void appendBody(ITooltip tooltip, IEntityAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(Options.ATTRUBUTE_HORSE_JUMP_HEIGHT)) {
            AbstractHorseEntity horse = accessor.getEntity();

            double jumpStrength = horse.getJumpStrength();
            double jumpHeight = -0.1817584952f * Math.pow(jumpStrength, 3) + 3.689713992f * Math.pow(jumpStrength, 2) + 2.128599134f * jumpStrength - 0.343930367f;

            Formatting format;
            if (jumpHeight < 2.0f)
                format = Formatting.DARK_GRAY;
            else if (jumpHeight > 4.0f)
                format = Formatting.GOLD;
            else
                format = Formatting.RESET;

            tooltip.addLine(new PairComponent(JUMP_KEY,
                Text.translatable(Tl.Tooltip.Horse.Jump.VALUE, FORMAT.format(jumpHeight)).formatted(format)));
        }

        if (config.getBoolean(Options.ATTRUBUTE_HORSE_SPEED)) {
            AbstractHorseEntity horse = accessor.getEntity();
            double speed = horse.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).getBaseValue() * 42.157787584f;

            Formatting format;
            if (speed < 7.0f)
                format = Formatting.DARK_GRAY;
            else if (speed > 11.0f)
                format = Formatting.GOLD;
            else
                format = Formatting.RESET;

            tooltip.addLine(new PairComponent(SPEED_KEY,
                Text.translatable(Tl.Tooltip.Horse.Speed.VALUE, FORMAT.format(speed)).formatted(format)));
        }
    }

}
