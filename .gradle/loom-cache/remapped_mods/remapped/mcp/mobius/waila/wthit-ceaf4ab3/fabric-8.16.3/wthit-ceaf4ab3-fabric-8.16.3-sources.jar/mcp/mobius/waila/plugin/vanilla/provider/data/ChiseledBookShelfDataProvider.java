package mcp.mobius.waila.plugin.vanilla.provider.data;

import java.util.List;

import mcp.mobius.waila.api.IData;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.data.ItemData;
import mcp.mobius.waila.mixin.ChiseledBookShelfBlockEntityAccess;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.block.entity.ChiseledBookshelfBlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

public enum ChiseledBookShelfDataProvider implements IDataProvider<ChiseledBookshelfBlockEntity> {

    INSTANCE;

    public static final Identifier DATA = new Identifier("chiseled_bookshelf");

    @Override
    public void appendData(IDataWriter data, IServerAccessor<ChiseledBookshelfBlockEntity> accessor, IPluginConfig config) {
        data.blockAll(ItemData.class);

        if (config.getBoolean(Options.BOOK_BOOKSHELF)) data.add(Data.class, res -> {
            var bookshelf = (ChiseledBookShelfBlockEntityAccess) accessor.getTarget();
            res.add(new Data(bookshelf.wthit_items()));
        });
    }

    public record Data(
        List<ItemStack> items
    ) implements IData {

        public Data(PacketByteBuf buf) {
            this(buf.readList(PacketByteBuf::readItemStack));
        }

        @Override
        public void write(PacketByteBuf buf) {
            buf.writeCollection(items, PacketByteBuf::writeItemStack);
        }

    }

}
