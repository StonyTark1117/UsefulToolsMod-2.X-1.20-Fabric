package mcp.mobius.waila.gui.widget;

import com.google.common.collect.ImmutableList;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.text.Text;

import static mcp.mobius.waila.util.DisplayUtil.createButton;

public class ButtonEntry extends ConfigListWidget.Entry {

    private final String title;
    private final ButtonWidget button;

    public ButtonEntry(String title, ButtonWidget button) {
        this(title, title, button);
    }

    public ButtonEntry(String name, String button, ButtonWidget buttonWidget) {
        this.title = I18n.translate(name);
        this.button = buttonWidget;
        buttonWidget.setMessage(Text.translatable(button));
    }

    public ButtonEntry(String title, int width, int height, ButtonWidget.PressAction pressAction) {
        this(title, title, width, height, pressAction);
    }

    public ButtonEntry(String name, String button, int width, int height, ButtonWidget.PressAction pressAction) {
        this(name, button, createButton(0, 0, width, height, Text.empty(), pressAction));
    }

    @Override
    protected void drawEntry(DrawContext ctx, int index, int rowTop, int rowLeft, int width, int height, int mouseX, int mouseY, boolean hovered, float deltaTime) {
        ctx.drawTextWithShadow(client.textRenderer, title, rowLeft, rowTop + (height - client.textRenderer.fontHeight) / 2, 0xFFFFFF);
        this.button.setX(rowLeft + width - button.getWidth());
        this.button.setY(rowTop + (height - button.getHeight()) / 2);
        this.button.render(ctx, mouseX, mouseY, deltaTime);
    }

    @Override
    protected void gatherChildren(ImmutableList.Builder<Element> children) {
        children.add(button);
    }

    @Override
    protected void buildSearchKey(StringBuilder sb) {
        sb.append(title);
    }

}
