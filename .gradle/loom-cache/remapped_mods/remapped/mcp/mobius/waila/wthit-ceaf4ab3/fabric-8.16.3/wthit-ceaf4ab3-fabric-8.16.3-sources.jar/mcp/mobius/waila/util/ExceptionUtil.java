package mcp.mobius.waila.util;

import Z;
import java.util.HashSet;
import java.util.Set;

import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.WailaConstants;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.jetbrains.annotations.Nullable;

public final class ExceptionUtil {

    private static final Log LOG = Log.create();
    private static final Set<String> ERRORS = new HashSet<>();

    public static boolean dump(Throwable e, String errorName, @Nullable ITooltip tooltip) {
        var log = ERRORS.add(errorName);

        if (log) {
            LOG.error("Caught unhandled exception : [{}] {}", errorName, e);
            LOG.error(ExceptionUtils.getStackTrace(e));
        }

        if (tooltip != null) {
            tooltip.setLine(WailaConstants.ERROR_TAG, Text
                .literal("Error on " + errorName + "\nSee logs for more info")
                .formatted(Formatting.RED));
        }

        return log;
    }

}
