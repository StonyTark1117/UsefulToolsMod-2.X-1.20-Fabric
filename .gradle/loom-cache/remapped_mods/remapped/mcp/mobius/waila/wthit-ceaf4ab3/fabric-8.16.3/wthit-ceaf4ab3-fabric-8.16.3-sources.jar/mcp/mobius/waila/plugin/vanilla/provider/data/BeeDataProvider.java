package mcp.mobius.waila.plugin.vanilla.provider.data;

import mcp.mobius.waila.api.IData;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.entity.passive.BeeEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

public enum BeeDataProvider implements IDataProvider<BeeEntity> {

    INSTANCE;

    public static final Identifier HIVE_POS = new Identifier("bee.hive_pos");

    @Override
    public void appendData(IDataWriter data, IServerAccessor<BeeEntity> accessor, IPluginConfig config) {
        if (config.getBoolean(Options.BEE_HIVE_POS)) {
            var hivePos = accessor.getTarget().getHivePos();
            if (hivePos != null) {
                data.addImmediate(new HivePosData(hivePos));
            }
        }
    }

    public record HivePosData(BlockPos pos) implements IData {

        public HivePosData(PacketByteBuf buf) {
            this(buf.readBlockPos());
        }

        @Override
        public void write(PacketByteBuf buf) {
            buf.writeBlockPos(pos);
        }

    }

}
