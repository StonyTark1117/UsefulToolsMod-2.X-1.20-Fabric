package mcp.mobius.waila.mixed;

import mcp.mobius.waila.api.__internal__.Internals;
import net.minecraft.client.network.ClientDynamicRegistryType;
import net.minecraft.registry.CombinedDynamicRegistries;
import net.minecraft.registry.DynamicRegistryManager;

public interface IMixedService {

    IMixedService INSTANCE = Internals.loadService(IMixedService.class);

    void ReloadableServerResources_updateRegistryTags(DynamicRegistryManager registryAccess);

    void ClientPacketListener_handleUpdateTags(CombinedDynamicRegistries<ClientDynamicRegistryType> registryAccess);

    void onLanguageReloaded();

}
