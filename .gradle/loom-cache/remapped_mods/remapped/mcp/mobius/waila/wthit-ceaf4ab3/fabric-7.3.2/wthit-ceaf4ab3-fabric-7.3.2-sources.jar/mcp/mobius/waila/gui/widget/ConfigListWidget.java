package mcp.mobius.waila.gui.widget;

import java.util.ArrayList;
import java.util.List;

import com.google.common.collect.ImmutableList;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.gui.screen.ConfigScreen;
import mcp.mobius.waila.gui.widget.value.ConfigValue;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.widget.ElementListWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.toast.SystemToast;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ConfigListWidget extends ElementListWidget<ConfigListWidget.Entry> {

    private final ConfigScreen owner;
    private final Runnable diskWriter;

    private int topOffset;
    private int bottomOffset;

    @Nullable
    private TextFieldWidget searchBox;
    private List<mcp.mobius.waila.gui.widget.ConfigListWidget.Entry> unfilteredChildren;

    public ConfigListWidget(ConfigScreen owner, MinecraftClient client, int width, int height, int top, int bottom, int itemHeight, Runnable diskWriter) {
        super(client, width, height, top, bottom, itemHeight - 4);

        this.owner = owner;
        this.diskWriter = diskWriter;

        resize(top, bottom);
        setRenderBackground(false);
    }

    public ConfigListWidget(ConfigScreen owner, MinecraftClient client, int width, int height, int top, int bottom, int itemHeight) {
        this(owner, client, width, height, top, bottom, itemHeight, null);
    }

    @Override
    public int getRowWidth() {
        return Math.min(width - 20, 450);
    }

    @Override
    protected int getScrollbarPositionX() {
        return client.getWindow().getScaledWidth() - 5;
    }

    public void tick() {
        if (searchBox != null) searchBox.tick();
        children().forEach(mcp.mobius.waila.gui.widget.ConfigListWidget.Entry::tick);
    }

    public boolean save(boolean ignoreErrors) {
        List<? extends ConfigValue<?>> values = children()
            .stream()
            .filter(e -> e instanceof ConfigValue)
            .map(e -> (ConfigValue<?>) e)
            .toList();

        if (values.stream().allMatch(ConfigValue::isValueValid)) {
            values.forEach(ConfigValue::save);
            if (diskWriter != null) diskWriter.run();
            return true;
        }

        if (!ignoreErrors) client.getToastManager().add(new SystemToast(
            SystemToast.Type.TUTORIAL_HINT,
            Text.translatable(Tl.Config.InvalidInput.TITLE),
            Text.translatable(Tl.Config.InvalidInput.DESC)));

        return ignoreErrors;
    }

    public TextFieldWidget getSearchBox() {
        if (searchBox != null) return searchBox;

        unfilteredChildren = new ArrayList<>(children());

        String category = "";
        for (mcp.mobius.waila.gui.widget.ConfigListWidget.Entry child : unfilteredChildren) {
            if (child instanceof CategoryEntry) category = child.category;
            child.category = category;
        }

        searchBox = new TextFieldWidget(client.textRenderer, 0, 0, 160, 18, Text.empty());
        searchBox.setPlaceholder(Text.translatable(Tl.Config.SEARCH_PROMPT));
        searchBox.setChangedListener(filter -> {
            children().clear();
            if (filter.isBlank()) {
                children().addAll(unfilteredChildren);
            } else {
                children().addAll(unfilteredChildren.stream().filter(it -> it.match(filter)).toList());
            }
            init();
        });

        return searchBox;
    }

    public void init() {
        for (mcp.mobius.waila.gui.widget.ConfigListWidget.Entry child : children()) {
            child.setFocused(null);
        }
        resize(topOffset, owner.height + bottomOffset);
        setScrollAmount(getScrollAmount());
    }

    public void add(mcp.mobius.waila.gui.widget.ConfigListWidget.Entry entry) {
        add(children().size(), entry);
    }

    public void add(int index, mcp.mobius.waila.gui.widget.ConfigListWidget.Entry entry) {
        children().add(index, entry);
    }

    public ConfigListWidget with(mcp.mobius.waila.gui.widget.ConfigListWidget.Entry entry) {
        return with(children().size(), entry);
    }

    public ConfigListWidget with(int index, mcp.mobius.waila.gui.widget.ConfigListWidget.Entry entry) {
        add(index, entry);
        return this;
    }

    public void resize(int top, int bottom) {
        this.topOffset = top;
        this.bottomOffset = bottom - owner.height;
        updateSize(owner.width, owner.height, topOffset, owner.height + bottomOffset);
        if (searchBox != null) searchBox.setPosition(getRowLeft() + getRowWidth() - 160, (top - 18) / 2);
    }

    public abstract static class Entry extends ElementListWidget.Entry<mcp.mobius.waila.gui.widget.ConfigListWidget.Entry> {

        protected final MinecraftClient client;
        protected @Nullable List<? extends Element> children;
        protected @Nullable List<? extends Selectable> narratables;
        public String category = "";

        public Entry() {
            this.client = MinecraftClient.getInstance();
        }

        public void tick() {
        }

        protected void gatherChildren(ImmutableList.Builder<Element> children) {
        }

        protected void gatherNarratables(ImmutableList.Builder<Selectable> narratables) {
        }

        protected boolean match(String filter) {
            return StringUtils.containsIgnoreCase(category, filter);
        }

        @Override
        public @NotNull List<? extends Element> children() {
            if (children == null) {
                ImmutableList.Builder<Element> builder = ImmutableList.builder();
                gatherChildren(builder);
                children = builder.build();
            }

            return children;
        }

        @Override
        public @NotNull List<? extends Selectable> selectableChildren() {
            if (narratables == null) {
                ImmutableList.Builder<Selectable> builder = ImmutableList.builder();
                gatherNarratables(builder);
                narratables = builder.build();
            }

            return narratables;
        }

        @Override
        public void method_25343(@NotNull MatrixStack matrices, int index, int rowTop, int rowLeft, int width, int height, int mouseX, int mouseY, boolean hovered, float deltaTime) {
            if (rowTop <= mouseY && mouseY < rowTop + height + 4) {
                DrawContext.fill(matrices, 0, rowTop - 2, client.getWindow().getScaledWidth(), rowTop + height + 2, 0x22FFFFFF);
            }
        }

    }

}
