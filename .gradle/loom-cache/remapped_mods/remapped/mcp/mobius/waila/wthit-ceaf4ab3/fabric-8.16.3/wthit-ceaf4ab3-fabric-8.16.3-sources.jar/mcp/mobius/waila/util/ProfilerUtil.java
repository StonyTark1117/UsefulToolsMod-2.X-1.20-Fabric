package mcp.mobius.waila.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.profiler.Profiler;

public class ProfilerUtil {

    public static Impl profile(String name) {
        return Impl.INSTANCE.start(name);
    }

    public enum Impl implements AutoCloseable {
        INSTANCE;

        Profiler profiler;

        private Impl start(String name) {
            profiler = MinecraftClient.getInstance().getProfiler();
            profiler.push(name);
            return this;
        }

        @Override
        public void close() {
            profiler.pop();
        }
    }

}
