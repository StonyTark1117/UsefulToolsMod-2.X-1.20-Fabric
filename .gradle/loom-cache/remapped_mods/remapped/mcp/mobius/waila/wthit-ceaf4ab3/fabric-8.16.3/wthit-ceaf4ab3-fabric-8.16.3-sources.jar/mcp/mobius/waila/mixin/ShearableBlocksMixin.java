package mcp.mobius.waila.mixin;

import mcp.mobius.waila.mixed.IShearable;
import net.minecraft.block.CherryLeavesBlock;
import net.minecraft.block.CobwebBlock;
import net.minecraft.block.DeadBushBlock;
import net.minecraft.block.FernBlock;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.MangroveLeavesBlock;
import net.minecraft.block.SeagrassBlock;
import net.minecraft.block.VineBlock;
import org.spongepowered.asm.mixin.Mixin;


@Mixin({
    CherryLeavesBlock.class,
    DeadBushBlock.class,
    LeavesBlock.class,
    MangroveLeavesBlock.class,
    SeagrassBlock.class,
    FernBlock.class,
    VineBlock.class,
    CobwebBlock.class})
public class ShearableBlocksMixin implements IShearable {

}
