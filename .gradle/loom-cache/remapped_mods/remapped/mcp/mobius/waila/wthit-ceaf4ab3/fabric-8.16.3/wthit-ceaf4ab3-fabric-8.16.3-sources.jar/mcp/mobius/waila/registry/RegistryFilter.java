package mcp.mobius.waila.registry;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import java.util.regex.Pattern;

import com.google.common.base.Preconditions;
import com.google.common.base.Stopwatch;
import mcp.mobius.waila.api.IRegistryFilter;
import mcp.mobius.waila.util.Log;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public class RegistryFilter<T> implements IRegistryFilter<T> {

    public static final ThreadLocal<@Nullable DynamicRegistryManager> REGISTRY = ThreadLocal.withInitial(() -> null);
    public static final Set<RegistryFilter<?>> INSTANCES = Collections.newSetFromMap(Collections.synchronizedMap(new WeakHashMap<>()));

    private static final Log LOG = Log.create();

    private final RegistryKey<? extends Registry<T>> registryKey;
    private final Set<Rule<T>> rules;

    private final ThreadLocal<@Nullable Registry<T>> registry = ThreadLocal.withInitial(() -> null);
    private final ThreadLocal<Set<T>> entries = ThreadLocal.withInitial(Set::of);
    private final ThreadLocal<Boolean> loaded = ThreadLocal.withInitial(() -> true);

    private RegistryFilter(RegistryKey<? extends Registry<T>> registry, Set<Rule<T>> rules) {
        this.registryKey = registry;
        this.rules = rules;

        INSTANCES.add(this);
        attach();
    }

    public static void attach(@Nullable DynamicRegistryManager registryAccess) {
        REGISTRY.set(registryAccess);
        INSTANCES.forEach(RegistryFilter::attach);
    }

    public void attach() {
        var access = REGISTRY.get();
        registry.set(access == null ? null : access.get(registryKey));
        entries.set(Set.of());
        loaded.set(false);
    }

    private void load() {
        if (loaded.get()) return;

        var registry = this.registry.get();
        if (registry == null) return;

        Stopwatch stopwatch = null;
        if (LOG.isDebugEnabled()) {
            stopwatch = Stopwatch.createStarted();
            LOG.debug("Attaching registry to filter, id: {}", hashCode());
        }

        var entries = new HashSet<T>(this.entries.get().size());

        rules.forEach(rule -> registry.streamEntries().forEach(holder -> {
            if (rule.predicate.test(holder)) {
                if (rule.negate) {
                    entries.remove(holder.value());
                } else {
                    entries.add(holder.value());
                }
            }
        }));

        this.entries.set(Collections.unmodifiableSet(entries));

        if (stopwatch != null) {
            LOG.debug("Finished in {}ms, {} entries matched", stopwatch.elapsed(TimeUnit.MILLISECONDS), entries.size());
            entries.stream()
                .map(it -> Objects.requireNonNull(registry.getId(it)).toString())
                .sorted()
                .forEach(it -> LOG.debug("\t{}", it));
        }

        loaded.set(true);
    }

    @Override
    public Collection<T> getMatches() {
        load();
        return entries.get();
    }

    @Override
    public boolean matches(T object) {
        load();
        return entries.get().contains(object);
    }

    private record Rule<T>(
        boolean negate,
        Predicate<RegistryEntry.Reference<T>> predicate) {

    }

    public static class Builder<T> implements IRegistryFilter.Builder<T> {

        private final RegistryKey<? extends Registry<T>> registryKey;
        private final Set<Rule<T>> rules;

        private final @Nullable Stopwatch stopwatch;

        public Builder(RegistryKey<? extends Registry<T>> registryKey) {
            if (LOG.isDebugEnabled()) {
                LOG.debug("Start filter for {}", registryKey.getValue());
                stopwatch = Stopwatch.createStarted();
            } else {
                stopwatch = null;
            }

            this.registryKey = registryKey;
            this.rules = new LinkedHashSet<>();
        }

        @Override
        public IRegistryFilter.Builder<T> parse(String rule) {
            if (rule.charAt(0) == '!') {
                parse0(rule.substring(1), true);
            } else {
                parse0(rule, false);
            }

            return this;
        }

        private void parse0(String rule, boolean negate) {
            switch (rule.charAt(0)) {
                case '@' -> {
                    LOG.debug("\tNegate: {}, Namespace: {}", negate, rule);
                    var namespace = rule.substring(1);
                    rules.add(new Rule<>(negate, it -> it.registryKey().getValue().getNamespace().equals(namespace)));
                }
                case '#' -> {
                    LOG.debug("\tNegate: {}, Tag      : {}", negate, rule);
                    var tagId = new Identifier(rule.substring(1));
                    var tag = TagKey.of(registryKey, tagId);
                    rules.add(new Rule<>(negate, it -> it.isIn(tag)));
                }
                case '/' -> {
                    LOG.debug("\tNegate: {}, Regex    : {}", negate, rule);
                    Preconditions.checkArgument(rule.endsWith("/"), "Regex filter must also ends with /");
                    var pattern = Pattern.compile(rule.substring(1, rule.length() - 1));
                    rules.add(new Rule<>(negate, it -> pattern.matcher(it.registryKey().getValue().toString()).matches()));
                }
                default -> {
                    LOG.debug("\tNegate: {}, ID       : {}", negate, rule);
                    rules.add(new Rule<>(negate, it -> it.matchesId(new Identifier(rule))));
                }
            }
        }

        @Override
        public IRegistryFilter.Builder<T> parse(Iterable<String> rules) {
            rules.forEach(this::parse);
            return this;
        }

        @Override
        public IRegistryFilter.Builder<T> parse(String... rules) {
            for (var filter : rules) parse(filter);
            return this;
        }

        @Override
        public IRegistryFilter<T> build() {
            var res = new RegistryFilter<>(registryKey, rules);

            if (stopwatch != null) {
                LOG.debug("Finished in {}ms, id: {}", stopwatch.elapsed(TimeUnit.MILLISECONDS), res.hashCode());
            }

            return res;
        }

    }

}
