package mcp.mobius.waila.plugin.core.pick;

import D;
import F;
import Z;
import java.util.List;
import java.util.Objects;

import mcp.mobius.waila.api.IObjectPicker;
import mcp.mobius.waila.api.IPickerAccessor;
import mcp.mobius.waila.api.IPickerResults;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.WailaConstants;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.util.Unit;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.world.BlockView;
import org.jetbrains.annotations.ApiStatus;

@Deprecated
@ApiStatus.ScheduledForRemoval(inVersion = "1.21")
public enum ObjectPicker implements IObjectPicker {

    INSTANCE;

    @Override
    public void pick(IPickerAccessor accessor, IPickerResults results, IPluginConfig config) {
        var camera = accessor.getCameraEntity();

        if (camera == null) {
            return;
        }

        var showBlock = config.getBoolean(WailaConstants.CONFIG_SHOW_BLOCK);
        var showFluid = config.getBoolean(WailaConstants.CONFIG_SHOW_FLUID);
        var showEntity = config.getBoolean(WailaConstants.CONFIG_SHOW_ENTITY);

        if (!(showBlock || showFluid || showEntity)) {
            return;
        }

        var frameDelta = accessor.getFrameDelta();
        var maxDistance = accessor.getMaxDistance();

        var viewVec = camera.getRotationVec(frameDelta);
        var start = camera.getCameraPosVec(frameDelta);
        var end = start.add(viewVec.x * maxDistance, viewVec.y * maxDistance, viewVec.z * maxDistance);

        var world = camera.getWorld();

        if (showBlock || showFluid) {
            BlockView.raycast(start, end, Unit.INSTANCE, (unit, pos) -> {
                if (showBlock) {
                    var blockState = world.getBlockState(pos);

                    if (!blockState.isAir()) {
                        var blockShape = blockState.getOutlineShape(world, pos);
                        var blockHit = world.raycastBlock(start, end, pos.toImmutable(), blockShape, blockState);

                        if (blockHit != null) {
                            results.add(blockHit, start.squaredDistanceTo(blockHit.getPos()));
                        }
                    }
                }

                if (showFluid) {
                    var fluidState = world.getFluidState(pos);

                    if (fluidState.isStill()) {
                        var fluidShape = fluidState.getShape(world, pos);
                        var fluidHit = fluidShape.raycast(start, end, pos);

                        if (fluidHit != null) {
                            results.add(fluidHit, start.squaredDistanceTo(fluidHit.getPos()));
                        }
                    }
                }

                return null;
            }, unit -> unit);
        }

        if (showEntity) {
            var entities = camera.getWorld().getOtherEntities(camera, new Box(start, end), EntityPredicates.VALID_ENTITY);

            for (var entity : entities) {
                var bounds = entity.getBoundingBox();
                var clip = bounds.raycast(start, end).orElse(null);

                if (bounds.contains(start)) {
                    clip = Objects.requireNonNullElse(clip, start);
                }

                if (clip != null) {
                    results.add(new EntityHitResult(entity, clip), start.squaredDistanceTo(clip));
                }
            }
        }
    }

}
