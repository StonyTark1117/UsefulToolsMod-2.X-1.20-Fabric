package mcp.mobius.waila.plugin.vanilla;

import mcp.mobius.waila.api.IClientRegistrar;
import mcp.mobius.waila.api.IWailaClientPlugin;
import mcp.mobius.waila.api.data.FluidData;
import mcp.mobius.waila.plugin.vanilla.fluid.LavaDescriptor;
import mcp.mobius.waila.plugin.vanilla.fluid.WaterDescriptor;
import mcp.mobius.waila.plugin.vanilla.provider.BeaconProvider;
import mcp.mobius.waila.plugin.vanilla.provider.BeeProvider;
import mcp.mobius.waila.plugin.vanilla.provider.BeehiveProvider;
import mcp.mobius.waila.plugin.vanilla.provider.BlockAttributesProvider;
import mcp.mobius.waila.plugin.vanilla.provider.BoatProvider;
import mcp.mobius.waila.plugin.vanilla.provider.BreakProgressProvider;
import mcp.mobius.waila.plugin.vanilla.provider.ChiseledBookShelfProvider;
import mcp.mobius.waila.plugin.vanilla.provider.ComposterProvider;
import mcp.mobius.waila.plugin.vanilla.provider.EntityAttributesProvider;
import mcp.mobius.waila.plugin.vanilla.provider.FallingBlockProvider;
import mcp.mobius.waila.plugin.vanilla.provider.HorseProvider;
import mcp.mobius.waila.plugin.vanilla.provider.InfestedBlockProvider;
import mcp.mobius.waila.plugin.vanilla.provider.InvisibleEntityProvider;
import mcp.mobius.waila.plugin.vanilla.provider.ItemEntityProvider;
import mcp.mobius.waila.plugin.vanilla.provider.ItemFrameProvider;
import mcp.mobius.waila.plugin.vanilla.provider.JukeboxProvider;
import mcp.mobius.waila.plugin.vanilla.provider.MobEffectProvider;
import mcp.mobius.waila.plugin.vanilla.provider.MobTimerProvider;
import mcp.mobius.waila.plugin.vanilla.provider.NoteBlockProvider;
import mcp.mobius.waila.plugin.vanilla.provider.PandaProvider;
import mcp.mobius.waila.plugin.vanilla.provider.PetOwnerProvider;
import mcp.mobius.waila.plugin.vanilla.provider.PlantProvider;
import mcp.mobius.waila.plugin.vanilla.provider.PlayerHeadProvider;
import mcp.mobius.waila.plugin.vanilla.provider.PowderSnowProvider;
import mcp.mobius.waila.plugin.vanilla.provider.RedstoneProvider;
import mcp.mobius.waila.plugin.vanilla.provider.SpawnerProvider;
import mcp.mobius.waila.plugin.vanilla.provider.TrappedChestProvider;
import mcp.mobius.waila.plugin.vanilla.provider.VehicleProvider;
import net.minecraft.block.BeehiveBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChiseledBookshelfBlock;
import net.minecraft.block.CocoaBlock;
import net.minecraft.block.ComparatorBlock;
import net.minecraft.block.ComposterBlock;
import net.minecraft.block.CropBlock;
import net.minecraft.block.InfestedBlock;
import net.minecraft.block.LeverBlock;
import net.minecraft.block.NetherWartBlock;
import net.minecraft.block.NoteBlock;
import net.minecraft.block.PowderSnowBlock;
import net.minecraft.block.RedstoneWireBlock;
import net.minecraft.block.RepeaterBlock;
import net.minecraft.block.SaplingBlock;
import net.minecraft.block.StemBlock;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.block.TrappedChestBlock;
import net.minecraft.block.entity.BeaconBlockEntity;
import net.minecraft.block.entity.JukeboxBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Tameable;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.entity.passive.BeeEntity;
import net.minecraft.entity.passive.PandaEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.fluid.Fluids;

public class VanillaClientPlugin implements IWailaClientPlugin {

    @Override
    public void register(IClientRegistrar registrar) {
        registrar.body(BlockAttributesProvider.INSTANCE, Block.class, 950);

        registrar.icon(ItemEntityProvider.INSTANCE, ItemEntity.class);
        registrar.head(ItemEntityProvider.INSTANCE, ItemEntity.class, 950);
        registrar.body(ItemEntityProvider.INSTANCE, ItemEntity.class, 950);
        registrar.tail(ItemEntityProvider.INSTANCE, ItemEntity.class, 950);
        registrar.override(ItemEntityProvider.INSTANCE, ItemEntity.class);

        registrar.head(EntityAttributesProvider.INSTANCE, Entity.class, 950);
        registrar.body(EntityAttributesProvider.INSTANCE, Entity.class, 950);

        registrar.body(PetOwnerProvider.INSTANCE, Tameable.class);

        registrar.body(HorseProvider.INSTANCE, AbstractHorseEntity.class);

        registrar.body(PandaProvider.INSTANCE, PandaEntity.class);

        registrar.body(BeehiveProvider.INSTANCE, BeehiveBlock.class);
        registrar.body(BeeProvider.INSTANCE, BeeEntity.class);

        registrar.body(BeaconProvider.INSTANCE, BeaconBlockEntity.class);

        registrar.body(MobEffectProvider.INSTANCE, LivingEntity.class);

        registrar.body(JukeboxProvider.INSTANCE, JukeboxBlockEntity.class);

        registrar.body(MobTimerProvider.INSTANCE, PassiveEntity.class);

        registrar.override(InvisibleEntityProvider.INSTANCE, LivingEntity.class);
        registrar.override(InfestedBlockProvider.INSTANCE, InfestedBlock.class);
        registrar.override(TrappedChestProvider.INSTANCE, TrappedChestBlock.class);
        registrar.override(PowderSnowProvider.INSTANCE, PowderSnowBlock.class);
        registrar.override(VehicleProvider.INSTANCE, Entity.class, 900);

        registrar.eventListener(BreakProgressProvider.INSTANCE);

        registrar.head(SpawnerProvider.INSTANCE, MobSpawnerBlockEntity.class, 950);

        registrar.icon(PlantProvider.INSTANCE, CropBlock.class);
        registrar.body(PlantProvider.INSTANCE, CropBlock.class);
        registrar.body(PlantProvider.INSTANCE, StemBlock.class);
        registrar.body(PlantProvider.INSTANCE, CocoaBlock.class);
        registrar.body(PlantProvider.INSTANCE, NetherWartBlock.class);
        registrar.body(PlantProvider.INSTANCE, SweetBerryBushBlock.class);
        registrar.body(PlantProvider.INSTANCE, SaplingBlock.class);

        registrar.body(RedstoneProvider.INSTANCE, LeverBlock.class);
        registrar.body(RedstoneProvider.INSTANCE, RepeaterBlock.class);
        registrar.body(RedstoneProvider.INSTANCE, ComparatorBlock.class);
        registrar.body(RedstoneProvider.INSTANCE, RedstoneWireBlock.class);

        registrar.icon(PlayerHeadProvider.INSTANCE, SkullBlockEntity.class);
        registrar.body(PlayerHeadProvider.INSTANCE, SkullBlockEntity.class);

        registrar.body(ComposterProvider.INSTANCE, ComposterBlock.class);

        registrar.body(NoteBlockProvider.INSTANCE, NoteBlock.class);

        registrar.icon(FallingBlockProvider.INSTANCE, FallingBlockEntity.class);
        registrar.head(FallingBlockProvider.INSTANCE, FallingBlockEntity.class);

        registrar.head(BoatProvider.INSTANCE, BoatEntity.class, 950);
        registrar.tail(BoatProvider.INSTANCE, BoatEntity.class, 950);

        registrar.icon(ItemFrameProvider.INSTANCE, ItemFrameEntity.class);
        registrar.head(ItemFrameProvider.INSTANCE, ItemFrameEntity.class);
        registrar.body(ItemFrameProvider.INSTANCE, ItemFrameEntity.class);
        registrar.tail(ItemFrameProvider.INSTANCE, ItemFrameEntity.class);

        registrar.icon(ChiseledBookShelfProvider.INSTANCE, ChiseledBookshelfBlock.class);
        registrar.head(ChiseledBookShelfProvider.INSTANCE, ChiseledBookshelfBlock.class);
        registrar.body(ChiseledBookShelfProvider.INSTANCE, ChiseledBookshelfBlock.class);
        registrar.tail(ChiseledBookShelfProvider.INSTANCE, ChiseledBookshelfBlock.class);

        FluidData.describeFluid(Fluids.WATER, WaterDescriptor.INSTANCE);
        FluidData.describeFluid(Fluids.LAVA, LavaDescriptor.INSTANCE);
        FluidData.describeCauldron(Blocks.WATER_CAULDRON, WaterDescriptor.INSTANCE);
        FluidData.describeCauldron(Blocks.LAVA_CAULDRON, LavaDescriptor.INSTANCE);
    }

}
