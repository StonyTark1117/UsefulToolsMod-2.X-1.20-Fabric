package mcp.mobius.waila.gui.hud;

import Z;
import java.util.List;
import java.util.Objects;
import java.util.function.ObjDoubleConsumer;

import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.config.PluginConfig;
import net.minecraft.entity.Entity;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.util.Unit;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

public class RayCaster {

    public static void cast(World world, Entity camera, Vec3d origin, Vec3d direction, float maxDistance, ObjDoubleConsumer<HitResult> results) {
        var showBlock = PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_BLOCK);
        var showFluid = PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_FLUID);
        var showEntity = PluginConfig.CLIENT.getBoolean(WailaConstants.CONFIG_SHOW_ENTITY);

        var max = origin.add(direction.x * maxDistance, direction.y * maxDistance, direction.z * maxDistance);

        if (showBlock || showFluid) {
            BlockView.raycast(origin, max, Unit.INSTANCE, (unit, pos) -> {
                if (showBlock) {
                    var blockState = world.getBlockState(pos);

                    if (!blockState.isAir()) {
                        var blockShape = blockState.getOutlineShape(world, pos);
                        var blockHit = world.raycastBlock(origin, max, pos.toImmutable(), blockShape, blockState);

                        if (blockHit != null) {
                            results.accept(blockHit, origin.squaredDistanceTo(blockHit.getPos()));
                        }
                    }
                }

                if (showFluid) {
                    var fluidState = world.getFluidState(pos);

                    if (fluidState.isStill()) {
                        var fluidShape = fluidState.getShape(world, pos);
                        var fluidHit = fluidShape.raycast(origin, max, pos.toImmutable());

                        if (fluidHit != null) {
                            results.accept(fluidHit, origin.squaredDistanceTo(fluidHit.getPos()));
                        }
                    }
                }

                return null;
            }, unit -> unit);
        }

        if (showEntity) {
            var entities = world.getOtherEntities(camera, new Box(origin, max), EntityPredicates.VALID_ENTITY);

            for (var entity : entities) {
                var bounds = entity.getBoundingBox();
                var clip = bounds.raycast(origin, max).orElse(null);

                if (bounds.contains(origin)) {
                    clip = Objects.requireNonNullElse(clip, origin);
                }

                if (clip != null) {
                    results.accept(new EntityHitResult(entity, clip), origin.squaredDistanceTo(clip));
                }
            }
        }
    }

}
