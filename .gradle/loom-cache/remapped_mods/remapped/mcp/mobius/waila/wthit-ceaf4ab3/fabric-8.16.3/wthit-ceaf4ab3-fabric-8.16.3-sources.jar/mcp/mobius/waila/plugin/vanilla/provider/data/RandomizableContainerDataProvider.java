package mcp.mobius.waila.plugin.vanilla.provider.data;

import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.data.ItemData;
import mcp.mobius.waila.mixin.RandomizableContainerBlockEntityAccess;
import net.minecraft.block.entity.LootableContainerBlockEntity;

public enum RandomizableContainerDataProvider implements IDataProvider<LootableContainerBlockEntity> {

    INSTANCE;

    @Override
    public void appendData(IDataWriter data, IServerAccessor<LootableContainerBlockEntity> accessor, IPluginConfig config) {
        if (((RandomizableContainerBlockEntityAccess) accessor.getTarget()).wthit_lootTable() != null) {
            data.blockAll(ItemData.class);
        }
    }

}
