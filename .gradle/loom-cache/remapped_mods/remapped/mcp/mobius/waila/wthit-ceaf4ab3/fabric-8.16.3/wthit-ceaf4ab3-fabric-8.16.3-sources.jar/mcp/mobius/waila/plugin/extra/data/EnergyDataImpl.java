package mcp.mobius.waila.plugin.extra.data;

import java.util.HashMap;
import java.util.Map;

import mcp.mobius.waila.api.data.EnergyData;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;

public class EnergyDataImpl extends EnergyData {

    private final double stored;
    private final double capacity;

    public EnergyDataImpl(double stored, double capacity) {
        this.stored = stored;
        this.capacity = capacity;
    }

    public EnergyDataImpl(PacketByteBuf buf) {
        this.stored = buf.readDouble();
        this.capacity = buf.readDouble();
    }

    @Override
    public void write(PacketByteBuf buf) {
        buf.writeDouble(stored);
        buf.writeDouble(capacity);
    }

    public double stored() {
        return stored;
    }

    public double capacity() {
        return capacity;
    }

    public static class Description implements EnergyData.Description {

        public static final Map<String, mcp.mobius.waila.plugin.extra.data.EnergyDataImpl.Description> MAP = new HashMap<>();
        private static final mcp.mobius.waila.plugin.extra.data.EnergyDataImpl.Description DEFAULT = new mcp.mobius.waila.plugin.extra.data.EnergyDataImpl.Description();

        private Text name = DEFAULT_NAME;
        private int color = DEFAULT_COLOR;
        private String unit = DEFAULT_UNIT;

        public static mcp.mobius.waila.plugin.extra.data.EnergyDataImpl.Description get(String namespace) {
            return MAP.getOrDefault(namespace, DEFAULT);
        }

        public Text name() {
            return name;
        }

        public int color() {
            return color;
        }

        public String unit() {
            return unit;
        }

        @Override
        public mcp.mobius.waila.plugin.extra.data.EnergyDataImpl.Description name(Text name) {
            this.name = name;
            return this;
        }

        @Override
        public mcp.mobius.waila.plugin.extra.data.EnergyDataImpl.Description color(int color) {
            this.color = color & 0xFFFFFF;
            return this;
        }

        @Override
        public mcp.mobius.waila.plugin.extra.data.EnergyDataImpl.Description unit(String unit) {
            this.unit = unit;
            return this;
        }

    }

}
