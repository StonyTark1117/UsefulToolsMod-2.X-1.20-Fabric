package mcp.mobius.waila.fabric;

import mcp.mobius.waila.command.ServerCommand;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("UnstableApiUsage")
public class FabricServerCommand extends ServerCommand {

    @Override
    protected @Nullable String fillContainer(ServerWorld world, BlockPos pos, ServerPlayerEntity player) {
        var storage = ItemStorage.SIDED.find(world, pos, Direction.UP);
        if (storage == null) return "No storage at " + pos.toShortString();

        try (var tx = Transaction.openOuter()) {
            while (true) {
                var offHandStack = player.getOffHandStack();
                var item = !offHandStack.isEmpty()
                    ? offHandStack.getItem()
                    : Registries.ITEM.getRandom(world.random).orElseThrow().value();

                if (storage.insert(ItemVariant.of(item), item.getMaxCount(), tx) == 0L) break;
            }
            tx.commit();
            return null;
        }
    }

}
