package mcp.mobius.waila.plugin.vanilla;

import mcp.mobius.waila.api.IRegistrar;
import mcp.mobius.waila.api.IWailaPlugin;
import mcp.mobius.waila.api.IntFormat;
import mcp.mobius.waila.plugin.vanilla.config.NoteDisplayMode;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import mcp.mobius.waila.plugin.vanilla.provider.BeehiveProvider;
import mcp.mobius.waila.plugin.vanilla.provider.BlockAttributesProvider;
import mcp.mobius.waila.plugin.vanilla.provider.BoatProvider;
import mcp.mobius.waila.plugin.vanilla.provider.BreakProgressProvider;
import mcp.mobius.waila.plugin.vanilla.provider.ComposterProvider;
import mcp.mobius.waila.plugin.vanilla.provider.EntityAttributesProvider;
import mcp.mobius.waila.plugin.vanilla.provider.FallingBlockProvider;
import mcp.mobius.waila.plugin.vanilla.provider.FurnaceProvider;
import mcp.mobius.waila.plugin.vanilla.provider.HorseProvider;
import mcp.mobius.waila.plugin.vanilla.provider.InfestedBlockProvider;
import mcp.mobius.waila.plugin.vanilla.provider.InvisibleEntityProvider;
import mcp.mobius.waila.plugin.vanilla.provider.ItemEntityProvider;
import mcp.mobius.waila.plugin.vanilla.provider.ItemFrameProvider;
import mcp.mobius.waila.plugin.vanilla.provider.JukeboxProvider;
import mcp.mobius.waila.plugin.vanilla.provider.MobTimerProvider;
import mcp.mobius.waila.plugin.vanilla.provider.NoteBlockProvider;
import mcp.mobius.waila.plugin.vanilla.provider.PetOwnerProvider;
import mcp.mobius.waila.plugin.vanilla.provider.PlantProvider;
import mcp.mobius.waila.plugin.vanilla.provider.PlayerHeadProvider;
import mcp.mobius.waila.plugin.vanilla.provider.PowderSnowProvider;
import mcp.mobius.waila.plugin.vanilla.provider.RedstoneProvider;
import mcp.mobius.waila.plugin.vanilla.provider.SpawnerProvider;
import mcp.mobius.waila.plugin.vanilla.provider.TrappedChestProvider;
import mcp.mobius.waila.plugin.vanilla.provider.VehicleProvider;
import net.minecraft.block.BeehiveBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.CocoaBlock;
import net.minecraft.block.ComparatorBlock;
import net.minecraft.block.ComposterBlock;
import net.minecraft.block.CropBlock;
import net.minecraft.block.InfestedBlock;
import net.minecraft.block.LeverBlock;
import net.minecraft.block.NetherWartBlock;
import net.minecraft.block.NoteBlock;
import net.minecraft.block.PowderSnowBlock;
import net.minecraft.block.RedstoneWireBlock;
import net.minecraft.block.RepeaterBlock;
import net.minecraft.block.StemBlock;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.block.TrappedChestBlock;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.JukeboxBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Tameable;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.vehicle.BoatEntity;

import static mcp.mobius.waila.api.TooltipPosition.BODY;
import static mcp.mobius.waila.api.TooltipPosition.HEAD;
import static mcp.mobius.waila.api.TooltipPosition.TAIL;

public class WailaVanilla implements IWailaPlugin {

    @Override
    public void register(IRegistrar registrar) {
        registrar.addMergedConfig(Options.ITEM_ENTITY, true);
        registrar.addIcon(ItemEntityProvider.INSTANCE, ItemEntity.class);
        registrar.addComponent(ItemEntityProvider.INSTANCE, HEAD, ItemEntity.class, 950);
        registrar.addComponent(ItemEntityProvider.INSTANCE, TAIL, ItemEntity.class, 950);
        registrar.addOverride(ItemEntityProvider.INSTANCE, ItemEntity.class);

        registrar.addMergedSyncedConfig(Options.PET_OWNER, true, false);
        registrar.addConfig(Options.PET_HIDE_UNKNOWN_OWNER, false);
        registrar.addComponent(PetOwnerProvider.INSTANCE, BODY, Tameable.class);
        registrar.addEntityData(PetOwnerProvider.INSTANCE, Tameable.class);

        registrar.addConfig(Options.ATTRIBUTE_BLOCK_POSITION, false);
        registrar.addConfig(Options.ATTRIBUTE_BLOCK_STATE, false);
        registrar.addConfig(Options.ATTRIBUTE_ENTITY_POSITION, false);
        registrar.addMergedConfig(Options.ATTRIBUTE_HEALTH, true);
        registrar.addMergedSyncedConfig(Options.ATTRIBUTE_ABSORPTION, true, false);
        registrar.addMergedConfig(Options.ATTRIBUTE_ARMOR, true);
        registrar.addConfig(Options.ATTRIBUTE_COMPACT, false);
        registrar.addConfig(Options.ATTRIBUTE_ICON_PER_LINE, 25);
        registrar.addConfig(Options.ATTRIBUTE_LONG_HEALTH_MAX, 100);
        registrar.addConfig(Options.ATTRIBUTE_LONG_ARMOR_MAX, 100);
        registrar.addMergedConfig(Options.ATTRUBUTE_HORSE_JUMP_HEIGHT, true);
        registrar.addMergedConfig(Options.ATTRUBUTE_HORSE_SPEED, true);
        registrar.addComponent(BlockAttributesProvider.INSTANCE, BODY, Block.class, 950);
        registrar.addComponent(EntityAttributesProvider.INSTANCE, HEAD, Entity.class, 950);
        registrar.addComponent(EntityAttributesProvider.INSTANCE, BODY, Entity.class, 950);
        registrar.addComponent(HorseProvider.INSTANCE, BODY, AbstractHorseEntity.class);
        registrar.addEntityData(EntityAttributesProvider.INSTANCE, Entity.class);

        registrar.addMergedSyncedConfig(Options.FURNACE_CONTENTS, true, false);
        registrar.addComponent(FurnaceProvider.INSTANCE, BODY, AbstractFurnaceBlockEntity.class);
        registrar.addBlockData(FurnaceProvider.INSTANCE, AbstractFurnaceBlockEntity.class);

        registrar.addMergedSyncedConfig(Options.JUKEBOX_RECORD, true, false);
        registrar.addComponent(JukeboxProvider.INSTANCE, BODY, JukeboxBlockEntity.class);
        registrar.addBlockData(JukeboxProvider.INSTANCE, JukeboxBlockEntity.class);

        registrar.addMergedSyncedConfig(Options.TIMER_GROW, true, false);
        registrar.addMergedSyncedConfig(Options.TIMER_BREED, true, false);
        registrar.addComponent(MobTimerProvider.INSTANCE, BODY, PassiveEntity.class);
        registrar.addEntityData(MobTimerProvider.INSTANCE, PassiveEntity.class);

        registrar.addMergedConfig(Options.OVERRIDE_INVISIBLE_ENTITY, true);
        registrar.addMergedConfig(Options.OVERRIDE_TRAPPED_CHEST, true);
        registrar.addMergedConfig(Options.OVERRIDE_POWDER_SNOW, true);
        registrar.addMergedConfig(Options.OVERRIDE_INFESTED, true);
        registrar.addConfig(Options.OVERRIDE_VEHICLE, true);
        registrar.addOverride(InvisibleEntityProvider.INSTANCE, LivingEntity.class);
        registrar.addOverride(InfestedBlockProvider.INSTANCE, InfestedBlock.class);
        registrar.addOverride(TrappedChestProvider.INSTANCE, TrappedChestBlock.class);
        registrar.addOverride(PowderSnowProvider.INSTANCE, PowderSnowBlock.class);
        registrar.addOverride(VehicleProvider.INSTANCE, Entity.class, 900);

        registrar.addMergedConfig(Options.BREAKING_PROGRESS, true);
        registrar.addConfig(Options.BREAKING_PROGRESS_COLOR, 0xAAFFFFFF, IntFormat.ARGB_HEX);
        registrar.addConfig(Options.BREAKING_PROGRESS_BOTTOM_ONLY, false);
        registrar.addEventListener(BreakProgressProvider.INSTANCE);

        registrar.addMergedConfig(Options.SPAWNER_TYPE, true);
        registrar.addComponent(SpawnerProvider.INSTANCE, HEAD, MobSpawnerBlockEntity.class, 950);

        registrar.addMergedConfig(Options.CROP_PROGRESS, true);
        registrar.addIcon(PlantProvider.INSTANCE, CropBlock.class);
        registrar.addComponent(PlantProvider.INSTANCE, BODY, CropBlock.class);
        registrar.addComponent(PlantProvider.INSTANCE, BODY, StemBlock.class);
        registrar.addComponent(PlantProvider.INSTANCE, BODY, CocoaBlock.class);
        registrar.addComponent(PlantProvider.INSTANCE, BODY, NetherWartBlock.class);
        registrar.addComponent(PlantProvider.INSTANCE, BODY, SweetBerryBushBlock.class);

        registrar.addMergedConfig(Options.REDSTONE_LEVER, true);
        registrar.addMergedConfig(Options.REDSTONE_REPEATER, true);
        registrar.addMergedConfig(Options.REDSTONE_COMPARATOR, true);
        registrar.addMergedConfig(Options.REDSTONE_LEVEL, true);
        registrar.addComponent(RedstoneProvider.INSTANCE, BODY, LeverBlock.class);
        registrar.addComponent(RedstoneProvider.INSTANCE, BODY, RepeaterBlock.class);
        registrar.addComponent(RedstoneProvider.INSTANCE, BODY, ComparatorBlock.class);
        registrar.addComponent(RedstoneProvider.INSTANCE, BODY, RedstoneWireBlock.class);

        registrar.addMergedConfig(Options.PLAYER_HEAD_NAME, true);
        registrar.addIcon(PlayerHeadProvider.INSTANCE, SkullBlockEntity.class);
        registrar.addComponent(PlayerHeadProvider.INSTANCE, BODY, SkullBlockEntity.class);

        registrar.addMergedConfig(Options.LEVEL_COMPOSTER, true);
        registrar.addMergedConfig(Options.LEVEL_HONEY, true);
        registrar.addComponent(ComposterProvider.INSTANCE, BODY, ComposterBlock.class);
        registrar.addComponent(BeehiveProvider.INSTANCE, BODY, BeehiveBlock.class);

        registrar.addMergedConfig(Options.NOTE_BLOCK_TYPE, true);
        registrar.addConfig(Options.NOTE_BLOCK_NOTE, NoteDisplayMode.SHARP);
        registrar.addConfig(Options.NOTE_BLOCK_INT_VALUE, false);
        registrar.addComponent(NoteBlockProvider.INSTANCE, BODY, NoteBlock.class);

        registrar.addIcon(FallingBlockProvider.INSTANCE, FallingBlockEntity.class);
        registrar.addComponent(FallingBlockProvider.INSTANCE, HEAD, FallingBlockEntity.class);

        registrar.addComponent(BoatProvider.INSTANCE, HEAD, BoatEntity.class, 950);
        registrar.addComponent(BoatProvider.INSTANCE, TAIL, BoatEntity.class, 950);

        registrar.addIcon(ItemFrameProvider.INSTANCE, ItemFrameEntity.class);
        registrar.addComponent(ItemFrameProvider.INSTANCE, HEAD, ItemFrameEntity.class);
        registrar.addComponent(ItemFrameProvider.INSTANCE, TAIL, ItemFrameEntity.class);

        registrar.addBlacklist(
            Blocks.BARRIER,
            Blocks.STRUCTURE_VOID);

        registrar.addBlacklist(
            EntityType.AREA_EFFECT_CLOUD,
            EntityType.EXPERIENCE_ORB,
            EntityType.FIREBALL,
            EntityType.FIREWORK_ROCKET,
            EntityType.INTERACTION,
            EntityType.SNOWBALL);
    }

}
