package mcp.mobius.waila.gui.screen;

import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.buildconst.Tl;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import org.jetbrains.annotations.NotNull;

import static mcp.mobius.waila.util.DisplayUtil.createButton;

public class HomeScreen extends Screen {

    private final Screen parent;

    public HomeScreen(Screen parent) {
        super(Text.literal(WailaConstants.MOD_NAME));

        this.parent = parent;
    }

    @Override
    @SuppressWarnings("ConstantConditions")
    protected void init() {
        addDrawableChild(createButton(width / 2 - 100, height / 2 - 48, 200, 20, Text.translatable(Tl.Gui.WAILA_SETTINGS, WailaConstants.MOD_NAME), w ->
            client.setScreen(new WailaConfigScreen(this))));
        addDrawableChild(createButton(width / 2 - 100, height / 2 - 24, 200, 20, Text.translatable(Tl.Gui.PLUGIN_SETTINGS), w ->
            client.setScreen(new PluginConfigScreen(this))));
        addDrawableChild(createButton(width / 2 - 100, height / 2, 200, 20, Text.translatable(Tl.Gui.CREDITS), w ->
            client.setScreen(new CreditsScreen(this))));
        addDrawableChild(createButton(width / 2 - 50, height / 2 + 24, 100, 20, ScreenTexts.DONE, w ->
            client.setScreen(parent)));
    }

    @Override
    public void method_25394(@NotNull MatrixStack matrices, int x, int y, float partialTicks) {
        renderBackground(matrices);
        method_25300(matrices, textRenderer, title.getString(), width / 2, height / 2 - 50 - textRenderer.fontHeight, 0xFFFFFF);
        super.render(matrices, x, y, partialTicks);
    }

}
