package mcp.mobius.waila.access;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.ICommonAccessor;
import mcp.mobius.waila.api.IDataReader;
import mcp.mobius.waila.api.IEntityAccessor;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public enum DataAccessor implements ICommonAccessor, IBlockAccessor, IEntityAccessor {

    INSTANCE;

    private World world;
    private PlayerEntity player;
    private HitResult hitResult;
    private Vec3d renderingVec = null;
    private Block block = Blocks.AIR;
    private BlockState state = Blocks.AIR.getDefaultState();
    private BlockPos pos = BlockPos.ORIGIN;
    private Identifier blockRegistryName = Registries.ITEM.getDefaultId();
    private BlockEntity blockEntity;
    private Entity entity;
    private long timeLastUpdate = System.currentTimeMillis();
    private double partialFrame;
    private ItemStack stack = ItemStack.EMPTY;

    @Override
    public World getWorld() {
        return this.world;
    }

    @Override
    public PlayerEntity getPlayer() {
        return this.player;
    }

    @Override
    public Block getBlock() {
        return this.block;
    }

    @Override
    public BlockState getBlockState() {
        return this.state;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends BlockEntity> T getBlockEntity() {
        return (T) this.blockEntity;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends Entity> T getEntity() {
        return (T) this.entity;
    }

    public void setEntity(Entity entity) {
        this.entity = entity;
    }

    @Override
    public BlockPos getPosition() {
        return this.pos;
    }

    @Override
    public HitResult getHitResult() {
        return this.hitResult;
    }

    @Override
    public Vec3d getRenderingPosition() {
        return this.renderingVec;
    }

    @Override
    @SuppressWarnings("removal")
    public NbtCompound getServerData() {
        return getData().raw();
    }

    @Override
    public IDataReader getData() {
        DataReader data = DataReader.INSTANCE;
        if (!isTagCorrectBlockEntity() && !isTagCorrectEntity()) data.reset(null);
        return data;
    }

    @Override
    public long getServerDataTime() {
        NbtCompound data = getData().raw();
        return data.contains("WailaTime") ? data.getLong("WailaTime") : System.currentTimeMillis();
    }

    @Override
    public double getPartialFrame() {
        return this.partialFrame;
    }

    @Override
    public Direction getSide() {
        return hitResult == null ? null : hitResult.getType() == HitResult.Type.ENTITY ? null : ((BlockHitResult) hitResult).getSide();
    }

    @Override
    public ItemStack getStack() {
        return this.stack;
    }

    @Override
    public Identifier getBlockId() {
        return blockRegistryName;
    }

    public void set(World world, PlayerEntity player, HitResult hit, Entity viewEntity, double partialTicks) {
        this.world = world;
        this.player = player;
        this.hitResult = hit;

        if (this.hitResult.getType() == HitResult.Type.BLOCK) {
            this.pos = ((BlockHitResult) hit).getBlockPos();
            this.blockEntity = this.world.getBlockEntity(this.pos);
            this.entity = null;
            setState(world.getBlockState(pos));
        } else if (this.hitResult.getType() == HitResult.Type.ENTITY) {
            this.entity = ((EntityHitResult) hit).getEntity();
            this.pos = entity.getBlockPos();
            this.blockEntity = null;
            setState(Blocks.AIR.getDefaultState());
        }

        if (viewEntity != null) {
            double px = viewEntity.prevX + (viewEntity.getX() - viewEntity.prevX) * partialTicks;
            double py = viewEntity.prevY + (viewEntity.getY() - viewEntity.prevY) * partialTicks;
            double pz = viewEntity.prevZ + (viewEntity.getZ() - viewEntity.prevZ) * partialTicks;
            this.renderingVec = new Vec3d(this.pos.getX() - px, this.pos.getY() - py, this.pos.getZ() - pz);
            this.partialFrame = partialTicks;
        }
    }

    public void setState(BlockState state) {
        this.state = state;
        this.block = state.getBlock();
        this.stack = block.getPickStack(world, pos, state);
        this.blockRegistryName = Registries.BLOCK.getId(block);
    }

    private boolean isTagCorrectBlockEntity() {
        if (blockEntity == null) return false;

        NbtCompound tag = DataReader.INSTANCE.raw();

        if (tag == null) {
            this.timeLastUpdate = System.currentTimeMillis() - 250;
            return false;
        }

        int x = tag.getInt("x");
        int y = tag.getInt("y");
        int z = tag.getInt("z");

        BlockPos hitPos = ((BlockHitResult) hitResult).getBlockPos();
        if (x == hitPos.getX() && y == hitPos.getY() && z == hitPos.getZ())
            return true;
        else {
            this.timeLastUpdate = System.currentTimeMillis() - 250;
            return false;
        }
    }

    private boolean isTagCorrectEntity() {
        if (entity == null) return false;

        NbtCompound tag = DataReader.INSTANCE.raw();

        if (tag == null || !tag.contains("WailaEntityID")) {
            this.timeLastUpdate = System.currentTimeMillis() - 250;
            return false;
        }

        int id = tag.getInt("WailaEntityID");

        if (id == this.entity.getId())
            return true;
        else {
            this.timeLastUpdate = System.currentTimeMillis() - 250;
            return false;
        }
    }

    public boolean isTimeElapsed(long time) {
        return System.currentTimeMillis() - this.timeLastUpdate >= time;
    }

    public void resetTimer() {
        this.timeLastUpdate = System.currentTimeMillis();
    }

}
