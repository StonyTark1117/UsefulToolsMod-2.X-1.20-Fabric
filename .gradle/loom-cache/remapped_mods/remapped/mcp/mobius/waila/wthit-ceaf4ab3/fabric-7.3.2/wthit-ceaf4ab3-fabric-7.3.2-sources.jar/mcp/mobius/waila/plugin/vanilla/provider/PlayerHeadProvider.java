package mcp.mobius.waila.plugin.vanilla.provider;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.component.ItemComponent;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.text.Text;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Nullable;

public enum PlayerHeadProvider implements IBlockComponentProvider {

    INSTANCE;

    static final ItemComponent PLAYER_HEAD_STACK = new ItemComponent(Items.PLAYER_HEAD);

    @Nullable
    @Override
    public ITooltipComponent getIcon(IBlockAccessor accessor, IPluginConfig config) {
        SkullBlockEntity skull = accessor.getBlockEntity();
        if (skull != null && skull.getOwner() != null) {
            NbtCompound tag = PLAYER_HEAD_STACK.stack.getOrCreateNbt();
            NbtCompound skullOwner = tag.getCompound("SkullOwner");
            tag.put("SkullOwner", NbtHelper.writeGameProfile(skullOwner, skull.getOwner()));
            return PLAYER_HEAD_STACK;
        }
        return null;
    }

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(Options.PLAYER_HEAD_NAME)) {
            SkullBlockEntity skull = accessor.getBlockEntity();
            if (skull != null && skull.getOwner() != null && !StringUtils.isBlank(skull.getOwner().getName())) {
                tooltip.addLine(Text.translatable(skull.getOwner().getName()));
            }
        }
    }

}
