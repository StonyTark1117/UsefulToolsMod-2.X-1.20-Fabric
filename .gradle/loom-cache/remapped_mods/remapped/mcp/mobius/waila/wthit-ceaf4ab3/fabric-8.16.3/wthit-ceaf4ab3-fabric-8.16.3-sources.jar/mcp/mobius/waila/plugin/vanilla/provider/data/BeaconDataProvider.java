package mcp.mobius.waila.plugin.vanilla.provider.data;

import mcp.mobius.waila.api.IData;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.mixin.BeaconBlockEntityAccess;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.block.entity.BeaconBlockEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public enum BeaconDataProvider implements IDataProvider<BeaconBlockEntity> {

    INSTANCE;

    public static final Identifier DATA = new Identifier("beacon");

    @Override
    public void appendData(IDataWriter data, IServerAccessor<BeaconBlockEntity> accessor, IPluginConfig config) {
        if (config.getBoolean(Options.EFFECT_BEACON)) data.add(Data.class, res -> {
            var beacon = (BeaconBlockEntity & BeaconBlockEntityAccess) accessor.getTarget();
            res.add(new Data(beacon.wthit_primaryPower(), beacon.wthit_levels() >= 4 ? beacon.wthit_secondaryPower() : null));
        });
    }

    public record Data(
        @Nullable StatusEffect primary,
        @Nullable StatusEffect secondary
    ) implements IData {

        public Data(PacketByteBuf buf) {
            this(
                buf.readNullable(b -> b.readRegistryValue(Registries.STATUS_EFFECT)),
                buf.readNullable(b -> b.readRegistryValue(Registries.STATUS_EFFECT)));
        }

        @Override
        public void write(PacketByteBuf buf) {
            buf.writeNullable(primary, (b, m) -> b.writeRegistryValue(Registries.STATUS_EFFECT, m));
            buf.writeNullable(secondary, (b, m) -> b.writeRegistryValue(Registries.STATUS_EFFECT, m));
        }

    }

}
