package mcp.mobius.waila.plugin.vanilla.provider;

import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.component.PairComponent;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeverBlock;
import net.minecraft.block.enums.ComparatorMode;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;

public enum RedstoneProvider implements IBlockComponentProvider {

    INSTANCE;

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(Options.REDSTONE_LEVER) && accessor.getBlock() instanceof LeverBlock) {
            boolean active = accessor.getBlockState().get(Properties.POWERED);
            tooltip.addLine(new PairComponent(
                Text.translatable(Tl.Tooltip.STATE),
                Text.translatable(active ? Tl.Tooltip.STATE_ON : Tl.Tooltip.STATE_OFF)));
            return;
        }

        if (config.getBoolean(Options.REDSTONE_REPEATER) && accessor.getBlock() == Blocks.REPEATER) {
            int delay = accessor.getBlockState().get(Properties.DELAY);
            tooltip.addLine(new PairComponent(
                Text.translatable(Tl.Tooltip.DELAY),
                Text.literal(String.valueOf(delay))));
            return;
        }

        if (config.getBoolean(Options.REDSTONE_COMPARATOR) && accessor.getBlock() == Blocks.COMPARATOR) {
            ComparatorMode mode = accessor.getBlockState().get(Properties.COMPARATOR_MODE);
            tooltip.addLine(new PairComponent(
                Text.translatable(Tl.Tooltip.MODE),
                Text.translatable(mode == ComparatorMode.COMPARE ? Tl.Tooltip.MODE_COMPARATOR : Tl.Tooltip.MODE_SUBTRACTOR)));
            return;
        }

        if (config.getBoolean(Options.REDSTONE_LEVEL) && accessor.getBlock() == Blocks.REDSTONE_WIRE) {
            tooltip.addLine(new PairComponent(
                Text.translatable(Tl.Tooltip.POWER),
                Text.literal(accessor.getBlockState().get(Properties.POWER).toString())));
        }
    }

}
