package mcp.mobius.waila.mixin;

import net.minecraft.client.gui.hud.PlayerListHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(PlayerListHud.class)
public interface PlayerTabOverlayAccess {

    @Accessor("visible")
    boolean wthit_isVisible();

}
