package mcp.mobius.waila.plugin.vanilla.provider;

import F;
import I;
import Z;
import java.text.DecimalFormat;

import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IEntityAccessor;
import mcp.mobius.waila.api.IEntityComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.ITooltipLine;
import mcp.mobius.waila.api.WailaHelper;
import mcp.mobius.waila.api.component.ArmorComponent;
import mcp.mobius.waila.api.component.HealthComponent;
import mcp.mobius.waila.api.component.PositionComponent;
import mcp.mobius.waila.api.component.SpacingComponent;
import mcp.mobius.waila.api.component.TextureComponent;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.entity.LivingEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public enum EntityAttributesProvider implements IEntityComponentProvider {

    INSTANCE;

    private static final DecimalFormat DECIMAL = new DecimalFormat("0.##");

    private int addSpacing(ITooltipLine line, int i) {
        if (i > 0) {
            line.with(new SpacingComponent(3, 0));
            return i - 1;
        }
        return 0;
    }

    private void addHealth(ITooltipLine line, LivingEntity entity, NbtCompound data, boolean showAbsorption) {
        var component = Text.literal(DECIMAL.format(entity.getHealth()));
        if (showAbsorption && data.contains("abs")) {
            component.append(Text.literal("+" + DECIMAL.format(data.getFloat("abs"))).formatted(Formatting.GOLD));
        }
        line.with(new TextureComponent(WailaHelper.GUI_ICONS_TEXTURE, 8, 8, 52, 0, 9, 9, 256, 256))
            .with(component.append("/" + DECIMAL.format(entity.getMaxHealth())).formatted(Formatting.RED));
    }

    private void addArmor(ITooltipLine line, LivingEntity entity) {
        line.with(new TextureComponent(WailaHelper.GUI_ICONS_TEXTURE, 8, 8, 34, 9, 9, 9, 256, 256))
            .with(Text.literal(String.valueOf(entity.getArmor())));
    }

    @Override
    @SuppressWarnings("UnusedAssignment")
    public void appendHead(ITooltip tooltip, IEntityAccessor accessor, IPluginConfig config) {
        if (!(accessor.getEntity() instanceof LivingEntity entity)) {
            return;
        }

        var compact = config.getBoolean(Options.ENTITY_COMPACT);
        var showHealth = config.getBoolean(Options.ENTITY_HEALTH);
        var showAbsorption = config.getBoolean(Options.ENTITY_ABSORPTION);
        var showArmor = config.getBoolean(Options.ENTITY_ARMOR) && entity.getArmor() > 0;

        var data = accessor.getData().raw();

        if (compact) {
            var line = tooltip.setLine(Options.ENTITY_COMPACT);
            var i = 0;

            if (showHealth) {
                i = addSpacing(line, i);
                addHealth(line, entity, data, showAbsorption);
                i++;
            }

            if (showArmor) {
                i = addSpacing(line, i);
                addArmor(line, entity);
                i++;
            }
        } else {
            var maxPerLine = config.getInt(Options.ENTITY_ICON_PER_LINE);

            if (showHealth) {
                var line = tooltip.setLine(Options.ENTITY_HEALTH);
                var absorption = data.contains("abs") ? data.getFloat("abs") : 0f;
                if (entity.getMaxHealth() + absorption > config.getInt(Options.ENTITY_LONG_HEALTH_MAX)) {
                    addHealth(line, entity, data, showAbsorption);
                } else {
                    line.with(new HealthComponent(entity.getHealth(), entity.getMaxHealth(), maxPerLine, false));
                    if (showAbsorption && absorption > 0) {
                        line.with(new HealthComponent(absorption, 0, maxPerLine, true));
                    }
                }
            }

            if (showArmor) {
                var line = tooltip.setLine(Options.ENTITY_ARMOR);
                if (entity.getArmor() > config.getInt(Options.ENTITY_LONG_ARMOR_MAX)) {
                    addArmor(line, entity);
                } else {
                    line.with(new ArmorComponent(entity.getArmor(), maxPerLine));
                }
            }
        }
    }

    @Override
    public void appendBody(ITooltip tooltip, IEntityAccessor accessor, IPluginConfig config) {
        if (config.getBoolean(Options.ENTITY_POSITION)) {
            tooltip.setLine(Options.ENTITY_POSITION, new PositionComponent(accessor.getEntity().getPos()));
        }
    }

}
