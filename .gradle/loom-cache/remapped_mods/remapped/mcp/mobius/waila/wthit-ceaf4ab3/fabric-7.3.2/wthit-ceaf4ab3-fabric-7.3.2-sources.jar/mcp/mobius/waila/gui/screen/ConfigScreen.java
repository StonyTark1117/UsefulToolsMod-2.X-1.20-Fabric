package mcp.mobius.waila.gui.screen;

import java.util.List;
import mcp.mobius.waila.gui.widget.ConfigListWidget;
import mcp.mobius.waila.gui.widget.value.ConfigValue;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import org.jetbrains.annotations.NotNull;

import static mcp.mobius.waila.util.DisplayUtil.createButton;

public abstract class ConfigScreen extends Screen {

    private final Screen parent;
    private final Runnable saver;
    private final Runnable canceller;

    @SuppressWarnings("unchecked")
    private final List<Element> children = (List<Element>) children();
    private ConfigListWidget options;

    protected boolean cancelled;

    public ConfigScreen(Screen parent, Text title, Runnable saver, Runnable canceller) {
        super(title);

        this.parent = parent;
        this.saver = saver;
        this.canceller = canceller;
    }

    public ConfigScreen(Screen parent, Text title) {
        this(parent, title, null, null);
    }

    @Override
    public void init() {
        super.init();

        if (options == null) {
            options = getOptions();
        }

        TextFieldWidget searchBox = options.getSearchBox();
        if (searchBox.isNarratable()) addSelectableChild(searchBox);

        addSelectableChild(options);
        options.init();

        if (saver != null && canceller != null) {
            addDrawableChild(createButton(width / 2 - 102, height - 25, 100, 20, ScreenTexts.DONE, w -> {
                if (options.save(false)) {
                    saver.run();
                    close();
                }
            }));
            addDrawableChild(createButton(width / 2 + 2, height - 25, 100, 20, ScreenTexts.CANCEL, w -> {
                cancelled = true;
                canceller.run();
                close();
            }));
        } else {
            addDrawableChild(createButton(width / 2 - 50, height - 25, 100, 20, ScreenTexts.DONE, w -> {
                if (options.save(false)) {
                    close();
                }
            }));
        }

        if (searchBox.isNarratable()) setInitialFocus(searchBox);
    }

    protected void renderForeground(MatrixStack matrices, int rowLeft, int rowWidth, int mouseX, int mouseY, float partialTicks) {
        method_27535(matrices, textRenderer, title, rowLeft, 12, 0xFFFFFF);
    }

    @Override
    public void tick() {
        options.tick();
    }

    @Override
    public void method_25394(@NotNull MatrixStack matrices, int mouseX, int mouseY, float partialTicks) {
        renderBackground(matrices);
        options.render(matrices, mouseX, mouseY, partialTicks);

        TextFieldWidget searchBox = options.getSearchBox();
        if (searchBox.isNarratable()) options.getSearchBox().render(matrices, mouseX, mouseY, partialTicks);

        super.render(matrices, mouseX, mouseY, partialTicks);
        renderForeground(matrices, options.getRowLeft(), options.getRowWidth(), mouseX, mouseY, partialTicks);

        if (mouseY < 32 || mouseY > height - 32) {
            return;
        }

        options.hoveredElement(mouseX, mouseY).ifPresent(element -> {
            if (element instanceof ConfigValue<?> value) {
                value.renderTooltip(this, matrices, mouseX, mouseY, partialTicks);
            }
        });
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        for (Element child : children) {
            if (child instanceof TextFieldWidget editBox) {
                editBox.setFocused(false);
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    @SuppressWarnings("ConstantConditions")
    public void close() {
        client.setScreen(parent);
    }

    public void addListener(Element listener) {
        children.add(listener);
    }

    public abstract ConfigListWidget getOptions();

}
