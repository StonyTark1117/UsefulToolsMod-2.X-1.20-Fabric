package mcp.mobius.waila.gui.screen;

import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.text.Text;
import net.minecraft.util.annotation.MethodsReturnNonnullByDefault;
import org.jetbrains.annotations.NotNull;

@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
@SuppressWarnings("ConstantConditions")
public class AutoClosableScreen extends HandledScreen<AutoClosableScreen.Menu> {

    private AutoClosableScreen() {
        super(new Menu(), MinecraftClient.getInstance().player.getInventory(), Text.empty());
    }

    public static void inject() {
        MinecraftClient client = MinecraftClient.getInstance();
        Screen screen = client.currentScreen;
        if (!(screen instanceof AutoClosableScreen)) {
            client.setScreen(new AutoClosableScreen());
        }
    }

    @Override
    protected void method_2389(@NotNull MatrixStack matrices, float v, int i, int i1) {
        if (client.currentScreen == this) {
            client.setScreen(null);
        }
    }

    public static class Menu extends ScreenHandler {

        protected Menu() {
            super(null, 0);
        }

        @Override
        public ItemStack quickMove(PlayerEntity player, int i) {
            return ItemStack.EMPTY;
        }

        @Override
        public boolean canUse(PlayerEntity player) {
            return false;
        }

    }

}
