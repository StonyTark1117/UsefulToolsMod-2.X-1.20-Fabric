package mcp.mobius.waila.plugin.vanilla.provider.data;

import java.util.UUID;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import net.minecraft.entity.Entity;
import net.minecraft.entity.Tameable;

public enum PetOwnerDataProvider implements IDataProvider<Entity> {

    INSTANCE;

    @Override
    public void appendData(IDataWriter data, IServerAccessor<Entity> accessor, IPluginConfig config) {
        if (config.getBoolean(Options.PET_OWNER)) {
            var uuid = ((Tameable) accessor.getTarget()).getOwnerUuid();
            if (uuid != null) data.raw().putUuid("owner", uuid);
        }
    }

}
