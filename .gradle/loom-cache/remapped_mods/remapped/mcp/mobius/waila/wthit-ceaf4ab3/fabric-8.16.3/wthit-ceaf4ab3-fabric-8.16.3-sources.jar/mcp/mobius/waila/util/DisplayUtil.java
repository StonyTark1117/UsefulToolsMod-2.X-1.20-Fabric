package mcp.mobius.waila.util;

import java.util.IllegalFormatException;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.text.Text;
import net.minecraft.util.math.ColorHelper;
import F;
import com.mojang.blaze3d.systems.RenderSystem;
import org.joml.Matrix4f;

public final class DisplayUtil {


    private static final MinecraftClient CLIENT = MinecraftClient.getInstance();

    public static void enable3DRender() {
        DiffuseLighting.enableGuiDepthLighting();
        RenderSystem.enableDepthTest();
    }

    public static void enable2DRender() {
        DiffuseLighting.disableGuiDepthLighting();
        RenderSystem.disableDepthTest();
    }

    public static void renderRectBorder(Matrix4f matrix, VertexConsumer buf, int x, int y, int w, int h, int s, int gradStart, int gradEnd) {
        if (s <= 0) {
            return;
        }

        // @formatter:off
        fillGradient(matrix, buf, x        , y        , w, s          , gradStart, gradStart);
        fillGradient(matrix, buf, x        , y + h - s, w, s          , gradEnd  , gradEnd);
        fillGradient(matrix, buf, x        , y + s    , s, h - (s * 2), gradStart, gradEnd);
        fillGradient(matrix, buf, x + w - s, y + s    , s, h - (s * 2), gradStart, gradEnd);
        // @formatter:on
    }

    public static void fillGradient(Matrix4f matrix, VertexConsumer buf, int x, int y, int w, int h, int start, int end) {
        var sa = ColorHelper.Argb.getAlpha(start) / 255.0F;
        var sr = ColorHelper.Argb.getRed(start) / 255.0F;
        var sg = ColorHelper.Argb.getGreen(start) / 255.0F;
        var sb = ColorHelper.Argb.getBlue(start) / 255.0F;

        var ea = ColorHelper.Argb.getAlpha(end) / 255.0F;
        var er = ColorHelper.Argb.getRed(end) / 255.0F;
        var eg = ColorHelper.Argb.getGreen(end) / 255.0F;
        var eb = ColorHelper.Argb.getBlue(end) / 255.0F;

        buf.vertex(matrix, x, y, 0).color(sr, sg, sb, sa).next();
        buf.vertex(matrix, x, y + h, 0).color(er, eg, eb, ea).next();
        buf.vertex(matrix, x + w, y + h, 0).color(er, eg, eb, ea).next();
        buf.vertex(matrix, x + w, y, 0).color(sr, sg, sb, sa).next();
    }

    public static int getAlphaFromPercentage(int percentage) {
        return percentage == 100 ? 255 << 24 : percentage == 0 ? (int) (0.4F / 100.0F * 256) << 24 : (int) (percentage / 100.0F * 256) << 24;
    }

    public static String tryFormat(String format, Object... args) {
        try {
            return format.formatted(args);
        } catch (IllegalFormatException e) {
            return "FORMATTING ERROR";
        }
    }

    public static ButtonWidget createButton(int x, int y, int width, int height, Text label, ButtonWidget.PressAction pressAction) {
        return ButtonWidget.builder(label, pressAction).dimensions(x, y, width, height).build();
    }

}
