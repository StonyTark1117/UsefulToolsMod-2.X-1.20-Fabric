package mcp.mobius.waila.plugin.harvest.component;

import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.api.__internal__.ApiSide;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.item.ItemStack;
import org.jetbrains.annotations.Nullable;

@ApiSide.ClientOnly
public class ToolComponent implements ITooltipComponent {

    private final @Nullable ItemStack icon;

    private final int v0;
    private final int width;
    private final int xo;

    private int x;

    public ToolComponent(@Nullable ItemStack icon, @Nullable Boolean matches) {
        this.icon = icon;

        if (matches != null) v0 = matches ? 7 : 0;
        else v0 = -1;

        if (icon == null) {
            width = 6;
            xo = 0;
        } else {
            width = 9;
            xo = 3;
        }
    }

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return 9;
    }

    @Override
    public void render(DrawContext ctx, int x, int y, float delta) {
        this.x = x;
    }

    public void actuallyRender(DrawContext ctx, int y) {
        if (icon != null) {
            ctx.getMatrices().push();
            ctx.getMatrices().translate(-2, -2, 0);
            ctx.getMatrices().scale(0.85f, 0.85f, 1f);
            ctx.getMatrices().translate(x / 0.85f, y / 0.85f, 0);
            ctx.drawItem(icon, 0, 0);
            ctx.getMatrices().pop();
        }

        if (v0 == -1) return;
        ctx.getMatrices().push();
        ctx.getMatrices().translate(0, 0, ItemRenderer.field_32934);
        ctx.drawTexture(WailaConstants.COMPONENT_TEXTURE, x + xo, y + 3, 122, v0, 7, 7);
        ctx.getMatrices().pop();
    }

}
