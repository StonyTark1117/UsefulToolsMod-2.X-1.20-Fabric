package mcp.mobius.waila.gui.screen;

import java.util.List;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.gui.widget.ConfigListWidget;
import mcp.mobius.waila.gui.widget.value.ConfigValue;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.toast.SystemToast;
import net.minecraft.client.util.InputUtil;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static mcp.mobius.waila.util.DisplayUtil.createButton;

import J;

public abstract class ConfigScreen extends YesIAmSureTheClientInstanceIsPresentByTheTimeIUseItScreen {

    private final Screen parent;
    private final @Nullable Runnable saver;
    private final @Nullable Runnable canceller;

    private boolean showEscWarning = true;
    private long lastEscPressTime = 0;
    private int escPressed = 0;

    @SuppressWarnings("unchecked")
    private final List<Element> children = (List<Element>) children();
    private ConfigListWidget options;

    protected boolean cancelled;

    public ConfigScreen(Screen parent, Text title, @Nullable Runnable saver, @Nullable Runnable canceller) {
        super(title);

        this.parent = parent;
        this.saver = saver;
        this.canceller = canceller;
    }

    public ConfigScreen(Screen parent, Text title) {
        this(parent, title, null, null);
    }

    @Override
    public void init() {
        super.init();

        if (options == null) {
            options = getOptions();
        }

        options.init();

        if (options.enableSearchBox) {
            var searchBox = options.getSearchBox();
            addSelectableChild(searchBox);
            setInitialFocus(searchBox);
        }

        addSelectableChild(options);

        if (saver != null && canceller != null) {
            addDrawableChild(createButton(width / 2 - 102, height - 25, 100, 20, ScreenTexts.DONE, w -> {
                if (options.save(false)) {
                    saver.run();
                    close();
                }
            }));
            addDrawableChild(createButton(width / 2 + 2, height - 25, 100, 20, ScreenTexts.CANCEL, w -> {
                cancelled = true;
                canceller.run();
                close();
            }));
        } else {
            addDrawableChild(createButton(width / 2 - 50, height - 25, 100, 20, ScreenTexts.DONE, w -> {
                if (options.save(false)) {
                    close();
                }
            }));
        }
    }

    protected void renderForeground(DrawContext ctx, int rowLeft, int rowWidth, int mouseX, int mouseY, float partialTicks) {
        ctx.drawTextWithShadow(textRenderer, title, rowLeft, 12, 0xFFFFFF);
    }

    @Override
    public void tick() {
        options.tick();
    }

    @Override
    public void render(@NotNull DrawContext ctx, int mouseX, int mouseY, float partialTicks) {
        renderBackground(ctx);
        options.render(ctx, mouseX, mouseY, partialTicks);

        if (options.enableSearchBox) {
            options.getSearchBox().render(ctx, mouseX, mouseY, partialTicks);
        }

        super.render(ctx, mouseX, mouseY, partialTicks);
        renderForeground(ctx, options.getRowLeft(), options.getRowWidth(), mouseX, mouseY, partialTicks);

        if (mouseY < 32 || mouseY > height - 32) {
            return;
        }

        options.hoveredElement(mouseX, mouseY).ifPresent(element -> {
            if (element instanceof ConfigValue<?> value) {
                value.renderTooltip(ctx, mouseX, mouseY);
            }
        });
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        for (var child : children) {
            if (child instanceof TextFieldWidget editBox) {
                editBox.setFocused(false);
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        if (showEscWarning) {
            var now = System.currentTimeMillis();
            if ((now - lastEscPressTime) > 2 * 1000) {
                escPressed = 0;
            }

            lastEscPressTime = now;
            escPressed++;
            if (escPressed > 5) {
                client.getToastManager().add(new SystemToast(
                    SystemToast.Type.PACK_COPY_FAILURE,
                    Text.translatable(Tl.Gui.EscWarning.UMM),
                    Text.translatable(Tl.Gui.EscWarning.LMAO,
                        ScreenTexts.DONE.copy().formatted(Formatting.GOLD),
                        ScreenTexts.CANCEL.copy().formatted(Formatting.DARK_PURPLE))
                ));
                showEscWarning = false;
                escPressed = 0;
            }
        }

        return false;
    }

    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        if (keyCode == InputUtil.GLFW_KEY_ESCAPE) {
            showEscWarning = true;
        }

        return super.keyReleased(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    public void addListener(Element listener) {
        children.add(listener);
    }

    public abstract ConfigListWidget getOptions();

}
