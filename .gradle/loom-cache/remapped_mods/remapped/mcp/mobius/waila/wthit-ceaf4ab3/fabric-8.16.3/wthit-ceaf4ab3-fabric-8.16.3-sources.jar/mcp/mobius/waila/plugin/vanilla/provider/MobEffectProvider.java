package mcp.mobius.waila.plugin.vanilla.provider;

import I;
import mcp.mobius.waila.api.IEntityAccessor;
import mcp.mobius.waila.api.IEntityComponentProvider;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.plugin.vanilla.config.Options;
import mcp.mobius.waila.plugin.vanilla.provider.data.MobEffectDataProvider;
import mcp.mobius.waila.plugin.vanilla.provider.data.MobEffectDataProvider.Data;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public enum MobEffectProvider implements IEntityComponentProvider {

    INSTANCE;

    @Override
    public void appendBody(ITooltip tooltip, IEntityAccessor accessor, IPluginConfig config) {
        if (!config.getBoolean(Options.EFFECT_MOB)) return;

        var data = accessor.getData().get(MobEffectDataProvider.Data.class);
        if (data == null) return;

        data.list().forEach(it -> {
            var text = Text.translatable(it.getTranslationKey());
            var amplifier = it.getAmplifier();

            if (amplifier > 0) {
                if (I18n.hasTranslation("potion.potency." + amplifier)) {
                    text = Text.translatable("potion.withAmplifier", text, Text.translatable("potion.potency." + amplifier));
                } else {
                    text.append(" " + (amplifier + 1));
                }
            }

            if (it.getEffectType().getCategory() == StatusEffectCategory.HARMFUL) text.formatted(Formatting.RED);

            tooltip.setLine(Options.EFFECT_MOB, text);
        });
    }

}
