package mcp.mobius.waila.buildconst;

import java.lang.String;

/**
 * Generated constant class, do NOT modify!
 */
public final class Tl {
  public static final class Json5 {
    public static final class Config {
      public static final String DEFAULT_VALUE = "json5.waila.config.default_value";

      public static final String AVAILABLE_VALUES = "json5.waila.config.available_values";

      public static final class Plugin {
        public static final String CUSTOM_FILE = "json5.waila.config.plugin.custom_file";

        public static final String SERVER_REQUIRED = "json5.waila.config.plugin.server_required";

        public static final String MERGED = "json5.waila.config.plugin.merged";

        public static final String SYNCED = "json5.waila.config.plugin.synced";
      }
    }
  }

  public static final class Tooltip {
    public static final String CROP_GROWTH = "tooltip.waila.crop_growth";

    public static final String CROP_GROWABLE = "tooltip.waila.crop_growable";

    public static final String TREE_GROWABLE = "tooltip.waila.tree_growable";

    public static final String CROP_MATURE = "tooltip.waila.crop_mature";

    public static final String EMPTY = "tooltip.waila.empty";

    public static final String DELAY = "tooltip.waila.delay";

    public static final String MODE = "tooltip.waila.mode";

    public static final String MODE_COMPARATOR = "tooltip.waila.mode_comparator";

    public static final String MODE_SUBTRACTOR = "tooltip.waila.mode_subtractor";

    public static final String STATE = "tooltip.waila.state";

    public static final String STATE_ON = "tooltip.waila.state_on";

    public static final String STATE_OFF = "tooltip.waila.state_off";

    public static final String TRUE = "tooltip.waila.true";

    public static final String FALSE = "tooltip.waila.false";

    public static final String POWER = "tooltip.waila.power";

    public static final String SNEAK_FOR_DETAILS = "tooltip.waila.sneak_for_details";

    public static final String COMPOST_LEVEL = "tooltip.waila.compost_level";

    public static final String HONEY_LEVEL = "tooltip.waila.honey_level";

    public static final String OWNER = "tooltip.waila.owner";

    public static final String INSTRUMENT = "tooltip.waila.instrument";

    public static final class Extra {
      public static final String ENERGY = "tooltip.waila.extra.energy";

      public static final String UNKNOWN_FLUID = "tooltip.waila.extra.unknown_fluid";
    }

    public static final class Panda {
      public static final String PERSONALITY = "tooltip.waila.panda.personality";

      public static final String TRAITS = "tooltip.waila.panda.traits";

      public static final String GENE = "tooltip.waila.panda.gene";

      public static final class Gene {
        public static final String NORMAL = "tooltip.waila.panda.gene.normal";

        public static final String LAZY = "tooltip.waila.panda.gene.lazy";

        public static final String WORRIED = "tooltip.waila.panda.gene.worried";

        public static final String PLAYFUL = "tooltip.waila.panda.gene.playful";

        public static final String BROWN = "tooltip.waila.panda.gene.brown";

        public static final String WEAK = "tooltip.waila.panda.gene.weak";

        public static final String AGGRESSIVE = "tooltip.waila.panda.gene.aggressive";
      }
    }

    public static final class Timer {
      public static final String GROW = "tooltip.waila.timer.grow";

      public static final String BREED = "tooltip.waila.timer.breed";
    }

    public static final class Bee {
      public static final String HIVE = "tooltip.waila.bee.hive";
    }

    public static final class Harvest {
      public static final String HARVESTABLE = "tooltip.waila.harvest.harvestable";

      public static final String EFFECTIVE_TOOL = "tooltip.waila.harvest.effective_tool";

      public static final String LEVEL = "tooltip.waila.harvest.level";

      public static final String TOOL = "tooltip.waila.harvest.tool";

      public static final String TIER = "tooltip.waila.harvest.tier";

      public static final class Tier {
        public static final String WOOD = "tooltip.waila.harvest.tier.wood";

        public static final String STONE = "tooltip.waila.harvest.tier.stone";

        public static final String IRON = "tooltip.waila.harvest.tier.iron";

        public static final String GOLD = "tooltip.waila.harvest.tier.gold";

        public static final String DIAMOND = "tooltip.waila.harvest.tier.diamond";

        public static final String NETHERITE = "tooltip.waila.harvest.tier.netherite";
      }

      public static final class Tool {
        public static final class Minecraft {
          public static final String PICKAXE = "tooltip.waila.harvest.tool.minecraft.pickaxe";

          public static final String SHOVEL = "tooltip.waila.harvest.tool.minecraft.shovel";

          public static final String AXE = "tooltip.waila.harvest.tool.minecraft.axe";

          public static final String HOE = "tooltip.waila.harvest.tool.minecraft.hoe";

          public static final String SWORD = "tooltip.waila.harvest.tool.minecraft.sword";

          public static final String SHEARS = "tooltip.waila.harvest.tool.minecraft.shears";
        }
      }
    }

    public static final class Horse {
      public static final class Speed {
        public static final String KEY = "tooltip.waila.horse.speed.key";

        public static final String VALUE = "tooltip.waila.horse.speed.value";
      }

      public static final class Jump {
        public static final String KEY = "tooltip.waila.horse.jump.key";

        public static final String VALUE = "tooltip.waila.horse.jump.value";
      }
    }

    public static final class Owner {
      public static final String LOADING = "tooltip.waila.owner.loading";
    }

    public static final class Instrument {
      public static final String HARP = "tooltip.waila.instrument.harp";

      public static final String BASEDRUM = "tooltip.waila.instrument.basedrum";

      public static final String SNARE = "tooltip.waila.instrument.snare";

      public static final String HAT = "tooltip.waila.instrument.hat";

      public static final String BASS = "tooltip.waila.instrument.bass";

      public static final String FLUTE = "tooltip.waila.instrument.flute";

      public static final String BELL = "tooltip.waila.instrument.bell";

      public static final String GUITAR = "tooltip.waila.instrument.guitar";

      public static final String CHIME = "tooltip.waila.instrument.chime";

      public static final String XYLOPHONE = "tooltip.waila.instrument.xylophone";

      public static final String IRON_XYLOPHONE = "tooltip.waila.instrument.iron_xylophone";

      public static final String COW_BELL = "tooltip.waila.instrument.cow_bell";

      public static final String DIDGERIDOO = "tooltip.waila.instrument.didgeridoo";

      public static final String BIT = "tooltip.waila.instrument.bit";

      public static final String BANJO = "tooltip.waila.instrument.banjo";

      public static final String PLING = "tooltip.waila.instrument.pling";

      public static final String ZOMBIE = "tooltip.waila.instrument.zombie";

      public static final String SKELETON = "tooltip.waila.instrument.skeleton";

      public static final String CREEPER = "tooltip.waila.instrument.creeper";

      public static final String DRAGON = "tooltip.waila.instrument.dragon";

      public static final String WITHER_SKELETON = "tooltip.waila.instrument.wither_skeleton";

      public static final String PIGLIN = "tooltip.waila.instrument.piglin";

      public static final String NONE = "tooltip.waila.instrument.none";
    }
  }

  public static final class Theme {
    public static final class PluginWaila {
      public static final class NinePatch {
        public static final String TEXTURE = "theme.waila.plugin_waila.nine_patch.texture";

        public static final String USERESOURCEPACK = "theme.waila.plugin_waila.nine_patch.useResourcePack";

        public static final String TEXTCOLOR = "theme.waila.plugin_waila.nine_patch.textColor";

        public static final String TEXTUREWIDTH = "theme.waila.plugin_waila.nine_patch.textureWidth";

        public static final String TEXTUREHEIGHT = "theme.waila.plugin_waila.nine_patch.textureHeight";

        public static final String REGIONTOP = "theme.waila.plugin_waila.nine_patch.regionTop";

        public static final String REGIONMIDDLE = "theme.waila.plugin_waila.nine_patch.regionMiddle";

        public static final String REGIONBOTTOM = "theme.waila.plugin_waila.nine_patch.regionBottom";

        public static final String REGIONLEFT = "theme.waila.plugin_waila.nine_patch.regionLeft";

        public static final String REGIONCENTER = "theme.waila.plugin_waila.nine_patch.regionCenter";

        public static final String REGIONRIGHT = "theme.waila.plugin_waila.nine_patch.regionRight";

        public static final String MODE = "theme.waila.plugin_waila.nine_patch.mode";

        public static final String MODE_STRETCH = "theme.waila.plugin_waila.nine_patch.mode_stretch";

        public static final String MODE_TILE = "theme.waila.plugin_waila.nine_patch.mode_tile";
      }

      public static final class Gradient {
        public static final String BACKGROUNDCOLOR = "theme.waila.plugin_waila.gradient.backgroundColor";

        public static final String GRADIENTSTART = "theme.waila.plugin_waila.gradient.gradientStart";

        public static final String GRADIENTEND = "theme.waila.plugin_waila.gradient.gradientEnd";

        public static final String BORDERSIZE = "theme.waila.plugin_waila.gradient.borderSize";

        public static final String BORDEROFFSET = "theme.waila.plugin_waila.gradient.borderOffset";

        public static final String DRAWCORNER = "theme.waila.plugin_waila.gradient.drawCorner";

        public static final String FONTCOLOR = "theme.waila.plugin_waila.gradient.fontColor";
      }
    }
  }

  public static final class Key {
    public static final String CONFIG = "key.waila.config";

    public static final String SHOW_OVERLAY = "key.waila.show_overlay";

    public static final String TOGGLE_LIQUID = "key.waila.toggle_liquid";

    public static final String SHOW_RECIPE_INPUT = "key.waila.show_recipe_input";

    public static final String SHOW_RECIPE_OUTPUT = "key.waila.show_recipe_output";
  }

  public static final class Command {
    public static final String SERVER_DUMP_SUCCESS = "command.waila.server_dump_success";

    public static final String LOCAL_DUMP_SUCCESS = "command.waila.local_dump_success";

    public static final String CLIENT_DUMP_SUCCESS = "command.waila.client_dump_success";

    public static final class Plugin {
      public static final String RELOAD = "command.waila.plugin.reload";

      public static final String UNKNOWN = "command.waila.plugin.unknown";

      public static final String LOCKED = "command.waila.plugin.locked";

      public static final String DISABLED_ON_SERVER = "command.waila.plugin.disabled_on_server";

      public static final class Modify {
        public static final String DISABLE = "command.waila.plugin.modify.disable";

        public static final String ENABLE = "command.waila.plugin.modify.enable";
      }

      public static final class List {
        public static final class Enabled {
          public static final String NONE = "command.waila.plugin.list.enabled.none";

          public static final String SUCCESS = "command.waila.plugin.list.enabled.success";
        }

        public static final class Available {
          public static final String NONE = "command.waila.plugin.list.available.none";

          public static final String SUCCESS = "command.waila.plugin.list.available.success";
        }
      }
    }

    public static final class Overlay {
      public static final String TRUE = "command.waila.overlay.true";

      public static final String FALSE = "command.waila.overlay.false";
    }

    public static final class Config {
      public static final String UNKNOWN_ID = "command.waila.config.unknown_id";

      public static final class Get {
        public static final String ID = "command.waila.config.get.id";

        public static final String SYNCED = "command.waila.config.get.synced";

        public static final String CURRENT_VALUE = "command.waila.config.get.current_value";

        public static final String DEFAULT_VALUE = "command.waila.config.get.default_value";

        public static final String CLIENT_ONLY_VALUE = "command.waila.config.get.client_only_value";
      }

      public static final class Set {
        public static final String SYNCED = "command.waila.config.set.synced";

        public static final String SUCCESS = "command.waila.config.set.success";

        public static final String PARSE_FAIL = "command.waila.config.set.parse_fail";
      }
    }
  }

  public static final class Gui {
    public static final String CONFIGURATION = "gui.waila.configuration";

    public static final String WAILA_SETTINGS = "gui.waila.waila_settings";

    public static final String CREDITS = "gui.waila.credits";

    public static final class Inspector {
      public static final String TITLE = "gui.waila.inspector.title";

      public static final String TAG = "gui.waila.inspector.tag";

      public static final String PROVIDER = "gui.waila.inspector.provider";

      public static final String PLUGIN_ID = "gui.waila.inspector.plugin_id";

      public static final String MOD = "gui.waila.inspector.mod";
    }

    public static final class Credits {
      public static final String ORIGINAL_MOD_BY = "gui.waila.credits.original_mod_by";

      public static final String AUTHORS = "gui.waila.credits.authors";

      public static final String CONTRIBUTORS = "gui.waila.credits.contributors";
    }

    public static final class EscWarning {
      public static final String UMM = "gui.waila.esc_warning.umm";

      public static final String LMAO = "gui.waila.esc_warning.lmao";
    }

    public static final class Plugin {
      public static final String TOGGLE = "gui.waila.plugin.toggle";

      public static final String SETTINGS = "gui.waila.plugin.settings";

      public static final class Toggle {
        public static final String DISABLED_ON_SERVER = "gui.waila.plugin.toggle.disabled_on_server";

        public static final String LOCKED = "gui.waila.plugin.toggle.locked";

        public static final String CONFIRM = "gui.waila.plugin.toggle.confirm";
      }
    }
  }

  public static final class Config {
    public static final String SEARCH_PROMPT = "config.waila.search_prompt";

    public static final String EXPAND_ALL = "config.waila.expand_all";

    public static final String TRUE = "config.waila.true";

    public static final String FALSE = "config.waila.false";

    public static final String PREVIEW_PROMPT = "config.waila.preview_prompt";

    public static final String EDIT = "config.waila.edit";

    public static final String OPEN_FILE = "config.waila.open_file";

    public static final String NEW = "config.waila.new";

    public static final String MISSING_INPUT = "config.waila.missing_input";

    public static final String SERVER_ONLY = "config.waila.server_only";

    public static final String SERVER_DISABLED = "config.waila.server_disabled";

    public static final String SERVER_MISSING_MOD = "config.waila.server_missing_mod";

    public static final String SERVER_MISSING_OPTION = "config.waila.server_missing_option";

    public static final String GENERAL = "config.waila.general";

    public static final String DISPLAY_TOOLTIP = "config.waila.display_tooltip";

    public static final String SNEAKY_DETAILS = "config.waila.sneaky_details";

    public static final String HIDE_SNEAK_TEXT = "config.waila.hide_sneak_text";

    public static final String DISPLAY_MODE = "config.waila.display_mode";

    public static final String DISPLAY_MODE_TOGGLE = "config.waila.display_mode_toggle";

    public static final String DISPLAY_MODE_HOLD_KEY = "config.waila.display_mode_hold_key";

    public static final String HIDE_FROM_PLAYERS = "config.waila.hide_from_players";

    public static final String HIDE_FROM_DEBUG = "config.waila.hide_from_debug";

    public static final String RATE_LIMIT = "config.waila.rate_limit";

    public static final String BLACKLIST = "config.waila.blacklist";

    public static final String BLACKLIST_OPEN = "config.waila.blacklist_open";

    public static final String TTS = "config.waila.tts";

    public static final String OVERLAY = "config.waila.overlay";

    public static final String OVERLAY_FPS = "config.waila.overlay_fps";

    public static final String OVERLAY_POS_X = "config.waila.overlay_pos_x";

    public static final String OVERLAY_POS_Y = "config.waila.overlay_pos_y";

    public static final String BOSS_BARS_OVERLAP = "config.waila.boss_bars_overlap";

    public static final String OVERLAY_SCALE = "config.waila.overlay_scale";

    public static final String OVERLAY_ANCHOR_X = "config.waila.overlay_anchor_x";

    public static final String OVERLAY_ANCHOR_X_LEFT = "config.waila.overlay_anchor_x_left";

    public static final String OVERLAY_ANCHOR_X_RIGHT = "config.waila.overlay_anchor_x_right";

    public static final String OVERLAY_ANCHOR_X_CENTER = "config.waila.overlay_anchor_x_center";

    public static final String OVERLAY_ANCHOR_Y = "config.waila.overlay_anchor_y";

    public static final String OVERLAY_ANCHOR_Y_TOP = "config.waila.overlay_anchor_y_top";

    public static final String OVERLAY_ANCHOR_Y_BOTTOM = "config.waila.overlay_anchor_y_bottom";

    public static final String OVERLAY_ANCHOR_Y_MIDDLE = "config.waila.overlay_anchor_y_middle";

    public static final String OVERLAY_ALIGN_X = "config.waila.overlay_align_x";

    public static final String OVERLAY_ALIGN_X_LEFT = "config.waila.overlay_align_x_left";

    public static final String OVERLAY_ALIGN_X_RIGHT = "config.waila.overlay_align_x_right";

    public static final String OVERLAY_ALIGN_X_CENTER = "config.waila.overlay_align_x_center";

    public static final String OVERLAY_ALIGN_Y = "config.waila.overlay_align_y";

    public static final String OVERLAY_ALIGN_Y_TOP = "config.waila.overlay_align_y_top";

    public static final String OVERLAY_ALIGN_Y_BOTTOM = "config.waila.overlay_align_y_bottom";

    public static final String OVERLAY_ALIGN_Y_MIDDLE = "config.waila.overlay_align_y_middle";

    public static final String OVERLAY_COLOR = "config.waila.overlay_color";

    public static final String OVERLAY_BACKGROUND_ALPHA = "config.waila.overlay_background_alpha";

    public static final String OVERLAY_THEME = "config.waila.overlay_theme";

    public static final String FORMATTING = "config.waila.formatting";

    public static final String FORMAT_MOD_NAME = "config.waila.format_mod_name";

    public static final String FORMAT_BLOCK_NAME = "config.waila.format_block_name";

    public static final String FORMAT_FLUID_NAME = "config.waila.format_fluid_name";

    public static final String FORMAT_ENTITY_NAME = "config.waila.format_entity_name";

    public static final String FORMAT_REGISTRY_NAME = "config.waila.format_registry_name";

    public static final String KEYBINDS = "config.waila.keybinds";

    public static final String PLUGIN_ = "config.waila.plugin_";

    public static final class OverlayFps {
      public static final String DISABLED_REASON = "config.waila.overlay_fps.disabled_reason";
    }

    public static final class InvalidInput {
      public static final String TITLE = "config.waila.invalid_input.title";

      public static final String DESC = "config.waila.invalid_input.desc";
    }

    public static final class OverlayThemeEditor {
      public static final String REFRESH = "config.waila.overlay_theme_editor.refresh";

      public static final String ID = "config.waila.overlay_theme_editor.id";

      public static final String ID_EMPTY = "config.waila.overlay_theme_editor.id_empty";

      public static final String TYPE = "config.waila.overlay_theme_editor.type";

      public static final String ATTRIBUTES = "config.waila.overlay_theme_editor.attributes";

      public static final String DELETE = "config.waila.overlay_theme_editor.delete";

      public static final String DELETE_PROMPT = "config.waila.overlay_theme_editor.delete_prompt";
    }
  }
}
