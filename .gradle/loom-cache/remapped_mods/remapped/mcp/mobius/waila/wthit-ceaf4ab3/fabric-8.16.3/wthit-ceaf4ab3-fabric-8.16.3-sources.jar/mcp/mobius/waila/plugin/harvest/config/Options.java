package mcp.mobius.waila.plugin.harvest.config;

import net.minecraft.util.Identifier;

public class Options {

    // @formatter:off
    public static final Identifier ENABLED      = rl("enabled");
    public static final Identifier DISPLAY_MODE = rl("display_mode");
    public static final Identifier CREATIVE     = rl("creative");
    // @formatter:on

    public static Identifier rl(String path) {
        return new Identifier("harvest", path);
    }

}
