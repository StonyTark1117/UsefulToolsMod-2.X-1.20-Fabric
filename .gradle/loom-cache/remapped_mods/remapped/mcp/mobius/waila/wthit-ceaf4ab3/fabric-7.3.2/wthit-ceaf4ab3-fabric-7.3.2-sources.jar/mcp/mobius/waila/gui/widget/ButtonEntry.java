package mcp.mobius.waila.gui.widget;

import com.google.common.collect.ImmutableList;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;

import static mcp.mobius.waila.util.DisplayUtil.createButton;

public class ButtonEntry extends ConfigListWidget.Entry {

    private final String title;
    private final ButtonWidget button;

    public ButtonEntry(String title, ButtonWidget button) {
        this(title, title, button);
    }

    public ButtonEntry(String name, String button, ButtonWidget buttonWidget) {
        this.title = I18n.translate(name);
        this.button = buttonWidget;
        buttonWidget.setMessage(Text.translatable(button));
    }

    public ButtonEntry(String title, int width, int height, ButtonWidget.PressAction pressAction) {
        this(title, title, width, height, pressAction);
    }

    public ButtonEntry(String name, String button, int width, int height, ButtonWidget.PressAction pressAction) {
        this(name, button, createButton(0, 0, width, height, Text.empty(), pressAction));
    }

    @Override
    public void method_25343(@NotNull MatrixStack matrices, int index, int rowTop, int rowLeft, int width, int height, int mouseX, int mouseY, boolean hovered, float deltaTime) {
        super.method_25343(matrices, index, rowTop, rowLeft, width, height, mouseX, mouseY, hovered, deltaTime);

        client.textRenderer.method_1720(matrices, title, rowLeft, rowTop + (height - client.textRenderer.fontHeight) / 2f, 16777215);
        this.button.setX(rowLeft + width - button.getWidth());
        this.button.setY(rowTop + (height - button.getHeight()) / 2);
        this.button.render(matrices, mouseX, mouseY, deltaTime);
    }

    @Override
    protected void gatherChildren(ImmutableList.Builder<Element> children) {
        children.add(button);
    }

    @Override
    public boolean match(String filter) {
        return super.match(filter) || StringUtils.containsIgnoreCase(title, filter);
    }

}
