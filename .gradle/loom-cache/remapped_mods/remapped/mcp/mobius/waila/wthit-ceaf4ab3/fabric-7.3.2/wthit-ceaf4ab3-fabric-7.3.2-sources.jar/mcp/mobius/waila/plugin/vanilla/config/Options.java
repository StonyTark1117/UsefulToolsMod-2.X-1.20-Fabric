package mcp.mobius.waila.plugin.vanilla.config;

import net.minecraft.util.Identifier;

public final class Options {

    // @formatter:off
    public static final Identifier BREAKING_PROGRESS             = rl("breaking_progress.enabled");
    public static final Identifier BREAKING_PROGRESS_COLOR       = rl("breaking_progress.color");
    public static final Identifier BREAKING_PROGRESS_BOTTOM_ONLY = rl("breaking_progress.bottom_only");
    public static final Identifier FURNACE_CONTENTS              = rl("furnace_contents");
    public static final Identifier ITEM_ENTITY                   = rl("item_entity");
    public static final Identifier OVERRIDE_INFESTED             = rl("override.infested");
    public static final Identifier OVERRIDE_TRAPPED_CHEST        = rl("override.trapped_chest");
    public static final Identifier OVERRIDE_POWDER_SNOW          = rl("override.powder_snow");
    public static final Identifier OVERRIDE_VEHICLE              = rl("override.vehicle");
    public static final Identifier OVERRIDE_INVISIBLE_ENTITY     = rl("override.invisible_entity");
    public static final Identifier PET_OWNER                     = rl("pet.owner");
    public static final Identifier PET_HIDE_UNKNOWN_OWNER        = rl("pet.hide_unknown_owner");
    public static final Identifier SPAWNER_TYPE                  = rl("spawner_type");
    public static final Identifier CROP_PROGRESS                 = rl("crop_progress");
    public static final Identifier REDSTONE_LEVER                = rl("redstone.lever");
    public static final Identifier REDSTONE_REPEATER             = rl("redstone.repeater");
    public static final Identifier REDSTONE_COMPARATOR           = rl("redstone.comparator");
    public static final Identifier REDSTONE_LEVEL                = rl("redstone.level");
    public static final Identifier JUKEBOX_RECORD                = rl("jukebox.record");
    public static final Identifier PLAYER_HEAD_NAME              = rl("player_head.name");
    public static final Identifier LEVEL_COMPOSTER               = rl("level.composter");
    public static final Identifier LEVEL_HONEY                   = rl("level.honey");
    public static final Identifier NOTE_BLOCK_TYPE               = rl("note_block.type");
    public static final Identifier NOTE_BLOCK_NOTE               = rl("note_block.note");
    public static final Identifier NOTE_BLOCK_INT_VALUE          = rl("note_block.int_value");
    public static final Identifier TIMER_GROW                    = rl("timer.grow");
    public static final Identifier TIMER_BREED                   = rl("timer.breed");
    public static final Identifier ATTRIBUTE_BLOCK_POSITION      = rl("attribute.block_position");
    public static final Identifier ATTRIBUTE_BLOCK_STATE         = rl("attribute.block_state");
    public static final Identifier ATTRIBUTE_ENTITY_POSITION     = rl("attribute.entity_position");
    public static final Identifier ATTRIBUTE_HEALTH              = rl("attribute.health");
    public static final Identifier ATTRIBUTE_ABSORPTION          = rl("attribute.absorption");
    public static final Identifier ATTRIBUTE_ARMOR               = rl("attribute.armor");
    public static final Identifier ATTRIBUTE_COMPACT             = rl("attribute.compact");
    public static final Identifier ATTRIBUTE_ICON_PER_LINE       = rl("attribute.icon_per_line");
    public static final Identifier ATTRIBUTE_LONG_HEALTH_MAX     = rl("attribute.long_health_max");
    public static final Identifier ATTRIBUTE_LONG_ARMOR_MAX      = rl("attribute.long_armor_max");
    public static final Identifier ATTRUBUTE_HORSE_JUMP_HEIGHT   = rl("attribute.horse_jump_height");
    public static final Identifier ATTRUBUTE_HORSE_SPEED         = rl("attribute.horse_speed");
    // @formatter:on

    private static Identifier rl(String rl) {
        return new Identifier(rl);
    }

}
