package mcp.mobius.waila.plugin.harvest.tool;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;
import I;
import com.google.common.base.Suppliers;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import mcp.mobius.waila.api.__internal__.IApiService;
import mcp.mobius.waila.api.__internal__.Internals;
import mcp.mobius.waila.buildconst.Tl;
import net.minecraft.block.Block;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public final class ToolTier {

    public static final ToolTier NONE = Internals.unsafeAlloc(ToolTier.class);

    private static final Supplier<Map<ToolMaterial, ToolTier>> TIERS = Suppliers.memoize(() -> {
        var builder = ImmutableMap.<ToolMaterial, ToolTier>builder();
        var tiers = IApiService.INSTANCE.getTiers();
        for (var i = 0; i < tiers.size(); i++) {
            var tier = tiers.get(i);
            builder.put(tier, new ToolTier(tier, i));
        }
        return builder.build();
    });

    private static final Supplier<Map<Identifier, String>> VANILLA_TIER_TL_KEYS = Suppliers.memoize(() -> {
        var map = new HashMap<Identifier, String>();
        for (var tier : ToolMaterials.values()) {
            var tag = IApiService.INSTANCE.getTierTag(tier);
            if (tag == null) continue;
            map.put(tag.id(), tier.name().toLowerCase(Locale.ROOT));
        }
        return map;
    });

    public final ToolMaterial tier;
    public final int index;
    public final @Nullable TagKey<Block> tag;

    private final Supplier<String> tlKey;

    public ToolTier(ToolMaterial tier, int index) {
        this.tier = tier;
        this.index = index;
        this.tag = IApiService.INSTANCE.getTierTag(tier);

        this.tlKey = Suppliers.memoize(() -> {
            String key;

            if (tag != null) {
                var vanilla = VANILLA_TIER_TL_KEYS.get().get(tag.id());
                key = vanilla != null ? vanilla : tag.id().toTranslationKey();
            } else {
                key = String.valueOf(tier.getMiningLevel());
            }

            return Tl.Tooltip.Harvest.TIER + "." + key;
        });
    }

    public static Collection<ToolTier> all() {
        return TIERS.get().values();
    }

    @Nullable
    public static ToolTier get(ToolMaterial tier) {
        return TIERS.get().get(tier);
    }

    public String tlKey() {
        return tlKey.get();
    }

    public boolean isEqualTo(ToolTier other) {
        if (this == other) return true;
        if (this.tier == other.tier) return true;
        if (this.tag != null && other.tag != null) return this.tag.id().equals(other.tag.id());
        return false;
    }

    public boolean isBetterThanOrEqualTo(ToolTier other) {
        return isEqualTo(other) || this.index >= other.index;
    }

}
