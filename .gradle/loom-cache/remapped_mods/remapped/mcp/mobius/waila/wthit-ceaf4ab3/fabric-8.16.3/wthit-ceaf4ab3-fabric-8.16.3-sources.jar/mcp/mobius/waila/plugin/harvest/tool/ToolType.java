package mcp.mobius.waila.plugin.harvest.tool;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Predicate;
import java.util.function.Supplier;

import com.google.common.base.Suppliers;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import mcp.mobius.waila.api.IToolType;
import mcp.mobius.waila.buildconst.Tl;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ToolType implements IToolType, IToolType.Builder0, IToolType.Builder1, IToolType.Builder2, IToolType.Builder3 {

    private static final Map<Identifier, ToolType> MAP = new LinkedHashMap<>();

    public Identifier id;
    public ItemStack lowestTierStack;
    public Predicate<BlockState> blockPredicate;
    public Predicate<ItemStack> itemPredicate;
    public Text text;

    private final Supplier<Map<ToolTier, ItemStack>> icons = Suppliers.memoize(() -> {
        var tiers = ToolTier.all();
        var map = new Reference2ObjectOpenHashMap<ToolTier, ItemStack>();

        for (var item : Registries.ITEM) {
            var stack = item.getDefaultStack();
            if (itemPredicate.test(stack)) {
                for (var registeredTier : tiers) {
                    if (!map.containsKey(registeredTier) && item instanceof ToolItem tiered) {
                        var itemTier = ToolTier.get(tiered.getMaterial());
                        if (itemTier != null && itemTier.isEqualTo(registeredTier)) {
                            map.put(registeredTier, stack);
                        }
                    }
                }
            }
        }

        if (map.size() < tiers.size()) {
            for (var tier : tiers) {
                map.putIfAbsent(tier, lowestTierStack);
            }
        }

        return map;
    });

    public ItemStack getIcon(ToolTier tier) {
        if (tier == ToolTier.NONE) return lowestTierStack;
        else return icons.get().get(tier);
    }

    public void bind(Identifier id) {
        this.id = id;
        this.text = Text.translatable(Tl.Tooltip.Harvest.TOOL + "." + id.toTranslationKey());

        MAP.put(id, this);
    }

    public static Collection<ToolType> all() {
        return MAP.values();
    }

    @Override
    public Builder1 lowestTierStack(ItemStack stack) {
        lowestTierStack = stack;
        return this;
    }

    @Override
    public Builder1 lowestTierItem(ItemConvertible item) {
        lowestTierStack = new ItemStack(item);
        return this;
    }

    @Override
    public Builder2 blockPredicate(Predicate<BlockState> predicate) {
        blockPredicate = predicate;
        return this;
    }

    @Override
    public Builder2 blockTag(TagKey<Block> tag) {
        blockPredicate = state -> state.isIn(tag);
        return this;
    }

    @Override
    public Builder2 blockTag(Identifier tag) {
        return blockTag(TagKey.of(RegistryKeys.BLOCK, tag));
    }

    @Override
    public Builder3 itemPredicate(Predicate<ItemStack> predicate) {
        itemPredicate = predicate;
        return this;
    }

    @Override
    public Builder3 itemTag(TagKey<Item> tag) {
        itemPredicate = stack -> stack.isIn(tag);
        return this;
    }

    @Override
    public Builder3 itemTag(Identifier tag) {
        return itemTag(TagKey.of(RegistryKeys.ITEM, tag));
    }

    @Override
    public IToolType build() {
        return this;
    }

}
