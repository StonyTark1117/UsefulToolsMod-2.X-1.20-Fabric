package mcp.mobius.waila.plugin.vanilla.fluid;

import mcp.mobius.waila.api.data.FluidData;
import mcp.mobius.waila.api.data.FluidData.CauldronDescriptor;
import mcp.mobius.waila.api.data.FluidData.FluidDescription;
import mcp.mobius.waila.api.data.FluidData.FluidDescriptionContext;
import mcp.mobius.waila.api.data.FluidData.FluidDescriptor;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.text.Text;

public enum LavaDescriptor implements FluidDescriptor<FlowableFluid>, CauldronDescriptor {

    INSTANCE;

    private static final Text NAME = Text.translatable("block.minecraft.lava");

    @Override
    public void describeFluid(FluidDescriptionContext<FlowableFluid> ctx, FluidDescription desc) {
        desc.name(NAME)
            .sprite(MinecraftClient.getInstance().getBakedModelManager().getBlockModels().getModel(Blocks.LAVA.getDefaultState()).getParticleSprite());
    }

    @Override
    public FluidData getCauldronFluidData(BlockState state) {
        return FluidData.of(FluidData.Unit.MILLIBUCKETS, 1)
            .add(Fluids.LAVA, null, 1000, 1000);
    }

}
