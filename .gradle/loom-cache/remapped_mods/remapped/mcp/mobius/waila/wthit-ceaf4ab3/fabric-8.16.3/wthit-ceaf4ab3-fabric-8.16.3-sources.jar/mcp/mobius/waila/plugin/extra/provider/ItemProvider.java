package mcp.mobius.waila.plugin.extra.provider;

import F;
import I;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;
import mcp.mobius.waila.api.ICommonRegistrar;
import mcp.mobius.waila.api.IDataReader;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.ITooltipComponent;
import mcp.mobius.waila.api.component.ItemListComponent;
import mcp.mobius.waila.api.component.NamedItemListComponent;
import mcp.mobius.waila.api.data.ItemData;
import mcp.mobius.waila.api.data.ProgressData;
import mcp.mobius.waila.plugin.extra.data.ItemDataImpl;
import mcp.mobius.waila.plugin.extra.data.ProgressDataImpl;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public class ItemProvider extends DataProvider<ItemData, ItemDataImpl> {

    public static final ItemProvider INSTANCE = new ItemProvider();
    private static final NbtCompound EMPTY = new NbtCompound();

    private @Nullable ItemData lastData = null;
    private @Nullable ITooltipComponent lastItemsComponent = null;

    protected ItemProvider() {
        super(ItemData.ID, ItemData.class, ItemDataImpl.class, ItemDataImpl::new);
    }

    @Override
    protected void registerAdditions(ICommonRegistrar registrar, int priority) {
        registrar.syncedConfig(ItemData.CONFIG_SYNC_NBT, true, false);
        registrar.localConfig(ItemData.CONFIG_DISPLAY_MODE, ItemData.ItemDisplayMode.DYNAMIC);
        registrar.localConfig(ItemData.CONFIG_MAX_HEIGHT, 3);
        registrar.localConfig(ItemData.CONFIG_SORT_BY_COUNT, true);
        registrar.localConfig(ItemData.CONFIG_GRID_MODE_SCALE, 1f);
    }

    @Override
    protected void appendBody(ITooltip tooltip, IDataReader reader, IPluginConfig config, Identifier objectId) {
        var progress = (ProgressDataImpl) reader.get(ProgressData.class);
        if (progress == null || progress.ratio() == 0f) {
            super.appendBody(tooltip, reader, config, objectId);
        }
    }

    @Override
    protected void appendBody(ITooltip tooltip, ItemDataImpl data, IPluginConfig config, Identifier objectId) {
        if (data == lastData) {
            if (lastItemsComponent != null) tooltip.setLine(ItemData.ID, lastItemsComponent);
            return;
        }

        lastData = data;
        lastItemsComponent = null;

        Map<Object, ItemStack> merged = new LinkedHashMap<>();
        Map<Item, Set<NbtCompound>> unique = new HashMap<>();

        for (var stack : data.items()) {
            var item = stack.getItem();
            var count = stack.getCount();

            if (!data.syncNbt()) {
                if (unique.put(item, Set.of()) != null) {
                    merged.get(item).increment(count);
                } else {
                    merged.put(item, stack.copy());
                }
            } else {
                var nbt = stack.getNbt();
                if (nbt == null) nbt = EMPTY;

                if (unique.computeIfAbsent(item, i -> new HashSet<>()).add(nbt)) {
                    merged.put(new ItemWithNbt(item, nbt), stack.copy());
                } else {
                    merged.get(new ItemWithNbt(item, nbt)).increment(count);
                }
            }
        }

        if (merged.isEmpty()) return;

        var stream = merged.values().stream();
        if (config.getBoolean(ItemData.CONFIG_SORT_BY_COUNT)) {
            stream = stream.sorted(Comparator.comparingInt(ItemStack::getCount).reversed());
        }

        var list = stream.toList();
        var maxHeight = config.getInt(ItemData.CONFIG_MAX_HEIGHT);
        var scale = (float) config.getDouble(ItemData.CONFIG_GRID_MODE_SCALE);

        lastItemsComponent = switch (config.<ItemData.ItemDisplayMode>getEnum(ItemData.CONFIG_DISPLAY_MODE)) {
            case DYNAMIC -> list.size() <= maxHeight
                ? new NamedItemListComponent(list, maxHeight)
                : new ItemListComponent(list, maxHeight, scale);
            case GRID -> new ItemListComponent(list, maxHeight, scale);
            case LIST -> new NamedItemListComponent(list, maxHeight);
        };

        tooltip.setLine(ItemData.ID, lastItemsComponent);
    }

    private record ItemWithNbt(Item item, NbtCompound tag) {

    }

}
