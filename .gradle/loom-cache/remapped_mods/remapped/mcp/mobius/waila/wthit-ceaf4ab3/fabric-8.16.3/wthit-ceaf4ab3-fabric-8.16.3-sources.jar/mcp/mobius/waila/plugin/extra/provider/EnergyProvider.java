package mcp.mobius.waila.plugin.extra.provider;

import D;
import F;
import I;
import mcp.mobius.waila.api.ICommonRegistrar;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.WailaConstants;
import mcp.mobius.waila.api.WailaHelper;
import mcp.mobius.waila.api.component.BarComponent;
import mcp.mobius.waila.api.component.PairComponent;
import mcp.mobius.waila.api.component.WrappedComponent;
import mcp.mobius.waila.api.data.EnergyData;
import mcp.mobius.waila.plugin.extra.data.EnergyDataImpl;
import mcp.mobius.waila.plugin.extra.data.EnergyDataImpl.Description;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

public class EnergyProvider extends DataProvider<EnergyData, EnergyDataImpl> {

    public static final EnergyProvider INSTANCE = new EnergyProvider();

    private static final String INFINITE = "∞";

    private static final Identifier INFINITE_TAG_ID = new Identifier(WailaConstants.NAMESPACE, "extra/infinite_energy");
    private static final TagKey<Block> INFINITE_BLOCK_TAG = TagKey.of(RegistryKeys.BLOCK, INFINITE_TAG_ID);
    private static final TagKey<BlockEntityType<?>> INFINITE_BLOCK_ENTITY_TAG = TagKey.of(RegistryKeys.BLOCK_ENTITY_TYPE, INFINITE_TAG_ID);
    private static final TagKey<EntityType<?>> INFINITE_ENTITY_TAG = TagKey.of(RegistryKeys.ENTITY_TYPE, INFINITE_TAG_ID);

    private EnergyProvider() {
        super(EnergyData.ID, EnergyData.class, EnergyDataImpl.class, EnergyDataImpl::new);
    }

    @Override
    protected void registerAdditions(ICommonRegistrar registrar, int priority) {
        registrar.blockData(new InfiniteEnergyBlockProvider(), BlockEntity.class, 1);
        registrar.entityData(new InfiniteEnergyEntityProvider(), Entity.class, 1);
    }

    @Override
    protected void appendBody(ITooltip tooltip, EnergyDataImpl energy, IPluginConfig config, Identifier objectId) {
        var desc = EnergyDataImpl.Description.get(objectId.getNamespace());

        var stored = energy.stored();
        var capacity = energy.capacity();
        var ratio = Double.isInfinite(capacity) ? 1f : (float) (stored / capacity);

        var unit = desc.unit();
        var name = desc.name();
        var color = desc.color();

        String text;
        if (Double.isInfinite(stored)) text = INFINITE;
        else {
            text = WailaHelper.suffix((long) stored);
            if (Double.isFinite(capacity)) text += "/" + WailaHelper.suffix((long) capacity);
        }

        if (!unit.isEmpty()) text += " " + unit;

        tooltip.setLine(EnergyData.ID, new PairComponent(
            new WrappedComponent(name),
            new BarComponent(ratio, 0xFF000000 | color, text)));
    }

    private static class InfiniteEnergyBlockProvider implements IDataProvider<BlockEntity> {

        @Override
        public void appendData(IDataWriter data, IServerAccessor<BlockEntity> accessor, IPluginConfig config) {
            data.add(EnergyData.class, res -> {
                var target = accessor.getTarget();

                if (target.getCachedState().isIn(INFINITE_BLOCK_TAG)
                    || Registries.BLOCK_ENTITY_TYPE.getEntry(target.getType()).isIn(INFINITE_BLOCK_ENTITY_TAG)) {
                    res.add(EnergyData.INFINITE);
                }
            });
        }

    }

    private static class InfiniteEnergyEntityProvider implements IDataProvider<Entity> {

        @Override
        public void appendData(IDataWriter data, IServerAccessor<Entity> accessor, IPluginConfig config) {
            data.add(EnergyData.class, res -> {
                if (accessor.getTarget().getType().isIn(INFINITE_ENTITY_TAG)) {
                    res.add(EnergyData.INFINITE);
                }
            });
        }

    }

}
