package mcp.mobius.waila.gui.screen;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;

import com.google.common.collect.Lists;
import com.google.gson.Gson;
import mcp.mobius.waila.Waila;
import mcp.mobius.waila.buildconst.Tl;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ElementListWidget;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.NotNull;

import static mcp.mobius.waila.util.DisplayUtil.createButton;

import I;

public class CreditsScreen extends YesIAmSureTheClientInstanceIsPresentByTheTimeIUseItScreen {

    private final Screen parent;

    protected CreditsScreen(Screen parent) {
        super(Text.translatable(Tl.Gui.CREDITS));

        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();

        try {
            var credits = new Gson().fromJson(client.getResourceManager().getResource(Waila.id("credits.json")).orElseThrow().getReader(), CreditMap.class);
            var listWidget = new ListWidget(client, width, height, 32, height - 32, client.textRenderer.fontHeight + 6);

            credits.forEach((key, category) -> {
                var children = listWidget.children();

                children.add(new CreditLine(1, List.of(Text.translatable(Tl.Gui.CREDITS + "." + key).formatted(Formatting.GRAY))));

                for (var chunk : Lists.partition(category.values.stream().map(Text::literal).toList(), category.width)) {
                    children.add(new CreditLine(category.width, chunk));
                }

                children.add(new CreditLine(1, List.of()));
            });

            listWidget.init();
            addDrawableChild(listWidget);
        } catch (IOException e) {
            e.printStackTrace();
        }

        addDrawableChild(createButton(width / 2 - 50, height - 25, 100, 20, ScreenTexts.DONE, w -> close()));
    }

    @Override
    public void render(@NotNull DrawContext ctx, int mouseX, int mouseY, float partialTicks) {
        renderBackground(ctx);
        super.render(ctx, mouseX, mouseY, partialTicks);
        ctx.drawCenteredTextWithShadow(textRenderer, title.getString(), width / 2, 12, 0xFFFFFF);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    private static class CreditMap extends LinkedHashMap<String, CreditCategory> {

    }

    private static class CreditCategory {

        int width = 0;
        List<String> values = List.of();

    }

    private static class ListWidget extends ElementListWidget<CreditLine> {

        private ListWidget(MinecraftClient client, int width, int height, int top, int bottom, int itemHeight) {
            super(client, width, height, top, bottom, itemHeight);
        }

        private void init() {
            setRenderBackground(false);

            var totalHeight = (children().size() - 1) * itemHeight;
            if (totalHeight < height) {
                setRenderHeader(true, (height - totalHeight) / 2 - top);
            }
        }

        @Override
        public int getRowWidth() {
            return Math.min(width - 20, 360);
        }

        @Override
        protected int getScrollbarPositionX() {
            return client.getWindow().getScaledWidth() - 5;
        }

    }

    private class CreditLine extends ElementListWidget.Entry<CreditLine> {

        private final int column;
        private final List<MutableText> components;

        private CreditLine(int column, List<MutableText> components) {
            this.column = column;
            this.components = components;
        }

        @Override
        public @NotNull List<? extends Selectable> selectableChildren() {
            return Collections.emptyList();
        }

        @Override
        public @NotNull List<? extends Element> children() {
            return Collections.emptyList();
        }

        @Override
        public void render(@NotNull DrawContext ctx, int index, int rowTop, int rowLeft, int width, int height, int mouseX, int mouseY, boolean hovered, float deltaTime) {
            if (components.isEmpty()) return;

            var columnWidth = width / column;

            for (var i = 0; i < components.size(); i++) {
                var component = components.get(i);
                ctx.drawCenteredTextWithShadow(client.textRenderer, component, rowLeft + (columnWidth * i) + (columnWidth / 2), rowTop + 3, 0xFFFFFF);
            }
        }

    }

}
