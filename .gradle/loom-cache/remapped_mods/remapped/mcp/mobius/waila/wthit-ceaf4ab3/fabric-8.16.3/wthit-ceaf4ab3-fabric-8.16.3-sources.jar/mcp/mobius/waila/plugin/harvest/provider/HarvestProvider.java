package mcp.mobius.waila.plugin.harvest.provider;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import Z;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.ICommonAccessor;
import mcp.mobius.waila.api.IEventListener;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.ITooltip;
import mcp.mobius.waila.api.ITooltipLine;
import mcp.mobius.waila.api.component.GrowingComponent;
import mcp.mobius.waila.api.component.PairComponent;
import mcp.mobius.waila.buildconst.Tl;
import mcp.mobius.waila.plugin.harvest.component.ToolComponent;
import mcp.mobius.waila.plugin.harvest.config.HarvestDisplayMode;
import mcp.mobius.waila.plugin.harvest.config.Options;
import mcp.mobius.waila.plugin.harvest.tool.ToolTier;
import mcp.mobius.waila.plugin.harvest.tool.ToolType;
import net.minecraft.block.BlockState;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolItem;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.NotNull;

public enum HarvestProvider implements IBlockComponentProvider, IEventListener {

    INSTANCE;

    private static final Identifier CLASSIC_HARVESTABLE = Options.rl("classic.harvestable");
    private static final Identifier CLASSIC_EFFECTIVE_TOOL = Options.rl("classic.effective_tool");
    private static final Identifier CLASSIC_LEVEL = Options.rl("classic.level");

    private static final Identifier CLASSIC_MINIMAL = Options.rl("classic.minimal");

    private static final ToolType UNBREAKABLE = new ToolType();

    public final Map<BlockState, List<ToolType>> toolsCache = new Reference2ObjectOpenHashMap<>();
    public final Map<BlockState, ToolTier> tierCache = new Reference2ObjectOpenHashMap<>();

    private int updateId = 0;
    private BlockState state;

    private final List<ToolComponent> toolComponents = new ArrayList<>();
    private boolean renderComponents = false;

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        if (!config.getBoolean(Options.ENABLED)) return;
        if (accessor.getPlayer().isCreative() && !config.getBoolean(Options.CREATIVE)) return;

        updateId = accessor.getUpdateId();
        state = accessor.getBlockState();

        var unbreakable = state.getHardness(accessor.getWorld(), accessor.getPosition()) < 0;

        var tools = toolsCache.get(state);
        if (tools == null) {
            tools = new ArrayList<>();

            if (unbreakable) {
                tools.add(UNBREAKABLE);
            } else {
                for (var tool : ToolType.all()) {
                    if (tool.blockPredicate.test(state)) {
                        tools.add(tool);
                    }
                }
                if (tools.isEmpty()) tools = List.of();
            }
            toolsCache.put(state, tools);
        }

        var highestTier = tierCache.get(state);
        if (highestTier == null) {
            highestTier = ToolTier.NONE;
            for (var tier : ToolTier.all()) {
                if (tier.tag != null && state.isIn(tier.tag)) {
                    highestTier = tier;
                }
            }
            tierCache.put(state, highestTier);
        }

        HarvestDisplayMode displayMode = config.getEnum(Options.DISPLAY_MODE);
        if (displayMode == HarvestDisplayMode.MODERN) return;

        var heldStack = accessor.getPlayer().getInventory().getMainHandStack();

        if (displayMode == HarvestDisplayMode.CLASSIC) {
            tooltip.setLine(CLASSIC_HARVESTABLE, Text.empty()
                .append(getHarvestableSymbol(accessor, unbreakable))
                .append(" ")
                .append(Text.translatable(Tl.Tooltip.Harvest.HARVESTABLE)));

            if (!tools.isEmpty() && !unbreakable) tooltip.setLine(CLASSIC_EFFECTIVE_TOOL, new PairComponent(
                Text.translatable(Tl.Tooltip.Harvest.EFFECTIVE_TOOL),
                getToolText(tools, heldStack)));

            if (highestTier != ToolTier.NONE) tooltip.setLine(CLASSIC_LEVEL, new PairComponent(
                Text.translatable(Tl.Tooltip.Harvest.LEVEL),
                getTierText(highestTier, heldStack)));
        } else if (displayMode == HarvestDisplayMode.CLASSIC_MINIMAL) {
            var text = Text.empty();
            text.append(getHarvestableSymbol(accessor, unbreakable));

            if (!tools.isEmpty() && !unbreakable) {
                text.append(" | ").append(getToolText(tools, heldStack));
                if (highestTier != ToolTier.NONE) {
                    text.append(" | ");
                }
            }

            if (highestTier != ToolTier.NONE) {
                text.append(getTierText(highestTier, heldStack));
            }

            tooltip.setLine(CLASSIC_MINIMAL, text);
        }
    }

    @Override
    public void onHandleTooltip(ITooltip tooltip, ICommonAccessor accessor, IPluginConfig config) {
        renderComponents = false;

        if (!config.getBoolean(Options.ENABLED)) return;

        HarvestDisplayMode displayMode = config.getEnum(Options.DISPLAY_MODE);
        if (displayMode != HarvestDisplayMode.MODERN) return;

        if (updateId != accessor.getUpdateId()) return;

        var tools = toolsCache.get(state);
        var highestTier = tierCache.get(state);
        if (tools == null || highestTier == null || tools.isEmpty()) return;

        var heldStack = accessor.getPlayer().getInventory().getMainHandStack();

        var line = tooltip.getLine(tooltip.getLineCount() - 1);
        line.with(GrowingComponent.INSTANCE);

        toolComponents.clear();
        for (var tool : tools) {
            ToolComponent component;
            if (tool == UNBREAKABLE) {
                component = new ToolComponent(null, false);
            } else {
                var icon = tool.getIcon(highestTier);
                Boolean matches = null;
                if (state.isToolRequired()) {
                    matches = tool.itemPredicate.test(heldStack);
                    if (highestTier != ToolTier.NONE && heldStack.getItem() instanceof ToolItem tiered) {
                        var heldTier = ToolTier.get(tiered.getMaterial());
                        matches = matches && heldTier != null && heldTier.isBetterThanOrEqualTo(highestTier);
                    }
                }
                component = new ToolComponent(icon, matches);
            }
            line.with(component);
            toolComponents.add(component);
        }

        renderComponents = true;
    }

    @Override
    public void onAfterTooltipRender(DrawContext ctx, Rectangle rect, ICommonAccessor accessor, IPluginConfig config) {
        if (!renderComponents) return;

        for (var component : toolComponents) {
            component.actuallyRender(ctx, rect.y + rect.height - 13);
        }
    }

    @NotNull
    @SuppressWarnings("UnnecessaryUnicodeEscape")
    private MutableText getHarvestableSymbol(IBlockAccessor accessor, boolean unbreakable) {
        return unbreakable || !accessor.getPlayer().canHarvest(state)
            ? Text.literal("\u2718").formatted(Formatting.RED)
            : Text.literal("\u2714").formatted(Formatting.GREEN);
    }

    @NotNull
    private static MutableText getToolText(List<ToolType> tools, ItemStack heldStack) {
        var toolText = Text.empty();
        var toolIter = tools.iterator();
        while (toolIter.hasNext()) {
            var tool = toolIter.next();
            if (tool == UNBREAKABLE) continue;

            toolText.append(tool.text.copy().formatted(tool.itemPredicate.test(heldStack) ? Formatting.GREEN : Formatting.RED));
            if (toolIter.hasNext()) toolText.append(", ");
        }
        return toolText;
    }

    @NotNull
    private static MutableText getTierText(ToolTier highestTier, ItemStack heldStack) {
        var tierText = I18n.hasTranslation(highestTier.tlKey())
            ? Text.translatable(highestTier.tlKey())
            : Text.literal(String.valueOf(highestTier.index));
        if (heldStack.getItem() instanceof ToolItem tiered) {
            var heldTier = ToolTier.get(tiered.getMaterial());
            tierText.formatted(heldTier != null && heldTier.isBetterThanOrEqualTo(highestTier) ? Formatting.GREEN : Formatting.RED);
        } else {
            tierText.formatted(Formatting.RED);
        }
        return tierText;
    }

}
