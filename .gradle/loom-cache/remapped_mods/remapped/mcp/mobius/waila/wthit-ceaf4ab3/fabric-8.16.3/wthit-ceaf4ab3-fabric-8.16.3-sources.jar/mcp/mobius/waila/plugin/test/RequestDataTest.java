package mcp.mobius.waila.plugin.test;

import com.google.common.base.Preconditions;
import mcp.mobius.waila.api.IBlockAccessor;
import mcp.mobius.waila.api.IBlockComponentProvider;
import mcp.mobius.waila.api.IData;
import mcp.mobius.waila.api.IDataProvider;
import mcp.mobius.waila.api.IDataWriter;
import mcp.mobius.waila.api.IPluginConfig;
import mcp.mobius.waila.api.IServerAccessor;
import mcp.mobius.waila.api.ITooltip;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public enum RequestDataTest implements IBlockComponentProvider, IDataProvider<BarrelBlockEntity> {

    INSTANCE;

    public static final Identifier ENABLED = new Identifier("test:data.ctx");
    public static final Identifier RAW = new Identifier("test:data.ctx.raw");
    public static final Identifier TYPED = new Identifier("test:data.ctx.typed");

    public static final Identifier CTX = new Identifier("test:data.ctx.ctx");
    public static final Identifier DATA = new Identifier("test:data.ctx.data");

    @Override
    public void appendDataContext(IDataWriter ctx, IBlockAccessor accessor, IPluginConfig config) {
        Preconditions.checkState(accessor.getData().raw().isEmpty());
        Preconditions.checkState(accessor.getData().get(Data.class) == null);

        if (!config.getBoolean(ENABLED)) return;

        if (config.getBoolean(RAW)) ctx.raw().putString("kyk", "NIHAHAHAHA");
        if (config.getBoolean(TYPED)) ctx.addImmediate(new Ctx("gomen yuuka"));
    }

    @Override
    public void appendData(IDataWriter data, IServerAccessor<BarrelBlockEntity> accessor, IPluginConfig config) {
        var raw = accessor.getContext().raw();
        if (raw.contains("kyk")) {
            data.raw().putString("kyk", raw.getString("kyk"));
        }

        data.add(Data.class, res -> {
            var ctx = accessor.getContext().get(Ctx.class);
            if (ctx == null) return;

            res.add(new Data(ctx.msg));
        });
    }

    @Override
    public void appendBody(ITooltip tooltip, IBlockAccessor accessor, IPluginConfig config) {
        var raw = accessor.getData().raw();
        if (raw.contains("kyk")) {
            tooltip.addLine(Text.literal(raw.getString("kyk")));
        }

        var data = accessor.getData().get(Data.class);
        if (data != null) {
            tooltip.addLine(Text.literal(data.msg));
        }
    }

    public record Ctx(
        String msg
    ) implements IData {

        public Ctx(PacketByteBuf buf) {
            this(buf.readString());
        }

        @Override
        public void write(PacketByteBuf buf) {
            buf.writeString(msg);
        }

    }

    public record Data(
        String msg
    ) implements IData {

        public Data(PacketByteBuf buf) {
            this(buf.readString());
        }

        @Override
        public void write(PacketByteBuf buf) {
            buf.writeString(msg);
        }

    }


}
