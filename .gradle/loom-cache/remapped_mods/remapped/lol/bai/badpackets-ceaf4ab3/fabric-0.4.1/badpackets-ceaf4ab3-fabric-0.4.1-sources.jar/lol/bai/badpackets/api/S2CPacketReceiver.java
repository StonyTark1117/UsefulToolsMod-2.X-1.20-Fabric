package lol.bai.badpackets.api;

import lol.bai.badpackets.impl.marker.ApiSide;
import lol.bai.badpackets.impl.registry.ChannelRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

@ApiSide.ClientOnly
@FunctionalInterface
public interface S2CPacketReceiver {

    @ApiSide.ClientOnly
    static void register(Identifier id, S2CPacketReceiver receiver) {
        ChannelRegistry.S2C.register(id, receiver);
    }

    void receive(MinecraftClient client, ClientPlayNetworkHandler handler, PacketByteBuf buf, PacketSender responseSender);

}
