package lol.bai.badpackets.impl.handler;

import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

import io.netty.buffer.Unpooled;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import lol.bai.badpackets.api.PacketSender;
import lol.bai.badpackets.impl.Constants;
import lol.bai.badpackets.impl.registry.ChannelRegistry;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.packet.Packet;
import net.minecraft.util.Identifier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

public abstract class AbstractPacketHandler<T> implements PacketSender {

    protected final ChannelRegistry<T> registry;
    protected final Logger logger;

    private final BiFunction<Identifier, PacketByteBuf, Packet<?>> packetFactory;
    private final Set<Identifier> sendableChannels = new HashSet<>();

    private final ClientConnection connection;

    private boolean initialized = false;

    protected AbstractPacketHandler(String desc, ChannelRegistry<T> registry, BiFunction<Identifier, PacketByteBuf, Packet<?>> packetFactory, ClientConnection connection) {
        this.logger = LogManager.getLogger(desc);
        this.registry = registry;
        this.packetFactory = packetFactory;
        this.connection = connection;

        registry.addHandler(this);
    }

    private void receiveChannelSyncPacket(PacketByteBuf buf) {
        switch (buf.readByte()) {
            case Constants.CHANNEL_SYNC_SINGLE -> sendableChannels.add(buf.readIdentifier());
            case Constants.CHANNEL_SYNC_INITIAL -> {
                int groupSize = buf.readVarInt();
                for (int i = 0; i < groupSize; i++) {
                    String namespace = buf.readString();

                    int pathSize = buf.readVarInt();
                    for (int j = 0; j < pathSize; j++) {
                        String path = buf.readString();
                        sendableChannels.add(new Identifier(namespace, path));
                    }
                }
                onInitialChannelSyncPacketReceived();
            }
        }
    }

    public boolean receive(Identifier id, PacketByteBuf buf) {
        if (id.equals(Constants.CHANNEL_SYNC)) {
            receiveChannelSyncPacket(new PacketByteBuf(buf.slice()));
            return true;
        }

        if (registry.channels.containsKey(id)) {
            try {
                receive(registry.channels.get(id), new PacketByteBuf(buf.slice()));
            } catch (Throwable t) {
                logger.error("Error when receiving packet {}", id, t);
                throw t;
            }
            return true;
        }

        return false;
    }

    protected abstract void onInitialChannelSyncPacketReceived();

    protected abstract void receive(T receiver, PacketByteBuf buf);

    public void sendInitialChannelSyncPacket() {
        if (!initialized) {
            initialized = true;
            sendVanillaChannelRegisterPacket(Set.of(Constants.CHANNEL_SYNC));

            PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
            buf.writeByte(Constants.CHANNEL_SYNC_INITIAL);

            Map<String, List<Identifier>> group = registry.channels.keySet().stream().collect(Collectors.groupingBy(Identifier::getNamespace));
            buf.writeVarInt(group.size());

            for (Map.Entry<String, List<Identifier>> entry : group.entrySet()) {
                buf.writeString(entry.getKey());
                buf.writeVarInt(entry.getValue().size());

                for (Identifier value : entry.getValue()) {
                    buf.writeString(value.getPath());
                }
            }

            send(Constants.CHANNEL_SYNC, buf);
            sendVanillaChannelRegisterPacket(registry.channels.keySet());
        }
    }

    public void onRegister(Identifier id) {
        PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
        buf.writeByte(Constants.CHANNEL_SYNC_SINGLE);
        buf.writeIdentifier(id);
        send(Constants.CHANNEL_SYNC, buf);
        sendVanillaChannelRegisterPacket(Set.of(id));
    }

    public void onDisconnect() {
        registry.removeHandler(this);
    }

    private void sendVanillaChannelRegisterPacket(Set<Identifier> channels) {
        if (!channels.isEmpty()) {
            PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
            boolean first = true;
            for (Identifier channel : channels) {
                if (first) {
                    first = false;
                } else {
                    buf.writeByte(0);
                }
                buf.writeBytes(channel.toString().getBytes(StandardCharsets.US_ASCII));
            }
            send(Constants.MC_REGISTER_CHANNEL, buf);
        }
    }

    @Override
    public void send(Identifier id, PacketByteBuf buf, @Nullable PacketCallbacks callback) {
        connection.send(packetFactory.apply(id, buf), callback);
    }

    @Override
    public void send(Identifier id, PacketByteBuf buf, @Nullable GenericFutureListener<? extends Future<? super Void>> callback) {
        send(id, buf, callback == null ? null : new Listener(callback));
    }

    @Override
    public boolean canSend(Identifier id) {
        return sendableChannels.contains(id);
    }

    public static class Listener implements PacketCallbacks {

        public final GenericFutureListener<? extends Future<? super Void>> delegate;

        public Listener(GenericFutureListener<? extends Future<? super Void>> delegate) {
            this.delegate = delegate;
        }

    }

}
