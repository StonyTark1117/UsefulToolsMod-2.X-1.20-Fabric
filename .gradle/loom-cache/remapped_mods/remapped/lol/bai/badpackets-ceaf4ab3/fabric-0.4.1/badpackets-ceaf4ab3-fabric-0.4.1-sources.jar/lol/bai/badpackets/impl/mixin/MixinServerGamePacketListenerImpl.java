package lol.bai.badpackets.impl.mixin;

import lol.bai.badpackets.impl.handler.ServerPacketHandler;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.c2s.play.CustomPayloadC2SPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayNetworkHandler.class)
public class MixinServerGamePacketListenerImpl implements ServerPacketHandler.Holder {

    @Shadow
    @Final
    private MinecraftServer server;

    @Unique
    private ServerPacketHandler badpacket_packetHandler;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void badpackets_createServerPacketHandler(MinecraftServer minecraftServer, ClientConnection connection, ServerPlayerEntity serverPlayer, CallbackInfo ci) {
        badpacket_packetHandler = new ServerPacketHandler(minecraftServer, (ServerPlayNetworkHandler) (Object) this, connection);
    }

    @Inject(method = "onDisconnect", at = @At("HEAD"))
    private void badpackets_removeServerPacketHandler(Text reason, CallbackInfo ci) {
        badpacket_packetHandler.onDisconnect();
    }

    @Inject(method = "handleCustomPayload", at = @At("HEAD"), cancellable = true)
    private void badpackets_handleCustomPayload(CustomPayloadC2SPacket packet, CallbackInfo ci) {
        if (!server.isOnThread() && badpacket_packetHandler.receive(packet.getChannel(), packet.getData())) {
            ci.cancel();
        }
    }

    @Override
    public ServerPacketHandler badpackets_getHandler() {
        return badpacket_packetHandler;
    }


}

