package lol.bai.badpackets.impl;

import net.minecraft.util.Identifier;

public class Constants {

    public static final String MOD_ID = "badpackets";
    public static final Identifier CHANNEL_SYNC = new Identifier(MOD_ID, "channel_sync");
    public static final Identifier MC_REGISTER_CHANNEL = new Identifier("minecraft:register");
    public static final Identifier MC_UNREGISTER_CHANNEL = new Identifier("minecraft:unregister");
    public static final byte CHANNEL_SYNC_SINGLE = 0;
    public static final byte CHANNEL_SYNC_INITIAL = 1;

    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }

}
