package lol.bai.badpackets.impl.handler;

import lol.bai.badpackets.api.S2CPacketReceiver;
import lol.bai.badpackets.api.event.PacketSenderReadyCallback;
import lol.bai.badpackets.impl.registry.CallbackRegistry;
import lol.bai.badpackets.impl.registry.ChannelRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.c2s.play.CustomPayloadC2SPacket;

public class ClientPacketHandler extends AbstractPacketHandler<S2CPacketReceiver> {

    private final MinecraftClient client;
    private final ClientPlayNetworkHandler listener;

    public ClientPacketHandler(MinecraftClient client, ClientPlayNetworkHandler listener) {
        super("ClientPlayPacketHandler", ChannelRegistry.S2C, CustomPayloadC2SPacket::new, listener.getConnection());

        this.client = client;
        this.listener = listener;
    }

    public static ClientPacketHandler get() {
        ClientPlayNetworkHandler listener = MinecraftClient.getInstance().getNetworkHandler();
        if (listener == null) {
            throw new IllegalStateException("Cannot get c2s sender when not in game!");
        }

        return ((ClientPacketHandler.Holder) listener).badpackets_getHandler();
    }

    @Override
    protected void onInitialChannelSyncPacketReceived() {
        for (PacketSenderReadyCallback.Client callback : CallbackRegistry.CLIENT_PLAYER_JOIN) {
            callback.onJoin(listener, this, MinecraftClient.getInstance());
        }
    }

    @Override
    protected void receive(S2CPacketReceiver receiver, PacketByteBuf buf) {
        receiver.receive(client, listener, buf, this);
    }

    public interface Holder {

        ClientPacketHandler badpackets_getHandler();

    }

}
