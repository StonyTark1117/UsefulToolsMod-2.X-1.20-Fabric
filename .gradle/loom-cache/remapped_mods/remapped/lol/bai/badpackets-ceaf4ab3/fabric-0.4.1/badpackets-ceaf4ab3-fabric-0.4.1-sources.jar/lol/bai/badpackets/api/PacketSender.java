package lol.bai.badpackets.api;

import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import lol.bai.badpackets.api.event.PacketSenderReadyCallback;
import lol.bai.badpackets.impl.handler.ClientPacketHandler;
import lol.bai.badpackets.impl.handler.ServerPacketHandler;
import lol.bai.badpackets.impl.marker.ApiSide;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

@ApiStatus.NonExtendable
public interface PacketSender {

    /**
     * Returns client-to-server packet sender.
     * <p>
     * <b>Only available when on game.</b>
     *
     * @see PacketSenderReadyCallback#registerClient(PacketSenderReadyCallback.Client)
     */
    @ApiSide.ClientOnly
    static PacketSender c2s() {
        return ClientPacketHandler.get();
    }

    /**
     * Returns a server-to-client packet sender.
     *
     * @param player the player that we want to send packets to.
     *
     * @see PacketSenderReadyCallback#registerServer(PacketSenderReadyCallback.Server)
     */
    @ApiSide.ServerOnly
    static PacketSender s2c(ServerPlayerEntity player) {
        return ServerPacketHandler.get(player);
    }

    /**
     * Returns whether the target can receive a packet with the specified id.
     * <p>
     * <b>Note:</b> Only works for Bad Packets channels.
     */
    boolean canSend(Identifier id);

    /**
     * Send a packet to the target.
     */
    default void send(Identifier id, PacketByteBuf buf) {
        send(id, buf, (PacketCallbacks) null);
    }

    /**
     * Send a packet to the target.
     *
     * @param callback a callback in which will be called after the packet sent to the target.
     */
    void send(Identifier id, PacketByteBuf buf, @Nullable PacketCallbacks callback);

    /**
     * Send a packet to the target.
     *
     * @param callback a callback in which will be called after the packet sent to the target.
     */
    @Deprecated
    void send(Identifier id, PacketByteBuf buf, @Nullable GenericFutureListener<? extends Future<? super Void>> callback);

}
