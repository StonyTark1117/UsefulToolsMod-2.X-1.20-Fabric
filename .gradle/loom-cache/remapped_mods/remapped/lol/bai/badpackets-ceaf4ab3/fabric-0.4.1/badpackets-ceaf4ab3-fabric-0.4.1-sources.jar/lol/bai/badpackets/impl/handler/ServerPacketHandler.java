package lol.bai.badpackets.impl.handler;

import lol.bai.badpackets.api.C2SPacketReceiver;
import lol.bai.badpackets.api.event.PacketSenderReadyCallback;
import lol.bai.badpackets.impl.registry.CallbackRegistry;
import lol.bai.badpackets.impl.registry.ChannelRegistry;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.s2c.play.CustomPayloadS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;

public class ServerPacketHandler extends AbstractPacketHandler<C2SPacketReceiver> {

    private final MinecraftServer server;
    private final ServerPlayNetworkHandler handler;

    public ServerPacketHandler(MinecraftServer server, ServerPlayNetworkHandler handler, ClientConnection connection) {
        super("ServerPlayPacketHandler for " + handler.getPlayer().getEntityName(), ChannelRegistry.C2S, CustomPayloadS2CPacket::new, connection);
        this.server = server;
        this.handler = handler;
    }

    public static ServerPacketHandler get(ServerPlayerEntity player) {
        return ((ServerPacketHandler.Holder) player.networkHandler).badpackets_getHandler();
    }

    @Override
    protected void onInitialChannelSyncPacketReceived() {
        for (PacketSenderReadyCallback.Server callback : CallbackRegistry.SERVER_PLAYER_JOIN) {
            callback.onJoin(handler, this, server);
        }
    }

    @Override
    protected void receive(C2SPacketReceiver receiver, PacketByteBuf buf) {
        receiver.receive(server, handler.getPlayer(), handler, buf, this);
    }

    public interface Holder {

        ServerPacketHandler badpackets_getHandler();

    }

}
