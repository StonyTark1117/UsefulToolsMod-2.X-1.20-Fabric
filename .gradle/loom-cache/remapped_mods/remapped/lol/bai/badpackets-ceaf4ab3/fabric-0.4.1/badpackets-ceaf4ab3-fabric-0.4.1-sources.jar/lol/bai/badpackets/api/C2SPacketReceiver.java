package lol.bai.badpackets.api;

import lol.bai.badpackets.impl.marker.ApiSide;
import lol.bai.badpackets.impl.registry.ChannelRegistry;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

@ApiSide.ServerOnly
@FunctionalInterface
public interface C2SPacketReceiver {

    static void register(Identifier id, C2SPacketReceiver receiver) {
        ChannelRegistry.C2S.register(id, receiver);
    }

    void receive(MinecraftServer server, ServerPlayerEntity player, ServerPlayNetworkHandler handler, PacketByteBuf buf, PacketSender responseSender);

}
